(function(){ try {var elementStyle = document.createElement('style'); elementStyle.appendChild(document.createTextNode(".d-slider.svelte-qzeq9z.svelte-qzeq9z{position:relative}.d-slider.svelte-qzeq9z .d-slider__runway.svelte-qzeq9z{width:100%;background-color:#333;position:relative;cursor:pointer;vertical-align:middle}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__cursor.svelte-qzeq9z,.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__preload.svelte-qzeq9z,.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z{position:absolute;top:0;left:0;height:100%}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__cursor.svelte-qzeq9z{display:none;z-index:1;width:1px;background:#fff;pointer-events:none}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__cursor .d-slider__tips.svelte-qzeq9z{pointer-events:none;color:#fff;position:absolute;white-space:nowrap;z-index:2;bottom:14px;left:50%;padding:4px;box-sizing:border-box;display:block;font-size:12px;background:rgba(0,0,0,.6);border-radius:3px;transform:translate(-50%)}.d-slider.svelte-qzeq9z .d-slider__runway:hover .d-slider__cursor.svelte-qzeq9z{display:block}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__preload.svelte-qzeq9z{background-color:#717171}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z{background:linear-gradient(to right,var(--primary-color) 0%,var(--primary-color-end) 80%,var(--primary-color-end) 100%)}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z:before{display:block;content:\"\";position:absolute;right:-6px;top:50%;width:5px;height:5px;transition:.2s;transform:translateY(-50%) scale(1);border-radius:50%;background:#fff;border:5px solid var(--primary-color)}.d-slider.is-vertical.svelte-qzeq9z.svelte-qzeq9z{height:100px;display:inline-block}.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway.svelte-qzeq9z{position:relative;height:100%;margin:0 6px}.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__preload.svelte-qzeq9z,.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z,.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__cursor.svelte-qzeq9z{bottom:0;top:auto;width:100%}.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__cursor.svelte-qzeq9z{height:1px}.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z:before{top:-6px;left:50%;width:5px;height:5px;transform:translate(-50%) scale(1)}.d-progress-bar.svelte-qzeq9z.svelte-qzeq9z{position:absolute;left:0;right:0;bottom:0;width:100%;transition:height .1s;height:3px;z-index:1}.d-progress-bar.svelte-qzeq9z .d-slider__runway.svelte-qzeq9z{transition:height .1s;height:100%!important}.d-progress-bar.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z:before{transform:translateY(-50%) scale(0)}.d-progress-bar.svelte-qzeq9z.svelte-qzeq9z:hover{height:100%}.d-progress-bar.svelte-qzeq9z:hover .d-slider__bar.svelte-qzeq9z:before{transform:translateY(-50%) scale(1)!important}.d-player-filter-panel-item.svelte-qzeq9z .d-slider__runway.svelte-qzeq9z{background-color:#999}.d-player-filter-panel-item.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z:before{width:5px;height:5px}.filter-panel-slider.svelte-qzeq9z.svelte-qzeq9z{width:100%}.d-switch.svelte-31e6zs.svelte-31e6zs{position:relative;height:18px;transition:background .2s;background:#757575;border-radius:10px;display:inline-flex;align-items:center;vertical-align:middle}.d-switch.svelte-31e6zs .d-switch__input.svelte-31e6zs{position:relative;z-index:1;margin:0;width:100%;height:100%;opacity:0}.d-switch.svelte-31e6zs .d-switch_action.svelte-31e6zs{position:absolute;transition:.2s;left:2px;top:2px;z-index:0;height:5px;width:5px;background:#fff;border-radius:50%}.d-switch.is-checked.svelte-31e6zs.svelte-31e6zs{background-color:var(--primary-color)}.d-switch.is-checked.svelte-31e6zs .d-switch_action.svelte-31e6zs{left:100%;background:#fff;margin-left:-18px}.d-icon.svelte-6alrox{display:inline-block;cursor:pointer;overflow:hidden}.icon-play.svelte-6alrox{margin-left:5px}div.svelte-1sesy3u.svelte-1sesy3u,span.svelte-1sesy3u.svelte-1sesy3u,h5.svelte-1sesy3u.svelte-1sesy3u,i.svelte-1sesy3u.svelte-1sesy3u,ul.svelte-1sesy3u.svelte-1sesy3u,li.svelte-1sesy3u.svelte-1sesy3u{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}ul.svelte-1sesy3u.svelte-1sesy3u{list-style:none}@keyframes svelte-1sesy3u-rotating{to{-webkit-transform:rotate(360deg)}}.d-player-contextmenu.svelte-1sesy3u.svelte-1sesy3u,.d-player-dialog.svelte-1sesy3u.svelte-1sesy3u{position:absolute;left:0;top:0;bottom:50px;width:100%;z-index:5}.d-player-contextmenu.svelte-1sesy3u .d-player-copyText.svelte-1sesy3u{opacity:0}.d-player-contextmenu.svelte-1sesy3u .d-player-contextmenu-body.svelte-1sesy3u{position:absolute;border-radius:5px;font-size:12px;background:rgba(0,0,0,.8);color:#efefef;text-align:left;min-width:130px;box-sizing:border-box;padding:5px 0}.d-player-contextmenu.svelte-1sesy3u .d-player-contextmenu-body li.svelte-1sesy3u{padding:8px 20px;margin:0;cursor:pointer;transition:.2s}.d-player-contextmenu.svelte-1sesy3u .d-player-contextmenu-body li.svelte-1sesy3u:hover{background-color:#ffffff1a}.d-player-dialog.svelte-1sesy3u.svelte-1sesy3u{display:flex;justify-content:center;align-items:center}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body.svelte-1sesy3u{background-color:#212121e6;border-radius:5px;color:#fff;min-width:200px;padding:0 0 10px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-dialog-title.svelte-1sesy3u{text-align:center;position:relative;font-size:14px;font-weight:400;margin:0 0 10px;padding:12px 0;border-bottom:1px solid rgba(255,255,255,.15)}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-dialog-title .icon-close.svelte-1sesy3u{position:absolute;right:0px;top:0px;width:40px;height:40px;line-height:40px;text-align:center;cursor:pointer}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-hotkey-panel.svelte-1sesy3u{font-size:12px;color:#eee;padding-right:40px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-hotkey-panel .d-player-hotkey-panel-item.svelte-1sesy3u{line-height:26px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-hotkey-panel .d-player-hotkey-panel-item span.svelte-1sesy3u{text-align:center;display:inline-block;width:120px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-hotkey-panel .d-player-hotkey-panel-item span.svelte-1sesy3u:nth-child(2){color:#999;width:160px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel.svelte-1sesy3u{width:320px;padding:0 20px;text-align:center}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel .d-player-filter-reset.svelte-1sesy3u{text-align:center;cursor:pointer;margin-top:10px;padding:3px 20px;display:inline-block;border-radius:2px;font-size:12px;background:rgba(133,133,133,.5)}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel .d-player-filter-reset.svelte-1sesy3u:hover{background:rgba(255,255,255,.3)}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel .d-player-filter-panel-item.svelte-1sesy3u{height:32px;display:flex;align-items:center}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel .d-player-filter-panel-item span.svelte-1sesy3u{font-size:12px;display:block;width:80px;text-align:center}@font-face{font-family:iconfont;src:url(data:font/woff2;base64,d09GMgABAAAAAAf8AAsAAAAAD4AAAAesAAEAAAAAAAAAAAAAAAAAAAAAAAAAAAAAHFQGYACENAqQFI0gATYCJAMwCxoABCAFhGcHgRgbMA2jopRwhpH9xYEN7tEpwmIWXYlFbb0abbZI79LiOw8i759JE179cG04wTl4/lv73fdGdx1R7dBpePptO1IS0ROpEcucKY175977I5ZAEaYoB0Q+Sa9AyUuuH/ScmnFzExLIzqhN/27WA9pOSYBUSFMxoWIeqfuqJXeerBhQVrSma0bPHPxEe3/ryvP/O+8/vROmlEQSRRMb+GBOkyUgmdUv+7V8hmli/aG/EQqjplPxhHhyzZqoot6oROqNaqXSKgZrk2NVhFlY/ZvcBwGlU5v65uH5PUwdTjXMG8CGCvxoOVnCYeQmYnMKReR61X3j5QMHvfVHAO926uUnuiIo12AXut4HEbykIr8L6H/aqH1DN1cH6ytwwIDDgUnkzVf9Mi7j0GaVaYnWE2DczO1k+hWpS8cpyCzf5CG/v3tHvNa6IaYQ47zm7FpAEBVKVWcVleX4f16HsmrgftwVUiERBKQaQURqmOSxWwgowe5AqsY+hgAD9hkQCPIqAkW+QWCRBwQO+b0zfkj7zAJ2gT5gJrCcEZcy6q0k3pSWkWHj8nBmZvSUUTb8osN2s7NDvrdXy9Nj4OEpqIEIvRY3HgSKcZQwjtJS3DAytmYBP1FU9L3/95QyIMBkIg04lxMG42lHgjNnKzFOrpIelGoMuImUo5gYJWZmUln8gHHvebdwWjfAxMiUA08YhQPUsgelIOQoXHGTqgkpVLI6d55j9PHwK3FoAKBNZegLJupaYE4OgIPZDEU4VcoVnJw+yCoYJen8nooeZg8xh1dw1+lr7A1GPcBNDk+wU8z0R01PQJedZwEdOML6T/GY+RYOlQNVsVO4MJiynUNHad+DrMMYE6DECxPPp6YsmfmLfp2jszO+HSMX5vo5LbCgYXV9bicOrFDPI+TcNONAwuZOU5CInQB8k9z0KgEz9ZSDFCihUQLabhIWc9NrYIEIVIt5EDeskrA3qt9YDSPcdWDh2noLxHILj1c9ftyZVExBrBQf8ycPXZmJm19yxEd8SYWUnZDiw0f9KkHFyBEnQj4Jcxg16keoLs9e4FUXajyAkA/hOBh1+Jg/Tl5LwCHyShpOUqd85NsS6mQKJi6nUgR+0pNoYU0mxmzmjEZAGzSGurFL12bo2euXuavqeWbuxpUtKbNGQ2iq2mxKa2AdyOXblidgpmGYUnKTwMpEF0wUhCW+Sl/MlhKt0VCRaqbMpInEKxD6pEgh8IGMIZ3sKPbsO/4vhZPlndlsfQomL4051Z+cnFZpte02mX84Q8W1f5S7vYclBFYebq0HtaA4rCgkWDBKvPeaGbmxvnFjdCbI3Zqgv6QTvUUL7L0a5TmVoBTsSRkYStwLSjNLLKTOxQPr9mdUgALwUWxvm3tmT8FIqQ+I/vy5X6tMeE7iu1gRZnVOOLPKskb4PWbpek46J8lysdRZnctd0dXPIVtIdd8P3BB4TlLsQCz/PvQXdA4U+IFAO6tPRJy+kcbtFQmnbWZsp/HBt5RDf6N/299F71a8L1l2XHZ56PjwpMl5c/zm2L74vuE4iUzk6ypzk+373pWIJ+O74jvzg5EPfTfYIJQ3ZXfEednV2RMJQTydXZdZZ5sf/kT5rD/LR//8IYRA7yIxyJ3gO4hMcpcWSq+GXQu8FnYVaAqGXFcy2/8J325tba7MrARhjwNI/0h/srSLqLq+97+wSqPbAeMXczfUk+457lOffTaLYMcchIfgiDVCuOeqGCGCv/VzN25M3YXuk5nY3BWAekcGABlLarWx7FJG+g7amXCWcpWaZn8xiOP1ODp96TF4tnjHdo0tvL/UKaXIpjyuBFNgKXlIeV1KsfP+E7aa7cU7Tg+4X4w657FNCafER/j7IWTtLjju2vlB35b76OphdNX9lsqnaAdZwjBkmd14UtyqdBkVE0P1CLzF7HEvIPN3zSPyXP3S9y7nhMvCc5Zl9s1AdHTIS719PVb38Nacx0bnzXtO9YhVj54Yxd7iDEk3etkq57gf05ckk19/MyKOOSlZAnFV26xDvZQBytrbGblYPVZrz+eiIbVgcUszxV+IP038VPwFSOM9+nE1q2/0OVTdhzPtuA8A8O6xMQtEAACCXfwXYdxOlYz/1C6O4D8pXsl/IKQFVVxL5oIgA7hu3A+of8ma1Hq23rt8sxlJeWINH7gm/VW87WtqfLfUIqiHESmuJC3JjV0Ax6AOMHUdckh2cyWpsqb29qd0KCh5J9CJdON+u+BMKJP1P86EDypYACNaR1ncPjiVc/CiCygdODi4MkHrJymAbU8ERO8ZVOsPjN4ryuLewJn2B17vH0qPNXm8ynYNewY5YcREj2VS1bHgkr3UW0yakpsk+yMam8HKAtePeo+wRlPHDradhEQxi42q2OHlYliWimmjcpTkpkR61fPitB1cqSrYYyCOzIoRRuhVz0hKLe6Ywp/vFko0SpxRRD0qDHsi0qUzAZevgDpi1UoNDiTRakuEiCpiTDIMZVQu5/CjQCV3KYxOXyuHJOJKKzi0VR7tKFZlud1zqt09CyixV65LxYgVJ16CRCmklEpqafAX6pL3+nWmh0vFo6xOBiLnGNS8sThkpUGsxzooHM8xYpGowAF2vK3KpkInUp169CVtdEpQ1RACAAAAAA==) format(\"woff2\")}.iconfont{font-family:iconfont!important;font-size:16px;font-style:normal;-webkit-font-smoothing:antialiased;-moz-osx-font-smoothing:grayscale}.icon-replay:before{content:\"\\e631\"}.icon-pip:before{content:\"\\e820\"}.icon-loading:before{content:\"\\e62e\"}.icon-play:before{content:\"\\e851\"}.icon-pause:before{content:\"\\e863\"}.icon-screen:before{content:\"\\e88f\"}.icon-web-screen:before{content:\"\\e609\"}.icon-settings:before{content:\"\\e60c\"}.icon-volume-down:before{content:\"\\e60d\"}.icon-volume-up:before{content:\"\\e60e\"}.icon-volume-mute:before{content:\"\\e60f\"}div.svelte-1dcs6nc.svelte-1dcs6nc,span.svelte-1dcs6nc.svelte-1dcs6nc,p.svelte-1dcs6nc.svelte-1dcs6nc,img.svelte-1dcs6nc.svelte-1dcs6nc,i.svelte-1dcs6nc.svelte-1dcs6nc{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}.iconfont.svelte-1dcs6nc.svelte-1dcs6nc{display:inline-block}.d-flex-x.svelte-1dcs6nc.svelte-1dcs6nc{display:flex}.d-flex-x.svelte-1dcs6nc.svelte-1dcs6nc{align-items:center}.mr5.svelte-1dcs6nc.svelte-1dcs6nc{margin-right:5px}.d-pointer.svelte-1dcs6nc.svelte-1dcs6nc{cursor:pointer}.rotating.svelte-1dcs6nc.svelte-1dcs6nc{animation:svelte-1dcs6nc-rotating 2s linear infinite}@keyframes svelte-1dcs6nc-rotating{to{-webkit-transform:rotate(360deg)}}.f50.svelte-1dcs6nc.svelte-1dcs6nc{font-size:50px}.f24.svelte-1dcs6nc.svelte-1dcs6nc{font-size:24px}.d-loading.svelte-1dcs6nc.svelte-1dcs6nc{position:absolute;left:0;right:0;bottom:0px;top:0;display:flex;align-items:center;justify-content:center;background:rgba(0,0,0,.3);z-index:2;color:#efefef;text-align:center;font-size:13px}.loading-img.svelte-1dcs6nc.svelte-1dcs6nc{width:50px}.d-logo-loading.svelte-1dcs6nc.svelte-1dcs6nc{position:relative;width:100px;height:23px;overflow:hidden}.d-logo-loading.svelte-1dcs6nc .d-logo.svelte-1dcs6nc{width:100%;height:100%;background:url(https://s.thsi.cn/cd/ths-frontend-hxmui-container/front/thsc-hxmui/1.11.0/img/logo_light.ed78645a.png) 50%;background-size:cover}.d-logo-loading.svelte-1dcs6nc .d-light.svelte-1dcs6nc{position:absolute;left:0;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);width:32px;height:23px;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGIAAABaCAMAAAB0UnP8AAAAhFBMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8g2+bRAAAALHRSTlMABAgVDx4uDCU9ODMZKUJcRiFWYGZKt06ojpeJUq95bmqzo6CTfYRydaybgZ4JNUQAAAd9SURBVGjejNWNVtpAEIbhpoECGii/ojUCapEU7v/++s27ux23kMTxHH/O0Tx+Mzubb7eqsPquGo0Gg0FZllVVDYeLxVg1/VT6cbEYqqqqVOl3RyP7M/7+W2sV9gEhYARQBoDH/6Du9aFCWaBgOIFRtBqhsgwhAcD9p0KxaG4I8RhFWwqAIglEIAGPv7OaUPomMo440dUrD5FlCAHS4x2JxiIRg55peApCIDAGixD+/dlsNg+l76QIoV0YnqNzGP+HUJdcANiEckRBPIcTrRk8RIlABrVICXj8drutrfTVFBAZlqOqaFXPNAoqaxMZSABQ10vKEKLIULOmjDyLgdA3CQQyAITn/0wVFBnkwPBWdaZwgjZNp2QgQgBWoWQsZcQctMqJzhTXIciw2ZBgtVqnQhGiZmVGd6e8TwhVGISOknUpAgfVfr/XZynB2MzsXEEEA6JNcMJPUxBqBHv8iTJFSWQwDyc6O5UJEC5oCAL2+6bZhWqaE0hmiKi8U719KodD3RsQZFCTlEDC0UqIjJTDY1R9nYLwYVsIFw4C9PzLh9XlIqY5HQ6r1XL5L8aCgXenyE+sEZOJ2uSCgGdKyG5nORRju82JQSuRnyefRBIUQc9/okCOyag3ED/GGaFqSeFEnARtsgwXhN8qIWbYPAKh3fgKgaAaiAiT+EGIIGjOHwC/rEx5/mAca02DTokYc0+1EoUTPuxAqE3M4RkhGiJsHGEadAqi6iAYRTbs+3vbiZoQEizDr/P5XXU+C7EYx2a/XkMw70RgdBJcTyEEx8lCkAHhDYQcl6M6BTHvJ/Ijm/oUFpsQCAZQGEyDTtXajK+myM4Tk6gV4tQcLwgCHqlgcKhaCGbRsRUKARGHbSGeIBAwiGHE/hCISR9RXB9ZNrteatiEiMIfymKETt0g2ra7yAhWmxBGxEm8v5vw8vIiQsZtovxEFD2rzXlKfUohBFB/6FRG3OUperdiHIma8xT7pDbp6a+vbUR/CifoE0e2ZilsJ1KIVxXEW06k7ZbQmyKN4u4uHVkR9EmTQPgyUXRsBcRkPqdPzc6GbSEQMGzeELvG7loukOymbdmKIp+2H9mPZ44TxMPDA0RIYXuhC6SFKNoWr6riVtCndTxPCoGQEWy3EZzZzhTFrT5N0pG92LDfIAQ4wXaf1hAcqKsUvRfUtpN4zwh/d0v4SgqOrIg4iicRCBlh1yDvC3uxQkiAuH3PBiEjwpGFYBSEyImLESsRs0SUbYSfJ67ZeEHVSxHqk4hzIijbC12DTyJO/4g0CvrU/a5gt7nI2QobBXvnBKvH/cEbScRcxNVVfkO42gpu2RNbEUI48fjItEXYbjPtSAw8RRcxdYLFy0cBwShE7J0YQ9y+PopEIFTxDoxb0VyPgmmfbdp+fYjovz4gfPEi8bdSc1ttI4qh6ENbqKF1ZojBLZi0BOqG/P8HRmeNthVFntFknvy2kHS2rn5xVRghhcLTB/0HiCq8akUtRw/DT0u0UyhCeGpxXNs/QKyrAgRlG4Sr4kmhwAi+LDxrNxFeowoQqYMSwnIgofh1H/FfCIWi1TZ+CuE9UrYpeIQiCPZkibYhHqQKQ3wp0S5WpGgbwsu21QoQJRSoAoTq9tdAtKoAQQcVwst++q2i6pl8BoHwunIEgop3qgjlwFcQRPt8PoJoy1F0Bo4YqjiRAzMiiqoq3nlvUc0j3lEItF0QWXgHot1akUc89csgqHiOiFpBmj0tCYpod+UoI0LbSh9C0EPRlUt4F6miIgKwibgGgk9PlhYKxDRt+4kvDxZeLFRUQZAFIUh3JCg9WRC5M8hJcC8CgiPGuJob5rmqolphBCGOCcGLUk9Op8kkuWQPjcNpT7S2NFCGKog6WPCeeLKlHLVWZATiRnrPMR4xgXlN9VZToaBW7LPi8BFxG/I0R0YHJVUI0VhREai7TqqWn/BTWn7UJ9vHgsp9pYsS4zmM4MkK0aoCwj3E1taALFtG+p0IdEGO0trAGPYNAARN9IZQM5ubNCAN4gjCMoibwX7FCeYmjNC4rVqxJbwci5i48dRTXUMZwYxQsMNP9clWRF5+0B683FumuRF6T/2TLT2zth+YoZUgO8FYCa5tHbsdc906stgcDG02sYHFZvipZo/yZcSsnaCWpxYOg/BdiYMIUrZ6j2pFfVKB4NlaNB7/Eo5/BrHPAEG4xEIQRKiiWc++WwFr28+mXKtyA9gAGQQlj1RTy5eWgqGMSbvywYiF/x9swE0RCSHWrcjb+M9eLZoVM58QBEOeujHGWWE5vQDABOvPRlcgTRREdwab/W5xmMRIJyQDXC523Smnl3hPzd0Chm5503TmDhZnMAOYk4aXILCTCMKaKgridqY66JoXxzy/5mFDNaKzQoxv9qi4GMKoN8kBwAapLkSxaYWkERF3OwYkDqs6esoG3EQxam7Q9QLtJ+7V8/BigySRZLfjtCoGh3og+cgdhJlA7D9yw8BVYpizgORbvf4P8B0vJSPaU312lYXcPhgBsR9O4M8TEp1iLSvaRwUDyDyv/m8i2RCxLoCqjRwPvKW/f+j7KYAIDeIN31OsfyvZzREAAAAASUVORK5CYII=) 50%;background-size:cover;opacity:.6;-webkit-animation:svelte-1dcs6nc-move .8s ease-in-out infinite;animation:svelte-1dcs6nc-move .8s ease-in-out infinite}@keyframes svelte-1dcs6nc-move{0%{left:0}to{left:100%}}.d-player-top.svelte-q8odyd{position:absolute;font-size:16px;left:0px;top:0;right:0px;color:#fff;display:flex;padding:0 20px;height:60px;background-image:linear-gradient(rgba(0,0,0,.6),transparent);justify-content:space-between;z-index:1}.d-flex-center.svelte-o0d56g{display:flex}.d-flex-center.svelte-o0d56g{justify-content:center;align-items:center}.d-status.svelte-o0d56g{text-align:center;font-size:14px;vertical-align:middle;background:rgba(0,0,0,.8);padding:0 8px;height:30px;border-radius:5px;display:flex;align-items:center;color:#fffffff2}.d-radio.svelte-9brao2{position:relative;display:inline-block;padding-left:20px;box-sizing:border-box;height:18px;line-height:18px;font-size:14px;margin-left:12px;margin-top:10px;cursor:pointer;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.d-radio.svelte-9brao2:before{content:\"\";position:absolute;display:inline-block;top:2px;left:0;width:5px;height:5px;border:1px solid #ccc;border-radius:50%}.d-radio.d-radio-checked.svelte-9brao2:before{content:\"\";border-color:#409eff;position:absolute;display:inline-block;top:2px;left:0;width:5px;height:5px;border:1px solid #409eff;border-radius:50%}.d-radio.d-radio-checked.svelte-9brao2:after{content:\"\";position:absolute;top:5px;left:3px;display:inline-block;width:8px;height:8px;background-color:#00a1d6;border-radius:50%}.d-toast.svelte-bbg92z{position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background-color:#282828f5;padding:0 18px;border-radius:10px}.d-toast-content.svelte-bbg92z{font-size:16px;line-height:1;word-break:break-all;color:#fefefe}.d-feedback-container.svelte-bjqzkb.svelte-bjqzkb{position:absolute;left:0;top:0;right:0;bottom:0;display:flex;justify-content:center;align-items:center;z-index:3}.d-feedback-container.svelte-bjqzkb .dialog.svelte-bjqzkb{width:400px;height:240px;background-color:#212121e6;color:#fff}.d-feedback-container.svelte-bjqzkb .dialog .header.svelte-bjqzkb{width:100%;height:40px;display:flex;justify-content:center;align-items:center;font-size:16px;position:relative}.d-feedback-container.svelte-bjqzkb .dialog .header.svelte-bjqzkb:after{content:\" \";position:absolute;width:100%;height:1px;bottom:0;left:0;background-color:#fff6}.d-feedback-container.svelte-bjqzkb .dialog .header .icon-close.svelte-bjqzkb{position:absolute;right:0px;top:8px;width:40px;height:40px;line-height:40px;text-align:center;cursor:pointer;font:inherit}.d-feedback-container.svelte-bjqzkb .dialog .content.svelte-bjqzkb{position:relative;text-align:left}.d-feedback-container.svelte-bjqzkb .dialog .other.svelte-bjqzkb{font-size:14px;margin-left:12px}.d-feedback-container.svelte-bjqzkb .dialog #otherContent.svelte-bjqzkb{background-color:#191919;border:1px solid hsla(0,0%,100%,.4);resize:none;color:#ccc;margin-top:10px}.d-feedback-container.svelte-bjqzkb .dialog #otherContent.svelte-bjqzkb::-webkit-scrollbar{width:5px;background-color:#ffffff80}.d-feedback-container.svelte-bjqzkb .dialog #otherContent.svelte-bjqzkb::-webkit-scrollbar-thumb{width:5px;height:5px;background-color:#00000080;border-radius:10px}.d-feedback-container.svelte-bjqzkb .dialog .footer.svelte-bjqzkb{text-align:center}.d-feedback-container.svelte-bjqzkb .dialog .footer .d-player-filter-reset.svelte-bjqzkb{cursor:pointer;margin-top:10px;padding:3px 20px;display:inline-block;border-radius:2px;font-size:12px;background:rgba(133,133,133,.5)}.d-feedback-container.svelte-bjqzkb .dialog .footer .d-player-filter-reset.svelte-bjqzkb:hover{background:rgba(255,255,255,.3)}.d-icon-feedback.svelte-v622af{position:absolute;width:15px;height:15px;top:20px;right:35px;z-index:2;cursor:pointer}div.svelte-uvv227.svelte-uvv227,span.svelte-uvv227.svelte-uvv227,ul.svelte-uvv227.svelte-uvv227,li.svelte-uvv227.svelte-uvv227,video.svelte-uvv227.svelte-uvv227{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}ul.svelte-uvv227.svelte-uvv227{list-style:none}.d-fade-in-enter-active.svelte-uvv227.svelte-uvv227,.d-fade-in-leave-active.svelte-uvv227.svelte-uvv227{transition:.5s}.d-fade-in-enter-from.svelte-uvv227.svelte-uvv227,.d-fade-in-leave-to.svelte-uvv227.svelte-uvv227{opacity:0}.d-scale-out-enter-active.svelte-uvv227.svelte-uvv227,.d-scale-out-leave-active.svelte-uvv227.svelte-uvv227{transition:.3s}.d-scale-out-leave-to.svelte-uvv227.svelte-uvv227{transform:scale(1.3);opacity:0}.rotateHover.svelte-uvv227.svelte-uvv227{transition:.2s}.rotateHover.svelte-uvv227.svelte-uvv227:hover{transform:rotate(90deg)}.rotating.svelte-uvv227.svelte-uvv227{animation:svelte-uvv227-rotating 2s linear infinite}@keyframes svelte-uvv227-rotating{to{-webkit-transform:rotate(360deg)}}.iconfont.svelte-uvv227.svelte-uvv227{display:inline-block}.d-flex-x.svelte-uvv227.svelte-uvv227,.d-flex-y.svelte-uvv227.svelte-uvv227,.d-flex-center.svelte-uvv227.svelte-uvv227{display:flex}.d-flex-x.svelte-uvv227.svelte-uvv227{align-items:center}.d-flex-y.svelte-uvv227.svelte-uvv227{justify-content:center}.d-flex-center.svelte-uvv227.svelte-uvv227{justify-content:center;align-items:center}.mr5.svelte-uvv227.svelte-uvv227{margin-right:5px}.mr10.svelte-uvv227.svelte-uvv227{margin-right:10px}.ml5.svelte-uvv227.svelte-uvv227{margin-left:5px}.ml10.svelte-uvv227.svelte-uvv227{margin-left:10px}.d-pointer.svelte-uvv227.svelte-uvv227{cursor:pointer}.d-player-wrap.svelte-uvv227.svelte-uvv227{position:relative;overflow:hidden;background-color:#000}.d-player-wrap.web-full-screen.svelte-uvv227.svelte-uvv227{z-index:9999999;position:fixed;left:0;top:0;width:100vw!important;height:100vh!important}.d-player-wrap.svelte-uvv227 .d-player-video.svelte-uvv227{position:relative;z-index:1;width:100%;height:100%}.d-player-wrap.svelte-uvv227 .d-player-video .d-player-video-poster.svelte-uvv227{position:absolute;height:100%;width:100%;top:0;left:0}.d-player-wrap.svelte-uvv227 .d-player-video .d-player-video-main.svelte-uvv227{width:100%;height:100%;transition:.2s}.d-player-wrap.svelte-uvv227 .d-player-video .d-player-video-main.video-mirror.svelte-uvv227{transform:rotateY(180deg)}.d-player-wrap.svelte-uvv227 .d-player-control.svelte-uvv227{transition:.1s;transform:translateY(45px);position:absolute;z-index:2;left:0;bottom:0;height:50px;width:100%;color:#fff}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress.svelte-uvv227{width:100%;margin:0 auto;position:relative;height:5px;cursor:pointer}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress .d-progress-bar.svelte-uvv227{position:absolute;left:0;right:0;bottom:0;width:100%;transition:height .1s;height:3px;z-index:1}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress .d-progress-bar .d-slider__runway.svelte-uvv227{transition:height .1s;height:100%}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress .d-progress-bar .d-slider__runway .d-slider__bar.svelte-uvv227:before{transform:translateY(-50%) scale(0)}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress:hover .d-progress-bar.svelte-uvv227{height:100%}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress:hover .d-progress-bar .d-slider__bar.svelte-uvv227:before{transform:translateY(-50%) scale(1)!important}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool.svelte-uvv227{position:absolute;padding:0 10px;background-image:linear-gradient(180deg,transparent,rgba(0,0,0,.37),rgba(0,0,0,.75),rgba(0,0,0,.75));display:flex;justify-content:space-between;align-items:center;top:10px;left:0;bottom:0;width:100%;box-sizing:border-box}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-bar.svelte-uvv227{display:flex;height:100%}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-bar .d-tool-item.svelte-uvv227{position:relative;height:100%;cursor:pointer;text-align:center;padding:0 8px;display:flex;align-items:center;font-size:13px}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-bar .d-tool-item .d-tool-item-main.svelte-uvv227{position:absolute;white-space:nowrap;z-index:2;bottom:98%;left:50%;padding:6px 16px;box-sizing:border-box;display:none;background:rgba(0,0,0,.95);border-radius:5px;transform:translate(-50%)}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-bar .d-tool-item:hover .d-tool-item-main.svelte-uvv227{display:flex}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-time.svelte-uvv227{font-size:12px;color:#fff;font-weight:300}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-time .total-time.svelte-uvv227{color:#fffc}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .volume-box.svelte-uvv227{height:160px;width:50px;display:flex;align-items:center;justify-content:center}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .volume-box .volume-main.svelte-uvv227{height:90%;display:flex;width:60px;flex-direction:column;align-items:center}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .volume-box .volume-main .volume-text-size.svelte-uvv227{margin-bottom:10px;font-size:12px;font-weight:400}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .volume-box .volume-main.is-muted .d-slider__bar.svelte-uvv227{height:0!important}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .speed-main.svelte-uvv227{padding:0 10px}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .speed-main li.svelte-uvv227{cursor:pointer;line-height:34px;font-size:12px;color:#fff}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .speed-main li.svelte-uvv227:hover{opacity:.8}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .speed-main li.speed-active.svelte-uvv227{color:var(--primary-color);font-weight:700}.d-player-wrap.d-player-wrap-hover.svelte-uvv227 .d-player-control.svelte-uvv227{transform:translateY(0)}.d-player-wrap.d-player-wrap-hover.svelte-uvv227 .d-control-progress.svelte-uvv227{width:96%}.d-player-state.svelte-uvv227.svelte-uvv227,.d-player-input.svelte-uvv227.svelte-uvv227{position:absolute;left:0;top:0;right:0;bottom:40px;display:flex;justify-content:center;align-items:center;overflow:hidden;z-index:1}.d-player-input.svelte-uvv227.svelte-uvv227{width:100%;border:none;opacity:0;cursor:default}.d-play-btn.svelte-uvv227.svelte-uvv227{width:90px;height:90px;color:#fff;display:flex;align-items:center;justify-content:center;background-color:#000000b3;border-radius:50%}.d-player-lightoff.svelte-uvv227.svelte-uvv227{position:fixed;left:0;top:0;width:100vw;height:100vh;background-color:#000000e6}.is-lightoff.svelte-uvv227.svelte-uvv227{z-index:999998}.d-left-0.svelte-uvv227.svelte-uvv227{left:0!important}.d-player-state-top.svelte-uvv227.svelte-uvv227{position:absolute;left:0;top:0;right:0;bottom:40px px;display:flex;justify-content:center;align-items:flex-start;padding-top:5%;overflow:hidden;z-index:1}")); document.head.appendChild(elementStyle);} catch(e) {console.error('vite-plugin-css-injected-by-js', e);} })();function Pe() {
}
const Hr = (A) => A;
function Vr(A) {
  return A();
}
function Jt() {
  return /* @__PURE__ */ Object.create(null);
}
function ot(A) {
  A.forEach(Vr);
}
function ke(A) {
  return typeof A == "function";
}
function tt(A, b) {
  return A != A ? b == b : A !== b || A && typeof A == "object" || typeof A == "function";
}
let It;
function Ot(A, b) {
  return It || (It = document.createElement("a")), It.href = b, A === It.href;
}
function oi(A) {
  return Object.keys(A).length === 0;
}
function Fe(A) {
  return A == null ? "" : A;
}
const jr = typeof window < "u";
let li = jr ? () => window.performance.now() : () => Date.now(), jt = jr ? (A) => requestAnimationFrame(A) : Pe;
const _t = /* @__PURE__ */ new Set();
function zr(A) {
  _t.forEach((b) => {
    b.c(A) || (_t.delete(b), b.f());
  }), _t.size !== 0 && jt(zr);
}
function ui(A) {
  let b;
  return _t.size === 0 && jt(zr), {
    promise: new Promise((R) => {
      _t.add(b = { c: A, f: R });
    }),
    abort() {
      _t.delete(b);
    }
  };
}
function J(A, b) {
  A.appendChild(b);
}
function rt(A, b, R) {
  const G = zt(A);
  if (!G.getElementById(b)) {
    const K = re("style");
    K.id = b, K.textContent = R, Yr(G, K);
  }
}
function zt(A) {
  if (!A)
    return document;
  const b = A.getRootNode ? A.getRootNode() : A.ownerDocument;
  return b && b.host ? b : A.ownerDocument;
}
function fi(A) {
  const b = re("style");
  return Yr(zt(A), b), b.sheet;
}
function Yr(A, b) {
  return J(A.head || A, b), b.sheet;
}
function de(A, b, R) {
  A.insertBefore(b, R || null);
}
function fe(A) {
  A.parentNode && A.parentNode.removeChild(A);
}
function bt(A, b) {
  for (let R = 0; R < A.length; R += 1)
    A[R] && A[R].d(b);
}
function re(A) {
  return document.createElement(A);
}
function di(A) {
  return document.createElementNS("http://www.w3.org/2000/svg", A);
}
function ve(A) {
  return document.createTextNode(A);
}
function le() {
  return ve(" ");
}
function St() {
  return ve("");
}
function he(A, b, R, G) {
  return A.addEventListener(b, R, G), () => A.removeEventListener(b, R, G);
}
function wt(A) {
  return function(b) {
    return b.stopPropagation(), A.call(this, b);
  };
}
function Q(A, b, R) {
  R == null ? A.removeAttribute(b) : A.getAttribute(b) !== R && A.setAttribute(b, R);
}
function ci(A) {
  return Array.from(A.childNodes);
}
function De(A, b) {
  b = "" + b, A.wholeText !== b && (A.data = b);
}
function qt(A, b) {
  A.value = b == null ? "" : b;
}
function Mt(A, b, R, G) {
  R === null ? A.style.removeProperty(b) : A.style.setProperty(b, R, G ? "important" : "");
}
function $t(A, b, R) {
  A.classList[R ? "add" : "remove"](b);
}
function Xr(A, b, { bubbles: R = !1, cancelable: G = !1 } = {}) {
  const K = document.createEvent("CustomEvent");
  return K.initCustomEvent(A, R, G, b), K;
}
class hi {
  constructor(b = !1) {
    this.is_svg = !1, this.is_svg = b, this.e = this.n = null;
  }
  c(b) {
    this.h(b);
  }
  m(b, R, G = null) {
    this.e || (this.is_svg ? this.e = di(R.nodeName) : this.e = re(R.nodeName), this.t = R, this.c(b)), this.i(G);
  }
  h(b) {
    this.e.innerHTML = b, this.n = Array.from(this.e.childNodes);
  }
  i(b) {
    for (let R = 0; R < this.n.length; R += 1)
      de(this.t, this.n[R], b);
  }
  p(b) {
    this.d(), this.h(b), this.i(this.a);
  }
  d() {
    this.n.forEach(fe);
  }
}
const kt = /* @__PURE__ */ new Map();
let Ft = 0;
function vi(A) {
  let b = 5381, R = A.length;
  for (; R--; )
    b = (b << 5) - b ^ A.charCodeAt(R);
  return b >>> 0;
}
function gi(A, b) {
  const R = { stylesheet: fi(b), rules: {} };
  return kt.set(A, R), R;
}
function er(A, b, R, G, K, V, W, O = 0) {
  const p = 16.666 / G;
  let P = `{
`;
  for (let D = 0; D <= 1; D += p) {
    const _ = b + (R - b) * V(D);
    P += D * 100 + `%{${W(_, 1 - _)}}
`;
  }
  const T = P + `100% {${W(R, 1 - R)}}
}`, k = `__svelte_${vi(T)}_${O}`, C = zt(A), { stylesheet: B, rules: I } = kt.get(C) || gi(C, A);
  I[k] || (I[k] = !0, B.insertRule(`@keyframes ${k} ${T}`, B.cssRules.length));
  const L = A.style.animation || "";
  return A.style.animation = `${L ? `${L}, ` : ""}${k} ${G}ms linear ${K}ms 1 both`, Ft += 1, k;
}
function mi(A, b) {
  const R = (A.style.animation || "").split(", "), G = R.filter(
    b ? (V) => V.indexOf(b) < 0 : (V) => V.indexOf("__svelte") === -1
  ), K = R.length - G.length;
  K && (A.style.animation = G.join(", "), Ft -= K, Ft || pi());
}
function pi() {
  jt(() => {
    Ft || (kt.forEach((A) => {
      const { ownerNode: b } = A.stylesheet;
      b && fe(b);
    }), kt.clear());
  });
}
let At;
function Dt(A) {
  At = A;
}
function Yt() {
  if (!At)
    throw new Error("Function called outside component initialization");
  return At;
}
function Qr(A) {
  Yt().$$.on_mount.push(A);
}
function yi(A) {
  Yt().$$.on_destroy.push(A);
}
function gt() {
  const A = Yt();
  return (b, R, { cancelable: G = !1 } = {}) => {
    const K = A.$$.callbacks[b];
    if (K) {
      const V = Xr(b, R, { cancelable: G });
      return K.slice().forEach((W) => {
        W.call(A, V);
      }), !V.defaultPrevented;
    }
    return !0;
  };
}
function Ei(A, b) {
  const R = A.$$.callbacks[b.type];
  R && R.slice().forEach((G) => G.call(this, b));
}
const Tt = [], dt = [], Rt = [], tr = [], Zr = Promise.resolve();
let Ht = !1;
function Jr() {
  Ht || (Ht = !0, Zr.then(qr));
}
function Vt() {
  return Jr(), Zr;
}
function lt(A) {
  Rt.push(A);
}
const Nt = /* @__PURE__ */ new Set();
let Et = 0;
function qr() {
  if (Et !== 0)
    return;
  const A = At;
  do {
    try {
      for (; Et < Tt.length; ) {
        const b = Tt[Et];
        Et++, Dt(b), Ti(b.$$);
      }
    } catch (b) {
      throw Tt.length = 0, Et = 0, b;
    }
    for (Dt(null), Tt.length = 0, Et = 0; dt.length; )
      dt.pop()();
    for (let b = 0; b < Rt.length; b += 1) {
      const R = Rt[b];
      Nt.has(R) || (Nt.add(R), R());
    }
    Rt.length = 0;
  } while (Tt.length);
  for (; tr.length; )
    tr.pop()();
  Ht = !1, Nt.clear(), Dt(A);
}
function Ti(A) {
  if (A.fragment !== null) {
    A.update(), ot(A.before_update);
    const b = A.dirty;
    A.dirty = [-1], A.fragment && A.fragment.p(A.ctx, b), A.after_update.forEach(lt);
  }
}
let xt;
function _i() {
  return xt || (xt = Promise.resolve(), xt.then(() => {
    xt = null;
  })), xt;
}
function Kt(A, b, R) {
  A.dispatchEvent(Xr(`${b ? "intro" : "outro"}${R}`));
}
const Ct = /* @__PURE__ */ new Set();
let ct;
function Ke() {
  ct = {
    r: 0,
    c: [],
    p: ct
  };
}
function We() {
  ct.r || ot(ct.c), ct = ct.p;
}
function se(A, b) {
  A && A.i && (Ct.delete(A), A.i(b));
}
function ue(A, b, R, G) {
  if (A && A.o) {
    if (Ct.has(A))
      return;
    Ct.add(A), ct.c.push(() => {
      Ct.delete(A), G && (R && A.d(1), G());
    }), A.o(b);
  } else
    G && G();
}
const Si = { duration: 0 };
function $e(A, b, R, G) {
  const K = { direction: "both" };
  let V = b(A, R, K), W = G ? 0 : 1, O = null, p = null, P = null;
  function T() {
    P && mi(A, P);
  }
  function k(B, I) {
    const L = B.b - W;
    return I *= Math.abs(L), {
      a: W,
      b: B.b,
      d: L,
      duration: I,
      start: B.start,
      end: B.start + I,
      group: B.group
    };
  }
  function C(B) {
    const { delay: I = 0, duration: L = 300, easing: D = Hr, tick: _ = Pe, css: x } = V || Si, g = {
      start: li() + I,
      b: B
    };
    B || (g.group = ct, ct.r += 1), O || p ? p = g : (x && (T(), P = er(A, W, B, L, I, D, x)), B && _(0, 1), O = k(g, L), lt(() => Kt(A, B, "start")), ui((S) => {
      if (p && S > p.start && (O = k(p, L), p = null, Kt(A, O.b, "start"), x && (T(), P = er(A, W, O.b, O.duration, 0, D, V.css))), O) {
        if (S >= O.end)
          _(W = O.b, 1 - W), Kt(A, O.b, "end"), p || (O.b ? T() : --O.group.r || ot(O.group.c)), O = null;
        else if (S >= O.start) {
          const y = S - O.start;
          W = O.a + O.d * D(y / O.duration), _(W, 1 - W);
        }
      }
      return !!(O || p);
    }));
  }
  return {
    run(B) {
      ke(V) ? _i().then(() => {
        V = V(K), C(B);
      }) : C(B);
    },
    end() {
      T(), O = p = null;
    }
  };
}
function be(A) {
  A && A.c();
}
function Le(A, b, R, G) {
  const { fragment: K, after_update: V } = A.$$;
  K && K.m(b, R), G || lt(() => {
    const W = A.$$.on_mount.map(Vr).filter(ke);
    A.$$.on_destroy ? A.$$.on_destroy.push(...W) : ot(W), A.$$.on_mount = [];
  }), V.forEach(lt);
}
function Ae(A, b) {
  const R = A.$$;
  R.fragment !== null && (ot(R.on_destroy), R.fragment && R.fragment.d(b), R.on_destroy = R.fragment = null, R.ctx = []);
}
function xi(A, b) {
  A.$$.dirty[0] === -1 && (Tt.push(A), Jr(), A.$$.dirty.fill(0)), A.$$.dirty[b / 31 | 0] |= 1 << b % 31;
}
function it(A, b, R, G, K, V, W, O = [-1]) {
  const p = At;
  Dt(A);
  const P = A.$$ = {
    fragment: null,
    ctx: [],
    props: V,
    update: Pe,
    not_equal: K,
    bound: Jt(),
    on_mount: [],
    on_destroy: [],
    on_disconnect: [],
    before_update: [],
    after_update: [],
    context: new Map(b.context || (p ? p.$$.context : [])),
    callbacks: Jt(),
    dirty: O,
    skip_bound: !1,
    root: b.target || p.$$.root
  };
  W && W(P.root);
  let T = !1;
  if (P.ctx = R ? R(A, b.props || {}, (k, C, ...B) => {
    const I = B.length ? B[0] : C;
    return P.ctx && K(P.ctx[k], P.ctx[k] = I) && (!P.skip_bound && P.bound[k] && P.bound[k](I), T && xi(A, k)), C;
  }) : [], P.update(), T = !0, ot(P.before_update), P.fragment = G ? G(P.ctx) : !1, b.target) {
    if (b.hydrate) {
      const k = ci(b.target);
      P.fragment && P.fragment.l(k), k.forEach(fe);
    } else
      P.fragment && P.fragment.c();
    b.intro && se(A.$$.fragment), Le(A, b.target, b.anchor, b.customElement), qr();
  }
  Dt(p);
}
class nt {
  $destroy() {
    Ae(this, 1), this.$destroy = Pe;
  }
  $on(b, R) {
    if (!ke(R))
      return Pe;
    const G = this.$$.callbacks[b] || (this.$$.callbacks[b] = []);
    return G.push(R), () => {
      const K = G.indexOf(R);
      K !== -1 && G.splice(K, 1);
    };
  }
  $set(b) {
    this.$$set && !oi(b) && (this.$$.skip_bound = !0, this.$$set(b), this.$$.skip_bound = !1);
  }
}
function et(A, { delay: b = 0, duration: R = 400, easing: G = Hr } = {}) {
  const K = +getComputedStyle(A).opacity;
  return {
    delay: b,
    duration: R,
    easing: G,
    css: (V) => `opacity: ${V * K}`
  };
}
var Di = typeof globalThis < "u" ? globalThis : typeof window < "u" ? window : typeof global < "u" ? global : typeof self < "u" ? self : {};
function Li(A) {
  return A && A.__esModule && Object.prototype.hasOwnProperty.call(A, "default") ? A.default : A;
}
var $r = { exports: {} };
(function(A, b) {
  typeof window < "u" && function(G, K) {
    A.exports = K();
  }(Di, () => (() => {
    var R = {
      "./src/config.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          enableStreamingMode: () => d,
          hlsDefaultConfig: () => r,
          mergeConfig: () => t
        });
        var P = p("./src/controller/abr-controller.ts"), T = p("./src/controller/audio-stream-controller.ts"), k = p("./src/controller/audio-track-controller.ts"), C = p("./src/controller/subtitle-stream-controller.ts"), B = p("./src/controller/subtitle-track-controller.ts"), I = p("./src/controller/buffer-controller.ts"), L = p("./src/controller/timeline-controller.ts"), D = p("./src/controller/cap-level-controller.ts"), _ = p("./src/controller/fps-controller.ts"), x = p("./src/controller/eme-controller.ts"), g = p("./src/controller/cmcd-controller.ts"), S = p("./src/utils/xhr-loader.ts"), y = p("./src/utils/fetch-loader.ts"), l = p("./src/utils/cues.ts"), u = p("./src/utils/mediakeys-helper.ts"), a = p("./src/utils/logger.ts");
        function s() {
          return s = Object.assign ? Object.assign.bind() : function(e) {
            for (var h = 1; h < arguments.length; h++) {
              var f = arguments[h];
              for (var c in f)
                Object.prototype.hasOwnProperty.call(f, c) && (e[c] = f[c]);
            }
            return e;
          }, s.apply(this, arguments);
        }
        function m(e, h) {
          var f = Object.keys(e);
          if (Object.getOwnPropertySymbols) {
            var c = Object.getOwnPropertySymbols(e);
            h && (c = c.filter(function(M) {
              return Object.getOwnPropertyDescriptor(e, M).enumerable;
            })), f.push.apply(f, c);
          }
          return f;
        }
        function v(e) {
          for (var h = 1; h < arguments.length; h++) {
            var f = arguments[h] != null ? arguments[h] : {};
            h % 2 ? m(Object(f), !0).forEach(function(c) {
              i(e, c, f[c]);
            }) : Object.getOwnPropertyDescriptors ? Object.defineProperties(e, Object.getOwnPropertyDescriptors(f)) : m(Object(f)).forEach(function(c) {
              Object.defineProperty(e, c, Object.getOwnPropertyDescriptor(f, c));
            });
          }
          return e;
        }
        function i(e, h, f) {
          return h = n(h), h in e ? Object.defineProperty(e, h, { value: f, enumerable: !0, configurable: !0, writable: !0 }) : e[h] = f, e;
        }
        function n(e) {
          var h = E(e, "string");
          return typeof h == "symbol" ? h : String(h);
        }
        function E(e, h) {
          if (typeof e != "object" || e === null)
            return e;
          var f = e[Symbol.toPrimitive];
          if (f !== void 0) {
            var c = f.call(e, h || "default");
            if (typeof c != "object")
              return c;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (h === "string" ? String : Number)(e);
        }
        var r = v(v({
          autoStartLoad: !0,
          startPosition: -1,
          defaultAudioCodec: void 0,
          debug: !1,
          capLevelOnFPSDrop: !1,
          capLevelToPlayerSize: !1,
          ignoreDevicePixelRatio: !1,
          initialLiveManifestSize: 1,
          maxBufferLength: 30,
          backBufferLength: 1 / 0,
          maxBufferSize: 60 * 1e3 * 1e3,
          maxBufferHole: 0.1,
          highBufferWatchdogPeriod: 2,
          nudgeOffset: 0.1,
          nudgeMaxRetry: 3,
          maxFragLookUpTolerance: 0.25,
          liveSyncDurationCount: 3,
          liveMaxLatencyDurationCount: 1 / 0,
          liveSyncDuration: void 0,
          liveMaxLatencyDuration: void 0,
          maxLiveSyncPlaybackRate: 1,
          liveDurationInfinity: !1,
          liveBackBufferLength: null,
          maxMaxBufferLength: 600,
          enableWorker: !0,
          enableSoftwareAES: !0,
          manifestLoadingTimeOut: 1e4,
          manifestLoadingMaxRetry: 1,
          manifestLoadingRetryDelay: 1e3,
          manifestLoadingMaxRetryTimeout: 64e3,
          startLevel: void 0,
          levelLoadingTimeOut: 1e4,
          levelLoadingMaxRetry: 4,
          levelLoadingRetryDelay: 1e3,
          levelLoadingMaxRetryTimeout: 64e3,
          fragLoadingTimeOut: 2e4,
          fragLoadingMaxRetry: 6,
          fragLoadingRetryDelay: 1e3,
          fragLoadingMaxRetryTimeout: 64e3,
          startFragPrefetch: !1,
          fpsDroppedMonitoringPeriod: 5e3,
          fpsDroppedMonitoringThreshold: 0.2,
          appendErrorMaxRetry: 3,
          loader: S.default,
          fLoader: void 0,
          pLoader: void 0,
          xhrSetup: void 0,
          licenseXhrSetup: void 0,
          licenseResponseCallback: void 0,
          abrController: P.default,
          bufferController: I.default,
          capLevelController: D.default,
          fpsController: _.default,
          stretchShortVideoTrack: !1,
          maxAudioFramesDrift: 1,
          forceKeyFrameOnDiscontinuity: !0,
          abrEwmaFastLive: 3,
          abrEwmaSlowLive: 9,
          abrEwmaFastVoD: 3,
          abrEwmaSlowVoD: 9,
          abrEwmaDefaultEstimate: 5e5,
          abrBandWidthFactor: 0.95,
          abrBandWidthUpFactor: 0.7,
          abrMaxWithRealBitrate: !1,
          maxStarvationDelay: 4,
          maxLoadingDelay: 4,
          minAutoBitrate: 0,
          emeEnabled: !1,
          widevineLicenseUrl: void 0,
          drmSystems: {},
          drmSystemOptions: {},
          requestMediaKeySystemAccessFunc: u.requestMediaKeySystemAccess,
          testBandwidth: !0,
          progressive: !1,
          lowLatencyMode: !0,
          cmcd: void 0,
          enableDateRangeMetadataCues: !0,
          enableEmsgMetadataCues: !0,
          enableID3MetadataCues: !0
        }, o()), {}, {
          subtitleStreamController: C.SubtitleStreamController,
          subtitleTrackController: B.default,
          timelineController: L.TimelineController,
          audioStreamController: T.default,
          audioTrackController: k.default,
          emeController: x.default,
          cmcdController: g.default
        });
        function o() {
          return {
            cueHandler: l.default,
            enableWebVTT: !0,
            enableIMSC1: !0,
            enableCEA708Captions: !0,
            captionsTextTrack1Label: "English",
            captionsTextTrack1LanguageCode: "en",
            captionsTextTrack2Label: "Spanish",
            captionsTextTrack2LanguageCode: "es",
            captionsTextTrack3Label: "Unknown CC",
            captionsTextTrack3LanguageCode: "",
            captionsTextTrack4Label: "Unknown CC",
            captionsTextTrack4LanguageCode: "",
            renderTextTracksNatively: !0
          };
        }
        function t(e, h) {
          if ((h.liveSyncDurationCount || h.liveMaxLatencyDurationCount) && (h.liveSyncDuration || h.liveMaxLatencyDuration))
            throw new Error("Illegal hls.js config: don't mix up liveSyncDurationCount/liveMaxLatencyDurationCount and liveSyncDuration/liveMaxLatencyDuration");
          if (h.liveMaxLatencyDurationCount !== void 0 && (h.liveSyncDurationCount === void 0 || h.liveMaxLatencyDurationCount <= h.liveSyncDurationCount))
            throw new Error('Illegal hls.js config: "liveMaxLatencyDurationCount" must be greater than "liveSyncDurationCount"');
          if (h.liveMaxLatencyDuration !== void 0 && (h.liveSyncDuration === void 0 || h.liveMaxLatencyDuration <= h.liveSyncDuration))
            throw new Error('Illegal hls.js config: "liveMaxLatencyDuration" must be greater than "liveSyncDuration"');
          return s({}, e, h);
        }
        function d(e) {
          var h = e.loader;
          if (h !== y.default && h !== S.default)
            a.logger.log("[config]: Custom loader detected, cannot enable progressive streaming"), e.progressive = !1;
          else {
            var f = (0, y.fetchSupported)();
            f && (e.loader = y.default, e.progressive = !0, e.enableSoftwareAES = !0, a.logger.log("[config]: Progressive streaming enabled, using FetchLoader"));
          }
        }
      },
      "./src/controller/abr-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => S
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/utils/ewma-bandwidth-estimator.ts"), k = p("./src/events.ts"), C = p("./src/errors.ts"), B = p("./src/types/loader.ts"), I = p("./src/utils/logger.ts");
        function L(y, l) {
          for (var u = 0; u < l.length; u++) {
            var a = l[u];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(y, _(a.key), a);
          }
        }
        function D(y, l, u) {
          return l && L(y.prototype, l), u && L(y, u), Object.defineProperty(y, "prototype", { writable: !1 }), y;
        }
        function _(y) {
          var l = x(y, "string");
          return typeof l == "symbol" ? l : String(l);
        }
        function x(y, l) {
          if (typeof y != "object" || y === null)
            return y;
          var u = y[Symbol.toPrimitive];
          if (u !== void 0) {
            var a = u.call(y, l || "default");
            if (typeof a != "object")
              return a;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (l === "string" ? String : Number)(y);
        }
        var g = /* @__PURE__ */ function() {
          function y(u) {
            this.hls = void 0, this.lastLoadedFragLevel = 0, this._nextAutoLevel = -1, this.timer = void 0, this.onCheck = this._abandonRulesCheck.bind(this), this.fragCurrent = null, this.partCurrent = null, this.bitrateTestDelay = 0, this.bwEstimator = void 0, this.hls = u;
            var a = u.config;
            this.bwEstimator = new T.default(a.abrEwmaSlowVoD, a.abrEwmaFastVoD, a.abrEwmaDefaultEstimate), this.registerListeners();
          }
          var l = y.prototype;
          return l.registerListeners = function() {
            var a = this.hls;
            a.on(k.Events.FRAG_LOADING, this.onFragLoading, this), a.on(k.Events.FRAG_LOADED, this.onFragLoaded, this), a.on(k.Events.FRAG_BUFFERED, this.onFragBuffered, this), a.on(k.Events.LEVEL_LOADED, this.onLevelLoaded, this), a.on(k.Events.ERROR, this.onError, this);
          }, l.unregisterListeners = function() {
            var a = this.hls;
            a.off(k.Events.FRAG_LOADING, this.onFragLoading, this), a.off(k.Events.FRAG_LOADED, this.onFragLoaded, this), a.off(k.Events.FRAG_BUFFERED, this.onFragBuffered, this), a.off(k.Events.LEVEL_LOADED, this.onLevelLoaded, this), a.off(k.Events.ERROR, this.onError, this);
          }, l.destroy = function() {
            this.unregisterListeners(), this.clearTimer(), this.hls = this.onCheck = null, this.fragCurrent = this.partCurrent = null;
          }, l.onFragLoading = function(a, s) {
            var m = s.frag;
            if (m.type === B.PlaylistLevelType.MAIN && !this.timer) {
              var v;
              this.fragCurrent = m, this.partCurrent = (v = s.part) != null ? v : null, this.timer = self.setInterval(this.onCheck, 100);
            }
          }, l.onLevelLoaded = function(a, s) {
            var m = this.hls.config;
            s.details.live ? this.bwEstimator.update(m.abrEwmaSlowLive, m.abrEwmaFastLive) : this.bwEstimator.update(m.abrEwmaSlowVoD, m.abrEwmaFastVoD);
          }, l._abandonRulesCheck = function() {
            var a = this.fragCurrent, s = this.partCurrent, m = this.hls, v = m.autoLevelEnabled, i = m.media;
            if (!(!a || !i)) {
              var n = s ? s.stats : a.stats, E = s ? s.duration : a.duration;
              if (n.aborted || n.loaded && n.loaded === n.total || a.level === 0) {
                this.clearTimer(), this._nextAutoLevel = -1;
                return;
              }
              if (!(!v || i.paused || !i.playbackRate || !i.readyState)) {
                var r = m.mainForwardBufferInfo;
                if (r !== null) {
                  var o = performance.now() - n.loading.start, t = Math.abs(i.playbackRate);
                  if (!(o <= 500 * E / t)) {
                    var d = n.loaded && n.loading.first, e = this.bwEstimator.getEstimate(), h = m.levels, f = m.minAutoLevel, c = h[a.level], M = n.total || Math.max(n.loaded, Math.round(E * c.maxBitrate / 8)), w = d ? n.loaded * 1e3 / o : 0, F = w ? (M - n.loaded) / w : M * 8 / e, U = r.len / t;
                    if (!(F <= U)) {
                      var N = Number.POSITIVE_INFINITY, H;
                      for (H = a.level - 1; H > f; H--) {
                        var j = h[H].maxBitrate;
                        if (N = w ? E * j / (8 * 0.8 * w) : E * j / e, N < U)
                          break;
                      }
                      N >= F || (I.logger.warn("Fragment " + a.sn + (s ? " part " + s.index : "") + " of level " + a.level + " is loading too slowly and will cause an underbuffer; aborting and switching to level " + H + `
      Current BW estimate: ` + ((0, P.isFiniteNumber)(e) ? (e / 1024).toFixed(3) : "Unknown") + ` Kb/s
      Estimated load time for current fragment: ` + F.toFixed(3) + ` s
      Estimated load time for the next fragment: ` + N.toFixed(3) + ` s
      Time to underbuffer: ` + U.toFixed(3) + " s"), m.nextLoadLevel = H, d && this.bwEstimator.sample(o, n.loaded), this.clearTimer(), (a.loader || a.keyLoader) && (this.fragCurrent = this.partCurrent = null, a.abortRequests()), m.trigger(k.Events.FRAG_LOAD_EMERGENCY_ABORTED, {
                        frag: a,
                        part: s,
                        stats: n
                      }));
                    }
                  }
                }
              }
            }
          }, l.onFragLoaded = function(a, s) {
            var m = s.frag, v = s.part;
            if (m.type === B.PlaylistLevelType.MAIN && (0, P.isFiniteNumber)(m.sn)) {
              var i = v ? v.stats : m.stats, n = v ? v.duration : m.duration;
              if (this.clearTimer(), this.lastLoadedFragLevel = m.level, this._nextAutoLevel = -1, this.hls.config.abrMaxWithRealBitrate) {
                var E = this.hls.levels[m.level], r = (E.loaded ? E.loaded.bytes : 0) + i.loaded, o = (E.loaded ? E.loaded.duration : 0) + n;
                E.loaded = {
                  bytes: r,
                  duration: o
                }, E.realBitrate = Math.round(8 * r / o);
              }
              if (m.bitrateTest) {
                var t = {
                  stats: i,
                  frag: m,
                  part: v,
                  id: m.type
                };
                this.onFragBuffered(k.Events.FRAG_BUFFERED, t);
              }
            }
          }, l.onFragBuffered = function(a, s) {
            var m = s.frag, v = s.part, i = v ? v.stats : m.stats;
            if (!i.aborted && !(m.type !== B.PlaylistLevelType.MAIN || m.sn === "initSegment")) {
              var n = i.parsing.end - i.loading.start;
              this.bwEstimator.sample(n, i.loaded), i.bwEstimate = this.bwEstimator.getEstimate(), m.bitrateTest ? this.bitrateTestDelay = n / 1e3 : this.bitrateTestDelay = 0;
            }
          }, l.onError = function(a, s) {
            var m;
            if (((m = s.frag) === null || m === void 0 ? void 0 : m.type) === B.PlaylistLevelType.MAIN) {
              if (s.type === C.ErrorTypes.KEY_SYSTEM_ERROR) {
                this.clearTimer();
                return;
              }
              switch (s.details) {
                case C.ErrorDetails.FRAG_LOAD_ERROR:
                case C.ErrorDetails.FRAG_LOAD_TIMEOUT:
                case C.ErrorDetails.KEY_LOAD_ERROR:
                case C.ErrorDetails.KEY_LOAD_TIMEOUT:
                  this.clearTimer();
                  break;
              }
            }
          }, l.clearTimer = function() {
            self.clearInterval(this.timer), this.timer = void 0;
          }, l.getNextABRAutoLevel = function() {
            var a = this.fragCurrent, s = this.partCurrent, m = this.hls, v = m.maxAutoLevel, i = m.config, n = m.minAutoLevel, E = m.media, r = s ? s.duration : a ? a.duration : 0, o = E && E.playbackRate !== 0 ? Math.abs(E.playbackRate) : 1, t = this.bwEstimator ? this.bwEstimator.getEstimate() : i.abrEwmaDefaultEstimate, d = m.mainForwardBufferInfo, e = (d ? d.len : 0) / o, h = this.findBestLevel(t, n, v, e, i.abrBandWidthFactor, i.abrBandWidthUpFactor);
            if (h >= 0)
              return h;
            I.logger.trace((e ? "rebuffering expected" : "buffer is empty") + ", finding optimal quality level");
            var f = r ? Math.min(r, i.maxStarvationDelay) : i.maxStarvationDelay, c = i.abrBandWidthFactor, M = i.abrBandWidthUpFactor;
            if (!e) {
              var w = this.bitrateTestDelay;
              if (w) {
                var F = r ? Math.min(r, i.maxLoadingDelay) : i.maxLoadingDelay;
                f = F - w, I.logger.trace("bitrate test took " + Math.round(1e3 * w) + "ms, set first fragment max fetchDuration to " + Math.round(1e3 * f) + " ms"), c = M = 1;
              }
            }
            return h = this.findBestLevel(t, n, v, e + f, c, M), Math.max(h, 0);
          }, l.findBestLevel = function(a, s, m, v, i, n) {
            for (var E, r = this.fragCurrent, o = this.partCurrent, t = this.lastLoadedFragLevel, d = this.hls.levels, e = d[t], h = !!(e != null && (E = e.details) !== null && E !== void 0 && E.live), f = e == null ? void 0 : e.codecSet, c = o ? o.duration : r ? r.duration : 0, M = m; M >= s; M--) {
              var w = d[M];
              if (!(!w || f && w.codecSet !== f)) {
                var F = w.details, U = (o ? F == null ? void 0 : F.partTarget : F == null ? void 0 : F.averagetargetduration) || c, N = void 0;
                M <= t ? N = i * a : N = n * a;
                var H = d[M].maxBitrate, j = H * U / N;
                if (I.logger.trace("level/adjustedbw/bitrate/avgDuration/maxFetchDuration/fetchDuration: " + M + "/" + Math.round(N) + "/" + H + "/" + U + "/" + v + "/" + j), N > H && (j === 0 || !(0, P.isFiniteNumber)(j) || h && !this.bitrateTestDelay || j < v))
                  return M;
              }
            }
            return -1;
          }, D(y, [{
            key: "nextAutoLevel",
            get: function() {
              var a = this._nextAutoLevel, s = this.bwEstimator;
              if (a !== -1 && !s.canEstimate())
                return a;
              var m = this.getNextABRAutoLevel();
              return a !== -1 && this.hls.levels[m].loadError ? a : (a !== -1 && (m = Math.min(a, m)), m);
            },
            set: function(a) {
              this._nextAutoLevel = a;
            }
          }]), y;
        }();
        const S = g;
      },
      "./src/controller/audio-stream-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => i
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/controller/base-stream-controller.ts"), k = p("./src/events.ts"), C = p("./src/utils/buffer-helper.ts"), B = p("./src/controller/fragment-tracker.ts"), I = p("./src/types/level.ts"), L = p("./src/types/loader.ts"), D = p("./src/loader/fragment.ts"), _ = p("./src/demux/chunk-cache.ts"), x = p("./src/demux/transmuxer-interface.ts"), g = p("./src/types/transmuxer.ts"), S = p("./src/controller/fragment-finders.ts"), y = p("./src/utils/discontinuities.ts"), l = p("./src/errors.ts");
        function u() {
          return u = Object.assign ? Object.assign.bind() : function(n) {
            for (var E = 1; E < arguments.length; E++) {
              var r = arguments[E];
              for (var o in r)
                Object.prototype.hasOwnProperty.call(r, o) && (n[o] = r[o]);
            }
            return n;
          }, u.apply(this, arguments);
        }
        function a(n, E) {
          n.prototype = Object.create(E.prototype), n.prototype.constructor = n, s(n, E);
        }
        function s(n, E) {
          return s = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, t) {
            return o.__proto__ = t, o;
          }, s(n, E);
        }
        var m = 100, v = /* @__PURE__ */ function(n) {
          a(E, n);
          function E(o, t, d) {
            var e;
            return e = n.call(this, o, t, d, "[audio-stream-controller]") || this, e.videoBuffer = null, e.videoTrackCC = -1, e.waitingVideoCC = -1, e.audioSwitch = !1, e.trackId = -1, e.waitingData = null, e.mainDetails = null, e.bufferFlushed = !1, e.cachedTrackLoadedData = null, e._registerListeners(), e;
          }
          var r = E.prototype;
          return r.onHandlerDestroying = function() {
            this._unregisterListeners(), this.mainDetails = null;
          }, r._registerListeners = function() {
            var t = this.hls;
            t.on(k.Events.MEDIA_ATTACHED, this.onMediaAttached, this), t.on(k.Events.MEDIA_DETACHING, this.onMediaDetaching, this), t.on(k.Events.MANIFEST_LOADING, this.onManifestLoading, this), t.on(k.Events.LEVEL_LOADED, this.onLevelLoaded, this), t.on(k.Events.AUDIO_TRACKS_UPDATED, this.onAudioTracksUpdated, this), t.on(k.Events.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), t.on(k.Events.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), t.on(k.Events.ERROR, this.onError, this), t.on(k.Events.BUFFER_RESET, this.onBufferReset, this), t.on(k.Events.BUFFER_CREATED, this.onBufferCreated, this), t.on(k.Events.BUFFER_FLUSHED, this.onBufferFlushed, this), t.on(k.Events.INIT_PTS_FOUND, this.onInitPtsFound, this), t.on(k.Events.FRAG_BUFFERED, this.onFragBuffered, this);
          }, r._unregisterListeners = function() {
            var t = this.hls;
            t.off(k.Events.MEDIA_ATTACHED, this.onMediaAttached, this), t.off(k.Events.MEDIA_DETACHING, this.onMediaDetaching, this), t.off(k.Events.MANIFEST_LOADING, this.onManifestLoading, this), t.off(k.Events.LEVEL_LOADED, this.onLevelLoaded, this), t.off(k.Events.AUDIO_TRACKS_UPDATED, this.onAudioTracksUpdated, this), t.off(k.Events.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), t.off(k.Events.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), t.off(k.Events.ERROR, this.onError, this), t.off(k.Events.BUFFER_RESET, this.onBufferReset, this), t.off(k.Events.BUFFER_CREATED, this.onBufferCreated, this), t.off(k.Events.BUFFER_FLUSHED, this.onBufferFlushed, this), t.off(k.Events.INIT_PTS_FOUND, this.onInitPtsFound, this), t.off(k.Events.FRAG_BUFFERED, this.onFragBuffered, this);
          }, r.onInitPtsFound = function(t, d) {
            var e = d.frag, h = d.id, f = d.initPTS;
            if (h === "main") {
              var c = e.cc;
              this.initPTS[e.cc] = f, this.log("InitPTS for cc: " + c + " found from main: " + f), this.videoTrackCC = c, this.state === T.State.WAITING_INIT_PTS && this.tick();
            }
          }, r.startLoad = function(t) {
            if (!this.levels) {
              this.startPosition = t, this.state = T.State.STOPPED;
              return;
            }
            var d = this.lastCurrentTime;
            this.stopLoad(), this.setInterval(m), this.fragLoadError = 0, d > 0 && t === -1 ? (this.log("Override startPosition with lastCurrentTime @" + d.toFixed(3)), t = d, this.state = T.State.IDLE) : (this.loadedmetadata = !1, this.state = T.State.WAITING_TRACK), this.nextLoadPosition = this.startPosition = this.lastCurrentTime = t, this.tick();
          }, r.doTick = function() {
            switch (this.state) {
              case T.State.IDLE:
                this.doTickIdle();
                break;
              case T.State.WAITING_TRACK: {
                var t, d = this.levels, e = this.trackId, h = d == null || (t = d[e]) === null || t === void 0 ? void 0 : t.details;
                if (h) {
                  if (this.waitForCdnTuneIn(h))
                    break;
                  this.state = T.State.WAITING_INIT_PTS;
                }
                break;
              }
              case T.State.FRAG_LOADING_WAITING_RETRY: {
                var f, c = performance.now(), M = this.retryDate;
                (!M || c >= M || (f = this.media) !== null && f !== void 0 && f.seeking) && (this.log("RetryDate reached, switch back to IDLE state"), this.resetStartWhenNotLoaded(this.trackId), this.state = T.State.IDLE);
                break;
              }
              case T.State.WAITING_INIT_PTS: {
                var w = this.waitingData;
                if (w) {
                  var F = w.frag, U = w.part, N = w.cache, H = w.complete;
                  if (this.initPTS[F.cc] !== void 0) {
                    this.waitingData = null, this.waitingVideoCC = -1, this.state = T.State.FRAG_LOADING;
                    var j = N.flush(), z = {
                      frag: F,
                      part: U,
                      payload: j,
                      networkDetails: null
                    };
                    this._handleFragmentLoadProgress(z), H && n.prototype._handleFragmentLoadComplete.call(this, z);
                  } else if (this.videoTrackCC !== this.waitingVideoCC)
                    this.log("Waiting fragment cc (" + F.cc + ") cancelled because video is at cc " + this.videoTrackCC), this.clearWaitingFragment();
                  else {
                    var Y = this.getLoadPosition(), X = C.BufferHelper.bufferInfo(this.mediaBuffer, Y, this.config.maxBufferHole), Z = (0, S.fragmentWithinToleranceTest)(X.end, this.config.maxFragLookUpTolerance, F);
                    Z < 0 && (this.log("Waiting fragment cc (" + F.cc + ") @ " + F.start + " cancelled because another fragment at " + X.end + " is needed"), this.clearWaitingFragment());
                  }
                } else
                  this.state = T.State.IDLE;
              }
            }
            this.onTickEnd();
          }, r.clearWaitingFragment = function() {
            var t = this.waitingData;
            t && (this.fragmentTracker.removeFragment(t.frag), this.waitingData = null, this.waitingVideoCC = -1, this.state = T.State.IDLE);
          }, r.resetLoadingState = function() {
            this.clearWaitingFragment(), n.prototype.resetLoadingState.call(this);
          }, r.onTickEnd = function() {
            var t = this.media;
            !t || !t.readyState || (this.lastCurrentTime = t.currentTime);
          }, r.doTickIdle = function() {
            var t = this.hls, d = this.levels, e = this.media, h = this.trackId, f = t.config;
            if (!(!d || !d[h]) && !(!e && (this.startFragRequested || !f.startFragPrefetch))) {
              var c = d[h], M = c.details;
              if (!M || M.live && this.levelLastLoaded !== h || this.waitForCdnTuneIn(M)) {
                this.state = T.State.WAITING_TRACK;
                return;
              }
              var w = this.mediaBuffer ? this.mediaBuffer : this.media;
              this.bufferFlushed && w && (this.bufferFlushed = !1, this.afterBufferFlushed(w, D.ElementaryStreamTypes.AUDIO, L.PlaylistLevelType.AUDIO));
              var F = this.getFwdBufferInfo(w, L.PlaylistLevelType.AUDIO);
              if (F !== null) {
                var U = this.audioSwitch;
                if (!U && this._streamEnded(F, M)) {
                  t.trigger(k.Events.BUFFER_EOS, {
                    type: "audio"
                  }), this.state = T.State.ENDED;
                  return;
                }
                var N = this.getFwdBufferInfo(this.videoBuffer ? this.videoBuffer : this.media, L.PlaylistLevelType.MAIN), H = F.len, j = this.getMaxBufferLength(N == null ? void 0 : N.len);
                if (!(H >= j && !U)) {
                  var z = M.fragments, Y = z[0].start, X = F.end;
                  if (U && e) {
                    var Z = this.getLoadPosition();
                    X = Z, M.PTSKnown && Z < Y && (F.end > Y || F.nextStart) && (this.log("Alt audio track ahead of main track, seek to start of alt audio track"), e.currentTime = Y + 0.05);
                  }
                  if (!(N && X > N.end + M.targetduration) && !((!N || !N.len) && F.len)) {
                    var te = this.getNextFragment(X, M);
                    if (!te) {
                      this.bufferFlushed = !0;
                      return;
                    }
                    this.loadFragment(te, M, X);
                  }
                }
              }
            }
          }, r.getMaxBufferLength = function(t) {
            var d = n.prototype.getMaxBufferLength.call(this);
            return t ? Math.max(d, t) : d;
          }, r.onMediaDetaching = function() {
            this.videoBuffer = null, n.prototype.onMediaDetaching.call(this);
          }, r.onAudioTracksUpdated = function(t, d) {
            var e = d.audioTracks;
            this.resetTransmuxer(), this.levels = e.map(function(h) {
              return new I.Level(h);
            });
          }, r.onAudioTrackSwitching = function(t, d) {
            var e = !!d.url;
            this.trackId = d.id;
            var h = this.fragCurrent;
            h && h.abortRequests(), this.fragCurrent = null, this.clearWaitingFragment(), e ? this.setInterval(m) : this.resetTransmuxer(), e ? (this.audioSwitch = !0, this.state = T.State.IDLE) : this.state = T.State.STOPPED, this.tick();
          }, r.onManifestLoading = function() {
            this.mainDetails = null, this.fragmentTracker.removeAllFragments(), this.startPosition = this.lastCurrentTime = 0, this.bufferFlushed = !1;
          }, r.onLevelLoaded = function(t, d) {
            this.mainDetails = d.details, this.cachedTrackLoadedData !== null && (this.hls.trigger(k.Events.AUDIO_TRACK_LOADED, this.cachedTrackLoadedData), this.cachedTrackLoadedData = null);
          }, r.onAudioTrackLoaded = function(t, d) {
            var e;
            if (this.mainDetails == null) {
              this.cachedTrackLoadedData = d;
              return;
            }
            var h = this.levels, f = d.details, c = d.id;
            if (!h) {
              this.warn("Audio tracks were reset while loading level " + c);
              return;
            }
            this.log("Track " + c + " loaded [" + f.startSN + "," + f.endSN + "],duration:" + f.totalduration);
            var M = h[c], w = 0;
            if (f.live || (e = M.details) !== null && e !== void 0 && e.live) {
              var F = this.mainDetails;
              if (f.fragments[0] || (f.deltaUpdateFailed = !0), f.deltaUpdateFailed || !F)
                return;
              !M.details && f.hasProgramDateTime && F.hasProgramDateTime ? ((0, y.alignMediaPlaylistByPDT)(f, F), w = f.fragments[0].start) : w = this.alignPlaylists(f, M.details);
            }
            M.details = f, this.levelLastLoaded = c, !this.startFragRequested && (this.mainDetails || !f.live) && this.setStartPosition(M.details, w), this.state === T.State.WAITING_TRACK && !this.waitForCdnTuneIn(f) && (this.state = T.State.IDLE), this.tick();
          }, r._handleFragmentLoadProgress = function(t) {
            var d, e = t.frag, h = t.part, f = t.payload, c = this.config, M = this.trackId, w = this.levels;
            if (!w) {
              this.warn("Audio tracks were reset while fragment load was in progress. Fragment " + e.sn + " of level " + e.level + " will not be buffered");
              return;
            }
            var F = w[M];
            console.assert(F, "Audio track is defined on fragment load progress");
            var U = F.details;
            console.assert(U, "Audio track details are defined on fragment load progress");
            var N = c.defaultAudioCodec || F.audioCodec || "mp4a.40.2", H = this.transmuxer;
            H || (H = this.transmuxer = new x.default(this.hls, L.PlaylistLevelType.AUDIO, this._handleTransmuxComplete.bind(this), this._handleTransmuxerFlush.bind(this)));
            var j = this.initPTS[e.cc], z = (d = e.initSegment) === null || d === void 0 ? void 0 : d.data;
            if (j !== void 0) {
              var Y = !1, X = h ? h.index : -1, Z = X !== -1, te = new g.ChunkMetadata(e.level, e.sn, e.stats.chunkCount, f.byteLength, X, Z);
              H.push(f, z, N, "", e, h, U.totalduration, Y, te, j);
            } else {
              this.log("Unknown video PTS for cc " + e.cc + ", waiting for video PTS before demuxing audio frag " + e.sn + " of [" + U.startSN + " ," + U.endSN + "],track " + M);
              var $ = this.waitingData = this.waitingData || {
                frag: e,
                part: h,
                cache: new _.default(),
                complete: !1
              }, ee = $.cache;
              ee.push(new Uint8Array(f)), this.waitingVideoCC = this.videoTrackCC, this.state = T.State.WAITING_INIT_PTS;
            }
          }, r._handleFragmentLoadComplete = function(t) {
            if (this.waitingData) {
              this.waitingData.complete = !0;
              return;
            }
            n.prototype._handleFragmentLoadComplete.call(this, t);
          }, r.onBufferReset = function() {
            this.mediaBuffer = this.videoBuffer = null, this.loadedmetadata = !1;
          }, r.onBufferCreated = function(t, d) {
            var e = d.tracks.audio;
            e && (this.mediaBuffer = e.buffer || null), d.tracks.video && (this.videoBuffer = d.tracks.video.buffer || null);
          }, r.onFragBuffered = function(t, d) {
            var e = d.frag, h = d.part;
            if (e.type !== L.PlaylistLevelType.AUDIO) {
              if (!this.loadedmetadata && e.type === L.PlaylistLevelType.MAIN) {
                var f;
                (f = this.videoBuffer || this.media) !== null && f !== void 0 && f.buffered.length && (this.loadedmetadata = !0);
              }
              return;
            }
            if (this.fragContextChanged(e)) {
              this.warn("Fragment " + e.sn + (h ? " p: " + h.index : "") + " of level " + e.level + " finished buffering, but was aborted. state: " + this.state + ", audioSwitch: " + this.audioSwitch);
              return;
            }
            e.sn !== "initSegment" && (this.fragPrevious = e, this.audioSwitch && (this.audioSwitch = !1, this.hls.trigger(k.Events.AUDIO_TRACK_SWITCHED, {
              id: this.trackId
            }))), this.fragBufferedComplete(e, h);
          }, r.onError = function(t, d) {
            if (d.type === l.ErrorTypes.KEY_SYSTEM_ERROR) {
              this.onFragmentOrKeyLoadError(L.PlaylistLevelType.AUDIO, d);
              return;
            }
            switch (d.details) {
              case l.ErrorDetails.FRAG_LOAD_ERROR:
              case l.ErrorDetails.FRAG_LOAD_TIMEOUT:
              case l.ErrorDetails.FRAG_PARSING_ERROR:
              case l.ErrorDetails.KEY_LOAD_ERROR:
              case l.ErrorDetails.KEY_LOAD_TIMEOUT:
                this.onFragmentOrKeyLoadError(L.PlaylistLevelType.AUDIO, d);
                break;
              case l.ErrorDetails.AUDIO_TRACK_LOAD_ERROR:
              case l.ErrorDetails.AUDIO_TRACK_LOAD_TIMEOUT:
                this.state !== T.State.ERROR && this.state !== T.State.STOPPED && (this.state = d.fatal ? T.State.ERROR : T.State.IDLE, this.warn(d.details + " while loading frag, switching to " + this.state + " state"));
                break;
              case l.ErrorDetails.BUFFER_FULL_ERROR:
                if (d.parent === "audio" && (this.state === T.State.PARSING || this.state === T.State.PARSED)) {
                  var e = !0, h = this.getFwdBufferInfo(this.mediaBuffer, L.PlaylistLevelType.AUDIO);
                  h && h.len > 0.5 && (e = !this.reduceMaxBufferLength(h.len)), e && (this.warn("Buffer full error also media.currentTime is not buffered, flush audio buffer"), this.fragCurrent = null, n.prototype.flushMainBuffer.call(this, 0, Number.POSITIVE_INFINITY, "audio")), this.resetLoadingState();
                }
                break;
            }
          }, r.onBufferFlushed = function(t, d) {
            var e = d.type;
            e === D.ElementaryStreamTypes.AUDIO && (this.bufferFlushed = !0, this.state === T.State.ENDED && (this.state = T.State.IDLE));
          }, r._handleTransmuxComplete = function(t) {
            var d, e = "audio", h = this.hls, f = t.remuxResult, c = t.chunkMeta, M = this.getCurrentContext(c);
            if (!M) {
              this.warn("The loading context changed while buffering fragment " + c.sn + " of level " + c.level + ". This chunk will not be buffered."), this.resetStartWhenNotLoaded(c.level);
              return;
            }
            var w = M.frag, F = M.part, U = M.level.details, N = f.audio, H = f.text, j = f.id3, z = f.initSegment;
            if (!(this.fragContextChanged(w) || !U)) {
              if (this.state = T.State.PARSING, this.audioSwitch && N && this.completeAudioSwitch(), z != null && z.tracks && (this._bufferInitSegment(z.tracks, w, c), h.trigger(k.Events.FRAG_PARSING_INIT_SEGMENT, {
                frag: w,
                id: e,
                tracks: z.tracks
              })), N) {
                var Y = N.startPTS, X = N.endPTS, Z = N.startDTS, te = N.endDTS;
                F && (F.elementaryStreams[D.ElementaryStreamTypes.AUDIO] = {
                  startPTS: Y,
                  endPTS: X,
                  startDTS: Z,
                  endDTS: te
                }), w.setElementaryStreamInfo(D.ElementaryStreamTypes.AUDIO, Y, X, Z, te), this.bufferFragmentData(N, w, F, c);
              }
              if (j != null && (d = j.samples) !== null && d !== void 0 && d.length) {
                var $ = u({
                  id: e,
                  frag: w,
                  details: U
                }, j);
                h.trigger(k.Events.FRAG_PARSING_METADATA, $);
              }
              if (H) {
                var ee = u({
                  id: e,
                  frag: w,
                  details: U
                }, H);
                h.trigger(k.Events.FRAG_PARSING_USERDATA, ee);
              }
            }
          }, r._bufferInitSegment = function(t, d, e) {
            if (this.state === T.State.PARSING) {
              t.video && delete t.video;
              var h = t.audio;
              if (!!h) {
                h.levelCodec = h.codec, h.id = "audio", this.log("Init audio buffer, container:" + h.container + ", codecs[parsed]=[" + h.codec + "]"), this.hls.trigger(k.Events.BUFFER_CODECS, t);
                var f = h.initSegment;
                if (f != null && f.byteLength) {
                  var c = {
                    type: "audio",
                    frag: d,
                    part: null,
                    chunkMeta: e,
                    parent: d.type,
                    data: f
                  };
                  this.hls.trigger(k.Events.BUFFER_APPENDING, c);
                }
                this.tick();
              }
            }
          }, r.loadFragment = function(t, d, e) {
            var h = this.fragmentTracker.getState(t);
            this.fragCurrent = t, (this.audioSwitch || h === B.FragmentState.NOT_LOADED || h === B.FragmentState.PARTIAL) && (t.sn === "initSegment" ? this._loadInitSegment(t, d) : d.live && !(0, P.isFiniteNumber)(this.initPTS[t.cc]) ? (this.log("Waiting for video PTS in continuity counter " + t.cc + " of live stream before loading audio fragment " + t.sn + " of level " + this.trackId), this.state = T.State.WAITING_INIT_PTS) : (this.startFragRequested = !0, n.prototype.loadFragment.call(this, t, d, e)));
          }, r.completeAudioSwitch = function() {
            var t = this.hls, d = this.media, e = this.trackId;
            d && (this.log("Switching audio track : flushing all audio"), n.prototype.flushMainBuffer.call(this, 0, Number.POSITIVE_INFINITY, "audio")), this.audioSwitch = !1, t.trigger(k.Events.AUDIO_TRACK_SWITCHED, {
              id: e
            });
          }, E;
        }(T.default);
        const i = v;
      },
      "./src/controller/audio-track-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => S
        });
        var P = p("./src/events.ts"), T = p("./src/errors.ts"), k = p("./src/controller/base-playlist-controller.ts"), C = p("./src/types/loader.ts");
        function B(y, l) {
          for (var u = 0; u < l.length; u++) {
            var a = l[u];
            a.enumerable = a.enumerable || !1, a.configurable = !0, "value" in a && (a.writable = !0), Object.defineProperty(y, L(a.key), a);
          }
        }
        function I(y, l, u) {
          return l && B(y.prototype, l), u && B(y, u), Object.defineProperty(y, "prototype", { writable: !1 }), y;
        }
        function L(y) {
          var l = D(y, "string");
          return typeof l == "symbol" ? l : String(l);
        }
        function D(y, l) {
          if (typeof y != "object" || y === null)
            return y;
          var u = y[Symbol.toPrimitive];
          if (u !== void 0) {
            var a = u.call(y, l || "default");
            if (typeof a != "object")
              return a;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (l === "string" ? String : Number)(y);
        }
        function _(y, l) {
          y.prototype = Object.create(l.prototype), y.prototype.constructor = y, x(y, l);
        }
        function x(y, l) {
          return x = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(a, s) {
            return a.__proto__ = s, a;
          }, x(y, l);
        }
        var g = /* @__PURE__ */ function(y) {
          _(l, y);
          function l(a) {
            var s;
            return s = y.call(this, a, "[audio-track-controller]") || this, s.tracks = [], s.groupId = null, s.tracksInGroup = [], s.trackId = -1, s.trackName = "", s.selectDefaultTrack = !0, s.registerListeners(), s;
          }
          var u = l.prototype;
          return u.registerListeners = function() {
            var s = this.hls;
            s.on(P.Events.MANIFEST_LOADING, this.onManifestLoading, this), s.on(P.Events.MANIFEST_PARSED, this.onManifestParsed, this), s.on(P.Events.LEVEL_LOADING, this.onLevelLoading, this), s.on(P.Events.LEVEL_SWITCHING, this.onLevelSwitching, this), s.on(P.Events.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), s.on(P.Events.ERROR, this.onError, this);
          }, u.unregisterListeners = function() {
            var s = this.hls;
            s.off(P.Events.MANIFEST_LOADING, this.onManifestLoading, this), s.off(P.Events.MANIFEST_PARSED, this.onManifestParsed, this), s.off(P.Events.LEVEL_LOADING, this.onLevelLoading, this), s.off(P.Events.LEVEL_SWITCHING, this.onLevelSwitching, this), s.off(P.Events.AUDIO_TRACK_LOADED, this.onAudioTrackLoaded, this), s.off(P.Events.ERROR, this.onError, this);
          }, u.destroy = function() {
            this.unregisterListeners(), this.tracks.length = 0, this.tracksInGroup.length = 0, y.prototype.destroy.call(this);
          }, u.onManifestLoading = function() {
            this.tracks = [], this.groupId = null, this.tracksInGroup = [], this.trackId = -1, this.trackName = "", this.selectDefaultTrack = !0;
          }, u.onManifestParsed = function(s, m) {
            this.tracks = m.audioTracks || [];
          }, u.onAudioTrackLoaded = function(s, m) {
            var v = m.id, i = m.details, n = this.tracksInGroup[v];
            if (!n) {
              this.warn("Invalid audio track id " + v);
              return;
            }
            var E = n.details;
            n.details = m.details, this.log("audioTrack " + v + " loaded [" + i.startSN + "-" + i.endSN + "]"), v === this.trackId && (this.retryCount = 0, this.playlistLoaded(v, m, E));
          }, u.onLevelLoading = function(s, m) {
            this.switchLevel(m.level);
          }, u.onLevelSwitching = function(s, m) {
            this.switchLevel(m.level);
          }, u.switchLevel = function(s) {
            var m = this.hls.levels[s];
            if (!!(m != null && m.audioGroupIds)) {
              var v = m.audioGroupIds[m.urlId];
              if (this.groupId !== v) {
                this.groupId = v;
                var i = this.tracks.filter(function(E) {
                  return !v || E.groupId === v;
                });
                this.selectDefaultTrack && !i.some(function(E) {
                  return E.default;
                }) && (this.selectDefaultTrack = !1), this.tracksInGroup = i;
                var n = {
                  audioTracks: i
                };
                this.log("Updating audio tracks, " + i.length + ' track(s) found in "' + v + '" group-id'), this.hls.trigger(P.Events.AUDIO_TRACKS_UPDATED, n), this.selectInitialTrack();
              }
            }
          }, u.onError = function(s, m) {
            y.prototype.onError.call(this, s, m), !(m.fatal || !m.context) && m.context.type === C.PlaylistContextType.AUDIO_TRACK && m.context.id === this.trackId && m.context.groupId === this.groupId && this.retryLoadingOrFail(m);
          }, u.setAudioTrack = function(s) {
            var m = this.tracksInGroup;
            if (s < 0 || s >= m.length) {
              this.warn("Invalid id passed to audio-track controller");
              return;
            }
            this.clearTimer();
            var v = m[this.trackId];
            this.log("Now switching to audio-track index " + s);
            var i = m[s], n = i.id, E = i.groupId, r = E === void 0 ? "" : E, o = i.name, t = i.type, d = i.url;
            if (this.trackId = s, this.trackName = o, this.selectDefaultTrack = !1, this.hls.trigger(P.Events.AUDIO_TRACK_SWITCHING, {
              id: n,
              groupId: r,
              name: o,
              type: t,
              url: d
            }), !(i.details && !i.details.live)) {
              var e = this.switchParams(i.url, v == null ? void 0 : v.details);
              this.loadPlaylist(e);
            }
          }, u.selectInitialTrack = function() {
            var s = this.tracksInGroup;
            console.assert(s.length, "Initial audio track should be selected when tracks are known");
            var m = this.trackName, v = this.findTrackId(m) || this.findTrackId();
            v !== -1 ? this.setAudioTrack(v) : (this.warn("No track found for running audio group-ID: " + this.groupId), this.hls.trigger(P.Events.ERROR, {
              type: T.ErrorTypes.MEDIA_ERROR,
              details: T.ErrorDetails.AUDIO_TRACK_LOAD_ERROR,
              fatal: !0
            }));
          }, u.findTrackId = function(s) {
            for (var m = this.tracksInGroup, v = 0; v < m.length; v++) {
              var i = m[v];
              if ((!this.selectDefaultTrack || i.default) && (!s || s === i.name))
                return i.id;
            }
            return -1;
          }, u.loadPlaylist = function(s) {
            y.prototype.loadPlaylist.call(this);
            var m = this.tracksInGroup[this.trackId];
            if (this.shouldLoadTrack(m)) {
              var v = m.id, i = m.groupId, n = m.url;
              if (s)
                try {
                  n = s.addDirectives(n);
                } catch (E) {
                  this.warn("Could not construct new URL with HLS Delivery Directives: " + E);
                }
              this.log("loading audio-track playlist for id: " + v), this.clearTimer(), this.hls.trigger(P.Events.AUDIO_TRACK_LOADING, {
                url: n,
                id: v,
                groupId: i,
                deliveryDirectives: s || null
              });
            }
          }, I(l, [{
            key: "audioTracks",
            get: function() {
              return this.tracksInGroup;
            }
          }, {
            key: "audioTrack",
            get: function() {
              return this.trackId;
            },
            set: function(s) {
              this.selectDefaultTrack = !1, this.setAudioTrack(s);
            }
          }]), l;
        }(k.default);
        const S = g;
      },
      "./src/controller/base-playlist-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => B
        });
        var P = p("./src/types/level.ts"), T = p("./src/controller/level-helper.ts"), k = p("./src/utils/logger.ts"), C = p("./src/errors.ts"), B = /* @__PURE__ */ function() {
          function I(D, _) {
            this.hls = void 0, this.timer = -1, this.requestScheduled = -1, this.canLoad = !1, this.retryCount = 0, this.log = void 0, this.warn = void 0, this.log = k.logger.log.bind(k.logger, _ + ":"), this.warn = k.logger.warn.bind(k.logger, _ + ":"), this.hls = D;
          }
          var L = I.prototype;
          return L.destroy = function() {
            this.clearTimer(), this.hls = this.log = this.warn = null;
          }, L.onError = function(_, x) {
            x.fatal && (x.type === C.ErrorTypes.NETWORK_ERROR || x.type === C.ErrorTypes.KEY_SYSTEM_ERROR) && this.stopLoad();
          }, L.clearTimer = function() {
            clearTimeout(this.timer), this.timer = -1;
          }, L.startLoad = function() {
            this.canLoad = !0, this.retryCount = 0, this.requestScheduled = -1, this.loadPlaylist();
          }, L.stopLoad = function() {
            this.canLoad = !1, this.clearTimer();
          }, L.switchParams = function(_, x) {
            var g = x == null ? void 0 : x.renditionReports;
            if (g)
              for (var S = 0; S < g.length; S++) {
                var y = g[S], l = void 0;
                try {
                  l = new self.URL(y.URI, x.url).href;
                } catch (m) {
                  k.logger.warn("Could not construct new URL for Rendition Report: " + m), l = y.URI || "";
                }
                if (l === _.slice(-l.length)) {
                  var u = parseInt(y["LAST-MSN"]) || (x == null ? void 0 : x.lastPartSn), a = parseInt(y["LAST-PART"]) || (x == null ? void 0 : x.lastPartIndex);
                  if (this.hls.config.lowLatencyMode) {
                    var s = Math.min(x.age - x.partTarget, x.targetduration);
                    a >= 0 && s > x.partTarget && (a += 1);
                  }
                  return new P.HlsUrlParameters(u, a >= 0 ? a : void 0, P.HlsSkip.No);
                }
              }
          }, L.loadPlaylist = function(_) {
            this.requestScheduled === -1 && (this.requestScheduled = self.performance.now());
          }, L.shouldLoadTrack = function(_) {
            return this.canLoad && _ && !!_.url && (!_.details || _.details.live);
          }, L.playlistLoaded = function(_, x, g) {
            var S = this, y = x.details, l = x.stats, u = self.performance.now(), a = l.loading.first ? Math.max(0, u - l.loading.first) : 0;
            if (y.advancedDateTime = Date.now() - a, y.live || g != null && g.live) {
              if (y.reloaded(g), g && this.log("live playlist " + _ + " " + (y.advanced ? "REFRESHED " + y.lastPartSn + "-" + y.lastPartIndex : "MISSED")), g && y.fragments.length > 0 && (0, T.mergeDetails)(g, y), !this.canLoad || !y.live)
                return;
              var s, m = void 0, v = void 0;
              if (y.canBlockReload && y.endSN && y.advanced) {
                var i = this.hls.config.lowLatencyMode, n = y.lastPartSn, E = y.endSN, r = y.lastPartIndex, o = r !== -1, t = n === E, d = i ? 0 : r;
                o ? (m = t ? E + 1 : n, v = t ? d : r + 1) : m = E + 1;
                var e = y.age, h = e + y.ageHeader, f = Math.min(h - y.partTarget, y.targetduration * 1.5);
                if (f > 0) {
                  if (g && f > g.tuneInGoal)
                    this.warn("CDN Tune-in goal increased from: " + g.tuneInGoal + " to: " + f + " with playlist age: " + y.age), f = 0;
                  else {
                    var c = Math.floor(f / y.targetduration);
                    if (m += c, v !== void 0) {
                      var M = Math.round(f % y.targetduration / y.partTarget);
                      v += M;
                    }
                    this.log("CDN Tune-in age: " + y.ageHeader + "s last advanced " + e.toFixed(2) + "s goal: " + f + " skip sn " + c + " to part " + v);
                  }
                  y.tuneInGoal = f;
                }
                if (s = this.getDeliveryDirectives(y, x.deliveryDirectives, m, v), i || !t) {
                  this.loadPlaylist(s);
                  return;
                }
              } else
                s = this.getDeliveryDirectives(y, x.deliveryDirectives, m, v);
              var w = this.hls.mainForwardBufferInfo, F = w ? w.end - w.len : 0, U = (y.edge - F) * 1e3, N = (0, T.computeReloadInterval)(y, U);
              y.updated ? u > this.requestScheduled + N && (this.requestScheduled = l.loading.start) : this.requestScheduled = -1, m !== void 0 && y.canBlockReload ? this.requestScheduled = l.loading.first + N - (y.partTarget * 1e3 || 1e3) : this.requestScheduled = (this.requestScheduled === -1 ? u : this.requestScheduled) + N;
              var H = this.requestScheduled - u;
              H = Math.max(0, H), this.log("reload live playlist " + _ + " in " + Math.round(H) + " ms"), this.timer = self.setTimeout(function() {
                return S.loadPlaylist(s);
              }, H);
            } else
              this.clearTimer();
          }, L.getDeliveryDirectives = function(_, x, g, S) {
            var y = (0, P.getSkipValue)(_, g);
            return x != null && x.skip && _.deltaUpdateFailed && (g = x.msn, S = x.part, y = P.HlsSkip.No), new P.HlsUrlParameters(g, S, y);
          }, L.retryLoadingOrFail = function(_) {
            var x = this, g = this.hls.config, S = this.retryCount < g.levelLoadingMaxRetry;
            if (S) {
              var y;
              if (this.requestScheduled = -1, this.retryCount++, _.details.indexOf("LoadTimeOut") > -1 && (y = _.context) !== null && y !== void 0 && y.deliveryDirectives)
                this.warn("retry playlist loading #" + this.retryCount + ' after "' + _.details + '"'), this.loadPlaylist();
              else {
                var l = Math.min(Math.pow(2, this.retryCount) * g.levelLoadingRetryDelay, g.levelLoadingMaxRetryTimeout);
                this.timer = self.setTimeout(function() {
                  return x.loadPlaylist();
                }, l), this.warn("retry playlist loading #" + this.retryCount + " in " + l + ' ms after "' + _.details + '"');
              }
            } else
              this.warn('cannot recover from error "' + _.details + '"'), this.clearTimer(), _.fatal = !0;
            return S;
          }, I;
        }();
      },
      "./src/controller/base-stream-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          State: () => o,
          default: () => t
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/task-loop.ts"), k = p("./src/controller/fragment-tracker.ts"), C = p("./src/utils/buffer-helper.ts"), B = p("./src/utils/logger.ts"), I = p("./src/events.ts"), L = p("./src/errors.ts"), D = p("./src/types/transmuxer.ts"), _ = p("./src/utils/mp4-tools.ts"), x = p("./src/utils/discontinuities.ts"), g = p("./src/controller/fragment-finders.ts"), S = p("./src/controller/level-helper.ts"), y = p("./src/loader/fragment-loader.ts"), l = p("./src/crypt/decrypter.ts"), u = p("./src/utils/time-ranges.ts"), a = p("./src/types/loader.ts");
        function s(d, e) {
          for (var h = 0; h < e.length; h++) {
            var f = e[h];
            f.enumerable = f.enumerable || !1, f.configurable = !0, "value" in f && (f.writable = !0), Object.defineProperty(d, v(f.key), f);
          }
        }
        function m(d, e, h) {
          return e && s(d.prototype, e), h && s(d, h), Object.defineProperty(d, "prototype", { writable: !1 }), d;
        }
        function v(d) {
          var e = i(d, "string");
          return typeof e == "symbol" ? e : String(e);
        }
        function i(d, e) {
          if (typeof d != "object" || d === null)
            return d;
          var h = d[Symbol.toPrimitive];
          if (h !== void 0) {
            var f = h.call(d, e || "default");
            if (typeof f != "object")
              return f;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (e === "string" ? String : Number)(d);
        }
        function n(d) {
          if (d === void 0)
            throw new ReferenceError("this hasn't been initialised - super() hasn't been called");
          return d;
        }
        function E(d, e) {
          d.prototype = Object.create(e.prototype), d.prototype.constructor = d, r(d, e);
        }
        function r(d, e) {
          return r = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(f, c) {
            return f.__proto__ = c, f;
          }, r(d, e);
        }
        var o = {
          STOPPED: "STOPPED",
          IDLE: "IDLE",
          KEY_LOADING: "KEY_LOADING",
          FRAG_LOADING: "FRAG_LOADING",
          FRAG_LOADING_WAITING_RETRY: "FRAG_LOADING_WAITING_RETRY",
          WAITING_TRACK: "WAITING_TRACK",
          PARSING: "PARSING",
          PARSED: "PARSED",
          ENDED: "ENDED",
          ERROR: "ERROR",
          WAITING_INIT_PTS: "WAITING_INIT_PTS",
          WAITING_LEVEL: "WAITING_LEVEL"
        }, t = /* @__PURE__ */ function(d) {
          E(e, d);
          function e(f, c, M, w) {
            var F;
            return F = d.call(this) || this, F.hls = void 0, F.fragPrevious = null, F.fragCurrent = null, F.fragmentTracker = void 0, F.transmuxer = null, F._state = o.STOPPED, F.media = null, F.mediaBuffer = null, F.config = void 0, F.bitrateTest = !1, F.lastCurrentTime = 0, F.nextLoadPosition = 0, F.startPosition = 0, F.loadedmetadata = !1, F.fragLoadError = 0, F.retryDate = 0, F.levels = null, F.fragmentLoader = void 0, F.keyLoader = void 0, F.levelLastLoaded = null, F.startFragRequested = !1, F.decrypter = void 0, F.initPTS = [], F.onvseeking = null, F.onvended = null, F.logPrefix = "", F.log = void 0, F.warn = void 0, F.logPrefix = w, F.log = B.logger.log.bind(B.logger, w + ":"), F.warn = B.logger.warn.bind(B.logger, w + ":"), F.hls = f, F.fragmentLoader = new y.default(f.config), F.keyLoader = M, F.fragmentTracker = c, F.config = f.config, F.decrypter = new l.default(f.config), f.on(I.Events.LEVEL_SWITCHING, F.onLevelSwitching, n(F)), F;
          }
          var h = e.prototype;
          return h.doTick = function() {
            this.onTickEnd();
          }, h.onTickEnd = function() {
          }, h.startLoad = function(c) {
          }, h.stopLoad = function() {
            this.fragmentLoader.abort(), this.keyLoader.abort();
            var c = this.fragCurrent;
            c && (c.abortRequests(), this.fragmentTracker.removeFragment(c)), this.resetTransmuxer(), this.fragCurrent = null, this.fragPrevious = null, this.clearInterval(), this.clearNextTick(), this.state = o.STOPPED;
          }, h._streamEnded = function(c, M) {
            if (M.live || c.nextStart || !c.end || !this.media)
              return !1;
            var w = M.partList;
            if (w != null && w.length) {
              var F = w[w.length - 1], U = C.BufferHelper.isBuffered(this.media, F.start + F.duration / 2);
              return U;
            }
            var N = M.fragments[M.fragments.length - 1].type;
            return this.fragmentTracker.isEndListAppended(N);
          }, h.getLevelDetails = function() {
            if (this.levels && this.levelLastLoaded !== null) {
              var c;
              return (c = this.levels[this.levelLastLoaded]) === null || c === void 0 ? void 0 : c.details;
            }
          }, h.onMediaAttached = function(c, M) {
            var w = this.media = this.mediaBuffer = M.media;
            this.onvseeking = this.onMediaSeeking.bind(this), this.onvended = this.onMediaEnded.bind(this), w.addEventListener("seeking", this.onvseeking), w.addEventListener("ended", this.onvended);
            var F = this.config;
            this.levels && F.autoStartLoad && this.state === o.STOPPED && this.startLoad(F.startPosition);
          }, h.onMediaDetaching = function() {
            var c = this.media;
            c != null && c.ended && (this.log("MSE detaching and video ended, reset startPosition"), this.startPosition = this.lastCurrentTime = 0), c && this.onvseeking && this.onvended && (c.removeEventListener("seeking", this.onvseeking), c.removeEventListener("ended", this.onvended), this.onvseeking = this.onvended = null), this.keyLoader && this.keyLoader.detach(), this.media = this.mediaBuffer = null, this.loadedmetadata = !1, this.fragmentTracker.removeAllFragments(), this.stopLoad();
          }, h.onMediaSeeking = function() {
            var c = this.config, M = this.fragCurrent, w = this.media, F = this.mediaBuffer, U = this.state, N = w ? w.currentTime : 0, H = C.BufferHelper.bufferInfo(F || w, N, c.maxBufferHole);
            if (this.log("media seeking to " + ((0, P.isFiniteNumber)(N) ? N.toFixed(3) : N) + ", state: " + U), this.state === o.ENDED)
              this.resetLoadingState();
            else if (M) {
              var j = c.maxFragLookUpTolerance, z = M.start - j, Y = M.start + M.duration + j;
              if (!H.len || Y < H.start || z > H.end) {
                var X = N > Y;
                (N < z || X) && (X && M.loader && (this.log("seeking outside of buffer while fragment load in progress, cancel fragment load"), M.abortRequests()), this.resetLoadingState());
              }
            }
            w && (this.lastCurrentTime = N), !this.loadedmetadata && !H.len && (this.nextLoadPosition = this.startPosition = N), this.tickImmediate();
          }, h.onMediaEnded = function() {
            this.startPosition = this.lastCurrentTime = 0;
          }, h.onLevelSwitching = function(c, M) {
            this.fragLoadError = 0;
          }, h.onHandlerDestroying = function() {
            this.stopLoad(), d.prototype.onHandlerDestroying.call(this);
          }, h.onHandlerDestroyed = function() {
            this.state = o.STOPPED, this.hls.off(I.Events.LEVEL_SWITCHING, this.onLevelSwitching, this), this.fragmentLoader && this.fragmentLoader.destroy(), this.keyLoader && this.keyLoader.destroy(), this.decrypter && this.decrypter.destroy(), this.hls = this.log = this.warn = this.decrypter = this.keyLoader = this.fragmentLoader = this.fragmentTracker = null, d.prototype.onHandlerDestroyed.call(this);
          }, h.loadFragment = function(c, M, w) {
            this._loadFragForPlayback(c, M, w);
          }, h._loadFragForPlayback = function(c, M, w) {
            var F = this, U = function(H) {
              if (F.fragContextChanged(c)) {
                F.warn("Fragment " + c.sn + (H.part ? " p: " + H.part.index : "") + " of level " + c.level + " was dropped during download."), F.fragmentTracker.removeFragment(c);
                return;
              }
              c.stats.chunkCount++, F._handleFragmentLoadProgress(H);
            };
            this._doFragLoad(c, M, w, U).then(function(N) {
              if (!!N) {
                F.fragLoadError = 0;
                var H = F.state;
                if (F.fragContextChanged(c)) {
                  (H === o.FRAG_LOADING || !F.fragCurrent && H === o.PARSING) && (F.fragmentTracker.removeFragment(c), F.state = o.IDLE);
                  return;
                }
                "payload" in N && (F.log("Loaded fragment " + c.sn + " of level " + c.level), F.hls.trigger(I.Events.FRAG_LOADED, N)), F._handleFragmentLoadComplete(N);
              }
            }).catch(function(N) {
              F.state === o.STOPPED || F.state === o.ERROR || (F.warn(N), F.resetFragmentLoading(c));
            });
          }, h.flushMainBuffer = function(c, M, w) {
            if (w === void 0 && (w = null), !!(c - M)) {
              var F = {
                startOffset: c,
                endOffset: M,
                type: w
              };
              this.fragLoadError = 0, this.hls.trigger(I.Events.BUFFER_FLUSHING, F);
            }
          }, h._loadInitSegment = function(c, M) {
            var w = this;
            this._doFragLoad(c, M).then(function(F) {
              if (!F || w.fragContextChanged(c) || !w.levels)
                throw new Error("init load aborted");
              return F;
            }).then(function(F) {
              var U = w.hls, N = F.payload, H = c.decryptdata;
              if (N && N.byteLength > 0 && H && H.key && H.iv && H.method === "AES-128") {
                var j = self.performance.now();
                return w.decrypter.decrypt(new Uint8Array(N), H.key.buffer, H.iv.buffer).then(function(z) {
                  var Y = self.performance.now();
                  return U.trigger(I.Events.FRAG_DECRYPTED, {
                    frag: c,
                    payload: z,
                    stats: {
                      tstart: j,
                      tdecrypt: Y
                    }
                  }), F.payload = z, F;
                });
              }
              return F;
            }).then(function(F) {
              var U = w.fragCurrent, N = w.hls, H = w.levels;
              if (!H)
                throw new Error("init load aborted, missing levels");
              var j = H[c.level].details;
              console.assert(j, "Level details are defined when init segment is loaded");
              var z = c.stats;
              w.state = o.IDLE, w.fragLoadError = 0, c.data = new Uint8Array(F.payload), z.parsing.start = z.buffering.start = self.performance.now(), z.parsing.end = z.buffering.end = self.performance.now(), F.frag === U && N.trigger(I.Events.FRAG_BUFFERED, {
                stats: z,
                frag: U,
                part: null,
                id: c.type
              }), w.tick();
            }).catch(function(F) {
              w.state === o.STOPPED || w.state === o.ERROR || (w.warn(F), w.resetFragmentLoading(c));
            });
          }, h.fragContextChanged = function(c) {
            var M = this.fragCurrent;
            return !c || !M || c.level !== M.level || c.sn !== M.sn || c.urlId !== M.urlId;
          }, h.fragBufferedComplete = function(c, M) {
            var w, F, U = this.mediaBuffer ? this.mediaBuffer : this.media;
            this.log("Buffered " + c.type + " sn: " + c.sn + (M ? " part: " + M.index : "") + " of " + (this.logPrefix === "[stream-controller]" ? "level" : "track") + " " + c.level + " (frag:[" + (c.startPTS || NaN).toFixed(3) + "-" + (c.endPTS || NaN).toFixed(3) + "] > buffer:" + (U ? u.default.toString(C.BufferHelper.getBuffered(U)) : "(detached)") + ")"), this.state = o.IDLE, U && (!this.loadedmetadata && c.type == a.PlaylistLevelType.MAIN && U.buffered.length && ((w = this.fragCurrent) === null || w === void 0 ? void 0 : w.sn) === ((F = this.fragPrevious) === null || F === void 0 ? void 0 : F.sn) && (this.loadedmetadata = !0, this.seekToStartPos()), this.tick());
          }, h.seekToStartPos = function() {
          }, h._handleFragmentLoadComplete = function(c) {
            var M = this.transmuxer;
            if (!!M) {
              var w = c.frag, F = c.part, U = c.partsLoaded, N = !U || U.length === 0 || U.some(function(j) {
                return !j;
              }), H = new D.ChunkMetadata(w.level, w.sn, w.stats.chunkCount + 1, 0, F ? F.index : -1, !N);
              M.flush(H);
            }
          }, h._handleFragmentLoadProgress = function(c) {
          }, h._doFragLoad = function(c, M, w, F) {
            var U, N = this;
            if (w === void 0 && (w = null), !this.levels)
              throw new Error("frag load aborted, missing levels");
            var H = null;
            if (c.encrypted && !((U = c.decryptdata) !== null && U !== void 0 && U.key) ? (this.log("Loading key for " + c.sn + " of [" + M.startSN + "-" + M.endSN + "], " + (this.logPrefix === "[stream-controller]" ? "level" : "track") + " " + c.level), this.state = o.KEY_LOADING, this.fragCurrent = c, H = this.keyLoader.load(c).then(function(Z) {
              if (!N.fragContextChanged(Z.frag))
                return N.hls.trigger(I.Events.KEY_LOADED, Z), N.state === o.KEY_LOADING && (N.state = o.IDLE), Z;
            }), this.hls.trigger(I.Events.KEY_LOADING, {
              frag: c
            }), this.throwIfFragContextChanged("KEY_LOADING")) : !c.encrypted && M.encryptedFragments.length && this.keyLoader.loadClear(c, M.encryptedFragments), w = Math.max(c.start, w || 0), this.config.lowLatencyMode && M) {
              var j = M.partList;
              if (j && F) {
                w > c.end && M.fragmentHint && (c = M.fragmentHint);
                var z = this.getNextPart(j, c, w);
                if (z > -1) {
                  var Y = j[z];
                  return this.log("Loading part sn: " + c.sn + " p: " + Y.index + " cc: " + c.cc + " of playlist [" + M.startSN + "-" + M.endSN + "] parts [0-" + z + "-" + (j.length - 1) + "] " + (this.logPrefix === "[stream-controller]" ? "level" : "track") + ": " + c.level + ", target: " + parseFloat(w.toFixed(3))), this.nextLoadPosition = Y.start + Y.duration, this.state = o.FRAG_LOADING, this.hls.trigger(I.Events.FRAG_LOADING, {
                    frag: c,
                    part: j[z],
                    targetBufferTime: w
                  }), this.throwIfFragContextChanged("FRAG_LOADING parts"), H ? H.then(function(Z) {
                    return !Z || N.fragContextChanged(Z.frag) ? null : N.doFragPartsLoad(c, j, z, F);
                  }).catch(function(Z) {
                    return N.handleFragLoadError(Z);
                  }) : this.doFragPartsLoad(c, j, z, F).catch(function(Z) {
                    return N.handleFragLoadError(Z);
                  });
                } else if (!c.url || this.loadedEndOfParts(j, w))
                  return Promise.resolve(null);
              }
            }
            this.log("Loading fragment " + c.sn + " cc: " + c.cc + " " + (M ? "of [" + M.startSN + "-" + M.endSN + "] " : "") + (this.logPrefix === "[stream-controller]" ? "level" : "track") + ": " + c.level + ", target: " + parseFloat(w.toFixed(3))), (0, P.isFiniteNumber)(c.sn) && !this.bitrateTest && (this.nextLoadPosition = c.start + c.duration), this.state = o.FRAG_LOADING, this.hls.trigger(I.Events.FRAG_LOADING, {
              frag: c,
              targetBufferTime: w
            }), this.throwIfFragContextChanged("FRAG_LOADING");
            var X = this.config.progressive;
            return X && H ? H.then(function(Z) {
              return !Z || N.fragContextChanged(Z == null ? void 0 : Z.frag) ? null : N.fragmentLoader.load(c, F);
            }).catch(function(Z) {
              return N.handleFragLoadError(Z);
            }) : Promise.all([this.fragmentLoader.load(c, X ? F : void 0), H]).then(function(Z) {
              var te = Z[0];
              return !X && te && F && F(te), te;
            }).catch(function(Z) {
              return N.handleFragLoadError(Z);
            });
          }, h.throwIfFragContextChanged = function(c) {
            if (this.fragCurrent === null)
              throw new Error("frag load aborted, context changed in " + c);
          }, h.doFragPartsLoad = function(c, M, w, F) {
            var U = this;
            return new Promise(function(N, H) {
              var j = [], z = function Y(X) {
                var Z = M[X];
                U.fragmentLoader.loadPart(c, Z, F).then(function(te) {
                  j[Z.index] = te;
                  var $ = te.part;
                  U.hls.trigger(I.Events.FRAG_LOADED, te);
                  var ee = M[X + 1];
                  if (ee && ee.fragment === c)
                    Y(X + 1);
                  else
                    return N({
                      frag: c,
                      part: $,
                      partsLoaded: j
                    });
                }).catch(H);
              };
              z(w);
            });
          }, h.handleFragLoadError = function(c) {
            if ("data" in c) {
              var M = c.data;
              c.data && M.details === L.ErrorDetails.INTERNAL_ABORTED ? this.handleFragLoadAborted(M.frag, M.part) : this.hls.trigger(I.Events.ERROR, M);
            } else
              this.hls.trigger(I.Events.ERROR, {
                type: L.ErrorTypes.OTHER_ERROR,
                details: L.ErrorDetails.INTERNAL_EXCEPTION,
                err: c,
                fatal: !0
              });
            return null;
          }, h._handleTransmuxerFlush = function(c) {
            var M = this.getCurrentContext(c);
            if (!M || this.state !== o.PARSING) {
              !this.fragCurrent && this.state !== o.STOPPED && this.state !== o.ERROR && (this.state = o.IDLE);
              return;
            }
            var w = M.frag, F = M.part, U = M.level, N = self.performance.now();
            w.stats.parsing.end = N, F && (F.stats.parsing.end = N), this.updateLevelTiming(w, F, U, c.partial);
          }, h.getCurrentContext = function(c) {
            var M = this.levels, w = c.level, F = c.sn, U = c.part;
            if (!M || !M[w])
              return this.warn("Levels object was unset while buffering fragment " + F + " of level " + w + ". The current chunk will not be buffered."), null;
            var N = M[w], H = U > -1 ? (0, S.getPartWith)(N, F, U) : null, j = H ? H.fragment : (0, S.getFragmentWithSN)(N, F, this.fragCurrent);
            return j ? {
              frag: j,
              part: H,
              level: N
            } : null;
          }, h.bufferFragmentData = function(c, M, w, F) {
            if (!(!c || this.state !== o.PARSING)) {
              var U = c.data1, N = c.data2, H = U;
              if (U && N && (H = (0, _.appendUint8Array)(U, N)), !(!H || !H.length)) {
                var j = {
                  type: c.type,
                  frag: M,
                  part: w,
                  chunkMeta: F,
                  parent: M.type,
                  data: H
                };
                this.hls.trigger(I.Events.BUFFER_APPENDING, j), c.dropped && c.independent && !w && this.flushBufferGap(M);
              }
            }
          }, h.flushBufferGap = function(c) {
            var M = this.media;
            if (!!M) {
              if (!C.BufferHelper.isBuffered(M, M.currentTime)) {
                this.flushMainBuffer(0, c.start);
                return;
              }
              var w = M.currentTime, F = C.BufferHelper.bufferInfo(M, w, 0), U = c.duration, N = Math.min(this.config.maxFragLookUpTolerance * 2, U * 0.25), H = Math.max(Math.min(c.start - N, F.end - N), w + N);
              c.start - H > N && this.flushMainBuffer(H, c.start);
            }
          }, h.getFwdBufferInfo = function(c, M) {
            var w = this.config, F = this.getLoadPosition();
            if (!(0, P.isFiniteNumber)(F))
              return null;
            var U = C.BufferHelper.bufferInfo(c, F, w.maxBufferHole);
            if (U.len === 0 && U.nextStart !== void 0) {
              var N = this.fragmentTracker.getBufferedFrag(F, M);
              if (N && U.nextStart < N.end)
                return C.BufferHelper.bufferInfo(c, F, Math.max(U.nextStart, w.maxBufferHole));
            }
            return U;
          }, h.getMaxBufferLength = function(c) {
            var M = this.config, w;
            return c ? w = Math.max(8 * M.maxBufferSize / c, M.maxBufferLength) : w = M.maxBufferLength, Math.min(w, M.maxMaxBufferLength);
          }, h.reduceMaxBufferLength = function(c) {
            var M = this.config, w = c || M.maxBufferLength;
            return M.maxMaxBufferLength >= w ? (M.maxMaxBufferLength /= 2, this.warn("Reduce max buffer length to " + M.maxMaxBufferLength + "s"), !0) : !1;
          }, h.getNextFragment = function(c, M) {
            var w = M.fragments, F = w.length;
            if (!F)
              return null;
            var U = this.config, N = w[0].start, H;
            if (M.live) {
              var j = U.initialLiveManifestSize;
              if (F < j)
                return this.warn("Not enough fragments to start playback (have: " + F + ", need: " + j + ")"), null;
              !M.PTSKnown && !this.startFragRequested && this.startPosition === -1 && (H = this.getInitialLiveFragment(M, w), this.startPosition = H ? this.hls.liveSyncPosition || H.start : c);
            } else
              c <= N && (H = w[0]);
            if (!H) {
              var z = U.lowLatencyMode ? M.partEnd : M.fragmentEnd;
              H = this.getFragmentAtPosition(c, z, M);
            }
            return this.mapToInitFragWhenRequired(H);
          }, h.mapToInitFragWhenRequired = function(c) {
            return c != null && c.initSegment && !(c != null && c.initSegment.data) && !this.bitrateTest ? c.initSegment : c;
          }, h.getNextPart = function(c, M, w) {
            for (var F = -1, U = !1, N = !0, H = 0, j = c.length; H < j; H++) {
              var z = c[H];
              if (N = N && !z.independent, F > -1 && w < z.start)
                break;
              var Y = z.loaded;
              Y ? F = -1 : (U || z.independent || N) && z.fragment === M && (F = H), U = Y;
            }
            return F;
          }, h.loadedEndOfParts = function(c, M) {
            var w = c[c.length - 1];
            return w && M > w.start && w.loaded;
          }, h.getInitialLiveFragment = function(c, M) {
            var w = this.fragPrevious, F = null;
            if (w) {
              if (c.hasProgramDateTime && (this.log("Live playlist, switching playlist, load frag with same PDT: " + w.programDateTime), F = (0, g.findFragmentByPDT)(M, w.endProgramDateTime, this.config.maxFragLookUpTolerance)), !F) {
                var U = w.sn + 1;
                if (U >= c.startSN && U <= c.endSN) {
                  var N = M[U - c.startSN];
                  w.cc === N.cc && (F = N, this.log("Live playlist, switching playlist, load frag with next SN: " + F.sn));
                }
                F || (F = (0, g.findFragWithCC)(M, w.cc), F && this.log("Live playlist, switching playlist, load frag with same CC: " + F.sn));
              }
            } else {
              var H = this.hls.liveSyncPosition;
              H !== null && (F = this.getFragmentAtPosition(H, this.bitrateTest ? c.fragmentEnd : c.edge, c));
            }
            return F;
          }, h.getFragmentAtPosition = function(c, M, w) {
            var F = this.config, U = this.fragPrevious, N = w.fragments, H = w.endSN, j = w.fragmentHint, z = F.maxFragLookUpTolerance, Y = !!(F.lowLatencyMode && w.partList && j);
            Y && j && !this.bitrateTest && (N = N.concat(j), H = j.sn);
            var X;
            if (c < M) {
              var Z = c > M - z ? 0 : z;
              X = (0, g.findFragmentByPTS)(U, N, c, Z);
            } else
              X = N[N.length - 1];
            if (X) {
              var te = X.sn - w.startSN;
              if (this.fragmentTracker.getState(X) === k.FragmentState.OK && (U = X), U && X.sn === U.sn && !Y) {
                var $ = U && X.level === U.level;
                if ($) {
                  var ee = N[te + 1];
                  X.sn < H && this.fragmentTracker.getState(ee) !== k.FragmentState.OK ? (this.log("SN " + X.sn + " just loaded, load next one: " + ee.sn), X = ee) : X = null;
                }
              }
            }
            return X;
          }, h.synchronizeToLiveEdge = function(c) {
            var M = this.config, w = this.media;
            if (!!w) {
              var F = this.hls.liveSyncPosition, U = w.currentTime, N = c.fragments[0].start, H = c.edge, j = U >= N - M.maxFragLookUpTolerance && U <= H;
              if (F !== null && w.duration > F && (U < F || !j)) {
                var z = M.liveMaxLatencyDuration !== void 0 ? M.liveMaxLatencyDuration : M.liveMaxLatencyDurationCount * c.targetduration;
                (!j && w.readyState < 4 || U < H - z) && (this.loadedmetadata || (this.nextLoadPosition = F), w.readyState && (this.warn("Playback: " + U.toFixed(3) + " is located too far from the end of live sliding playlist: " + H + ", reset currentTime to : " + F.toFixed(3)), w.currentTime = F));
              }
            }
          }, h.alignPlaylists = function(c, M) {
            var w = this.levels, F = this.levelLastLoaded, U = this.fragPrevious, N = F !== null ? w[F] : null, H = c.fragments.length;
            if (!H)
              return this.warn("No fragments in live playlist"), 0;
            var j = c.fragments[0].start, z = !M, Y = c.alignedSliding && (0, P.isFiniteNumber)(j);
            if (z || !Y && !j) {
              (0, x.alignStream)(U, N, c);
              var X = c.fragments[0].start;
              return this.log("Live playlist sliding: " + X.toFixed(2) + " start-sn: " + (M ? M.startSN : "na") + "->" + c.startSN + " prev-sn: " + (U ? U.sn : "na") + " fragments: " + H), X;
            }
            return j;
          }, h.waitForCdnTuneIn = function(c) {
            var M = 3;
            return c.live && c.canBlockReload && c.partTarget && c.tuneInGoal > Math.max(c.partHoldBack, c.partTarget * M);
          }, h.setStartPosition = function(c, M) {
            var w = this.startPosition;
            if (w < M && (w = -1), w === -1 || this.lastCurrentTime === -1) {
              var F = c.startTimeOffset;
              (0, P.isFiniteNumber)(F) ? (w = M + F, F < 0 && (w += c.totalduration), w = Math.min(Math.max(M, w), M + c.totalduration), this.log("Start time offset " + F + " found in playlist, adjust startPosition to " + w), this.startPosition = w) : c.live ? w = this.hls.liveSyncPosition || M : this.startPosition = w = 0, this.lastCurrentTime = w;
            }
            this.nextLoadPosition = w;
          }, h.getLoadPosition = function() {
            var c = this.media, M = 0;
            return this.loadedmetadata && c ? M = c.currentTime : this.nextLoadPosition && (M = this.nextLoadPosition), M;
          }, h.handleFragLoadAborted = function(c, M) {
            this.transmuxer && c.sn !== "initSegment" && c.stats.aborted && (this.warn("Fragment " + c.sn + (M ? " part" + M.index : "") + " of level " + c.level + " was aborted"), this.resetFragmentLoading(c));
          }, h.resetFragmentLoading = function(c) {
            (!this.fragCurrent || !this.fragContextChanged(c) && this.state !== o.FRAG_LOADING_WAITING_RETRY) && (this.state = o.IDLE);
          }, h.onFragmentOrKeyLoadError = function(c, M) {
            if (M.fatal) {
              this.stopLoad(), this.state = o.ERROR;
              return;
            }
            var w = this.config;
            if (M.chunkMeta) {
              var F = this.getCurrentContext(M.chunkMeta);
              F && (M.frag = F.frag, M.levelRetry = !0, this.fragLoadError = w.fragLoadingMaxRetry);
            }
            var U = M.frag;
            if (!(!U || U.type !== c)) {
              var N = this.fragCurrent;
              if (console.assert(N && U.sn === N.sn && U.level === N.level && U.urlId === N.urlId, "Frag load error must match current frag to retry"), this.fragLoadError + 1 <= w.fragLoadingMaxRetry) {
                this.loadedmetadata || (this.startFragRequested = !1, this.nextLoadPosition = this.startPosition);
                var H = Math.min(Math.pow(2, this.fragLoadError) * w.fragLoadingRetryDelay, w.fragLoadingMaxRetryTimeout);
                this.warn("Fragment " + U.sn + " of " + c + " " + U.level + " failed to load, retrying in " + H + "ms"), this.retryDate = self.performance.now() + H, this.fragLoadError++, this.state = o.FRAG_LOADING_WAITING_RETRY;
              } else
                M.levelRetry ? (c === a.PlaylistLevelType.AUDIO && (this.fragCurrent = null), this.fragLoadError = 0, this.state = o.IDLE) : (B.logger.error(M.details + " reaches max retry, redispatch as fatal ..."), M.fatal = !0, this.hls.stopLoad(), this.state = o.ERROR);
            }
          }, h.afterBufferFlushed = function(c, M, w) {
            if (!!c) {
              var F = C.BufferHelper.getBuffered(c);
              this.fragmentTracker.detectEvictedFragments(M, F, w), this.state === o.ENDED && this.resetLoadingState();
            }
          }, h.resetLoadingState = function() {
            this.log("Reset loading state"), this.fragCurrent = null, this.fragPrevious = null, this.state = o.IDLE;
          }, h.resetStartWhenNotLoaded = function(c) {
            if (!this.loadedmetadata) {
              this.startFragRequested = !1;
              var M = this.levels ? this.levels[c].details : null;
              M != null && M.live ? (this.startPosition = -1, this.setStartPosition(M, 0), this.resetLoadingState()) : this.nextLoadPosition = this.startPosition;
            }
          }, h.updateLevelTiming = function(c, M, w, F) {
            var U = this, N = w.details;
            console.assert(!!N, "level.details must be defined");
            var H = Object.keys(c.elementaryStreams).reduce(function(j, z) {
              var Y = c.elementaryStreams[z];
              if (Y) {
                var X = Y.endPTS - Y.startPTS;
                if (X <= 0)
                  return U.warn("Could not parse fragment " + c.sn + " " + z + " duration reliably (" + X + ")"), j || !1;
                var Z = F ? 0 : (0, S.updateFragPTSDTS)(N, c, Y.startPTS, Y.endPTS, Y.startDTS, Y.endDTS);
                return U.hls.trigger(I.Events.LEVEL_PTS_UPDATED, {
                  details: N,
                  level: w,
                  drift: Z,
                  type: z,
                  frag: c,
                  start: Y.startPTS,
                  end: Y.endPTS
                }), !0;
              }
              return j;
            }, !1);
            H || (this.warn("Found no media in fragment " + c.sn + " of level " + w.id + " resetting transmuxer to fallback to playlist timing"), this.resetTransmuxer()), this.state = o.PARSED, this.hls.trigger(I.Events.FRAG_PARSED, {
              frag: c,
              part: M
            });
          }, h.resetTransmuxer = function() {
            this.transmuxer && (this.transmuxer.destroy(), this.transmuxer = null);
          }, m(e, [{
            key: "state",
            get: function() {
              return this._state;
            },
            set: function(c) {
              var M = this._state;
              M !== c && (this._state = c, this.log(M + "->" + c));
            }
          }]), e;
        }(T.default);
      },
      "./src/controller/buffer-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => g
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/events.ts"), k = p("./src/utils/logger.ts"), C = p("./src/errors.ts"), B = p("./src/utils/buffer-helper.ts"), I = p("./src/utils/mediasource-helper.ts"), L = p("./src/loader/fragment.ts"), D = p("./src/controller/buffer-operation-queue.ts"), _ = (0, I.getMediaSource)(), x = /([ha]vc.)(?:\.[^.,]+)+/, g = /* @__PURE__ */ function() {
          function S(l) {
            var u = this;
            this.details = null, this._objectUrl = null, this.operationQueue = void 0, this.listeners = void 0, this.hls = void 0, this.bufferCodecEventsExpected = 0, this._bufferCodecEventsTotal = 0, this.media = null, this.mediaSource = null, this.lastMpegAudioChunk = null, this.appendError = 0, this.tracks = {}, this.pendingTracks = {}, this.sourceBuffer = void 0, this._onMediaSourceOpen = function() {
              var a = u.media, s = u.mediaSource;
              k.logger.log("[buffer-controller]: Media source opened"), a && (a.removeEventListener("emptied", u._onMediaEmptied), u.updateMediaElementDuration(), u.hls.trigger(T.Events.MEDIA_ATTACHED, {
                media: a
              })), s && s.removeEventListener("sourceopen", u._onMediaSourceOpen), u.checkPendingTracks();
            }, this._onMediaSourceClose = function() {
              k.logger.log("[buffer-controller]: Media source closed");
            }, this._onMediaSourceEnded = function() {
              k.logger.log("[buffer-controller]: Media source ended");
            }, this._onMediaEmptied = function() {
              var a = u.media, s = u._objectUrl;
              a && a.src !== s && k.logger.error("Media element src was set while attaching MediaSource (" + s + " > " + a.src + ")");
            }, this.hls = l, this._initSourceBuffer(), this.registerListeners();
          }
          var y = S.prototype;
          return y.hasSourceTypes = function() {
            return this.getSourceBufferTypes().length > 0 || Object.keys(this.pendingTracks).length > 0;
          }, y.destroy = function() {
            this.unregisterListeners(), this.details = null, this.lastMpegAudioChunk = null;
          }, y.registerListeners = function() {
            var u = this.hls;
            u.on(T.Events.MEDIA_ATTACHING, this.onMediaAttaching, this), u.on(T.Events.MEDIA_DETACHING, this.onMediaDetaching, this), u.on(T.Events.MANIFEST_PARSED, this.onManifestParsed, this), u.on(T.Events.BUFFER_RESET, this.onBufferReset, this), u.on(T.Events.BUFFER_APPENDING, this.onBufferAppending, this), u.on(T.Events.BUFFER_CODECS, this.onBufferCodecs, this), u.on(T.Events.BUFFER_EOS, this.onBufferEos, this), u.on(T.Events.BUFFER_FLUSHING, this.onBufferFlushing, this), u.on(T.Events.LEVEL_UPDATED, this.onLevelUpdated, this), u.on(T.Events.FRAG_PARSED, this.onFragParsed, this), u.on(T.Events.FRAG_CHANGED, this.onFragChanged, this);
          }, y.unregisterListeners = function() {
            var u = this.hls;
            u.off(T.Events.MEDIA_ATTACHING, this.onMediaAttaching, this), u.off(T.Events.MEDIA_DETACHING, this.onMediaDetaching, this), u.off(T.Events.MANIFEST_PARSED, this.onManifestParsed, this), u.off(T.Events.BUFFER_RESET, this.onBufferReset, this), u.off(T.Events.BUFFER_APPENDING, this.onBufferAppending, this), u.off(T.Events.BUFFER_CODECS, this.onBufferCodecs, this), u.off(T.Events.BUFFER_EOS, this.onBufferEos, this), u.off(T.Events.BUFFER_FLUSHING, this.onBufferFlushing, this), u.off(T.Events.LEVEL_UPDATED, this.onLevelUpdated, this), u.off(T.Events.FRAG_PARSED, this.onFragParsed, this), u.off(T.Events.FRAG_CHANGED, this.onFragChanged, this);
          }, y._initSourceBuffer = function() {
            this.sourceBuffer = {}, this.operationQueue = new D.default(this.sourceBuffer), this.listeners = {
              audio: [],
              video: [],
              audiovideo: []
            }, this.lastMpegAudioChunk = null;
          }, y.onManifestParsed = function(u, a) {
            var s = 2;
            (a.audio && !a.video || !a.altAudio) && (s = 1), this.bufferCodecEventsExpected = this._bufferCodecEventsTotal = s, this.details = null, k.logger.log(this.bufferCodecEventsExpected + " bufferCodec event(s) expected");
          }, y.onMediaAttaching = function(u, a) {
            var s = this.media = a.media;
            if (s && _) {
              var m = this.mediaSource = new _();
              m.addEventListener("sourceopen", this._onMediaSourceOpen), m.addEventListener("sourceended", this._onMediaSourceEnded), m.addEventListener("sourceclose", this._onMediaSourceClose), s.src = self.URL.createObjectURL(m), this._objectUrl = s.src, s.addEventListener("emptied", this._onMediaEmptied);
            }
          }, y.onMediaDetaching = function() {
            var u = this.media, a = this.mediaSource, s = this._objectUrl;
            if (a) {
              if (k.logger.log("[buffer-controller]: media source detaching"), a.readyState === "open")
                try {
                  a.endOfStream();
                } catch (m) {
                  k.logger.warn("[buffer-controller]: onMediaDetaching: " + m.message + " while calling endOfStream");
                }
              this.onBufferReset(), a.removeEventListener("sourceopen", this._onMediaSourceOpen), a.removeEventListener("sourceended", this._onMediaSourceEnded), a.removeEventListener("sourceclose", this._onMediaSourceClose), u && (u.removeEventListener("emptied", this._onMediaEmptied), s && self.URL.revokeObjectURL(s), u.src === s ? (u.removeAttribute("src"), u.load()) : k.logger.warn("[buffer-controller]: media.src was changed by a third party - skip cleanup")), this.mediaSource = null, this.media = null, this._objectUrl = null, this.bufferCodecEventsExpected = this._bufferCodecEventsTotal, this.pendingTracks = {}, this.tracks = {};
            }
            this.hls.trigger(T.Events.MEDIA_DETACHED, void 0);
          }, y.onBufferReset = function() {
            var u = this;
            this.getSourceBufferTypes().forEach(function(a) {
              var s = u.sourceBuffer[a];
              try {
                s && (u.removeBufferListeners(a), u.mediaSource && u.mediaSource.removeSourceBuffer(s), u.sourceBuffer[a] = void 0);
              } catch (m) {
                k.logger.warn("[buffer-controller]: Failed to reset the " + a + " buffer", m);
              }
            }), this._initSourceBuffer();
          }, y.onBufferCodecs = function(u, a) {
            var s = this, m = this.getSourceBufferTypes().length;
            Object.keys(a).forEach(function(v) {
              if (m) {
                var i = s.tracks[v];
                if (i && typeof i.buffer.changeType == "function") {
                  var n = a[v], E = n.id, r = n.codec, o = n.levelCodec, t = n.container, d = n.metadata, e = (i.levelCodec || i.codec).replace(x, "$1"), h = (o || r).replace(x, "$1");
                  if (e !== h) {
                    var f = t + ";codecs=" + (o || r);
                    s.appendChangeType(v, f), k.logger.log("[buffer-controller]: switching codec " + e + " to " + h), s.tracks[v] = {
                      buffer: i.buffer,
                      codec: r,
                      container: t,
                      levelCodec: o,
                      metadata: d,
                      id: E
                    };
                  }
                }
              } else
                s.pendingTracks[v] = a[v];
            }), !m && (this.bufferCodecEventsExpected = Math.max(this.bufferCodecEventsExpected - 1, 0), this.mediaSource && this.mediaSource.readyState === "open" && this.checkPendingTracks());
          }, y.appendChangeType = function(u, a) {
            var s = this, m = this.operationQueue, v = {
              execute: function() {
                var n = s.sourceBuffer[u];
                n && (k.logger.log("[buffer-controller]: changing " + u + " sourceBuffer type to " + a), n.changeType(a)), m.shiftAndExecuteNext(u);
              },
              onStart: function() {
              },
              onComplete: function() {
              },
              onError: function(n) {
                k.logger.warn("[buffer-controller]: Failed to change " + u + " SourceBuffer type", n);
              }
            };
            m.append(v, u);
          }, y.onBufferAppending = function(u, a) {
            var s = this, m = this.hls, v = this.operationQueue, i = this.tracks, n = a.data, E = a.type, r = a.frag, o = a.part, t = a.chunkMeta, d = t.buffering[E], e = self.performance.now();
            d.start = e;
            var h = r.stats.buffering, f = o ? o.stats.buffering : null;
            h.start === 0 && (h.start = e), f && f.start === 0 && (f.start = e);
            var c = i.audio, M = !1;
            E === "audio" && (c == null ? void 0 : c.container) === "audio/mpeg" && (M = !this.lastMpegAudioChunk || t.id === 1 || this.lastMpegAudioChunk.sn !== t.sn, this.lastMpegAudioChunk = t);
            var w = r.start, F = {
              execute: function() {
                if (d.executeStart = self.performance.now(), M) {
                  var N = s.sourceBuffer[E];
                  if (N) {
                    var H = w - N.timestampOffset;
                    Math.abs(H) >= 0.1 && (k.logger.log("[buffer-controller]: Updating audio SourceBuffer timestampOffset to " + w + " (delta: " + H + ") sn: " + r.sn + ")"), N.timestampOffset = w);
                  }
                }
                s.appendExecutor(n, E);
              },
              onStart: function() {
              },
              onComplete: function() {
                var N = self.performance.now();
                d.executeEnd = d.end = N, h.first === 0 && (h.first = N), f && f.first === 0 && (f.first = N);
                var H = s.sourceBuffer, j = {};
                for (var z in H)
                  j[z] = B.BufferHelper.getBuffered(H[z]);
                s.appendError = 0, s.hls.trigger(T.Events.BUFFER_APPENDED, {
                  type: E,
                  frag: r,
                  part: o,
                  chunkMeta: t,
                  parent: r.type,
                  timeRanges: j
                });
              },
              onError: function(N) {
                k.logger.error("[buffer-controller]: Error encountered while trying to append to the " + E + " SourceBuffer", N);
                var H = {
                  type: C.ErrorTypes.MEDIA_ERROR,
                  parent: r.type,
                  details: C.ErrorDetails.BUFFER_APPEND_ERROR,
                  err: N,
                  fatal: !1
                };
                N.code === DOMException.QUOTA_EXCEEDED_ERR ? H.details = C.ErrorDetails.BUFFER_FULL_ERROR : (s.appendError++, H.details = C.ErrorDetails.BUFFER_APPEND_ERROR, s.appendError > m.config.appendErrorMaxRetry && (k.logger.error("[buffer-controller]: Failed " + m.config.appendErrorMaxRetry + " times to append segment in sourceBuffer"), H.fatal = !0, m.stopLoad())), m.trigger(T.Events.ERROR, H);
              }
            };
            v.append(F, E);
          }, y.onBufferFlushing = function(u, a) {
            var s = this, m = this.operationQueue, v = function(n) {
              return {
                execute: s.removeExecutor.bind(s, n, a.startOffset, a.endOffset),
                onStart: function() {
                },
                onComplete: function() {
                  s.hls.trigger(T.Events.BUFFER_FLUSHED, {
                    type: n
                  });
                },
                onError: function(r) {
                  k.logger.warn("[buffer-controller]: Failed to remove from " + n + " SourceBuffer", r);
                }
              };
            };
            a.type ? m.append(v(a.type), a.type) : this.getSourceBufferTypes().forEach(function(i) {
              m.append(v(i), i);
            });
          }, y.onFragParsed = function(u, a) {
            var s = this, m = a.frag, v = a.part, i = [], n = v ? v.elementaryStreams : m.elementaryStreams;
            n[L.ElementaryStreamTypes.AUDIOVIDEO] ? i.push("audiovideo") : (n[L.ElementaryStreamTypes.AUDIO] && i.push("audio"), n[L.ElementaryStreamTypes.VIDEO] && i.push("video"));
            var E = function() {
              var o = self.performance.now();
              m.stats.buffering.end = o, v && (v.stats.buffering.end = o);
              var t = v ? v.stats : m.stats;
              s.hls.trigger(T.Events.FRAG_BUFFERED, {
                frag: m,
                part: v,
                stats: t,
                id: m.type
              });
            };
            i.length === 0 && k.logger.warn("Fragments must have at least one ElementaryStreamType set. type: " + m.type + " level: " + m.level + " sn: " + m.sn), this.blockBuffers(E, i);
          }, y.onFragChanged = function(u, a) {
            this.flushBackBuffer();
          }, y.onBufferEos = function(u, a) {
            var s = this, m = this.getSourceBufferTypes().reduce(function(v, i) {
              var n = s.sourceBuffer[i];
              return n && (!a.type || a.type === i) && (n.ending = !0, n.ended || (n.ended = !0, k.logger.log("[buffer-controller]: " + i + " sourceBuffer now EOS"))), v && !!(!n || n.ended);
            }, !0);
            m && (k.logger.log("[buffer-controller]: Queueing mediaSource.endOfStream()"), this.blockBuffers(function() {
              s.getSourceBufferTypes().forEach(function(i) {
                var n = s.sourceBuffer[i];
                n && (n.ending = !1);
              });
              var v = s.mediaSource;
              if (!v || v.readyState !== "open") {
                v && k.logger.info("[buffer-controller]: Could not call mediaSource.endOfStream(). mediaSource.readyState: " + v.readyState);
                return;
              }
              k.logger.log("[buffer-controller]: Calling mediaSource.endOfStream()"), v.endOfStream();
            }));
          }, y.onLevelUpdated = function(u, a) {
            var s = a.details;
            !s.fragments.length || (this.details = s, this.getSourceBufferTypes().length ? this.blockBuffers(this.updateMediaElementDuration.bind(this)) : this.updateMediaElementDuration());
          }, y.flushBackBuffer = function() {
            var u = this.hls, a = this.details, s = this.media, m = this.sourceBuffer;
            if (!(!s || a === null)) {
              var v = this.getSourceBufferTypes();
              if (!!v.length) {
                var i = a.live && u.config.liveBackBufferLength !== null ? u.config.liveBackBufferLength : u.config.backBufferLength;
                if (!(!(0, P.isFiniteNumber)(i) || i < 0)) {
                  var n = s.currentTime, E = a.levelTargetDuration, r = Math.max(i, E), o = Math.floor(n / E) * E - r;
                  v.forEach(function(t) {
                    var d = m[t];
                    if (d) {
                      var e = B.BufferHelper.getBuffered(d);
                      if (e.length > 0 && o > e.start(0)) {
                        if (u.trigger(T.Events.BACK_BUFFER_REACHED, {
                          bufferEnd: o
                        }), a.live)
                          u.trigger(T.Events.LIVE_BACK_BUFFER_REACHED, {
                            bufferEnd: o
                          });
                        else if (d.ended && e.end(e.length - 1) - n < E * 2) {
                          k.logger.info("[buffer-controller]: Cannot flush " + t + " back buffer while SourceBuffer is in ended state");
                          return;
                        }
                        u.trigger(T.Events.BUFFER_FLUSHING, {
                          startOffset: 0,
                          endOffset: o,
                          type: t
                        });
                      }
                    }
                  });
                }
              }
            }
          }, y.updateMediaElementDuration = function() {
            if (!(!this.details || !this.media || !this.mediaSource || this.mediaSource.readyState !== "open")) {
              var u = this.details, a = this.hls, s = this.media, m = this.mediaSource, v = u.fragments[0].start + u.totalduration, i = s.duration, n = (0, P.isFiniteNumber)(m.duration) ? m.duration : 0;
              u.live && a.config.liveDurationInfinity ? (k.logger.log("[buffer-controller]: Media Source duration is set to Infinity"), m.duration = 1 / 0, this.updateSeekableRange(u)) : (v > n && v > i || !(0, P.isFiniteNumber)(i)) && (k.logger.log("[buffer-controller]: Updating Media Source duration to " + v.toFixed(3)), m.duration = v);
            }
          }, y.updateSeekableRange = function(u) {
            var a = this.mediaSource, s = u.fragments, m = s.length;
            if (m && u.live && a !== null && a !== void 0 && a.setLiveSeekableRange) {
              var v = Math.max(0, s[0].start), i = Math.max(v, v + u.totalduration);
              a.setLiveSeekableRange(v, i);
            }
          }, y.checkPendingTracks = function() {
            var u = this.bufferCodecEventsExpected, a = this.operationQueue, s = this.pendingTracks, m = Object.keys(s).length;
            if (m && !u || m === 2) {
              this.createSourceBuffers(s), this.pendingTracks = {};
              var v = this.getSourceBufferTypes();
              if (v.length === 0) {
                this.hls.trigger(T.Events.ERROR, {
                  type: C.ErrorTypes.MEDIA_ERROR,
                  details: C.ErrorDetails.BUFFER_INCOMPATIBLE_CODECS_ERROR,
                  fatal: !0,
                  reason: "could not create source buffer for media codec(s)"
                });
                return;
              }
              v.forEach(function(i) {
                a.executeNext(i);
              });
            }
          }, y.createSourceBuffers = function(u) {
            var a = this.sourceBuffer, s = this.mediaSource;
            if (!s)
              throw Error("createSourceBuffers called when mediaSource was null");
            var m = 0;
            for (var v in u)
              if (!a[v]) {
                var i = u[v];
                if (!i)
                  throw Error("source buffer exists for track " + v + ", however track does not");
                var n = i.levelCodec || i.codec, E = i.container + ";codecs=" + n;
                k.logger.log("[buffer-controller]: creating sourceBuffer(" + E + ")");
                try {
                  var r = a[v] = s.addSourceBuffer(E), o = v;
                  this.addBufferListener(o, "updatestart", this._onSBUpdateStart), this.addBufferListener(o, "updateend", this._onSBUpdateEnd), this.addBufferListener(o, "error", this._onSBUpdateError), this.tracks[v] = {
                    buffer: r,
                    codec: n,
                    container: i.container,
                    levelCodec: i.levelCodec,
                    metadata: i.metadata,
                    id: i.id
                  }, m++;
                } catch (t) {
                  k.logger.error("[buffer-controller]: error while trying to add sourceBuffer: " + t.message), this.hls.trigger(T.Events.ERROR, {
                    type: C.ErrorTypes.MEDIA_ERROR,
                    details: C.ErrorDetails.BUFFER_ADD_CODEC_ERROR,
                    fatal: !1,
                    error: t,
                    mimeType: E
                  });
                }
              }
            m && this.hls.trigger(T.Events.BUFFER_CREATED, {
              tracks: this.tracks
            });
          }, y._onSBUpdateStart = function(u) {
            var a = this.operationQueue, s = a.current(u);
            s.onStart();
          }, y._onSBUpdateEnd = function(u) {
            var a = this.operationQueue, s = a.current(u);
            s.onComplete(), a.shiftAndExecuteNext(u);
          }, y._onSBUpdateError = function(u, a) {
            k.logger.error("[buffer-controller]: " + u + " SourceBuffer error", a), this.hls.trigger(T.Events.ERROR, {
              type: C.ErrorTypes.MEDIA_ERROR,
              details: C.ErrorDetails.BUFFER_APPENDING_ERROR,
              fatal: !1
            });
            var s = this.operationQueue.current(u);
            s && s.onError(a);
          }, y.removeExecutor = function(u, a, s) {
            var m = this.media, v = this.mediaSource, i = this.operationQueue, n = this.sourceBuffer, E = n[u];
            if (!m || !v || !E) {
              k.logger.warn("[buffer-controller]: Attempting to remove from the " + u + " SourceBuffer, but it does not exist"), i.shiftAndExecuteNext(u);
              return;
            }
            var r = (0, P.isFiniteNumber)(m.duration) ? m.duration : 1 / 0, o = (0, P.isFiniteNumber)(v.duration) ? v.duration : 1 / 0, t = Math.max(0, a), d = Math.min(s, r, o);
            d > t && !E.ending ? (E.ended = !1, k.logger.log("[buffer-controller]: Removing [" + t + "," + d + "] from the " + u + " SourceBuffer"), console.assert(!E.updating, u + " sourceBuffer must not be updating"), E.remove(t, d)) : i.shiftAndExecuteNext(u);
          }, y.appendExecutor = function(u, a) {
            var s = this.operationQueue, m = this.sourceBuffer, v = m[a];
            if (!v) {
              k.logger.warn("[buffer-controller]: Attempting to append to the " + a + " SourceBuffer, but it does not exist"), s.shiftAndExecuteNext(a);
              return;
            }
            v.ended = !1, console.assert(!v.updating, a + " sourceBuffer must not be updating"), v.appendBuffer(u);
          }, y.blockBuffers = function(u, a) {
            var s = this;
            if (a === void 0 && (a = this.getSourceBufferTypes()), !a.length) {
              k.logger.log("[buffer-controller]: Blocking operation requested, but no SourceBuffers exist"), Promise.resolve().then(u);
              return;
            }
            var m = this.operationQueue, v = a.map(function(i) {
              return m.appendBlocker(i);
            });
            Promise.all(v).then(function() {
              u(), a.forEach(function(i) {
                var n = s.sourceBuffer[i];
                (!n || !n.updating) && m.shiftAndExecuteNext(i);
              });
            });
          }, y.getSourceBufferTypes = function() {
            return Object.keys(this.sourceBuffer);
          }, y.addBufferListener = function(u, a, s) {
            var m = this.sourceBuffer[u];
            if (!!m) {
              var v = s.bind(this, u);
              this.listeners[u].push({
                event: a,
                listener: v
              }), m.addEventListener(a, v);
            }
          }, y.removeBufferListeners = function(u) {
            var a = this.sourceBuffer[u];
            !a || this.listeners[u].forEach(function(s) {
              a.removeEventListener(s.event, s.listener);
            });
          }, S;
        }();
      },
      "./src/controller/buffer-operation-queue.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => T
        });
        var P = p("./src/utils/logger.ts"), T = /* @__PURE__ */ function() {
          function k(B) {
            this.buffers = void 0, this.queues = {
              video: [],
              audio: [],
              audiovideo: []
            }, this.buffers = B;
          }
          var C = k.prototype;
          return C.append = function(I, L) {
            var D = this.queues[L];
            D.push(I), D.length === 1 && this.buffers[L] && this.executeNext(L);
          }, C.insertAbort = function(I, L) {
            var D = this.queues[L];
            D.unshift(I), this.executeNext(L);
          }, C.appendBlocker = function(I) {
            var L, D = new Promise(function(x) {
              L = x;
            }), _ = {
              execute: L,
              onStart: function() {
              },
              onComplete: function() {
              },
              onError: function() {
              }
            };
            return this.append(_, I), D;
          }, C.executeNext = function(I) {
            var L = this.buffers, D = this.queues, _ = L[I], x = D[I];
            if (x.length) {
              var g = x[0];
              try {
                g.execute();
              } catch (S) {
                P.logger.warn("[buffer-operation-queue]: Unhandled exception executing the current operation"), g.onError(S), (!_ || !_.updating) && (x.shift(), this.executeNext(I));
              }
            }
          }, C.shiftAndExecuteNext = function(I) {
            this.queues[I].shift(), this.executeNext(I);
          }, C.current = function(I) {
            return this.queues[I][0];
          }, k;
        }();
      },
      "./src/controller/cap-level-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => L
        });
        var P = p("./src/events.ts");
        function T(D, _) {
          for (var x = 0; x < _.length; x++) {
            var g = _[x];
            g.enumerable = g.enumerable || !1, g.configurable = !0, "value" in g && (g.writable = !0), Object.defineProperty(D, C(g.key), g);
          }
        }
        function k(D, _, x) {
          return _ && T(D.prototype, _), x && T(D, x), Object.defineProperty(D, "prototype", { writable: !1 }), D;
        }
        function C(D) {
          var _ = B(D, "string");
          return typeof _ == "symbol" ? _ : String(_);
        }
        function B(D, _) {
          if (typeof D != "object" || D === null)
            return D;
          var x = D[Symbol.toPrimitive];
          if (x !== void 0) {
            var g = x.call(D, _ || "default");
            if (typeof g != "object")
              return g;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (_ === "string" ? String : Number)(D);
        }
        var I = /* @__PURE__ */ function() {
          function D(x) {
            this.autoLevelCapping = void 0, this.firstLevel = void 0, this.media = void 0, this.restrictedLevels = void 0, this.timer = void 0, this.hls = void 0, this.streamController = void 0, this.clientRect = void 0, this.hls = x, this.autoLevelCapping = Number.POSITIVE_INFINITY, this.firstLevel = -1, this.media = null, this.restrictedLevels = [], this.timer = void 0, this.clientRect = null, this.registerListeners();
          }
          var _ = D.prototype;
          return _.setStreamController = function(g) {
            this.streamController = g;
          }, _.destroy = function() {
            this.unregisterListener(), this.hls.config.capLevelToPlayerSize && this.stopCapping(), this.media = null, this.clientRect = null, this.hls = this.streamController = null;
          }, _.registerListeners = function() {
            var g = this.hls;
            g.on(P.Events.FPS_DROP_LEVEL_CAPPING, this.onFpsDropLevelCapping, this), g.on(P.Events.MEDIA_ATTACHING, this.onMediaAttaching, this), g.on(P.Events.MANIFEST_PARSED, this.onManifestParsed, this), g.on(P.Events.BUFFER_CODECS, this.onBufferCodecs, this), g.on(P.Events.MEDIA_DETACHING, this.onMediaDetaching, this);
          }, _.unregisterListener = function() {
            var g = this.hls;
            g.off(P.Events.FPS_DROP_LEVEL_CAPPING, this.onFpsDropLevelCapping, this), g.off(P.Events.MEDIA_ATTACHING, this.onMediaAttaching, this), g.off(P.Events.MANIFEST_PARSED, this.onManifestParsed, this), g.off(P.Events.BUFFER_CODECS, this.onBufferCodecs, this), g.off(P.Events.MEDIA_DETACHING, this.onMediaDetaching, this);
          }, _.onFpsDropLevelCapping = function(g, S) {
            D.isLevelAllowed(S.droppedLevel, this.restrictedLevels) && this.restrictedLevels.push(S.droppedLevel);
          }, _.onMediaAttaching = function(g, S) {
            this.media = S.media instanceof HTMLVideoElement ? S.media : null, this.clientRect = null;
          }, _.onManifestParsed = function(g, S) {
            var y = this.hls;
            this.restrictedLevels = [], this.firstLevel = S.firstLevel, y.config.capLevelToPlayerSize && S.video && this.startCapping();
          }, _.onBufferCodecs = function(g, S) {
            var y = this.hls;
            y.config.capLevelToPlayerSize && S.video && this.startCapping();
          }, _.onMediaDetaching = function() {
            this.stopCapping();
          }, _.detectPlayerSize = function() {
            if (this.media && this.mediaHeight > 0 && this.mediaWidth > 0) {
              var g = this.hls.levels;
              if (g.length) {
                var S = this.hls;
                S.autoLevelCapping = this.getMaxLevel(g.length - 1), S.autoLevelCapping > this.autoLevelCapping && this.streamController && this.streamController.nextLevelSwitch(), this.autoLevelCapping = S.autoLevelCapping;
              }
            }
          }, _.getMaxLevel = function(g) {
            var S = this, y = this.hls.levels;
            if (!y.length)
              return -1;
            var l = y.filter(function(u, a) {
              return D.isLevelAllowed(a, S.restrictedLevels) && a <= g;
            });
            return this.clientRect = null, D.getMaxLevelByMediaSize(l, this.mediaWidth, this.mediaHeight);
          }, _.startCapping = function() {
            this.timer || (this.autoLevelCapping = Number.POSITIVE_INFINITY, this.hls.firstLevel = this.getMaxLevel(this.firstLevel), self.clearInterval(this.timer), this.timer = self.setInterval(this.detectPlayerSize.bind(this), 1e3), this.detectPlayerSize());
          }, _.stopCapping = function() {
            this.restrictedLevels = [], this.firstLevel = -1, this.autoLevelCapping = Number.POSITIVE_INFINITY, this.timer && (self.clearInterval(this.timer), this.timer = void 0);
          }, _.getDimensions = function() {
            if (this.clientRect)
              return this.clientRect;
            var g = this.media, S = {
              width: 0,
              height: 0
            };
            if (g) {
              var y = g.getBoundingClientRect();
              S.width = y.width, S.height = y.height, !S.width && !S.height && (S.width = y.right - y.left || g.width || 0, S.height = y.bottom - y.top || g.height || 0);
            }
            return this.clientRect = S, S;
          }, D.isLevelAllowed = function(g, S) {
            return S === void 0 && (S = []), S.indexOf(g) === -1;
          }, D.getMaxLevelByMediaSize = function(g, S, y) {
            if (!g || !g.length)
              return -1;
            for (var l = function(v, i) {
              return i ? v.width !== i.width || v.height !== i.height : !0;
            }, u = g.length - 1, a = 0; a < g.length; a += 1) {
              var s = g[a];
              if ((s.width >= S || s.height >= y) && l(s, g[a + 1])) {
                u = a;
                break;
              }
            }
            return u;
          }, k(D, [{
            key: "mediaWidth",
            get: function() {
              return this.getDimensions().width * this.contentScaleFactor;
            }
          }, {
            key: "mediaHeight",
            get: function() {
              return this.getDimensions().height * this.contentScaleFactor;
            }
          }, {
            key: "contentScaleFactor",
            get: function() {
              var g = 1;
              if (!this.hls.config.ignoreDevicePixelRatio)
                try {
                  g = self.devicePixelRatio;
                } catch {
                }
              return g;
            }
          }]), D;
        }();
        const L = I;
      },
      "./src/controller/cmcd-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => y
        });
        var P = p("./src/events.ts"), T = p("./src/types/cmcd.ts"), k = p("./src/utils/buffer-helper.ts"), C = p("./src/utils/logger.ts");
        function B(l, u) {
          for (var a = 0; a < u.length; a++) {
            var s = u[a];
            s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(l, L(s.key), s);
          }
        }
        function I(l, u, a) {
          return u && B(l.prototype, u), a && B(l, a), Object.defineProperty(l, "prototype", { writable: !1 }), l;
        }
        function L(l) {
          var u = D(l, "string");
          return typeof u == "symbol" ? u : String(u);
        }
        function D(l, u) {
          if (typeof l != "object" || l === null)
            return l;
          var a = l[Symbol.toPrimitive];
          if (a !== void 0) {
            var s = a.call(l, u || "default");
            if (typeof s != "object")
              return s;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (u === "string" ? String : Number)(l);
        }
        function _(l, u) {
          var a = typeof Symbol < "u" && l[Symbol.iterator] || l["@@iterator"];
          if (a)
            return (a = a.call(l)).next.bind(a);
          if (Array.isArray(l) || (a = x(l)) || u && l && typeof l.length == "number") {
            a && (l = a);
            var s = 0;
            return function() {
              return s >= l.length ? { done: !0 } : { done: !1, value: l[s++] };
            };
          }
          throw new TypeError(`Invalid attempt to iterate non-iterable instance.
In order to be iterable, non-array objects must have a [Symbol.iterator]() method.`);
        }
        function x(l, u) {
          if (!!l) {
            if (typeof l == "string")
              return g(l, u);
            var a = Object.prototype.toString.call(l).slice(8, -1);
            if (a === "Object" && l.constructor && (a = l.constructor.name), a === "Map" || a === "Set")
              return Array.from(l);
            if (a === "Arguments" || /^(?:Ui|I)nt(?:8|16|32)(?:Clamped)?Array$/.test(a))
              return g(l, u);
          }
        }
        function g(l, u) {
          (u == null || u > l.length) && (u = l.length);
          for (var a = 0, s = new Array(u); a < u; a++)
            s[a] = l[a];
          return s;
        }
        function S() {
          return S = Object.assign ? Object.assign.bind() : function(l) {
            for (var u = 1; u < arguments.length; u++) {
              var a = arguments[u];
              for (var s in a)
                Object.prototype.hasOwnProperty.call(a, s) && (l[s] = a[s]);
            }
            return l;
          }, S.apply(this, arguments);
        }
        var y = /* @__PURE__ */ function() {
          function l(a) {
            var s = this;
            this.hls = void 0, this.config = void 0, this.media = void 0, this.sid = void 0, this.cid = void 0, this.useHeaders = !1, this.initialized = !1, this.starved = !1, this.buffering = !0, this.audioBuffer = void 0, this.videoBuffer = void 0, this.onWaiting = function() {
              s.initialized && (s.starved = !0), s.buffering = !0;
            }, this.onPlaying = function() {
              s.initialized || (s.initialized = !0), s.buffering = !1;
            }, this.applyPlaylistData = function(i) {
              try {
                s.apply(i, {
                  ot: T.CMCDObjectType.MANIFEST,
                  su: !s.initialized
                });
              } catch (n) {
                C.logger.warn("Could not generate manifest CMCD data.", n);
              }
            }, this.applyFragmentData = function(i) {
              try {
                var n = i.frag, E = s.hls.levels[n.level], r = s.getObjectType(n), o = {
                  d: n.duration * 1e3,
                  ot: r
                };
                (r === T.CMCDObjectType.VIDEO || r === T.CMCDObjectType.AUDIO || r == T.CMCDObjectType.MUXED) && (o.br = E.bitrate / 1e3, o.tb = s.getTopBandwidth(r) / 1e3, o.bl = s.getBufferLength(r)), s.apply(i, o);
              } catch (t) {
                C.logger.warn("Could not generate segment CMCD data.", t);
              }
            }, this.hls = a;
            var m = this.config = a.config, v = m.cmcd;
            v != null && (m.pLoader = this.createPlaylistLoader(), m.fLoader = this.createFragmentLoader(), this.sid = v.sessionId || l.uuid(), this.cid = v.contentId, this.useHeaders = v.useHeaders === !0, this.registerListeners());
          }
          var u = l.prototype;
          return u.registerListeners = function() {
            var s = this.hls;
            s.on(P.Events.MEDIA_ATTACHED, this.onMediaAttached, this), s.on(P.Events.MEDIA_DETACHED, this.onMediaDetached, this), s.on(P.Events.BUFFER_CREATED, this.onBufferCreated, this);
          }, u.unregisterListeners = function() {
            var s = this.hls;
            s.off(P.Events.MEDIA_ATTACHED, this.onMediaAttached, this), s.off(P.Events.MEDIA_DETACHED, this.onMediaDetached, this), s.off(P.Events.BUFFER_CREATED, this.onBufferCreated, this), this.onMediaDetached();
          }, u.destroy = function() {
            this.unregisterListeners(), this.hls = this.config = this.audioBuffer = this.videoBuffer = null;
          }, u.onMediaAttached = function(s, m) {
            this.media = m.media, this.media.addEventListener("waiting", this.onWaiting), this.media.addEventListener("playing", this.onPlaying);
          }, u.onMediaDetached = function() {
            !this.media || (this.media.removeEventListener("waiting", this.onWaiting), this.media.removeEventListener("playing", this.onPlaying), this.media = null);
          }, u.onBufferCreated = function(s, m) {
            var v, i;
            this.audioBuffer = (v = m.tracks.audio) === null || v === void 0 ? void 0 : v.buffer, this.videoBuffer = (i = m.tracks.video) === null || i === void 0 ? void 0 : i.buffer;
          }, u.createData = function() {
            var s;
            return {
              v: T.CMCDVersion,
              sf: T.CMCDStreamingFormat.HLS,
              sid: this.sid,
              cid: this.cid,
              pr: (s = this.media) === null || s === void 0 ? void 0 : s.playbackRate,
              mtp: this.hls.bandwidthEstimate / 1e3
            };
          }, u.apply = function(s, m) {
            m === void 0 && (m = {}), S(m, this.createData());
            var v = m.ot === T.CMCDObjectType.INIT || m.ot === T.CMCDObjectType.VIDEO || m.ot === T.CMCDObjectType.MUXED;
            if (this.starved && v && (m.bs = !0, m.su = !0, this.starved = !1), m.su == null && (m.su = this.buffering), this.useHeaders) {
              var i = l.toHeaders(m);
              if (!Object.keys(i).length)
                return;
              s.headers || (s.headers = {}), S(s.headers, i);
            } else {
              var n = l.toQuery(m);
              if (!n)
                return;
              s.url = l.appendQueryToUri(s.url, n);
            }
          }, u.getObjectType = function(s) {
            var m = s.type;
            if (m === "subtitle")
              return T.CMCDObjectType.TIMED_TEXT;
            if (s.sn === "initSegment")
              return T.CMCDObjectType.INIT;
            if (m === "audio")
              return T.CMCDObjectType.AUDIO;
            if (m === "main")
              return this.hls.audioTracks.length ? T.CMCDObjectType.VIDEO : T.CMCDObjectType.MUXED;
          }, u.getTopBandwidth = function(s) {
            var m = 0, v, i = this.hls;
            if (s === T.CMCDObjectType.AUDIO)
              v = i.audioTracks;
            else {
              var n = i.maxAutoLevel, E = n > -1 ? n + 1 : i.levels.length;
              v = i.levels.slice(0, E);
            }
            for (var r = _(v), o; !(o = r()).done; ) {
              var t = o.value;
              t.bitrate > m && (m = t.bitrate);
            }
            return m > 0 ? m : NaN;
          }, u.getBufferLength = function(s) {
            var m = this.hls.media, v = s === T.CMCDObjectType.AUDIO ? this.audioBuffer : this.videoBuffer;
            if (!v || !m)
              return NaN;
            var i = k.BufferHelper.bufferInfo(v, m.currentTime, this.config.maxBufferHole);
            return i.len * 1e3;
          }, u.createPlaylistLoader = function() {
            var s = this.config.pLoader, m = this.applyPlaylistData, v = s || this.config.loader;
            return /* @__PURE__ */ function() {
              function i(E) {
                this.loader = void 0, this.loader = new v(E);
              }
              var n = i.prototype;
              return n.destroy = function() {
                this.loader.destroy();
              }, n.abort = function() {
                this.loader.abort();
              }, n.load = function(r, o, t) {
                m(r), this.loader.load(r, o, t);
              }, I(i, [{
                key: "stats",
                get: function() {
                  return this.loader.stats;
                }
              }, {
                key: "context",
                get: function() {
                  return this.loader.context;
                }
              }]), i;
            }();
          }, u.createFragmentLoader = function() {
            var s = this.config.fLoader, m = this.applyFragmentData, v = s || this.config.loader;
            return /* @__PURE__ */ function() {
              function i(E) {
                this.loader = void 0, this.loader = new v(E);
              }
              var n = i.prototype;
              return n.destroy = function() {
                this.loader.destroy();
              }, n.abort = function() {
                this.loader.abort();
              }, n.load = function(r, o, t) {
                m(r), this.loader.load(r, o, t);
              }, I(i, [{
                key: "stats",
                get: function() {
                  return this.loader.stats;
                }
              }, {
                key: "context",
                get: function() {
                  return this.loader.context;
                }
              }]), i;
            }();
          }, l.uuid = function() {
            var s = URL.createObjectURL(new Blob()), m = s.toString();
            return URL.revokeObjectURL(s), m.slice(m.lastIndexOf("/") + 1);
          }, l.serialize = function(s) {
            for (var m = [], v = function(F) {
              return !Number.isNaN(F) && F != null && F !== "" && F !== !1;
            }, i = function(F) {
              return Math.round(F);
            }, n = function(F) {
              return i(F / 100) * 100;
            }, E = function(F) {
              return encodeURIComponent(F);
            }, r = {
              br: i,
              d: i,
              bl: n,
              dl: n,
              mtp: n,
              nor: E,
              rtp: n,
              tb: i
            }, o = Object.keys(s || {}).sort(), t = _(o), d; !(d = t()).done; ) {
              var e = d.value, h = s[e];
              if (!!v(h) && !(e === "v" && h === 1) && !(e == "pr" && h === 1)) {
                var f = r[e];
                f && (h = f(h));
                var c = typeof h, M = void 0;
                e === "ot" || e === "sf" || e === "st" ? M = e + "=" + h : c === "boolean" ? M = e : c === "number" ? M = e + "=" + h : M = e + "=" + JSON.stringify(h), m.push(M);
              }
            }
            return m.join(",");
          }, l.toHeaders = function(s) {
            for (var m = Object.keys(s), v = {}, i = ["Object", "Request", "Session", "Status"], n = [{}, {}, {}, {}], E = {
              br: 0,
              d: 0,
              ot: 0,
              tb: 0,
              bl: 1,
              dl: 1,
              mtp: 1,
              nor: 1,
              nrr: 1,
              su: 1,
              cid: 2,
              pr: 2,
              sf: 2,
              sid: 2,
              st: 2,
              v: 2,
              bs: 3,
              rtp: 3
            }, r = 0, o = m; r < o.length; r++) {
              var t = o[r], d = E[t] != null ? E[t] : 1;
              n[d][t] = s[t];
            }
            for (var e = 0; e < n.length; e++) {
              var h = l.serialize(n[e]);
              h && (v["CMCD-" + i[e]] = h);
            }
            return v;
          }, l.toQuery = function(s) {
            return "CMCD=" + encodeURIComponent(l.serialize(s));
          }, l.appendQueryToUri = function(s, m) {
            if (!m)
              return s;
            var v = s.includes("?") ? "&" : "?";
            return "" + s + v + m;
          }, l;
        }();
      },
      "./src/controller/eme-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => r
        });
        var P = p("./src/events.ts"), T = p("./src/errors.ts"), k = p("./src/utils/logger.ts"), C = p("./src/utils/mediakeys-helper.ts"), B = p("./src/utils/keysystem-util.ts"), I = p("./src/utils/numeric-encoding-utils.ts"), L = p("./src/loader/level-key.ts"), D = p("./src/utils/hex.ts"), _ = p("./src/utils/mp4-tools.ts"), x = p("./node_modules/eventemitter3/index.js"), g = /* @__PURE__ */ p.n(x);
        function S(o, t) {
          o.prototype = Object.create(t.prototype), o.prototype.constructor = o, s(o, t);
        }
        function y(o) {
          var t = typeof Map == "function" ? /* @__PURE__ */ new Map() : void 0;
          return y = function(e) {
            if (e === null || !a(e))
              return e;
            if (typeof e != "function")
              throw new TypeError("Super expression must either be null or a function");
            if (typeof t < "u") {
              if (t.has(e))
                return t.get(e);
              t.set(e, h);
            }
            function h() {
              return l(e, arguments, m(this).constructor);
            }
            return h.prototype = Object.create(e.prototype, { constructor: { value: h, enumerable: !1, writable: !0, configurable: !0 } }), s(h, e);
          }, y(o);
        }
        function l(o, t, d) {
          return u() ? l = Reflect.construct.bind() : l = function(h, f, c) {
            var M = [null];
            M.push.apply(M, f);
            var w = Function.bind.apply(h, M), F = new w();
            return c && s(F, c.prototype), F;
          }, l.apply(null, arguments);
        }
        function u() {
          if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham)
            return !1;
          if (typeof Proxy == "function")
            return !0;
          try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
            })), !0;
          } catch {
            return !1;
          }
        }
        function a(o) {
          return Function.toString.call(o).indexOf("[native code]") !== -1;
        }
        function s(o, t) {
          return s = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(e, h) {
            return e.__proto__ = h, e;
          }, s(o, t);
        }
        function m(o) {
          return m = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(d) {
            return d.__proto__ || Object.getPrototypeOf(d);
          }, m(o);
        }
        var v = 3, i = "[eme]", n = /* @__PURE__ */ function() {
          function o(d) {
            this.hls = void 0, this.config = void 0, this.media = null, this.keyFormatPromise = null, this.keySystemAccessPromises = {}, this._requestLicenseFailureCount = 0, this.mediaKeySessions = [], this.keyIdToKeySessionPromise = {}, this.setMediaKeysQueue = o.CDMCleanupPromise ? [o.CDMCleanupPromise] : [], this.onMediaEncrypted = this._onMediaEncrypted.bind(this), this.onWaitingForKey = this._onWaitingForKey.bind(this), this.debug = k.logger.debug.bind(k.logger, i), this.log = k.logger.log.bind(k.logger, i), this.warn = k.logger.warn.bind(k.logger, i), this.error = k.logger.error.bind(k.logger, i), this.hls = d, this.config = d.config, this.registerListeners();
          }
          var t = o.prototype;
          return t.destroy = function() {
            this.unregisterListeners(), this.onMediaDetached(), this.hls = this.onMediaEncrypted = this.onWaitingForKey = this.keyIdToKeySessionPromise = null;
          }, t.registerListeners = function() {
            this.hls.on(P.Events.MEDIA_ATTACHED, this.onMediaAttached, this), this.hls.on(P.Events.MEDIA_DETACHED, this.onMediaDetached, this), this.hls.on(P.Events.MANIFEST_LOADED, this.onManifestLoaded, this);
          }, t.unregisterListeners = function() {
            this.hls.off(P.Events.MEDIA_ATTACHED, this.onMediaAttached, this), this.hls.off(P.Events.MEDIA_DETACHED, this.onMediaDetached, this), this.hls.off(P.Events.MANIFEST_LOADED, this.onManifestLoaded, this);
          }, t.getLicenseServerUrl = function(e) {
            var h = this.config, f = h.drmSystems, c = h.widevineLicenseUrl, M = f[e];
            if (M)
              return M.licenseUrl;
            if (e === C.KeySystems.WIDEVINE && c)
              return c;
            throw new Error('no license server URL configured for key-system "' + e + '"');
          }, t.getServerCertificateUrl = function(e) {
            var h = this.config.drmSystems, f = h[e];
            if (f)
              return f.serverCertificateUrl;
            this.log('No Server Certificate in config.drmSystems["' + e + '"]');
          }, t.attemptKeySystemAccess = function(e) {
            var h = this, f = this.hls.levels, c = function(U, N, H) {
              return !!U && H.indexOf(U) === N;
            }, M = f.map(function(F) {
              return F.audioCodec;
            }).filter(c), w = f.map(function(F) {
              return F.videoCodec;
            }).filter(c);
            return M.length + w.length === 0 && w.push("avc1.42e01e"), new Promise(function(F, U) {
              var N = function H(j) {
                var z = j.shift();
                h.getMediaKeysPromise(z, M, w).then(function(Y) {
                  return F({
                    keySystem: z,
                    mediaKeys: Y
                  });
                }).catch(function(Y) {
                  j.length ? H(j) : Y instanceof E ? U(Y) : U(new E({
                    type: T.ErrorTypes.KEY_SYSTEM_ERROR,
                    details: T.ErrorDetails.KEY_SYSTEM_NO_ACCESS,
                    error: Y,
                    fatal: !0
                  }, Y.message));
                });
              };
              N(e);
            });
          }, t.requestMediaKeySystemAccess = function(e, h) {
            var f = this.config.requestMediaKeySystemAccessFunc;
            if (typeof f != "function") {
              var c = "Configured requestMediaKeySystemAccess is not a function " + f;
              return C.requestMediaKeySystemAccess === null && self.location.protocol === "http:" && (c = "navigator.requestMediaKeySystemAccess is not available over insecure protocol " + location.protocol), Promise.reject(new Error(c));
            }
            return f(e, h);
          }, t.getMediaKeysPromise = function(e, h, f) {
            var c = this, M = (0, C.getSupportedMediaKeySystemConfigurations)(e, h, f, this.config.drmSystemOptions), w = this.keySystemAccessPromises[e], F = w == null ? void 0 : w.keySystemAccess;
            if (!F) {
              this.log('Requesting encrypted media "' + e + '" key-system access with config: ' + JSON.stringify(M)), F = this.requestMediaKeySystemAccess(e, M);
              var U = this.keySystemAccessPromises[e] = {
                keySystemAccess: F
              };
              return F.catch(function(N) {
                c.log('Failed to obtain access to key-system "' + e + '": ' + N);
              }), F.then(function(N) {
                c.log('Access for key-system "' + N.keySystem + '" obtained');
                var H = c.fetchServerCertificate(e);
                return c.log('Create media-keys for "' + e + '"'), U.mediaKeys = N.createMediaKeys().then(function(j) {
                  return c.log('Media-keys created for "' + e + '"'), H.then(function(z) {
                    return z ? c.setMediaKeysServerCertificate(j, e, z) : j;
                  });
                }), U.mediaKeys.catch(function(j) {
                  c.error('Failed to create media-keys for "' + e + '"}: ' + j);
                }), U.mediaKeys;
              });
            }
            return F.then(function() {
              return w.mediaKeys;
            });
          }, t.createMediaKeySessionContext = function(e) {
            var h = e.decryptdata, f = e.keySystem, c = e.mediaKeys;
            console.assert(!!c, "mediaKeys is defined"), this.log('Creating key-system session "' + f + '" keyId: ' + D.default.hexDump(h.keyId || []));
            var M = c.createSession(), w = {
              decryptdata: h,
              keySystem: f,
              mediaKeys: c,
              mediaKeysSession: M,
              keyStatus: "status-pending"
            };
            return this.mediaKeySessions.push(w), w;
          }, t.renewKeySession = function(e) {
            var h = e.decryptdata;
            if (h.pssh) {
              var f = this.createMediaKeySessionContext(e), c = this.getKeyIdString(h), M = "cenc";
              this.keyIdToKeySessionPromise[c] = this.generateRequestWithPreferredKeySession(f, M, h.pssh, "expired");
            } else
              this.warn("Could not renew expired session. Missing pssh initData.");
            this.removeSession(e);
          }, t.getKeyIdString = function(e) {
            if (!e)
              throw new Error("Could not read keyId of undefined decryptdata");
            if (e.keyId === null)
              throw new Error("keyId is null");
            return D.default.hexDump(e.keyId);
          }, t.updateKeySession = function(e, h) {
            var f, c = e.mediaKeysSession;
            return this.log('Updating key-session "' + c.sessionId + '" for keyID ' + D.default.hexDump(((f = e.decryptdata) === null || f === void 0 ? void 0 : f.keyId) || []) + `
      } (data length: ` + (h && h.byteLength) + ")"), c.update(h);
          }, t.selectKeySystemFormat = function(e) {
            var h = Object.keys(e.levelkeys || {});
            return this.keyFormatPromise || (this.log("Selecting key-system from fragment (sn: " + e.sn + " " + e.type + ": " + e.level + ") key formats " + h.join(", ")), this.keyFormatPromise = this.getKeyFormatPromise(h)), this.keyFormatPromise;
          }, t.getKeyFormatPromise = function(e) {
            var h = this;
            return new Promise(function(f, c) {
              var M = (0, C.getKeySystemsForConfig)(h.config), w = e.map(C.keySystemFormatToKeySystemDomain).filter(function(F) {
                return !!F && M.indexOf(F) !== -1;
              });
              return h.getKeySystemSelectionPromise(w).then(function(F) {
                var U = F.keySystem, N = (0, C.keySystemDomainToKeySystemFormat)(U);
                N ? f(N) : c(new Error('Unable to find format for key-system "' + U + '"'));
              }).catch(c);
            });
          }, t.loadKey = function(e) {
            var h = this, f = e.keyInfo.decryptdata, c = this.getKeyIdString(f), M = "(keyId: " + c + ' format: "' + f.keyFormat + '" method: ' + f.method + " uri: " + f.uri + ")";
            this.log("Starting session for key " + M);
            var w = this.keyIdToKeySessionPromise[c];
            return w || (w = this.keyIdToKeySessionPromise[c] = this.getKeySystemForKeyPromise(f).then(function(F) {
              var U = F.keySystem, N = F.mediaKeys;
              return h.throwIfDestroyed(), h.log("Handle encrypted media sn: " + e.frag.sn + " " + e.frag.type + ": " + e.frag.level + " using key " + M), h.attemptSetMediaKeys(U, N).then(function() {
                h.throwIfDestroyed();
                var H = h.createMediaKeySessionContext({
                  keySystem: U,
                  mediaKeys: N,
                  decryptdata: f
                }), j = "cenc";
                return h.generateRequestWithPreferredKeySession(H, j, f.pssh, "playlist-key");
              });
            }), w.catch(function(F) {
              return h.handleError(F);
            })), w;
          }, t.throwIfDestroyed = function(e) {
            if (!this.hls)
              throw new Error("invalid state");
          }, t.handleError = function(e) {
            !this.hls || (this.error(e.message), e instanceof E ? this.hls.trigger(P.Events.ERROR, e.data) : this.hls.trigger(P.Events.ERROR, {
              type: T.ErrorTypes.KEY_SYSTEM_ERROR,
              details: T.ErrorDetails.KEY_SYSTEM_NO_KEYS,
              error: e,
              fatal: !0
            }));
          }, t.getKeySystemForKeyPromise = function(e) {
            var h = this.getKeyIdString(e), f = this.keyIdToKeySessionPromise[h];
            if (!f) {
              var c = (0, C.keySystemFormatToKeySystemDomain)(e.keyFormat), M = c ? [c] : (0, C.getKeySystemsForConfig)(this.config);
              return this.attemptKeySystemAccess(M);
            }
            return f;
          }, t.getKeySystemSelectionPromise = function(e) {
            if (e.length || (e = (0, C.getKeySystemsForConfig)(this.config)), e.length === 0)
              throw new E({
                type: T.ErrorTypes.KEY_SYSTEM_ERROR,
                details: T.ErrorDetails.KEY_SYSTEM_NO_CONFIGURED_LICENSE,
                fatal: !0
              }, "Missing key-system license configuration options " + JSON.stringify({
                drmSystems: this.config.drmSystems
              }));
            return this.attemptKeySystemAccess(e);
          }, t._onMediaEncrypted = function(e) {
            var h = this, f = e.initDataType, c = e.initData;
            if (this.debug('"' + e.type + '" event: init data type: "' + f + '"'), c !== null) {
              var M, w;
              if (f === "sinf" && this.config.drmSystems[C.KeySystems.FAIRPLAY]) {
                var F = (0, _.bin2str)(new Uint8Array(c));
                try {
                  var U = (0, I.base64Decode)(JSON.parse(F).sinf), N = (0, _.parseSinf)(new Uint8Array(U));
                  if (!N)
                    return;
                  M = N.subarray(8, 24), w = C.KeySystems.FAIRPLAY;
                } catch {
                  this.warn('Failed to parse sinf "encrypted" event message initData');
                  return;
                }
              } else {
                var H = (0, _.parsePssh)(c);
                if (H === null)
                  return;
                H.version === 0 && H.systemId === C.KeySystemIds.WIDEVINE && H.data && (M = H.data.subarray(8, 24)), w = (0, C.keySystemIdToKeySystemDomain)(H.systemId);
              }
              if (!(!w || !M)) {
                for (var j = D.default.hexDump(M), z = this.keyIdToKeySessionPromise, Y = this.mediaKeySessions, X = z[j], Z = function(ne) {
                  var oe = Y[ne], ae = oe.decryptdata;
                  if (ae.pssh || !ae.keyId)
                    return "continue";
                  var ie = D.default.hexDump(ae.keyId);
                  if (j === ie || ae.uri.replace(/-/g, "").indexOf(j) !== -1)
                    return X = z[ie], delete z[ie], ae.pssh = new Uint8Array(c), ae.keyId = M, X = z[j] = X.then(function() {
                      return h.generateRequestWithPreferredKeySession(oe, f, c, "encrypted-event-key-match");
                    }), "break";
                }, te = 0; te < Y.length; te++) {
                  var $ = Z(te);
                  if ($ !== "continue" && $ === "break")
                    break;
                }
                X || (X = z[j] = this.getKeySystemSelectionPromise([w]).then(function(ee) {
                  var ne, oe = ee.keySystem, ae = ee.mediaKeys;
                  h.throwIfDestroyed();
                  var ie = new L.LevelKey("ISO-23001-7", j, (ne = (0, C.keySystemDomainToKeySystemFormat)(oe)) != null ? ne : "");
                  return ie.pssh = new Uint8Array(c), ie.keyId = M, h.attemptSetMediaKeys(oe, ae).then(function() {
                    h.throwIfDestroyed();
                    var ce = h.createMediaKeySessionContext({
                      decryptdata: ie,
                      keySystem: oe,
                      mediaKeys: ae
                    });
                    return h.generateRequestWithPreferredKeySession(ce, f, c, "encrypted-event-no-match");
                  });
                })), X.catch(function(ee) {
                  return h.handleError(ee);
                });
              }
            }
          }, t._onWaitingForKey = function(e) {
            this.log('"' + e.type + '" event');
          }, t.attemptSetMediaKeys = function(e, h) {
            var f = this, c = this.setMediaKeysQueue.slice();
            this.log('Setting media-keys for "' + e + '"');
            var M = Promise.all(c).then(function() {
              if (!f.media)
                throw new Error("Attempted to set mediaKeys without media element attached");
              return f.media.setMediaKeys(h);
            });
            return this.setMediaKeysQueue.push(M), M.then(function() {
              f.log('Media-keys set for "' + e + '"'), c.push(M), f.setMediaKeysQueue = f.setMediaKeysQueue.filter(function(w) {
                return c.indexOf(w) === -1;
              });
            });
          }, t.generateRequestWithPreferredKeySession = function(e, h, f, c) {
            var M, w, F = this, U = (M = this.config.drmSystems) === null || M === void 0 || (w = M[e.keySystem]) === null || w === void 0 ? void 0 : w.generateRequest;
            if (U)
              try {
                var N = U.call(this.hls, h, f, e);
                if (!N)
                  throw new Error("Invalid response from configured generateRequest filter");
                h = N.initDataType, f = e.decryptdata.pssh = N.initData ? new Uint8Array(N.initData) : null;
              } catch (X) {
                var H;
                if (this.warn(X.message), (H = this.hls) !== null && H !== void 0 && H.config.debug)
                  throw X;
              }
            if (f === null)
              return this.log('Skipping key-session request for "' + c + '" (no initData)'), Promise.resolve(e);
            var j = this.getKeyIdString(e.decryptdata);
            this.log('Generating key-session request for "' + c + '": ' + j + " (init data type: " + h + " length: " + (f ? f.byteLength : null) + ")");
            var z = new (g())();
            e.mediaKeysSession.onmessage = function(X) {
              var Z = e.mediaKeysSession;
              if (!Z) {
                z.emit("error", new Error("invalid state"));
                return;
              }
              var te = X.messageType, $ = X.message;
              F.log('"' + te + '" message event for session "' + Z.sessionId + '" message size: ' + $.byteLength), te === "license-request" || te === "license-renewal" ? F.renewLicense(e, $).catch(function(ee) {
                F.handleError(ee), z.emit("error", ee);
              }) : te === "license-release" ? e.keySystem === C.KeySystems.FAIRPLAY && (F.updateKeySession(e, (0, B.strToUtf8array)("acknowledged")), F.removeSession(e)) : F.warn('unhandled media key message type "' + te + '"');
            }, e.mediaKeysSession.onkeystatuseschange = function(X) {
              var Z = e.mediaKeysSession;
              if (!Z) {
                z.emit("error", new Error("invalid state"));
                return;
              }
              F.onKeyStatusChange(e);
              var te = e.keyStatus;
              z.emit("keyStatus", te), te === "expired" && (F.warn(e.keySystem + " expired for key " + j), F.renewKeySession(e));
            };
            var Y = new Promise(function(X, Z) {
              z.on("error", Z), z.on("keyStatus", function(te) {
                te.startsWith("usable") ? X() : te === "output-restricted" ? Z(new E({
                  type: T.ErrorTypes.KEY_SYSTEM_ERROR,
                  details: T.ErrorDetails.KEY_SYSTEM_STATUS_OUTPUT_RESTRICTED,
                  fatal: !1
                }, "HDCP level output restricted")) : te === "internal-error" ? Z(new E({
                  type: T.ErrorTypes.KEY_SYSTEM_ERROR,
                  details: T.ErrorDetails.KEY_SYSTEM_STATUS_INTERNAL_ERROR,
                  fatal: !0
                }, 'key status changed to "' + te + '"')) : te === "expired" ? Z(new Error("key expired while generating request")) : F.warn('unhandled key status change "' + te + '"');
              });
            });
            return e.mediaKeysSession.generateRequest(h, f).then(function() {
              var X;
              F.log('Request generated for key-session "' + ((X = e.mediaKeysSession) === null || X === void 0 ? void 0 : X.sessionId) + '" keyId: ' + j);
            }).catch(function(X) {
              throw new E({
                type: T.ErrorTypes.KEY_SYSTEM_ERROR,
                details: T.ErrorDetails.KEY_SYSTEM_NO_SESSION,
                error: X,
                fatal: !1
              }, "Error generating key-session request: " + X);
            }).then(function() {
              return Y;
            }).catch(function(X) {
              throw z.removeAllListeners(), F.removeSession(e), X;
            }).then(function() {
              return z.removeAllListeners(), e;
            });
          }, t.onKeyStatusChange = function(e) {
            var h = this;
            e.mediaKeysSession.keyStatuses.forEach(function(f, c) {
              h.log('key status change "' + f + '" for keyStatuses keyId: ' + D.default.hexDump("buffer" in c ? new Uint8Array(c.buffer, c.byteOffset, c.byteLength) : new Uint8Array(c)) + " session keyId: " + D.default.hexDump(new Uint8Array(e.decryptdata.keyId || [])) + " uri: " + e.decryptdata.uri), e.keyStatus = f;
            });
          }, t.fetchServerCertificate = function(e) {
            var h = this;
            return new Promise(function(f, c) {
              var M = h.getServerCertificateUrl(e);
              if (!M)
                return f();
              h.log('Fetching serverCertificate for "' + e + '"');
              var w = new XMLHttpRequest();
              w.open("GET", M, !0), w.responseType = "arraybuffer", w.onreadystatechange = function() {
                w.readyState === XMLHttpRequest.DONE && (w.status === 200 ? f(w.response) : c(new E({
                  type: T.ErrorTypes.KEY_SYSTEM_ERROR,
                  details: T.ErrorDetails.KEY_SYSTEM_SERVER_CERTIFICATE_REQUEST_FAILED,
                  fatal: !0,
                  networkDetails: w
                }, '"' + e + '" certificate request XHR failed (' + M + "). Status: " + w.status + " (" + w.statusText + ")")));
              }, w.send();
            });
          }, t.setMediaKeysServerCertificate = function(e, h, f) {
            var c = this;
            return new Promise(function(M, w) {
              e.setServerCertificate(f).then(function(F) {
                c.log("setServerCertificate " + (F ? "success" : "not supported by CDM") + " (" + (f == null ? void 0 : f.byteLength) + ') on "' + h + '"'), M(e);
              }).catch(function(F) {
                w(new E({
                  type: T.ErrorTypes.KEY_SYSTEM_ERROR,
                  details: T.ErrorDetails.KEY_SYSTEM_SERVER_CERTIFICATE_UPDATE_FAILED,
                  error: F,
                  fatal: !0
                }, F.message));
              });
            });
          }, t.renewLicense = function(e, h) {
            var f = this;
            return this.requestLicense(e, new Uint8Array(h)).then(function(c) {
              return f.updateKeySession(e, new Uint8Array(c)).catch(function(M) {
                throw new E({
                  type: T.ErrorTypes.KEY_SYSTEM_ERROR,
                  details: T.ErrorDetails.KEY_SYSTEM_SESSION_UPDATE_FAILED,
                  error: M,
                  fatal: !0
                }, M.message);
              });
            });
          }, t.setupLicenseXHR = function(e, h, f, c) {
            var M = this, w = this.config.licenseXhrSetup;
            return w ? Promise.resolve().then(function() {
              if (!f.decryptdata)
                throw new Error("Key removed");
              return w.call(M.hls, e, h, f, c);
            }).catch(function(F) {
              if (!f.decryptdata)
                throw F;
              return e.open("POST", h, !0), w.call(M.hls, e, h, f, c);
            }).then(function(F) {
              e.readyState || e.open("POST", h, !0);
              var U = F || c;
              return {
                xhr: e,
                licenseChallenge: U
              };
            }) : (e.open("POST", h, !0), Promise.resolve({
              xhr: e,
              licenseChallenge: c
            }));
          }, t.requestLicense = function(e, h) {
            var f = this;
            return new Promise(function(c, M) {
              var w = f.getLicenseServerUrl(e.keySystem);
              f.log("Sending license request to URL: " + w);
              var F = new XMLHttpRequest();
              F.responseType = "arraybuffer", F.onreadystatechange = function() {
                if (!f.hls || !e.mediaKeysSession)
                  return M(new Error("invalid state"));
                if (F.readyState === 4)
                  if (F.status === 200) {
                    f._requestLicenseFailureCount = 0;
                    var U = F.response;
                    f.log("License received " + (U instanceof ArrayBuffer ? U.byteLength : U));
                    var N = f.config.licenseResponseCallback;
                    if (N)
                      try {
                        U = N.call(f.hls, F, w, e);
                      } catch (j) {
                        f.error(j);
                      }
                    c(U);
                  } else if (f._requestLicenseFailureCount++, f._requestLicenseFailureCount > v || F.status >= 400 && F.status < 500)
                    M(new E({
                      type: T.ErrorTypes.KEY_SYSTEM_ERROR,
                      details: T.ErrorDetails.KEY_SYSTEM_LICENSE_REQUEST_FAILED,
                      fatal: !0,
                      networkDetails: F
                    }, "License Request XHR failed (" + w + "). Status: " + F.status + " (" + F.statusText + ")"));
                  else {
                    var H = v - f._requestLicenseFailureCount + 1;
                    f.warn("Retrying license request, " + H + " attempts left"), f.requestLicense(e, h).then(c, M);
                  }
              }, e.licenseXhr && e.licenseXhr.readyState !== XMLHttpRequest.DONE && e.licenseXhr.abort(), e.licenseXhr = F, f.setupLicenseXHR(F, w, e, h).then(function(U) {
                var N = U.xhr, H = U.licenseChallenge;
                N.send(H);
              });
            });
          }, t.onMediaAttached = function(e, h) {
            if (!!this.config.emeEnabled) {
              var f = h.media;
              this.media = f, f.addEventListener("encrypted", this.onMediaEncrypted), f.addEventListener("waitingforkey", this.onWaitingForKey);
            }
          }, t.onMediaDetached = function() {
            var e = this, h = this.media, f = this.mediaKeySessions;
            h && (h.removeEventListener("encrypted", this.onMediaEncrypted), h.removeEventListener("waitingforkey", this.onWaitingForKey), this.media = null), this._requestLicenseFailureCount = 0, this.setMediaKeysQueue = [], this.mediaKeySessions = [], this.keyIdToKeySessionPromise = {}, L.LevelKey.clearKeyUriToKeyIdMap();
            var c = f.length;
            o.CDMCleanupPromise = Promise.all(f.map(function(M) {
              return e.removeSession(M);
            }).concat(h == null ? void 0 : h.setMediaKeys(null).catch(function(M) {
              e.log("Could not clear media keys: " + M + ". media.src: " + (h == null ? void 0 : h.src));
            }))).then(function() {
              c && (e.log("finished closing key sessions and clearing media keys"), f.length = 0);
            }).catch(function(M) {
              e.log("Could not close sessions and clear media keys: " + M + ". media.src: " + (h == null ? void 0 : h.src));
            });
          }, t.onManifestLoaded = function(e, h) {
            var f = h.sessionKeys;
            if (!(!f || !this.config.emeEnabled) && !this.keyFormatPromise) {
              var c = f.reduce(function(M, w) {
                return M.indexOf(w.keyFormat) === -1 && M.push(w.keyFormat), M;
              }, []);
              this.log("Selecting key-system from session-keys " + c.join(", ")), this.keyFormatPromise = this.getKeyFormatPromise(c);
            }
          }, t.removeSession = function(e) {
            var h = this, f = e.mediaKeysSession, c = e.licenseXhr;
            if (f) {
              this.log("Remove licenses and keys and close session " + f.sessionId), f.onmessage = null, f.onkeystatuseschange = null, c && c.readyState !== XMLHttpRequest.DONE && c.abort(), e.mediaKeysSession = e.decryptdata = e.licenseXhr = void 0;
              var M = this.mediaKeySessions.indexOf(e);
              return M > -1 && this.mediaKeySessions.splice(M, 1), f.remove().catch(function(w) {
                h.log("Could not remove session: " + w);
              }).then(function() {
                return f.close();
              }).catch(function(w) {
                h.log("Could not close session: " + w);
              });
            }
          }, o;
        }();
        n.CDMCleanupPromise = void 0;
        var E = /* @__PURE__ */ function(o) {
          S(t, o);
          function t(d, e) {
            var h;
            return h = o.call(this, e) || this, h.data = void 0, h.data = d, d.err = d.error, h;
          }
          return t;
        }(/* @__PURE__ */ y(Error));
        const r = n;
      },
      "./src/controller/fps-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => C
        });
        var P = p("./src/events.ts"), T = p("./src/utils/logger.ts"), k = /* @__PURE__ */ function() {
          function B(L) {
            this.hls = void 0, this.isVideoPlaybackQualityAvailable = !1, this.timer = void 0, this.media = null, this.lastTime = void 0, this.lastDroppedFrames = 0, this.lastDecodedFrames = 0, this.streamController = void 0, this.hls = L, this.registerListeners();
          }
          var I = B.prototype;
          return I.setStreamController = function(D) {
            this.streamController = D;
          }, I.registerListeners = function() {
            this.hls.on(P.Events.MEDIA_ATTACHING, this.onMediaAttaching, this);
          }, I.unregisterListeners = function() {
            this.hls.off(P.Events.MEDIA_ATTACHING, this.onMediaAttaching);
          }, I.destroy = function() {
            this.timer && clearInterval(this.timer), this.unregisterListeners(), this.isVideoPlaybackQualityAvailable = !1, this.media = null;
          }, I.onMediaAttaching = function(D, _) {
            var x = this.hls.config;
            if (x.capLevelOnFPSDrop) {
              var g = _.media instanceof self.HTMLVideoElement ? _.media : null;
              this.media = g, g && typeof g.getVideoPlaybackQuality == "function" && (this.isVideoPlaybackQualityAvailable = !0), self.clearInterval(this.timer), this.timer = self.setInterval(this.checkFPSInterval.bind(this), x.fpsDroppedMonitoringPeriod);
            }
          }, I.checkFPS = function(D, _, x) {
            var g = performance.now();
            if (_) {
              if (this.lastTime) {
                var S = g - this.lastTime, y = x - this.lastDroppedFrames, l = _ - this.lastDecodedFrames, u = 1e3 * y / S, a = this.hls;
                if (a.trigger(P.Events.FPS_DROP, {
                  currentDropped: y,
                  currentDecoded: l,
                  totalDroppedFrames: x
                }), u > 0 && y > a.config.fpsDroppedMonitoringThreshold * l) {
                  var s = a.currentLevel;
                  T.logger.warn("drop FPS ratio greater than max allowed value for currentLevel: " + s), s > 0 && (a.autoLevelCapping === -1 || a.autoLevelCapping >= s) && (s = s - 1, a.trigger(P.Events.FPS_DROP_LEVEL_CAPPING, {
                    level: s,
                    droppedLevel: a.currentLevel
                  }), a.autoLevelCapping = s, this.streamController.nextLevelSwitch());
                }
              }
              this.lastTime = g, this.lastDroppedFrames = x, this.lastDecodedFrames = _;
            }
          }, I.checkFPSInterval = function() {
            var D = this.media;
            if (D)
              if (this.isVideoPlaybackQualityAvailable) {
                var _ = D.getVideoPlaybackQuality();
                this.checkFPS(D, _.totalVideoFrames, _.droppedVideoFrames);
              } else
                this.checkFPS(D, D.webkitDecodedFrameCount, D.webkitDroppedFrameCount);
          }, B;
        }();
        const C = k;
      },
      "./src/controller/fragment-finders.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          findFragWithCC: () => L,
          findFragmentByPDT: () => k,
          findFragmentByPTS: () => C,
          fragmentWithinToleranceTest: () => B,
          pdtWithinToleranceTest: () => I
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/utils/binary-search.ts");
        function k(D, _, x) {
          if (_ === null || !Array.isArray(D) || !D.length || !(0, P.isFiniteNumber)(_))
            return null;
          var g = D[0].programDateTime;
          if (_ < (g || 0))
            return null;
          var S = D[D.length - 1].endProgramDateTime;
          if (_ >= (S || 0))
            return null;
          x = x || 0;
          for (var y = 0; y < D.length; ++y) {
            var l = D[y];
            if (I(_, x, l))
              return l;
          }
          return null;
        }
        function C(D, _, x, g) {
          x === void 0 && (x = 0), g === void 0 && (g = 0);
          var S = null;
          if (D ? S = _[D.sn - _[0].sn + 1] || null : x === 0 && _[0].start === 0 && (S = _[0]), S && B(x, g, S) === 0)
            return S;
          var y = T.default.search(_, B.bind(null, x, g));
          return y && (y !== D || !S) ? y : S;
        }
        function B(D, _, x) {
          if (D === void 0 && (D = 0), _ === void 0 && (_ = 0), x.start <= D && x.start + x.duration > D)
            return 0;
          var g = Math.min(_, x.duration + (x.deltaPTS ? x.deltaPTS : 0));
          return x.start + x.duration - g <= D ? 1 : x.start - g > D && x.start ? -1 : 0;
        }
        function I(D, _, x) {
          var g = Math.min(_, x.duration + (x.deltaPTS ? x.deltaPTS : 0)) * 1e3, S = x.endProgramDateTime || 0;
          return S - g > D;
        }
        function L(D, _) {
          return T.default.search(D, function(x) {
            return x.cc < _ ? 1 : x.cc > _ ? -1 : 0;
          });
        }
      },
      "./src/controller/fragment-tracker.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          FragmentState: () => k,
          FragmentTracker: () => C
        });
        var P = p("./src/events.ts"), T = p("./src/types/loader.ts"), k;
        (function(L) {
          L.NOT_LOADED = "NOT_LOADED", L.APPENDING = "APPENDING", L.PARTIAL = "PARTIAL", L.OK = "OK";
        })(k || (k = {}));
        var C = /* @__PURE__ */ function() {
          function L(_) {
            this.activeFragment = null, this.activeParts = null, this.endListFragments = /* @__PURE__ */ Object.create(null), this.fragments = /* @__PURE__ */ Object.create(null), this.timeRanges = /* @__PURE__ */ Object.create(null), this.bufferPadding = 0.2, this.hls = void 0, this.hls = _, this._registerListeners();
          }
          var D = L.prototype;
          return D._registerListeners = function() {
            var x = this.hls;
            x.on(P.Events.BUFFER_APPENDED, this.onBufferAppended, this), x.on(P.Events.FRAG_BUFFERED, this.onFragBuffered, this), x.on(P.Events.FRAG_LOADED, this.onFragLoaded, this);
          }, D._unregisterListeners = function() {
            var x = this.hls;
            x.off(P.Events.BUFFER_APPENDED, this.onBufferAppended, this), x.off(P.Events.FRAG_BUFFERED, this.onFragBuffered, this), x.off(P.Events.FRAG_LOADED, this.onFragLoaded, this);
          }, D.destroy = function() {
            this._unregisterListeners(), this.fragments = this.endListFragments = this.timeRanges = this.activeFragment = this.activeParts = null;
          }, D.getAppendedFrag = function(x, g) {
            if (g === T.PlaylistLevelType.MAIN) {
              var S = this.activeFragment, y = this.activeParts;
              if (!S)
                return null;
              if (y)
                for (var l = y.length; l--; ) {
                  var u = y[l], a = u ? u.end : S.appendedPTS;
                  if (u.start <= x && a !== void 0 && x <= a)
                    return l > 9 && (this.activeParts = y.slice(l - 9)), u;
                }
              else if (S.start <= x && S.appendedPTS !== void 0 && x <= S.appendedPTS)
                return S;
            }
            return this.getBufferedFrag(x, g);
          }, D.getBufferedFrag = function(x, g) {
            for (var S = this.fragments, y = Object.keys(S), l = y.length; l--; ) {
              var u = S[y[l]];
              if ((u == null ? void 0 : u.body.type) === g && u.buffered) {
                var a = u.body;
                if (a.start <= x && x <= a.end)
                  return a;
              }
            }
            return null;
          }, D.detectEvictedFragments = function(x, g, S) {
            var y = this;
            this.timeRanges && (this.timeRanges[x] = g), Object.keys(this.fragments).forEach(function(l) {
              var u = y.fragments[l];
              if (!!u) {
                if (!u.buffered && !u.loaded) {
                  u.body.type === S && y.removeFragment(u.body);
                  return;
                }
                var a = u.range[x];
                !a || a.time.some(function(s) {
                  var m = !y.isTimeBuffered(s.startPTS, s.endPTS, g);
                  return m && y.removeFragment(u.body), m;
                });
              }
            });
          }, D.detectPartialFragments = function(x) {
            var g = this, S = this.timeRanges, y = x.frag, l = x.part;
            if (!(!S || y.sn === "initSegment")) {
              var u = I(y), a = this.fragments[u];
              !a || (Object.keys(S).forEach(function(s) {
                var m = y.elementaryStreams[s];
                if (!!m) {
                  var v = S[s], i = l !== null || m.partial === !0;
                  a.range[s] = g.getBufferedTimes(y, l, i, v);
                }
              }), a.loaded = null, Object.keys(a.range).length ? (a.buffered = !0, a.body.endList && (this.endListFragments[a.body.type] = a)) : this.removeFragment(a.body));
            }
          }, D.fragBuffered = function(x) {
            var g = I(x), S = this.fragments[g];
            S && (S.loaded = null, S.buffered = !0);
          }, D.getBufferedTimes = function(x, g, S, y) {
            for (var l = {
              time: [],
              partial: S
            }, u = g ? g.start : x.start, a = g ? g.end : x.end, s = x.minEndPTS || a, m = x.maxStartPTS || u, v = 0; v < y.length; v++) {
              var i = y.start(v) - this.bufferPadding, n = y.end(v) + this.bufferPadding;
              if (m >= i && s <= n) {
                l.time.push({
                  startPTS: Math.max(u, y.start(v)),
                  endPTS: Math.min(a, y.end(v))
                });
                break;
              } else if (u < n && a > i)
                l.partial = !0, l.time.push({
                  startPTS: Math.max(u, y.start(v)),
                  endPTS: Math.min(a, y.end(v))
                });
              else if (a <= i)
                break;
            }
            return l;
          }, D.getPartialFragment = function(x) {
            var g = null, S, y, l, u = 0, a = this.bufferPadding, s = this.fragments;
            return Object.keys(s).forEach(function(m) {
              var v = s[m];
              !v || B(v) && (y = v.body.start - a, l = v.body.end + a, x >= y && x <= l && (S = Math.min(x - y, l - x), u <= S && (g = v.body, u = S)));
            }), g;
          }, D.isEndListAppended = function(x) {
            var g = this.endListFragments[x];
            return g !== void 0 && (g.buffered || B(g));
          }, D.getState = function(x) {
            var g = I(x), S = this.fragments[g];
            return S ? S.buffered ? B(S) ? k.PARTIAL : k.OK : k.APPENDING : k.NOT_LOADED;
          }, D.isTimeBuffered = function(x, g, S) {
            for (var y, l, u = 0; u < S.length; u++) {
              if (y = S.start(u) - this.bufferPadding, l = S.end(u) + this.bufferPadding, x >= y && g <= l)
                return !0;
              if (g <= y)
                return !1;
            }
            return !1;
          }, D.onFragLoaded = function(x, g) {
            var S = g.frag, y = g.part;
            if (!(S.sn === "initSegment" || S.bitrateTest || y)) {
              var l = I(S);
              this.fragments[l] = {
                body: S,
                loaded: g,
                buffered: !1,
                range: /* @__PURE__ */ Object.create(null)
              };
            }
          }, D.onBufferAppended = function(x, g) {
            var S = this, y = g.frag, l = g.part, u = g.timeRanges;
            if (y.type === T.PlaylistLevelType.MAIN)
              if (this.activeFragment !== y && (this.activeFragment = y, y.appendedPTS = void 0), l) {
                var a = this.activeParts;
                a || (this.activeParts = a = []), a.push(l);
              } else
                this.activeParts = null;
            this.timeRanges = u, Object.keys(u).forEach(function(s) {
              var m = u[s];
              if (S.detectEvictedFragments(s, m), !l && y.type === T.PlaylistLevelType.MAIN) {
                var v = y.elementaryStreams[s];
                if (!v)
                  return;
                for (var i = 0; i < m.length; i++) {
                  var n = m.end(i);
                  n <= v.endPTS && n > v.startPTS ? y.appendedPTS = Math.max(n, y.appendedPTS || 0) : y.appendedPTS = v.endPTS;
                }
              }
            });
          }, D.onFragBuffered = function(x, g) {
            this.detectPartialFragments(g);
          }, D.hasFragment = function(x) {
            var g = I(x);
            return !!this.fragments[g];
          }, D.removeFragmentsInRange = function(x, g, S) {
            var y = this;
            Object.keys(this.fragments).forEach(function(l) {
              var u = y.fragments[l];
              if (!!u && u.buffered) {
                var a = u.body;
                a.type === S && a.start < g && a.end > x && y.removeFragment(a);
              }
            });
          }, D.removeFragment = function(x) {
            var g = I(x);
            x.stats.loaded = 0, x.clearElementaryStreamInfo(), x.appendedPTS = void 0, delete this.fragments[g], x.endList && delete this.endListFragments[x.type];
          }, D.removeAllFragments = function() {
            this.fragments = /* @__PURE__ */ Object.create(null), this.endListFragments = /* @__PURE__ */ Object.create(null), this.activeFragment = null, this.activeParts = null;
          }, L;
        }();
        function B(L) {
          var D, _;
          return L.buffered && (((D = L.range.video) === null || D === void 0 ? void 0 : D.partial) || ((_ = L.range.audio) === null || _ === void 0 ? void 0 : _.partial));
        }
        function I(L) {
          return L.type + "_" + L.level + "_" + L.urlId + "_" + L.sn;
        }
      },
      "./src/controller/gap-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          MAX_START_GAP_JUMP: () => I,
          SKIP_BUFFER_HOLE_STEP_SECONDS: () => L,
          SKIP_BUFFER_RANGE_START: () => D,
          STALL_MINIMUM_DURATION_MS: () => B,
          default: () => _
        });
        var P = p("./src/utils/buffer-helper.ts"), T = p("./src/errors.ts"), k = p("./src/events.ts"), C = p("./src/utils/logger.ts"), B = 250, I = 2, L = 0.1, D = 0.05, _ = /* @__PURE__ */ function() {
          function x(S, y, l, u) {
            this.config = void 0, this.media = null, this.fragmentTracker = void 0, this.hls = void 0, this.nudgeRetry = 0, this.stallReported = !1, this.stalled = null, this.moved = !1, this.seeking = !1, this.config = S, this.media = y, this.fragmentTracker = l, this.hls = u;
          }
          var g = x.prototype;
          return g.destroy = function() {
            this.media = null, this.hls = this.fragmentTracker = null;
          }, g.poll = function(y, l) {
            var u = this.config, a = this.media, s = this.stalled;
            if (a !== null) {
              var m = a.currentTime, v = a.seeking, i = this.seeking && !v, n = !this.seeking && v;
              if (this.seeking = v, m !== y) {
                if (this.moved = !0, s !== null) {
                  if (this.stallReported) {
                    var E = self.performance.now() - s;
                    C.logger.warn("playback not stuck anymore @" + m + ", after " + Math.round(E) + "ms"), this.stallReported = !1;
                  }
                  this.stalled = null, this.nudgeRetry = 0;
                }
                return;
              }
              if ((n || i) && (this.stalled = null), !(a.paused && !v || a.ended || a.playbackRate === 0 || !P.BufferHelper.getBuffered(a).length)) {
                var r = P.BufferHelper.bufferInfo(a, m, 0), o = r.len > 0, t = r.nextStart || 0;
                if (!(!o && !t)) {
                  if (v) {
                    var d = r.len > I, e = !t || l && l.start <= m || t - m > I && !this.fragmentTracker.getPartialFragment(m);
                    if (d || e)
                      return;
                    this.moved = !1;
                  }
                  if (!this.moved && this.stalled !== null) {
                    var h, f = Math.max(t, r.start || 0) - m, c = this.hls.levels ? this.hls.levels[this.hls.currentLevel] : null, M = c == null || (h = c.details) === null || h === void 0 ? void 0 : h.live, w = M ? c.details.targetduration * 2 : I;
                    if (f > 0 && f <= w) {
                      this._trySkipBufferHole(null);
                      return;
                    }
                  }
                  var F = self.performance.now();
                  if (s === null) {
                    this.stalled = F;
                    return;
                  }
                  var U = F - s;
                  if (!(!v && U >= B && (this._reportStall(r), !this.media))) {
                    var N = P.BufferHelper.bufferInfo(a, m, u.maxBufferHole);
                    this._tryFixBufferStall(N, U);
                  }
                }
              }
            }
          }, g._tryFixBufferStall = function(y, l) {
            var u = this.config, a = this.fragmentTracker, s = this.media;
            if (s !== null) {
              var m = s.currentTime, v = a.getPartialFragment(m);
              if (v) {
                var i = this._trySkipBufferHole(v);
                if (i || !this.media)
                  return;
              }
              y.len > u.maxBufferHole && l > u.highBufferWatchdogPeriod * 1e3 && (C.logger.warn("Trying to nudge playhead over buffer-hole"), this.stalled = null, this._tryNudgeBuffer());
            }
          }, g._reportStall = function(y) {
            var l = this.hls, u = this.media, a = this.stallReported;
            !a && u && (this.stallReported = !0, C.logger.warn("Playback stalling at @" + u.currentTime + " due to low buffer (" + JSON.stringify(y) + ")"), l.trigger(k.Events.ERROR, {
              type: T.ErrorTypes.MEDIA_ERROR,
              details: T.ErrorDetails.BUFFER_STALLED_ERROR,
              fatal: !1,
              buffer: y.len
            }));
          }, g._trySkipBufferHole = function(y) {
            var l = this.config, u = this.hls, a = this.media;
            if (a === null)
              return 0;
            for (var s = a.currentTime, m = 0, v = P.BufferHelper.getBuffered(a), i = 0; i < v.length; i++) {
              var n = v.start(i);
              if (s + l.maxBufferHole >= m && s < n) {
                var E = Math.max(n + D, a.currentTime + L);
                return C.logger.warn("skipping hole, adjusting currentTime from " + s + " to " + E), this.moved = !0, this.stalled = null, a.currentTime = E, y && u.trigger(k.Events.ERROR, {
                  type: T.ErrorTypes.MEDIA_ERROR,
                  details: T.ErrorDetails.BUFFER_SEEK_OVER_HOLE,
                  fatal: !1,
                  reason: "fragment loaded with buffer holes, seeking from " + s + " to " + E,
                  frag: y
                }), E;
              }
              m = v.end(i);
            }
            return 0;
          }, g._tryNudgeBuffer = function() {
            var y = this.config, l = this.hls, u = this.media, a = this.nudgeRetry;
            if (u !== null) {
              var s = u.currentTime;
              if (this.nudgeRetry++, a < y.nudgeMaxRetry) {
                var m = s + (a + 1) * y.nudgeOffset;
                C.logger.warn("Nudging 'currentTime' from " + s + " to " + m), u.currentTime = m, l.trigger(k.Events.ERROR, {
                  type: T.ErrorTypes.MEDIA_ERROR,
                  details: T.ErrorDetails.BUFFER_NUDGE_ON_STALL,
                  fatal: !1
                });
              } else
                C.logger.error("Playhead still not moving while enough data buffered @" + s + " after " + y.nudgeMaxRetry + " nudges"), l.trigger(k.Events.ERROR, {
                  type: T.ErrorTypes.MEDIA_ERROR,
                  details: T.ErrorDetails.BUFFER_STALLED_ERROR,
                  fatal: !0
                });
            }
          }, x;
        }();
      },
      "./src/controller/id3-track-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => y
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/events.ts"), k = p("./src/utils/texttrack-utils.ts"), C = p("./src/demux/id3.ts"), B = p("./src/loader/date-range.ts"), I = p("./src/types/demuxer.ts"), L = 0.25;
        function D() {
          return self.WebKitDataCue || self.VTTCue || self.TextTrackCue;
        }
        var _ = function() {
          var l = D();
          try {
            new l(0, Number.POSITIVE_INFINITY, "");
          } catch {
            return Number.MAX_VALUE;
          }
          return Number.POSITIVE_INFINITY;
        }();
        function x(l, u) {
          return l.getTime() / 1e3 - u;
        }
        function g(l) {
          return Uint8Array.from(l.replace(/^0x/, "").replace(/([\da-fA-F]{2}) ?/g, "0x$1 ").replace(/ +$/, "").split(" ")).buffer;
        }
        var S = /* @__PURE__ */ function() {
          function l(a) {
            this.hls = void 0, this.id3Track = null, this.media = null, this.dateRangeCuesAppended = {}, this.hls = a, this._registerListeners();
          }
          var u = l.prototype;
          return u.destroy = function() {
            this._unregisterListeners(), this.id3Track = null, this.media = null, this.dateRangeCuesAppended = {}, this.hls = null;
          }, u._registerListeners = function() {
            var s = this.hls;
            s.on(T.Events.MEDIA_ATTACHED, this.onMediaAttached, this), s.on(T.Events.MEDIA_DETACHING, this.onMediaDetaching, this), s.on(T.Events.MANIFEST_LOADING, this.onManifestLoading, this), s.on(T.Events.FRAG_PARSING_METADATA, this.onFragParsingMetadata, this), s.on(T.Events.BUFFER_FLUSHING, this.onBufferFlushing, this), s.on(T.Events.LEVEL_UPDATED, this.onLevelUpdated, this);
          }, u._unregisterListeners = function() {
            var s = this.hls;
            s.off(T.Events.MEDIA_ATTACHED, this.onMediaAttached, this), s.off(T.Events.MEDIA_DETACHING, this.onMediaDetaching, this), s.off(T.Events.MANIFEST_LOADING, this.onManifestLoading, this), s.off(T.Events.FRAG_PARSING_METADATA, this.onFragParsingMetadata, this), s.off(T.Events.BUFFER_FLUSHING, this.onBufferFlushing, this), s.off(T.Events.LEVEL_UPDATED, this.onLevelUpdated, this);
          }, u.onMediaAttached = function(s, m) {
            this.media = m.media;
          }, u.onMediaDetaching = function() {
            !this.id3Track || ((0, k.clearCurrentCues)(this.id3Track), this.id3Track = null, this.media = null, this.dateRangeCuesAppended = {});
          }, u.onManifestLoading = function() {
            this.dateRangeCuesAppended = {};
          }, u.createTrack = function(s) {
            var m = this.getID3Track(s.textTracks);
            return m.mode = "hidden", m;
          }, u.getID3Track = function(s) {
            if (!!this.media) {
              for (var m = 0; m < s.length; m++) {
                var v = s[m];
                if (v.kind === "metadata" && v.label === "id3")
                  return (0, k.sendAddTrackEvent)(v, this.media), v;
              }
              return this.media.addTextTrack("metadata", "id3");
            }
          }, u.onFragParsingMetadata = function(s, m) {
            if (!!this.media) {
              var v = this.hls.config, i = v.enableEmsgMetadataCues, n = v.enableID3MetadataCues;
              if (!(!i && !n)) {
                var E = m.samples;
                this.id3Track || (this.id3Track = this.createTrack(this.media));
                for (var r = D(), o = 0; o < E.length; o++) {
                  var t = E[o].type;
                  if (!(t === I.MetadataSchema.emsg && !i || !n)) {
                    var d = C.getID3Frames(E[o].data);
                    if (d) {
                      var e = E[o].pts, h = e + E[o].duration;
                      h > _ && (h = _);
                      var f = h - e;
                      f <= 0 && (h = e + L);
                      for (var c = 0; c < d.length; c++) {
                        var M = d[c];
                        if (!C.isTimeStampFrame(M)) {
                          this.updateId3CueEnds(e);
                          var w = new r(e, h, "");
                          w.value = M, t && (w.type = t), this.id3Track.addCue(w);
                        }
                      }
                    }
                  }
                }
              }
            }
          }, u.updateId3CueEnds = function(s) {
            var m, v = (m = this.id3Track) === null || m === void 0 ? void 0 : m.cues;
            if (v)
              for (var i = v.length; i--; ) {
                var n = v[i];
                n.startTime < s && n.endTime === _ && (n.endTime = s);
              }
          }, u.onBufferFlushing = function(s, m) {
            var v = m.startOffset, i = m.endOffset, n = m.type, E = this.id3Track, r = this.hls;
            if (!!r) {
              var o = r.config, t = o.enableEmsgMetadataCues, d = o.enableID3MetadataCues;
              if (E && (t || d)) {
                var e;
                n === "audio" ? e = function(f) {
                  return f.type === I.MetadataSchema.audioId3 && d;
                } : n === "video" ? e = function(f) {
                  return f.type === I.MetadataSchema.emsg && t;
                } : e = function(f) {
                  return f.type === I.MetadataSchema.audioId3 && d || f.type === I.MetadataSchema.emsg && t;
                }, (0, k.removeCuesInRange)(E, v, i, e);
              }
            }
          }, u.onLevelUpdated = function(s, m) {
            var v = this, i = m.details;
            if (!(!this.media || !i.hasProgramDateTime || !this.hls.config.enableDateRangeMetadataCues)) {
              var n = this.dateRangeCuesAppended, E = this.id3Track, r = i.dateRanges, o = Object.keys(r);
              if (E)
                for (var t = Object.keys(n).filter(function(F) {
                  return !o.includes(F);
                }), d = function(U) {
                  var N = t[U];
                  Object.keys(n[N].cues).forEach(function(H) {
                    E.removeCue(n[N].cues[H]);
                  }), delete n[N];
                }, e = t.length; e--; )
                  d(e);
              var h = i.fragments[i.fragments.length - 1];
              if (!(o.length === 0 || !(0, P.isFiniteNumber)(h == null ? void 0 : h.programDateTime))) {
                this.id3Track || (this.id3Track = this.createTrack(this.media));
                for (var f = h.programDateTime / 1e3 - h.start, c = D(), M = function(U) {
                  var N = o[U], H = r[N], j = n[N], z = (j == null ? void 0 : j.cues) || {}, Y = (j == null ? void 0 : j.durationKnown) || !1, X = x(H.startDate, f), Z = _, te = H.endDate;
                  if (te)
                    Z = x(te, f), Y = !0;
                  else if (H.endOnNext && !Y) {
                    var $ = o.reduce(function(ce, me) {
                      var pe = r[me];
                      return pe.class === H.class && pe.id !== me && pe.startDate > H.startDate && ce.push(pe), ce;
                    }, []).sort(function(ce, me) {
                      return ce.startDate.getTime() - me.startDate.getTime();
                    })[0];
                    $ && (Z = x($.startDate, f), Y = !0);
                  }
                  for (var ee = Object.keys(H.attr), ne = 0; ne < ee.length; ne++) {
                    var oe = ee[ne];
                    if (!(oe === B.DateRangeAttribute.ID || oe === B.DateRangeAttribute.CLASS || oe === B.DateRangeAttribute.START_DATE || oe === B.DateRangeAttribute.DURATION || oe === B.DateRangeAttribute.END_DATE || oe === B.DateRangeAttribute.END_ON_NEXT)) {
                      var ae = z[oe];
                      if (ae)
                        Y && !j.durationKnown && (ae.endTime = Z);
                      else {
                        var ie = H.attr[oe];
                        ae = new c(X, Z, ""), (oe === B.DateRangeAttribute.SCTE35_OUT || oe === B.DateRangeAttribute.SCTE35_IN) && (ie = g(ie)), ae.value = {
                          key: oe,
                          data: ie
                        }, ae.type = I.MetadataSchema.dateRange, v.id3Track.addCue(ae), z[oe] = ae;
                      }
                    }
                  }
                  n[N] = {
                    cues: z,
                    dateRange: H,
                    durationKnown: Y
                  };
                }, w = 0; w < o.length; w++)
                  M(w);
              }
            }
          }, l;
        }();
        const y = S;
      },
      "./src/controller/latency-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => D
        });
        var P = p("./src/errors.ts"), T = p("./src/events.ts"), k = p("./src/utils/logger.ts");
        function C(_, x) {
          for (var g = 0; g < x.length; g++) {
            var S = x[g];
            S.enumerable = S.enumerable || !1, S.configurable = !0, "value" in S && (S.writable = !0), Object.defineProperty(_, I(S.key), S);
          }
        }
        function B(_, x, g) {
          return x && C(_.prototype, x), g && C(_, g), Object.defineProperty(_, "prototype", { writable: !1 }), _;
        }
        function I(_) {
          var x = L(_, "string");
          return typeof x == "symbol" ? x : String(x);
        }
        function L(_, x) {
          if (typeof _ != "object" || _ === null)
            return _;
          var g = _[Symbol.toPrimitive];
          if (g !== void 0) {
            var S = g.call(_, x || "default");
            if (typeof S != "object")
              return S;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (x === "string" ? String : Number)(_);
        }
        var D = /* @__PURE__ */ function() {
          function _(g) {
            var S = this;
            this.hls = void 0, this.config = void 0, this.media = null, this.levelDetails = null, this.currentTime = 0, this.stallCount = 0, this._latency = null, this.timeupdateHandler = function() {
              return S.timeupdate();
            }, this.hls = g, this.config = g.config, this.registerListeners();
          }
          var x = _.prototype;
          return x.destroy = function() {
            this.unregisterListeners(), this.onMediaDetaching(), this.levelDetails = null, this.hls = this.timeupdateHandler = null;
          }, x.registerListeners = function() {
            this.hls.on(T.Events.MEDIA_ATTACHED, this.onMediaAttached, this), this.hls.on(T.Events.MEDIA_DETACHING, this.onMediaDetaching, this), this.hls.on(T.Events.MANIFEST_LOADING, this.onManifestLoading, this), this.hls.on(T.Events.LEVEL_UPDATED, this.onLevelUpdated, this), this.hls.on(T.Events.ERROR, this.onError, this);
          }, x.unregisterListeners = function() {
            this.hls.off(T.Events.MEDIA_ATTACHED, this.onMediaAttached), this.hls.off(T.Events.MEDIA_DETACHING, this.onMediaDetaching), this.hls.off(T.Events.MANIFEST_LOADING, this.onManifestLoading), this.hls.off(T.Events.LEVEL_UPDATED, this.onLevelUpdated), this.hls.off(T.Events.ERROR, this.onError);
          }, x.onMediaAttached = function(S, y) {
            this.media = y.media, this.media.addEventListener("timeupdate", this.timeupdateHandler);
          }, x.onMediaDetaching = function() {
            this.media && (this.media.removeEventListener("timeupdate", this.timeupdateHandler), this.media = null);
          }, x.onManifestLoading = function() {
            this.levelDetails = null, this._latency = null, this.stallCount = 0;
          }, x.onLevelUpdated = function(S, y) {
            var l = y.details;
            this.levelDetails = l, l.advanced && this.timeupdate(), !l.live && this.media && this.media.removeEventListener("timeupdate", this.timeupdateHandler);
          }, x.onError = function(S, y) {
            y.details === P.ErrorDetails.BUFFER_STALLED_ERROR && (this.stallCount++, k.logger.warn("[playback-rate-controller]: Stall detected, adjusting target latency"));
          }, x.timeupdate = function() {
            var S = this.media, y = this.levelDetails;
            if (!(!S || !y)) {
              this.currentTime = S.currentTime;
              var l = this.computeLatency();
              if (l !== null) {
                this._latency = l;
                var u = this.config, a = u.lowLatencyMode, s = u.maxLiveSyncPlaybackRate;
                if (!(!a || s === 1)) {
                  var m = this.targetLatency;
                  if (m !== null) {
                    var v = l - m, i = Math.min(this.maxLatency, m + y.targetduration), n = v < i;
                    if (y.live && n && v > 0.05 && this.forwardBufferLength > 1) {
                      var E = Math.min(2, Math.max(1, s)), r = Math.round(2 / (1 + Math.exp(-0.75 * v - this.edgeStalled)) * 20) / 20;
                      S.playbackRate = Math.min(E, Math.max(1, r));
                    } else
                      S.playbackRate !== 1 && S.playbackRate !== 0 && (S.playbackRate = 1);
                  }
                }
              }
            }
          }, x.estimateLiveEdge = function() {
            var S = this.levelDetails;
            return S === null ? null : S.edge + S.age;
          }, x.computeLatency = function() {
            var S = this.estimateLiveEdge();
            return S === null ? null : S - this.currentTime;
          }, B(_, [{
            key: "latency",
            get: function() {
              return this._latency || 0;
            }
          }, {
            key: "maxLatency",
            get: function() {
              var S = this.config, y = this.levelDetails;
              return S.liveMaxLatencyDuration !== void 0 ? S.liveMaxLatencyDuration : y ? S.liveMaxLatencyDurationCount * y.targetduration : 0;
            }
          }, {
            key: "targetLatency",
            get: function() {
              var S = this.levelDetails;
              if (S === null)
                return null;
              var y = S.holdBack, l = S.partHoldBack, u = S.targetduration, a = this.config, s = a.liveSyncDuration, m = a.liveSyncDurationCount, v = a.lowLatencyMode, i = this.hls.userConfig, n = v && l || y;
              (i.liveSyncDuration || i.liveSyncDurationCount || n === 0) && (n = s !== void 0 ? s : m * u);
              var E = u, r = 1;
              return n + Math.min(this.stallCount * r, E);
            }
          }, {
            key: "liveSyncPosition",
            get: function() {
              var S = this.estimateLiveEdge(), y = this.targetLatency, l = this.levelDetails;
              if (S === null || y === null || l === null)
                return null;
              var u = l.edge, a = S - y - this.edgeStalled, s = u - l.totalduration, m = u - (this.config.lowLatencyMode && l.partTarget || l.targetduration);
              return Math.min(Math.max(s, a), m);
            }
          }, {
            key: "drift",
            get: function() {
              var S = this.levelDetails;
              return S === null ? 1 : S.drift;
            }
          }, {
            key: "edgeStalled",
            get: function() {
              var S = this.levelDetails;
              if (S === null)
                return 0;
              var y = (this.config.lowLatencyMode && S.partTarget || S.targetduration) * 3;
              return Math.max(S.age - y, 0);
            }
          }, {
            key: "forwardBufferLength",
            get: function() {
              var S = this.media, y = this.levelDetails;
              if (!S || !y)
                return 0;
              var l = S.buffered.length;
              return (l ? S.buffered.end(l - 1) : y.edge) - this.currentTime;
            }
          }]), _;
        }();
      },
      "./src/controller/level-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => a
        });
        var P = p("./src/types/level.ts"), T = p("./src/events.ts"), k = p("./src/errors.ts"), C = p("./src/utils/codecs.ts"), B = p("./src/controller/level-helper.ts"), I = p("./src/controller/base-playlist-controller.ts"), L = p("./src/types/loader.ts");
        function D() {
          return D = Object.assign ? Object.assign.bind() : function(s) {
            for (var m = 1; m < arguments.length; m++) {
              var v = arguments[m];
              for (var i in v)
                Object.prototype.hasOwnProperty.call(v, i) && (s[i] = v[i]);
            }
            return s;
          }, D.apply(this, arguments);
        }
        function _(s, m) {
          for (var v = 0; v < m.length; v++) {
            var i = m[v];
            i.enumerable = i.enumerable || !1, i.configurable = !0, "value" in i && (i.writable = !0), Object.defineProperty(s, g(i.key), i);
          }
        }
        function x(s, m, v) {
          return m && _(s.prototype, m), v && _(s, v), Object.defineProperty(s, "prototype", { writable: !1 }), s;
        }
        function g(s) {
          var m = S(s, "string");
          return typeof m == "symbol" ? m : String(m);
        }
        function S(s, m) {
          if (typeof s != "object" || s === null)
            return s;
          var v = s[Symbol.toPrimitive];
          if (v !== void 0) {
            var i = v.call(s, m || "default");
            if (typeof i != "object")
              return i;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (m === "string" ? String : Number)(s);
        }
        function y(s, m) {
          s.prototype = Object.create(m.prototype), s.prototype.constructor = s, l(s, m);
        }
        function l(s, m) {
          return l = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(i, n) {
            return i.__proto__ = n, i;
          }, l(s, m);
        }
        var u = /chrome|firefox/.test(navigator.userAgent.toLowerCase()), a = /* @__PURE__ */ function(s) {
          y(m, s);
          function m(i) {
            var n;
            return n = s.call(this, i, "[level-controller]") || this, n._levels = [], n._firstLevel = -1, n._startLevel = void 0, n.currentLevelIndex = -1, n.manualLevelIndex = -1, n.onParsedComplete = void 0, n._registerListeners(), n;
          }
          var v = m.prototype;
          return v._registerListeners = function() {
            var n = this.hls;
            n.on(T.Events.MANIFEST_LOADED, this.onManifestLoaded, this), n.on(T.Events.LEVEL_LOADED, this.onLevelLoaded, this), n.on(T.Events.AUDIO_TRACK_SWITCHED, this.onAudioTrackSwitched, this), n.on(T.Events.FRAG_LOADED, this.onFragLoaded, this), n.on(T.Events.ERROR, this.onError, this);
          }, v._unregisterListeners = function() {
            var n = this.hls;
            n.off(T.Events.MANIFEST_LOADED, this.onManifestLoaded, this), n.off(T.Events.LEVEL_LOADED, this.onLevelLoaded, this), n.off(T.Events.AUDIO_TRACK_SWITCHED, this.onAudioTrackSwitched, this), n.off(T.Events.FRAG_LOADED, this.onFragLoaded, this), n.off(T.Events.ERROR, this.onError, this);
          }, v.destroy = function() {
            this._unregisterListeners(), this.manualLevelIndex = -1, this._levels.length = 0, s.prototype.destroy.call(this);
          }, v.startLoad = function() {
            var n = this._levels;
            n.forEach(function(E) {
              E.loadError = 0;
            }), s.prototype.startLoad.call(this);
          }, v.onManifestLoaded = function(n, E) {
            var r = [], o = [], t = [], d, e = {}, h, f = !1, c = !1, M = !1;
            if (E.levels.forEach(function(N) {
              var H = N.attrs;
              f = f || !!(N.width && N.height), c = c || !!N.videoCodec, M = M || !!N.audioCodec, u && N.audioCodec && N.audioCodec.indexOf("mp4a.40.34") !== -1 && (N.audioCodec = void 0);
              var j = N.bitrate + "-" + N.attrs.RESOLUTION + "-" + N.attrs.CODECS;
              h = e[j], h ? h.url.push(N.url) : (h = new P.Level(N), e[j] = h, r.push(h)), H && (H.AUDIO && (0, B.addGroupId)(h, "audio", H.AUDIO), H.SUBTITLES && (0, B.addGroupId)(h, "text", H.SUBTITLES));
            }), (f || c) && M && (r = r.filter(function(N) {
              var H = N.videoCodec, j = N.width, z = N.height;
              return !!H || !!(j && z);
            })), r = r.filter(function(N) {
              var H = N.audioCodec, j = N.videoCodec;
              return (!H || (0, C.isCodecSupportedInMp4)(H, "audio")) && (!j || (0, C.isCodecSupportedInMp4)(j, "video"));
            }), E.audioTracks && (o = E.audioTracks.filter(function(N) {
              return !N.audioCodec || (0, C.isCodecSupportedInMp4)(N.audioCodec, "audio");
            }), (0, B.assignTrackIdsByGroup)(o)), E.subtitles && (t = E.subtitles, (0, B.assignTrackIdsByGroup)(t)), r.length > 0) {
              d = r[0].bitrate, r.sort(function(N, H) {
                return N.attrs["HDCP-LEVEL"] !== H.attrs["HDCP-LEVEL"] ? (N.attrs["HDCP-LEVEL"] || "") > (H.attrs["HDCP-LEVEL"] || "") ? 1 : -1 : N.bitrate !== H.bitrate ? N.bitrate - H.bitrate : N.attrs.SCORE !== H.attrs.SCORE ? N.attrs.decimalFloatingPoint("SCORE") - H.attrs.decimalFloatingPoint("SCORE") : f && N.height !== H.height ? N.height - H.height : 0;
              }), this._levels = r;
              for (var w = 0; w < r.length; w++)
                if (r[w].bitrate === d) {
                  this._firstLevel = w, this.log("manifest loaded, " + r.length + " level(s) found, first bitrate: " + d);
                  break;
                }
              var F = M && !c, U = {
                levels: r,
                audioTracks: o,
                subtitleTracks: t,
                sessionData: E.sessionData,
                sessionKeys: E.sessionKeys,
                firstLevel: this._firstLevel,
                stats: E.stats,
                audio: M,
                video: c,
                altAudio: !F && o.some(function(N) {
                  return !!N.url;
                })
              };
              this.hls.trigger(T.Events.MANIFEST_PARSED, U), (this.hls.config.autoStartLoad || this.hls.forceStartLoad) && this.hls.startLoad(this.hls.config.startPosition);
            } else
              this.hls.trigger(T.Events.ERROR, {
                type: k.ErrorTypes.MEDIA_ERROR,
                details: k.ErrorDetails.MANIFEST_INCOMPATIBLE_CODECS_ERROR,
                fatal: !0,
                url: E.url,
                reason: "no level with compatible codecs found in manifest"
              });
          }, v.onError = function(n, E) {
            var r, o;
            if (s.prototype.onError.call(this, n, E), !E.fatal) {
              var t = E.context, d = this._levels[this.currentLevelIndex];
              if (t && (t.type === L.PlaylistContextType.AUDIO_TRACK && d.audioGroupIds && t.groupId === d.audioGroupIds[d.urlId] || t.type === L.PlaylistContextType.SUBTITLE_TRACK && d.textGroupIds && t.groupId === d.textGroupIds[d.urlId])) {
                this.redundantFailover(this.currentLevelIndex);
                return;
              }
              var e = !1, h = !0, f;
              switch (E.details) {
                case k.ErrorDetails.FRAG_LOAD_ERROR:
                case k.ErrorDetails.FRAG_LOAD_TIMEOUT:
                case k.ErrorDetails.KEY_LOAD_ERROR:
                case k.ErrorDetails.KEY_LOAD_TIMEOUT:
                  if (E.frag) {
                    var c = E.frag.type === L.PlaylistLevelType.MAIN ? E.frag.level : this.currentLevelIndex, M = this._levels[c];
                    M ? (M.fragmentError++, M.fragmentError > this.hls.config.fragLoadingMaxRetry && (f = c)) : f = c;
                  }
                  break;
                case k.ErrorDetails.KEY_SYSTEM_STATUS_OUTPUT_RESTRICTED: {
                  var w = d.attrs["HDCP-LEVEL"];
                  w && (this.hls.maxHdcpLevel = P.HdcpLevels[P.HdcpLevels.indexOf(w) - 1], this.warn('Restricting playback to HDCP-LEVEL of "' + this.hls.maxHdcpLevel + '" or lower'));
                }
                case k.ErrorDetails.FRAG_PARSING_ERROR:
                case k.ErrorDetails.KEY_SYSTEM_NO_SESSION:
                  f = ((r = E.frag) === null || r === void 0 ? void 0 : r.type) === L.PlaylistLevelType.MAIN ? E.frag.level : this.currentLevelIndex, E.levelRetry = !1;
                  break;
                case k.ErrorDetails.LEVEL_LOAD_ERROR:
                case k.ErrorDetails.LEVEL_LOAD_TIMEOUT:
                  t && (t.deliveryDirectives && (h = !1), f = t.level), e = !0;
                  break;
                case k.ErrorDetails.REMUX_ALLOC_ERROR:
                  f = (o = E.level) != null ? o : this.currentLevelIndex, e = !0;
                  break;
              }
              f !== void 0 && this.recoverLevel(E, f, e, h);
            }
          }, v.recoverLevel = function(n, E, r, o) {
            var t = n.details, d = this._levels[E];
            if (d.loadError++, r) {
              var e = this.retryLoadingOrFail(n);
              if (e)
                n.levelRetry = !0;
              else {
                this.currentLevelIndex = -1;
                return;
              }
            }
            if (o) {
              var h = d.url.length;
              if (h > 1 && d.loadError < h)
                n.levelRetry = !0, this.redundantFailover(E);
              else if (this.manualLevelIndex === -1) {
                for (var f = -1, c = this._levels, M = c.length; M--; ) {
                  var w = (M + this.currentLevelIndex) % c.length;
                  if (w !== this.currentLevelIndex && c[w].loadError === 0) {
                    f = w;
                    break;
                  }
                }
                f > -1 && this.currentLevelIndex !== f ? (this.warn(t + ": switch to " + f), n.levelRetry = !0, this.hls.nextAutoLevel = f) : n.levelRetry === !1 && (n.fatal = !0);
              }
            }
          }, v.redundantFailover = function(n) {
            var E = this._levels[n], r = E.url.length;
            if (r > 1) {
              var o = (E.urlId + 1) % r;
              this.warn("Switching to redundant URL-id " + o), this._levels.forEach(function(t) {
                t.urlId = o;
              }), this.level = n;
            }
          }, v.onFragLoaded = function(n, E) {
            var r = E.frag;
            if (r !== void 0 && r.type === L.PlaylistLevelType.MAIN) {
              var o = this._levels[r.level];
              o !== void 0 && (o.fragmentError = 0, o.loadError = 0);
            }
          }, v.onLevelLoaded = function(n, E) {
            var r, o = E.level, t = E.details, d = this._levels[o];
            if (!d) {
              var e;
              this.warn("Invalid level index " + o), (e = E.deliveryDirectives) !== null && e !== void 0 && e.skip && (t.deltaUpdateFailed = !0);
              return;
            }
            o === this.currentLevelIndex ? (d.fragmentError === 0 && (d.loadError = 0, this.retryCount = 0), this.playlistLoaded(o, E, d.details)) : (r = E.deliveryDirectives) !== null && r !== void 0 && r.skip && (t.deltaUpdateFailed = !0);
          }, v.onAudioTrackSwitched = function(n, E) {
            var r = this.hls.levels[this.currentLevelIndex];
            if (!!r && r.audioGroupIds) {
              for (var o = -1, t = this.hls.audioTracks[E.id].groupId, d = 0; d < r.audioGroupIds.length; d++)
                if (r.audioGroupIds[d] === t) {
                  o = d;
                  break;
                }
              o !== r.urlId && (r.urlId = o, this.startLoad());
            }
          }, v.loadPlaylist = function(n) {
            s.prototype.loadPlaylist.call(this);
            var E = this.currentLevelIndex, r = this._levels[E];
            if (this.canLoad && r && r.url.length > 0) {
              var o = r.urlId, t = r.url[o];
              if (n)
                try {
                  t = n.addDirectives(t);
                } catch (d) {
                  this.warn("Could not construct new URL with HLS Delivery Directives: " + d);
                }
              this.log("Attempt loading level index " + E + ((n == null ? void 0 : n.msn) !== void 0 ? " at sn " + n.msn + " part " + n.part : "") + " with URL-id " + o + " " + t), this.clearTimer(), this.hls.trigger(T.Events.LEVEL_LOADING, {
                url: t,
                level: E,
                id: o,
                deliveryDirectives: n || null
              });
            }
          }, v.removeLevel = function(n, E) {
            var r = function(d, e) {
              return e !== E;
            }, o = this._levels.filter(function(t, d) {
              return d !== n ? !0 : t.url.length > 1 && E !== void 0 ? (t.url = t.url.filter(r), t.audioGroupIds && (t.audioGroupIds = t.audioGroupIds.filter(r)), t.textGroupIds && (t.textGroupIds = t.textGroupIds.filter(r)), t.urlId = 0, !0) : !1;
            }).map(function(t, d) {
              var e = t.details;
              return e != null && e.fragments && e.fragments.forEach(function(h) {
                h.level = d;
              }), t;
            });
            this._levels = o, this.hls.trigger(T.Events.LEVELS_UPDATED, {
              levels: o
            });
          }, x(m, [{
            key: "levels",
            get: function() {
              return this._levels.length === 0 ? null : this._levels;
            }
          }, {
            key: "level",
            get: function() {
              return this.currentLevelIndex;
            },
            set: function(n) {
              var E, r = this._levels;
              if (r.length !== 0 && !(this.currentLevelIndex === n && (E = r[n]) !== null && E !== void 0 && E.details)) {
                if (n < 0 || n >= r.length) {
                  var o = n < 0;
                  if (this.hls.trigger(T.Events.ERROR, {
                    type: k.ErrorTypes.OTHER_ERROR,
                    details: k.ErrorDetails.LEVEL_SWITCH_ERROR,
                    level: n,
                    fatal: o,
                    reason: "invalid level idx"
                  }), o)
                    return;
                  n = Math.min(n, r.length - 1);
                }
                this.clearTimer();
                var t = this.currentLevelIndex, d = r[t], e = r[n];
                this.log("switching to level " + n + " from " + t), this.currentLevelIndex = n;
                var h = D({}, e, {
                  level: n,
                  maxBitrate: e.maxBitrate,
                  uri: e.uri,
                  urlId: e.urlId
                });
                delete h._urlId, this.hls.trigger(T.Events.LEVEL_SWITCHING, h);
                var f = e.details;
                if (!f || f.live) {
                  var c = this.switchParams(e.uri, d == null ? void 0 : d.details);
                  this.loadPlaylist(c);
                }
              }
            }
          }, {
            key: "manualLevel",
            get: function() {
              return this.manualLevelIndex;
            },
            set: function(n) {
              this.manualLevelIndex = n, this._startLevel === void 0 && (this._startLevel = n), n !== -1 && (this.level = n);
            }
          }, {
            key: "firstLevel",
            get: function() {
              return this._firstLevel;
            },
            set: function(n) {
              this._firstLevel = n;
            }
          }, {
            key: "startLevel",
            get: function() {
              if (this._startLevel === void 0) {
                var n = this.hls.config.startLevel;
                return n !== void 0 ? n : this._firstLevel;
              } else
                return this._startLevel;
            },
            set: function(n) {
              this._startLevel = n;
            }
          }, {
            key: "nextLoadLevel",
            get: function() {
              return this.manualLevelIndex !== -1 ? this.manualLevelIndex : this.hls.nextAutoLevel;
            },
            set: function(n) {
              this.level = n, this.manualLevelIndex === -1 && (this.hls.nextAutoLevel = n);
            }
          }]), m;
        }(I.default);
      },
      "./src/controller/level-helper.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          addGroupId: () => B,
          addSliding: () => u,
          adjustSliding: () => l,
          assignTrackIdsByGroup: () => I,
          computeReloadInterval: () => a,
          getFragmentWithSN: () => s,
          getPartWith: () => m,
          mapFragmentIntersection: () => y,
          mapPartIntersection: () => S,
          mergeDetails: () => x,
          updateFragPTSDTS: () => _,
          updatePTS: () => L
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/utils/logger.ts"), k = p("./src/loader/date-range.ts");
        function C() {
          return C = Object.assign ? Object.assign.bind() : function(v) {
            for (var i = 1; i < arguments.length; i++) {
              var n = arguments[i];
              for (var E in n)
                Object.prototype.hasOwnProperty.call(n, E) && (v[E] = n[E]);
            }
            return v;
          }, C.apply(this, arguments);
        }
        function B(v, i, n) {
          switch (i) {
            case "audio":
              v.audioGroupIds || (v.audioGroupIds = []), v.audioGroupIds.push(n);
              break;
            case "text":
              v.textGroupIds || (v.textGroupIds = []), v.textGroupIds.push(n);
              break;
          }
        }
        function I(v) {
          var i = {};
          v.forEach(function(n) {
            var E = n.groupId || "";
            n.id = i[E] = i[E] || 0, i[E]++;
          });
        }
        function L(v, i, n) {
          var E = v[i], r = v[n];
          D(E, r);
        }
        function D(v, i) {
          var n = i.startPTS;
          if ((0, P.isFiniteNumber)(n)) {
            var E = 0, r;
            i.sn > v.sn ? (E = n - v.start, r = v) : (E = v.start - n, r = i), r.duration !== E && (r.duration = E);
          } else if (i.sn > v.sn) {
            var o = v.cc === i.cc;
            o && v.minEndPTS ? i.start = v.start + (v.minEndPTS - v.start) : i.start = v.start + v.duration;
          } else
            i.start = Math.max(v.start - i.duration, 0);
        }
        function _(v, i, n, E, r, o) {
          var t = E - n;
          t <= 0 && (T.logger.warn("Fragment should have a positive duration", i), E = n + i.duration, o = r + i.duration);
          var d = n, e = E, h = i.startPTS, f = i.endPTS;
          if ((0, P.isFiniteNumber)(h)) {
            var c = Math.abs(h - n);
            (0, P.isFiniteNumber)(i.deltaPTS) ? i.deltaPTS = Math.max(c, i.deltaPTS) : i.deltaPTS = c, d = Math.max(n, h), n = Math.min(n, h), r = Math.min(r, i.startDTS), e = Math.min(E, f), E = Math.max(E, f), o = Math.max(o, i.endDTS);
          }
          i.duration = E - n;
          var M = n - i.start;
          i.start = i.startPTS = n, i.maxStartPTS = d, i.startDTS = r, i.endPTS = E, i.minEndPTS = e, i.endDTS = o;
          var w = i.sn;
          if (!v || w < v.startSN || w > v.endSN)
            return 0;
          var F, U = w - v.startSN, N = v.fragments;
          for (N[U] = i, F = U; F > 0; F--)
            D(N[F], N[F - 1]);
          for (F = U; F < N.length - 1; F++)
            D(N[F], N[F + 1]);
          return v.fragmentHint && D(N[N.length - 1], v.fragmentHint), v.PTSKnown = v.alignedSliding = !0, M;
        }
        function x(v, i) {
          for (var n = null, E = v.fragments, r = E.length - 1; r >= 0; r--) {
            var o = E[r].initSegment;
            if (o) {
              n = o;
              break;
            }
          }
          v.fragmentHint && delete v.fragmentHint.endPTS;
          var t = 0, d;
          if (y(v, i, function(F, U) {
            F.relurl && (t = F.cc - U.cc), (0, P.isFiniteNumber)(F.startPTS) && (0, P.isFiniteNumber)(F.endPTS) && (U.start = U.startPTS = F.startPTS, U.startDTS = F.startDTS, U.appendedPTS = F.appendedPTS, U.maxStartPTS = F.maxStartPTS, U.endPTS = F.endPTS, U.endDTS = F.endDTS, U.minEndPTS = F.minEndPTS, U.duration = F.endPTS - F.startPTS, U.duration && (d = U), i.PTSKnown = i.alignedSliding = !0), U.elementaryStreams = F.elementaryStreams, U.loader = F.loader, U.stats = F.stats, U.urlId = F.urlId, F.initSegment && (U.initSegment = F.initSegment, n = F.initSegment);
          }), n) {
            var e = i.fragmentHint ? i.fragments.concat(i.fragmentHint) : i.fragments;
            e.forEach(function(F) {
              var U;
              (!F.initSegment || F.initSegment.relurl === ((U = n) === null || U === void 0 ? void 0 : U.relurl)) && (F.initSegment = n);
            });
          }
          if (i.skippedSegments)
            if (i.deltaUpdateFailed = i.fragments.some(function(F) {
              return !F;
            }), i.deltaUpdateFailed) {
              T.logger.warn("[level-helper] Previous playlist missing segments skipped in delta playlist");
              for (var h = i.skippedSegments; h--; )
                i.fragments.shift();
              i.startSN = i.fragments[0].sn, i.startCC = i.fragments[0].cc;
            } else
              i.canSkipDateRanges && (i.dateRanges = g(v.dateRanges, i.dateRanges, i.recentlyRemovedDateranges));
          var f = i.fragments;
          if (t) {
            T.logger.warn("discontinuity sliding from playlist, take drift into account");
            for (var c = 0; c < f.length; c++)
              f[c].cc += t;
          }
          i.skippedSegments && (i.startCC = i.fragments[0].cc), S(v.partList, i.partList, function(F, U) {
            U.elementaryStreams = F.elementaryStreams, U.stats = F.stats;
          }), d ? _(i, d, d.startPTS, d.endPTS, d.startDTS, d.endDTS) : l(v, i), f.length && (i.totalduration = i.edge - f[0].start), i.driftStartTime = v.driftStartTime, i.driftStart = v.driftStart;
          var M = i.advancedDateTime;
          if (i.advanced && M) {
            var w = i.edge;
            i.driftStart || (i.driftStartTime = M, i.driftStart = w), i.driftEndTime = M, i.driftEnd = w;
          } else
            i.driftEndTime = v.driftEndTime, i.driftEnd = v.driftEnd, i.advancedDateTime = v.advancedDateTime;
        }
        function g(v, i, n) {
          var E = C({}, v);
          return n && n.forEach(function(r) {
            delete E[r];
          }), Object.keys(i).forEach(function(r) {
            var o = new k.DateRange(i[r].attr, E[r]);
            o.isValid ? E[r] = o : T.logger.warn('Ignoring invalid Playlist Delta Update DATERANGE tag: "' + JSON.stringify(i[r].attr) + '"');
          }), E;
        }
        function S(v, i, n) {
          if (v && i)
            for (var E = 0, r = 0, o = v.length; r <= o; r++) {
              var t = v[r], d = i[r + E];
              t && d && t.index === d.index && t.fragment.sn === d.fragment.sn ? n(t, d) : E--;
            }
        }
        function y(v, i, n) {
          for (var E = i.skippedSegments, r = Math.max(v.startSN, i.startSN) - i.startSN, o = (v.fragmentHint ? 1 : 0) + (E ? i.endSN : Math.min(v.endSN, i.endSN)) - i.startSN, t = i.startSN - v.startSN, d = i.fragmentHint ? i.fragments.concat(i.fragmentHint) : i.fragments, e = v.fragmentHint ? v.fragments.concat(v.fragmentHint) : v.fragments, h = r; h <= o; h++) {
            var f = e[t + h], c = d[h];
            E && !c && h < E && (c = i.fragments[h] = f), f && c && n(f, c);
          }
        }
        function l(v, i) {
          var n = i.startSN + i.skippedSegments - v.startSN, E = v.fragments;
          n < 0 || n >= E.length || u(i, E[n].start);
        }
        function u(v, i) {
          if (i) {
            for (var n = v.fragments, E = v.skippedSegments; E < n.length; E++)
              n[E].start += i;
            v.fragmentHint && (v.fragmentHint.start += i);
          }
        }
        function a(v, i) {
          i === void 0 && (i = 1 / 0);
          var n = 1e3 * v.targetduration;
          if (v.updated) {
            var E = v.fragments, r = 4;
            if (E.length && n * r > i) {
              var o = E[E.length - 1].duration * 1e3;
              o < n && (n = o);
            }
          } else
            n /= 2;
          return Math.round(n);
        }
        function s(v, i, n) {
          if (!v || !v.details)
            return null;
          var E = v.details, r = E.fragments[i - E.startSN];
          return r || (r = E.fragmentHint, r && r.sn === i) ? r : i < E.startSN && n && n.sn === i ? n : null;
        }
        function m(v, i, n) {
          if (!v || !v.details)
            return null;
          var E = v.details.partList;
          if (E)
            for (var r = E.length; r--; ) {
              var o = E[r];
              if (o.index === n && o.fragment.sn === i)
                return o;
            }
          return null;
        }
      },
      "./src/controller/stream-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => i
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/controller/base-stream-controller.ts"), k = p("./src/is-supported.ts"), C = p("./src/events.ts"), B = p("./src/utils/buffer-helper.ts"), I = p("./src/controller/fragment-tracker.ts"), L = p("./src/types/loader.ts"), D = p("./src/loader/fragment.ts"), _ = p("./src/demux/transmuxer-interface.ts"), x = p("./src/types/transmuxer.ts"), g = p("./src/controller/gap-controller.ts"), S = p("./src/errors.ts");
        function y(n, E) {
          for (var r = 0; r < E.length; r++) {
            var o = E[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(n, u(o.key), o);
          }
        }
        function l(n, E, r) {
          return E && y(n.prototype, E), r && y(n, r), Object.defineProperty(n, "prototype", { writable: !1 }), n;
        }
        function u(n) {
          var E = a(n, "string");
          return typeof E == "symbol" ? E : String(E);
        }
        function a(n, E) {
          if (typeof n != "object" || n === null)
            return n;
          var r = n[Symbol.toPrimitive];
          if (r !== void 0) {
            var o = r.call(n, E || "default");
            if (typeof o != "object")
              return o;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (E === "string" ? String : Number)(n);
        }
        function s(n, E) {
          n.prototype = Object.create(E.prototype), n.prototype.constructor = n, m(n, E);
        }
        function m(n, E) {
          return m = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(o, t) {
            return o.__proto__ = t, o;
          }, m(n, E);
        }
        var v = 100, i = /* @__PURE__ */ function(n) {
          s(E, n);
          function E(o, t, d) {
            var e;
            return e = n.call(this, o, t, d, "[stream-controller]") || this, e.audioCodecSwap = !1, e.gapController = null, e.level = -1, e._forceStartLoad = !1, e.altAudio = !1, e.audioOnly = !1, e.fragPlaying = null, e.onvplaying = null, e.onvseeked = null, e.fragLastKbps = 0, e.couldBacktrack = !1, e.backtrackFragment = null, e.audioCodecSwitch = !1, e.videoBuffer = null, e._registerListeners(), e;
          }
          var r = E.prototype;
          return r._registerListeners = function() {
            var t = this.hls;
            t.on(C.Events.MEDIA_ATTACHED, this.onMediaAttached, this), t.on(C.Events.MEDIA_DETACHING, this.onMediaDetaching, this), t.on(C.Events.MANIFEST_LOADING, this.onManifestLoading, this), t.on(C.Events.MANIFEST_PARSED, this.onManifestParsed, this), t.on(C.Events.LEVEL_LOADING, this.onLevelLoading, this), t.on(C.Events.LEVEL_LOADED, this.onLevelLoaded, this), t.on(C.Events.FRAG_LOAD_EMERGENCY_ABORTED, this.onFragLoadEmergencyAborted, this), t.on(C.Events.ERROR, this.onError, this), t.on(C.Events.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), t.on(C.Events.AUDIO_TRACK_SWITCHED, this.onAudioTrackSwitched, this), t.on(C.Events.BUFFER_CREATED, this.onBufferCreated, this), t.on(C.Events.BUFFER_FLUSHED, this.onBufferFlushed, this), t.on(C.Events.LEVELS_UPDATED, this.onLevelsUpdated, this), t.on(C.Events.FRAG_BUFFERED, this.onFragBuffered, this);
          }, r._unregisterListeners = function() {
            var t = this.hls;
            t.off(C.Events.MEDIA_ATTACHED, this.onMediaAttached, this), t.off(C.Events.MEDIA_DETACHING, this.onMediaDetaching, this), t.off(C.Events.MANIFEST_LOADING, this.onManifestLoading, this), t.off(C.Events.MANIFEST_PARSED, this.onManifestParsed, this), t.off(C.Events.LEVEL_LOADED, this.onLevelLoaded, this), t.off(C.Events.FRAG_LOAD_EMERGENCY_ABORTED, this.onFragLoadEmergencyAborted, this), t.off(C.Events.ERROR, this.onError, this), t.off(C.Events.AUDIO_TRACK_SWITCHING, this.onAudioTrackSwitching, this), t.off(C.Events.AUDIO_TRACK_SWITCHED, this.onAudioTrackSwitched, this), t.off(C.Events.BUFFER_CREATED, this.onBufferCreated, this), t.off(C.Events.BUFFER_FLUSHED, this.onBufferFlushed, this), t.off(C.Events.LEVELS_UPDATED, this.onLevelsUpdated, this), t.off(C.Events.FRAG_BUFFERED, this.onFragBuffered, this);
          }, r.onHandlerDestroying = function() {
            this._unregisterListeners(), this.onMediaDetaching();
          }, r.startLoad = function(t) {
            if (this.levels) {
              var d = this.lastCurrentTime, e = this.hls;
              if (this.stopLoad(), this.setInterval(v), this.level = -1, this.fragLoadError = 0, !this.startFragRequested) {
                var h = e.startLevel;
                h === -1 && (e.config.testBandwidth && this.levels.length > 1 ? (h = 0, this.bitrateTest = !0) : h = e.nextAutoLevel), this.level = e.nextLoadLevel = h, this.loadedmetadata = !1;
              }
              d > 0 && t === -1 && (this.log("Override startPosition with lastCurrentTime @" + d.toFixed(3)), t = d), this.state = T.State.IDLE, this.nextLoadPosition = this.startPosition = this.lastCurrentTime = t, this.tick();
            } else
              this._forceStartLoad = !0, this.state = T.State.STOPPED;
          }, r.stopLoad = function() {
            this._forceStartLoad = !1, n.prototype.stopLoad.call(this);
          }, r.doTick = function() {
            switch (this.state) {
              case T.State.IDLE:
                this.doTickIdle();
                break;
              case T.State.WAITING_LEVEL: {
                var t, d = this.levels, e = this.level, h = d == null || (t = d[e]) === null || t === void 0 ? void 0 : t.details;
                if (h && (!h.live || this.levelLastLoaded === this.level)) {
                  if (this.waitForCdnTuneIn(h))
                    break;
                  this.state = T.State.IDLE;
                  break;
                }
                break;
              }
              case T.State.FRAG_LOADING_WAITING_RETRY:
                {
                  var f, c = self.performance.now(), M = this.retryDate;
                  (!M || c >= M || (f = this.media) !== null && f !== void 0 && f.seeking) && (this.log("retryDate reached, switch back to IDLE state"), this.resetStartWhenNotLoaded(this.level), this.state = T.State.IDLE);
                }
                break;
            }
            this.onTickEnd();
          }, r.onTickEnd = function() {
            n.prototype.onTickEnd.call(this), this.checkBuffer(), this.checkFragmentChanged();
          }, r.doTickIdle = function() {
            var t = this.hls, d = this.levelLastLoaded, e = this.levels, h = this.media, f = t.config, c = t.nextLoadLevel;
            if (!(d === null || !h && (this.startFragRequested || !f.startFragPrefetch)) && !(this.altAudio && this.audioOnly) && !(!e || !e[c])) {
              var M = e[c], w = this.getMainFwdBufferInfo();
              if (w !== null) {
                var F = this.getLevelDetails();
                if (F && this._streamEnded(w, F)) {
                  var U = {};
                  this.altAudio && (U.type = "video"), this.hls.trigger(C.Events.BUFFER_EOS, U), this.state = T.State.ENDED;
                  return;
                }
                this.level = t.nextLoadLevel = c;
                var N = M.details;
                if (!N || this.state === T.State.WAITING_LEVEL || N.live && this.levelLastLoaded !== c) {
                  this.level = c, this.state = T.State.WAITING_LEVEL;
                  return;
                }
                var H = w.len, j = this.getMaxBufferLength(M.maxBitrate);
                if (!(H >= j)) {
                  this.backtrackFragment && this.backtrackFragment.start > w.end && (this.backtrackFragment = null);
                  var z = this.backtrackFragment ? this.backtrackFragment.start : w.end, Y = this.getNextFragment(z, N);
                  if (this.couldBacktrack && !this.fragPrevious && Y && Y.sn !== "initSegment" && this.fragmentTracker.getState(Y) !== I.FragmentState.OK) {
                    var X, Z = ((X = this.backtrackFragment) != null ? X : Y).sn, te = Z - N.startSN, $ = N.fragments[te - 1];
                    $ && Y.cc === $.cc && (Y = $, this.fragmentTracker.removeFragment($));
                  } else
                    this.backtrackFragment && w.len && (this.backtrackFragment = null);
                  if (Y && this.fragmentTracker.getState(Y) === I.FragmentState.OK && this.nextLoadPosition > z) {
                    var ee = this.audioOnly && !this.altAudio ? D.ElementaryStreamTypes.AUDIO : D.ElementaryStreamTypes.VIDEO, ne = (ee === D.ElementaryStreamTypes.VIDEO ? this.videoBuffer : this.mediaBuffer) || this.media;
                    ne && this.afterBufferFlushed(ne, ee, L.PlaylistLevelType.MAIN), Y = this.getNextFragment(this.nextLoadPosition, N);
                  }
                  !Y || (Y.initSegment && !Y.initSegment.data && !this.bitrateTest && (Y = Y.initSegment), this.loadFragment(Y, N, z));
                }
              }
            }
          }, r.loadFragment = function(t, d, e) {
            var h, f = this.fragmentTracker.getState(t);
            this.fragCurrent = t, f === I.FragmentState.NOT_LOADED ? t.sn === "initSegment" ? this._loadInitSegment(t, d) : this.bitrateTest ? (this.log("Fragment " + t.sn + " of level " + t.level + " is being downloaded to test bitrate and will not be buffered"), this._loadBitrateTestFrag(t, d)) : (this.startFragRequested = !0, n.prototype.loadFragment.call(this, t, d, e)) : f === I.FragmentState.APPENDING ? this.reduceMaxBufferLength(t.duration) && this.fragmentTracker.removeFragment(t) : ((h = this.media) === null || h === void 0 ? void 0 : h.buffered.length) === 0 && this.fragmentTracker.removeAllFragments();
          }, r.getAppendedFrag = function(t) {
            var d = this.fragmentTracker.getAppendedFrag(t, L.PlaylistLevelType.MAIN);
            return d && "fragment" in d ? d.fragment : d;
          }, r.getBufferedFrag = function(t) {
            return this.fragmentTracker.getBufferedFrag(t, L.PlaylistLevelType.MAIN);
          }, r.followingBufferedFrag = function(t) {
            return t ? this.getBufferedFrag(t.end + 0.5) : null;
          }, r.immediateLevelSwitch = function() {
            this.abortCurrentFrag(), this.flushMainBuffer(0, Number.POSITIVE_INFINITY);
          }, r.nextLevelSwitch = function() {
            var t = this.levels, d = this.media;
            if (d != null && d.readyState) {
              var e, h = this.getAppendedFrag(d.currentTime);
              if (h && h.start > 1 && this.flushMainBuffer(0, h.start - 1), !d.paused && t) {
                var f = this.hls.nextLoadLevel, c = t[f], M = this.fragLastKbps;
                M && this.fragCurrent ? e = this.fragCurrent.duration * c.maxBitrate / (1e3 * M) + 1 : e = 0;
              } else
                e = 0;
              var w = this.getBufferedFrag(d.currentTime + e);
              if (w) {
                var F = this.followingBufferedFrag(w);
                if (F) {
                  this.abortCurrentFrag();
                  var U = F.maxStartPTS ? F.maxStartPTS : F.start, N = F.duration, H = Math.max(w.end, U + Math.min(Math.max(N - this.config.maxFragLookUpTolerance, N * 0.5), N * 0.75));
                  this.flushMainBuffer(H, Number.POSITIVE_INFINITY);
                }
              }
            }
          }, r.abortCurrentFrag = function() {
            var t = this.fragCurrent;
            switch (this.fragCurrent = null, this.backtrackFragment = null, t && t.abortRequests(), this.state) {
              case T.State.KEY_LOADING:
              case T.State.FRAG_LOADING:
              case T.State.FRAG_LOADING_WAITING_RETRY:
              case T.State.PARSING:
              case T.State.PARSED:
                this.state = T.State.IDLE;
                break;
            }
            this.nextLoadPosition = this.getLoadPosition();
          }, r.flushMainBuffer = function(t, d) {
            n.prototype.flushMainBuffer.call(this, t, d, this.altAudio ? "video" : null);
          }, r.onMediaAttached = function(t, d) {
            n.prototype.onMediaAttached.call(this, t, d);
            var e = d.media;
            this.onvplaying = this.onMediaPlaying.bind(this), this.onvseeked = this.onMediaSeeked.bind(this), e.addEventListener("playing", this.onvplaying), e.addEventListener("seeked", this.onvseeked), this.gapController = new g.default(this.config, e, this.fragmentTracker, this.hls);
          }, r.onMediaDetaching = function() {
            var t = this.media;
            t && this.onvplaying && this.onvseeked && (t.removeEventListener("playing", this.onvplaying), t.removeEventListener("seeked", this.onvseeked), this.onvplaying = this.onvseeked = null, this.videoBuffer = null), this.fragPlaying = null, this.gapController && (this.gapController.destroy(), this.gapController = null), n.prototype.onMediaDetaching.call(this);
          }, r.onMediaPlaying = function() {
            this.tick();
          }, r.onMediaSeeked = function() {
            var t = this.media, d = t ? t.currentTime : null;
            (0, P.isFiniteNumber)(d) && this.log("Media seeked to " + d.toFixed(3)), this.tick();
          }, r.onManifestLoading = function() {
            this.log("Trigger BUFFER_RESET"), this.hls.trigger(C.Events.BUFFER_RESET, void 0), this.fragmentTracker.removeAllFragments(), this.couldBacktrack = !1, this.startPosition = this.lastCurrentTime = 0, this.fragPlaying = null, this.backtrackFragment = null;
          }, r.onManifestParsed = function(t, d) {
            var e = !1, h = !1, f;
            d.levels.forEach(function(c) {
              f = c.audioCodec, f && (f.indexOf("mp4a.40.2") !== -1 && (e = !0), f.indexOf("mp4a.40.5") !== -1 && (h = !0));
            }), this.audioCodecSwitch = e && h && !(0, k.changeTypeSupported)(), this.audioCodecSwitch && this.log("Both AAC/HE-AAC audio found in levels; declaring level codec as HE-AAC"), this.levels = d.levels, this.startFragRequested = !1;
          }, r.onLevelLoading = function(t, d) {
            var e = this.levels;
            if (!(!e || this.state !== T.State.IDLE)) {
              var h = e[d.level];
              (!h.details || h.details.live && this.levelLastLoaded !== d.level || this.waitForCdnTuneIn(h.details)) && (this.state = T.State.WAITING_LEVEL);
            }
          }, r.onLevelLoaded = function(t, d) {
            var e, h = this.levels, f = d.level, c = d.details, M = c.totalduration;
            if (!h) {
              this.warn("Levels were reset while loading level " + f);
              return;
            }
            this.log("Level " + f + " loaded [" + c.startSN + "," + c.endSN + "], cc [" + c.startCC + ", " + c.endCC + "] duration:" + M);
            var w = this.fragCurrent;
            w && (this.state === T.State.FRAG_LOADING || this.state === T.State.FRAG_LOADING_WAITING_RETRY) && w.level !== d.level && w.loader && (this.state = T.State.IDLE, this.backtrackFragment = null, w.abortRequests());
            var F = h[f], U = 0;
            if (c.live || (e = F.details) !== null && e !== void 0 && e.live) {
              if (c.fragments[0] || (c.deltaUpdateFailed = !0), c.deltaUpdateFailed)
                return;
              U = this.alignPlaylists(c, F.details);
            }
            if (F.details = c, this.levelLastLoaded = f, this.hls.trigger(C.Events.LEVEL_UPDATED, {
              details: c,
              level: f
            }), this.state === T.State.WAITING_LEVEL) {
              if (this.waitForCdnTuneIn(c))
                return;
              this.state = T.State.IDLE;
            }
            this.startFragRequested ? c.live && this.synchronizeToLiveEdge(c) : this.setStartPosition(c, U), this.tick();
          }, r._handleFragmentLoadProgress = function(t) {
            var d, e = t.frag, h = t.part, f = t.payload, c = this.levels;
            if (!c) {
              this.warn("Levels were reset while fragment load was in progress. Fragment " + e.sn + " of level " + e.level + " will not be buffered");
              return;
            }
            var M = c[e.level], w = M.details;
            if (!w) {
              this.warn("Dropping fragment " + e.sn + " of level " + e.level + " after level details were reset");
              return;
            }
            var F = M.videoCodec, U = w.PTSKnown || !w.live, N = (d = e.initSegment) === null || d === void 0 ? void 0 : d.data, H = this._getAudioCodec(M), j = this.transmuxer = this.transmuxer || new _.default(this.hls, L.PlaylistLevelType.MAIN, this._handleTransmuxComplete.bind(this), this._handleTransmuxerFlush.bind(this)), z = h ? h.index : -1, Y = z !== -1, X = new x.ChunkMetadata(e.level, e.sn, e.stats.chunkCount, f.byteLength, z, Y), Z = this.initPTS[e.cc];
            j.push(f, N, H, F, e, h, w.totalduration, U, X, Z);
          }, r.onAudioTrackSwitching = function(t, d) {
            var e = this.altAudio, h = !!d.url, f = d.id;
            if (!h) {
              if (this.mediaBuffer !== this.media) {
                this.log("Switching on main audio, use media.buffered to schedule main fragment loading"), this.mediaBuffer = this.media;
                var c = this.fragCurrent;
                c && (this.log("Switching to main audio track, cancel main fragment load"), c.abortRequests()), this.resetTransmuxer(), this.resetLoadingState();
              } else
                this.audioOnly && this.resetTransmuxer();
              var M = this.hls;
              e && M.trigger(C.Events.BUFFER_FLUSHING, {
                startOffset: 0,
                endOffset: Number.POSITIVE_INFINITY,
                type: "audio"
              }), M.trigger(C.Events.AUDIO_TRACK_SWITCHED, {
                id: f
              });
            }
          }, r.onAudioTrackSwitched = function(t, d) {
            var e = d.id, h = !!this.hls.audioTracks[e].url;
            if (h) {
              var f = this.videoBuffer;
              f && this.mediaBuffer !== f && (this.log("Switching on alternate audio, use video.buffered to schedule main fragment loading"), this.mediaBuffer = f);
            }
            this.altAudio = h, this.tick();
          }, r.onBufferCreated = function(t, d) {
            var e = d.tracks, h, f, c = !1;
            for (var M in e) {
              var w = e[M];
              if (w.id === "main") {
                if (f = M, h = w, M === "video") {
                  var F = e[M];
                  F && (this.videoBuffer = F.buffer);
                }
              } else
                c = !0;
            }
            c && h ? (this.log("Alternate track found, use " + f + ".buffered to schedule main fragment loading"), this.mediaBuffer = h.buffer) : this.mediaBuffer = this.media;
          }, r.onFragBuffered = function(t, d) {
            var e = d.frag, h = d.part;
            if (!(e && e.type !== L.PlaylistLevelType.MAIN)) {
              if (this.fragContextChanged(e)) {
                this.warn("Fragment " + e.sn + (h ? " p: " + h.index : "") + " of level " + e.level + " finished buffering, but was aborted. state: " + this.state), this.state === T.State.PARSED && (this.state = T.State.IDLE);
                return;
              }
              var f = h ? h.stats : e.stats;
              this.fragLastKbps = Math.round(8 * f.total / (f.buffering.end - f.loading.first)), e.sn !== "initSegment" && (this.fragPrevious = e), this.fragBufferedComplete(e, h);
            }
          }, r.onError = function(t, d) {
            if (d.type === S.ErrorTypes.KEY_SYSTEM_ERROR) {
              this.onFragmentOrKeyLoadError(L.PlaylistLevelType.MAIN, d);
              return;
            }
            switch (d.details) {
              case S.ErrorDetails.FRAG_LOAD_ERROR:
              case S.ErrorDetails.FRAG_LOAD_TIMEOUT:
              case S.ErrorDetails.FRAG_PARSING_ERROR:
              case S.ErrorDetails.KEY_LOAD_ERROR:
              case S.ErrorDetails.KEY_LOAD_TIMEOUT:
                this.onFragmentOrKeyLoadError(L.PlaylistLevelType.MAIN, d);
                break;
              case S.ErrorDetails.LEVEL_LOAD_ERROR:
              case S.ErrorDetails.LEVEL_LOAD_TIMEOUT:
                this.state !== T.State.ERROR && (d.fatal ? (this.warn("" + d.details), this.state = T.State.ERROR) : !d.levelRetry && this.state === T.State.WAITING_LEVEL && (this.state = T.State.IDLE));
                break;
              case S.ErrorDetails.BUFFER_FULL_ERROR:
                if (d.parent === "main" && (this.state === T.State.PARSING || this.state === T.State.PARSED)) {
                  var e = !0, h = this.getFwdBufferInfo(this.media, L.PlaylistLevelType.MAIN);
                  h && h.len > 0.5 && (e = !this.reduceMaxBufferLength(h.len)), e && (this.warn("buffer full error also media.currentTime is not buffered, flush main"), this.immediateLevelSwitch()), this.resetLoadingState();
                }
                break;
            }
          }, r.checkBuffer = function() {
            var t = this.media, d = this.gapController;
            if (!(!t || !d || !t.readyState)) {
              if (this.loadedmetadata || !B.BufferHelper.getBuffered(t).length) {
                var e = this.state !== T.State.IDLE ? this.fragCurrent : null;
                d.poll(this.lastCurrentTime, e);
              }
              this.lastCurrentTime = t.currentTime;
            }
          }, r.onFragLoadEmergencyAborted = function() {
            this.state = T.State.IDLE, this.loadedmetadata || (this.startFragRequested = !1, this.nextLoadPosition = this.startPosition), this.tickImmediate();
          }, r.onBufferFlushed = function(t, d) {
            var e = d.type;
            if (e !== D.ElementaryStreamTypes.AUDIO || this.audioOnly && !this.altAudio) {
              var h = (e === D.ElementaryStreamTypes.VIDEO ? this.videoBuffer : this.mediaBuffer) || this.media;
              this.afterBufferFlushed(h, e, L.PlaylistLevelType.MAIN);
            }
          }, r.onLevelsUpdated = function(t, d) {
            this.levels = d.levels;
          }, r.swapAudioCodec = function() {
            this.audioCodecSwap = !this.audioCodecSwap;
          }, r.seekToStartPos = function() {
            var t = this.media;
            if (!!t) {
              var d = t.currentTime, e = this.startPosition;
              if (e >= 0 && d < e) {
                if (t.seeking) {
                  this.log("could not seek to " + e + ", already seeking at " + d);
                  return;
                }
                var h = B.BufferHelper.getBuffered(t), f = h.length ? h.start(0) : 0, c = f - e;
                c > 0 && (c < this.config.maxBufferHole || c < this.config.maxFragLookUpTolerance) && (this.log("adjusting start position by " + c + " to match buffer start"), e += c, this.startPosition = e), this.log("seek to target start position " + e + " from current time " + d), t.currentTime = e;
              }
            }
          }, r._getAudioCodec = function(t) {
            var d = this.config.defaultAudioCodec || t.audioCodec;
            return this.audioCodecSwap && d && (this.log("Swapping audio codec"), d.indexOf("mp4a.40.5") !== -1 ? d = "mp4a.40.2" : d = "mp4a.40.5"), d;
          }, r._loadBitrateTestFrag = function(t, d) {
            var e = this;
            t.bitrateTest = !0, this._doFragLoad(t, d).then(function(h) {
              var f = e.hls;
              if (!(!h || e.fragContextChanged(t))) {
                e.fragLoadError = 0, e.state = T.State.IDLE, e.startFragRequested = !1, e.bitrateTest = !1;
                var c = t.stats;
                c.parsing.start = c.parsing.end = c.buffering.start = c.buffering.end = self.performance.now(), f.trigger(C.Events.FRAG_LOADED, h), t.bitrateTest = !1;
              }
            });
          }, r._handleTransmuxComplete = function(t) {
            var d, e = "main", h = this.hls, f = t.remuxResult, c = t.chunkMeta, M = this.getCurrentContext(c);
            if (!M) {
              this.warn("The loading context changed while buffering fragment " + c.sn + " of level " + c.level + ". This chunk will not be buffered."), this.resetStartWhenNotLoaded(c.level);
              return;
            }
            var w = M.frag, F = M.part, U = M.level, N = f.video, H = f.text, j = f.id3, z = f.initSegment, Y = U.details, X = this.altAudio ? void 0 : f.audio;
            if (!this.fragContextChanged(w)) {
              if (this.state = T.State.PARSING, z) {
                z.tracks && (this._bufferInitSegment(U, z.tracks, w, c), h.trigger(C.Events.FRAG_PARSING_INIT_SEGMENT, {
                  frag: w,
                  id: e,
                  tracks: z.tracks
                }));
                var Z = z.initPTS, te = z.timescale;
                (0, P.isFiniteNumber)(Z) && (this.initPTS[w.cc] = Z, h.trigger(C.Events.INIT_PTS_FOUND, {
                  frag: w,
                  id: e,
                  initPTS: Z,
                  timescale: te
                }));
              }
              if (N && f.independent !== !1) {
                if (Y) {
                  var $ = N.startPTS, ee = N.endPTS, ne = N.startDTS, oe = N.endDTS;
                  if (F)
                    F.elementaryStreams[N.type] = {
                      startPTS: $,
                      endPTS: ee,
                      startDTS: ne,
                      endDTS: oe
                    };
                  else if (N.firstKeyFrame && N.independent && c.id === 1 && (this.couldBacktrack = !0), N.dropped && N.independent) {
                    var ae = this.getMainFwdBufferInfo(), ie = (ae ? ae.end : this.getLoadPosition()) + this.config.maxBufferHole, ce = N.firstKeyFramePTS ? N.firstKeyFramePTS : $;
                    if (ie < ce - this.config.maxBufferHole) {
                      this.backtrack(w);
                      return;
                    }
                    w.setElementaryStreamInfo(N.type, w.start, ee, w.start, oe, !0);
                  }
                  w.setElementaryStreamInfo(N.type, $, ee, ne, oe), this.backtrackFragment && (this.backtrackFragment = w), this.bufferFragmentData(N, w, F, c);
                }
              } else if (f.independent === !1) {
                this.backtrack(w);
                return;
              }
              if (X) {
                var me = X.startPTS, pe = X.endPTS, Ie = X.startDTS, Ee = X.endDTS;
                F && (F.elementaryStreams[D.ElementaryStreamTypes.AUDIO] = {
                  startPTS: me,
                  endPTS: pe,
                  startDTS: Ie,
                  endDTS: Ee
                }), w.setElementaryStreamInfo(D.ElementaryStreamTypes.AUDIO, me, pe, Ie, Ee), this.bufferFragmentData(X, w, F, c);
              }
              if (Y && j !== null && j !== void 0 && (d = j.samples) !== null && d !== void 0 && d.length) {
                var _e = {
                  id: e,
                  frag: w,
                  details: Y,
                  samples: j.samples
                };
                h.trigger(C.Events.FRAG_PARSING_METADATA, _e);
              }
              if (Y && H) {
                var Te = {
                  id: e,
                  frag: w,
                  details: Y,
                  samples: H.samples
                };
                h.trigger(C.Events.FRAG_PARSING_USERDATA, Te);
              }
            }
          }, r._bufferInitSegment = function(t, d, e, h) {
            var f = this;
            if (this.state === T.State.PARSING) {
              this.audioOnly = !!d.audio && !d.video, this.altAudio && !this.audioOnly && delete d.audio;
              var c = d.audio, M = d.video, w = d.audiovideo;
              if (c) {
                var F = t.audioCodec, U = navigator.userAgent.toLowerCase();
                this.audioCodecSwitch && (F && (F.indexOf("mp4a.40.5") !== -1 ? F = "mp4a.40.2" : F = "mp4a.40.5"), c.metadata.channelCount !== 1 && U.indexOf("firefox") === -1 && (F = "mp4a.40.5")), U.indexOf("android") !== -1 && c.container !== "audio/mpeg" && (F = "mp4a.40.2", this.log("Android: force audio codec to " + F)), t.audioCodec && t.audioCodec !== F && this.log('Swapping manifest audio codec "' + t.audioCodec + '" for "' + F + '"'), c.levelCodec = F, c.id = "main", this.log("Init audio buffer, container:" + c.container + ", codecs[selected/level/parsed]=[" + (F || "") + "/" + (t.audioCodec || "") + "/" + c.codec + "]");
              }
              M && (M.levelCodec = t.videoCodec, M.id = "main", this.log("Init video buffer, container:" + M.container + ", codecs[level/parsed]=[" + (t.videoCodec || "") + "/" + M.codec + "]")), w && this.log("Init audiovideo buffer, container:" + w.container + ", codecs[level/parsed]=[" + (t.attrs.CODECS || "") + "/" + w.codec + "]"), this.hls.trigger(C.Events.BUFFER_CODECS, d), Object.keys(d).forEach(function(N) {
                var H = d[N], j = H.initSegment;
                j != null && j.byteLength && f.hls.trigger(C.Events.BUFFER_APPENDING, {
                  type: N,
                  data: j,
                  frag: e,
                  part: null,
                  chunkMeta: h,
                  parent: e.type
                });
              }), this.tick();
            }
          }, r.getMainFwdBufferInfo = function() {
            return this.getFwdBufferInfo(this.mediaBuffer ? this.mediaBuffer : this.media, L.PlaylistLevelType.MAIN);
          }, r.backtrack = function(t) {
            this.couldBacktrack = !0, this.backtrackFragment = t, this.resetTransmuxer(), this.flushBufferGap(t), this.fragmentTracker.removeFragment(t), this.fragPrevious = null, this.nextLoadPosition = t.start, this.state = T.State.IDLE;
          }, r.checkFragmentChanged = function() {
            var t = this.media, d = null;
            if (t && t.readyState > 1 && t.seeking === !1) {
              var e = t.currentTime;
              if (B.BufferHelper.isBuffered(t, e) ? d = this.getAppendedFrag(e) : B.BufferHelper.isBuffered(t, e + 0.1) && (d = this.getAppendedFrag(e + 0.1)), d) {
                this.backtrackFragment = null;
                var h = this.fragPlaying, f = d.level;
                (!h || d.sn !== h.sn || h.level !== f || d.urlId !== h.urlId) && (this.fragPlaying = d, this.hls.trigger(C.Events.FRAG_CHANGED, {
                  frag: d
                }), (!h || h.level !== f) && this.hls.trigger(C.Events.LEVEL_SWITCHED, {
                  level: f
                }));
              }
            }
          }, l(E, [{
            key: "nextLevel",
            get: function() {
              var t = this.nextBufferedFrag;
              return t ? t.level : -1;
            }
          }, {
            key: "currentFrag",
            get: function() {
              var t = this.media;
              return t ? this.fragPlaying || this.getAppendedFrag(t.currentTime) : null;
            }
          }, {
            key: "currentProgramDateTime",
            get: function() {
              var t = this.media;
              if (t) {
                var d = t.currentTime, e = this.currentFrag;
                if (e && (0, P.isFiniteNumber)(d) && (0, P.isFiniteNumber)(e.programDateTime)) {
                  var h = e.programDateTime + (d - e.start) * 1e3;
                  return new Date(h);
                }
              }
              return null;
            }
          }, {
            key: "currentLevel",
            get: function() {
              var t = this.currentFrag;
              return t ? t.level : -1;
            }
          }, {
            key: "nextBufferedFrag",
            get: function() {
              var t = this.currentFrag;
              return t ? this.followingBufferedFrag(t) : null;
            }
          }, {
            key: "forceStartLoad",
            get: function() {
              return this._forceStartLoad;
            }
          }]), E;
        }(T.default);
      },
      "./src/controller/subtitle-stream-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          SubtitleStreamController: () => s
        });
        var P = p("./src/events.ts"), T = p("./src/utils/buffer-helper.ts"), k = p("./src/controller/fragment-finders.ts"), C = p("./src/utils/discontinuities.ts"), B = p("./src/controller/level-helper.ts"), I = p("./src/controller/fragment-tracker.ts"), L = p("./src/controller/base-stream-controller.ts"), D = p("./src/types/loader.ts"), _ = p("./src/types/level.ts");
        function x(v, i) {
          for (var n = 0; n < i.length; n++) {
            var E = i[n];
            E.enumerable = E.enumerable || !1, E.configurable = !0, "value" in E && (E.writable = !0), Object.defineProperty(v, S(E.key), E);
          }
        }
        function g(v, i, n) {
          return i && x(v.prototype, i), n && x(v, n), Object.defineProperty(v, "prototype", { writable: !1 }), v;
        }
        function S(v) {
          var i = y(v, "string");
          return typeof i == "symbol" ? i : String(i);
        }
        function y(v, i) {
          if (typeof v != "object" || v === null)
            return v;
          var n = v[Symbol.toPrimitive];
          if (n !== void 0) {
            var E = n.call(v, i || "default");
            if (typeof E != "object")
              return E;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (i === "string" ? String : Number)(v);
        }
        function l(v, i) {
          v.prototype = Object.create(i.prototype), v.prototype.constructor = v, u(v, i);
        }
        function u(v, i) {
          return u = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(E, r) {
            return E.__proto__ = r, E;
          }, u(v, i);
        }
        var a = 500, s = /* @__PURE__ */ function(v) {
          l(i, v);
          function i(E, r, o) {
            var t;
            return t = v.call(this, E, r, o, "[subtitle-stream-controller]") || this, t.levels = [], t.currentTrackId = -1, t.tracksBuffered = [], t.mainDetails = null, t._registerListeners(), t;
          }
          var n = i.prototype;
          return n.onHandlerDestroying = function() {
            this._unregisterListeners(), this.mainDetails = null;
          }, n._registerListeners = function() {
            var r = this.hls;
            r.on(P.Events.MEDIA_ATTACHED, this.onMediaAttached, this), r.on(P.Events.MEDIA_DETACHING, this.onMediaDetaching, this), r.on(P.Events.MANIFEST_LOADING, this.onManifestLoading, this), r.on(P.Events.LEVEL_LOADED, this.onLevelLoaded, this), r.on(P.Events.ERROR, this.onError, this), r.on(P.Events.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), r.on(P.Events.SUBTITLE_TRACK_SWITCH, this.onSubtitleTrackSwitch, this), r.on(P.Events.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), r.on(P.Events.SUBTITLE_FRAG_PROCESSED, this.onSubtitleFragProcessed, this), r.on(P.Events.BUFFER_FLUSHING, this.onBufferFlushing, this), r.on(P.Events.FRAG_BUFFERED, this.onFragBuffered, this);
          }, n._unregisterListeners = function() {
            var r = this.hls;
            r.off(P.Events.MEDIA_ATTACHED, this.onMediaAttached, this), r.off(P.Events.MEDIA_DETACHING, this.onMediaDetaching, this), r.off(P.Events.MANIFEST_LOADING, this.onManifestLoading, this), r.off(P.Events.LEVEL_LOADED, this.onLevelLoaded, this), r.off(P.Events.ERROR, this.onError, this), r.off(P.Events.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), r.off(P.Events.SUBTITLE_TRACK_SWITCH, this.onSubtitleTrackSwitch, this), r.off(P.Events.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), r.off(P.Events.SUBTITLE_FRAG_PROCESSED, this.onSubtitleFragProcessed, this), r.off(P.Events.BUFFER_FLUSHING, this.onBufferFlushing, this), r.off(P.Events.FRAG_BUFFERED, this.onFragBuffered, this);
          }, n.startLoad = function(r) {
            this.stopLoad(), this.state = L.State.IDLE, this.setInterval(a), this.nextLoadPosition = this.startPosition = this.lastCurrentTime = r, this.tick();
          }, n.onManifestLoading = function() {
            this.mainDetails = null, this.fragmentTracker.removeAllFragments();
          }, n.onLevelLoaded = function(r, o) {
            this.mainDetails = o.details;
          }, n.onSubtitleFragProcessed = function(r, o) {
            var t = o.frag, d = o.success;
            if (this.fragPrevious = t, this.state = L.State.IDLE, !!d) {
              var e = this.tracksBuffered[this.currentTrackId];
              if (!!e) {
                for (var h, f = t.start, c = 0; c < e.length; c++)
                  if (f >= e[c].start && f <= e[c].end) {
                    h = e[c];
                    break;
                  }
                var M = t.start + t.duration;
                h ? h.end = M : (h = {
                  start: f,
                  end: M
                }, e.push(h)), this.fragmentTracker.fragBuffered(t);
              }
            }
          }, n.onBufferFlushing = function(r, o) {
            var t = o.startOffset, d = o.endOffset;
            if (t === 0 && d !== Number.POSITIVE_INFINITY) {
              var e = this.currentTrackId, h = this.levels;
              if (!h.length || !h[e] || !h[e].details)
                return;
              var f = h[e].details, c = f.targetduration, M = d - c;
              if (M <= 0)
                return;
              o.endOffsetSubtitles = Math.max(0, M), this.tracksBuffered.forEach(function(w) {
                for (var F = 0; F < w.length; ) {
                  if (w[F].end <= M) {
                    w.shift();
                    continue;
                  } else if (w[F].start < M)
                    w[F].start = M;
                  else
                    break;
                  F++;
                }
              }), this.fragmentTracker.removeFragmentsInRange(t, M, D.PlaylistLevelType.SUBTITLE);
            }
          }, n.onFragBuffered = function(r, o) {
            if (!this.loadedmetadata && o.frag.type === D.PlaylistLevelType.MAIN) {
              var t;
              (t = this.media) !== null && t !== void 0 && t.buffered.length && (this.loadedmetadata = !0);
            }
          }, n.onError = function(r, o) {
            var t = o.frag;
            !t || t.type !== D.PlaylistLevelType.SUBTITLE || (this.fragCurrent && this.fragCurrent.abortRequests(), this.state = L.State.IDLE);
          }, n.onSubtitleTracksUpdated = function(r, o) {
            var t = this, d = o.subtitleTracks;
            this.tracksBuffered = [], this.levels = d.map(function(e) {
              return new _.Level(e);
            }), this.fragmentTracker.removeAllFragments(), this.fragPrevious = null, this.levels.forEach(function(e) {
              t.tracksBuffered[e.id] = [];
            }), this.mediaBuffer = null;
          }, n.onSubtitleTrackSwitch = function(r, o) {
            if (this.currentTrackId = o.id, !this.levels.length || this.currentTrackId === -1) {
              this.clearInterval();
              return;
            }
            var t = this.levels[this.currentTrackId];
            t != null && t.details ? this.mediaBuffer = this.mediaBufferTimeRanges : this.mediaBuffer = null, t && this.setInterval(a);
          }, n.onSubtitleTrackLoaded = function(r, o) {
            var t, d = o.details, e = o.id, h = this.currentTrackId, f = this.levels;
            if (!!f.length) {
              var c = f[h];
              if (!(e >= f.length || e !== h || !c)) {
                this.mediaBuffer = this.mediaBufferTimeRanges;
                var M = 0;
                if (d.live || (t = c.details) !== null && t !== void 0 && t.live) {
                  var w = this.mainDetails;
                  if (d.deltaUpdateFailed || !w)
                    return;
                  var F = w.fragments[0];
                  c.details ? (M = this.alignPlaylists(d, c.details), M === 0 && F && (M = F.start, (0, B.addSliding)(d, M))) : d.hasProgramDateTime && w.hasProgramDateTime ? ((0, C.alignMediaPlaylistByPDT)(d, w), M = d.fragments[0].start) : F && (M = F.start, (0, B.addSliding)(d, M));
                }
                if (c.details = d, this.levelLastLoaded = e, !this.startFragRequested && (this.mainDetails || !d.live) && this.setStartPosition(c.details, M), this.tick(), d.live && !this.fragCurrent && this.media && this.state === L.State.IDLE) {
                  var U = (0, k.findFragmentByPTS)(null, d.fragments, this.media.currentTime, 0);
                  U || (this.warn("Subtitle playlist not aligned with playback"), c.details = void 0);
                }
              }
            }
          }, n._handleFragmentLoadComplete = function(r) {
            var o = this, t = r.frag, d = r.payload, e = t.decryptdata, h = this.hls;
            if (!this.fragContextChanged(t) && d && d.byteLength > 0 && e && e.key && e.iv && e.method === "AES-128") {
              var f = performance.now();
              this.decrypter.decrypt(new Uint8Array(d), e.key.buffer, e.iv.buffer).then(function(c) {
                var M = performance.now();
                h.trigger(P.Events.FRAG_DECRYPTED, {
                  frag: t,
                  payload: c,
                  stats: {
                    tstart: f,
                    tdecrypt: M
                  }
                });
              }).catch(function(c) {
                o.warn(c.name + ": " + c.message), o.state = L.State.IDLE;
              });
            }
          }, n.doTick = function() {
            if (!this.media) {
              this.state = L.State.IDLE;
              return;
            }
            if (this.state === L.State.IDLE) {
              var r = this.currentTrackId, o = this.levels;
              if (!o.length || !o[r] || !o[r].details)
                return;
              var t = o[r].details, d = t.targetduration, e = this.config, h = this.getLoadPosition(), f = T.BufferHelper.bufferedInfo(this.tracksBuffered[this.currentTrackId] || [], h - d, e.maxBufferHole), c = f.end, M = f.len, w = this.getFwdBufferInfo(this.media, D.PlaylistLevelType.MAIN), F = this.getMaxBufferLength(w == null ? void 0 : w.len) + d;
              if (M > F)
                return;
              console.assert(t, "Subtitle track details are defined on idle subtitle stream controller tick");
              var U = t.fragments, N = U.length, H = t.edge, j = null, z = this.fragPrevious;
              if (c < H) {
                var Y = e.maxFragLookUpTolerance;
                j = (0, k.findFragmentByPTS)(z, U, Math.max(U[0].start, c), Y), !j && z && z.start < U[0].start && (j = U[0]);
              } else
                j = U[N - 1];
              if (!j)
                return;
              j = this.mapToInitFragWhenRequired(j), this.fragmentTracker.getState(j) === I.FragmentState.NOT_LOADED && this.loadFragment(j, t, c);
            }
          }, n.getMaxBufferLength = function(r) {
            var o = v.prototype.getMaxBufferLength.call(this);
            return r ? Math.max(o, r) : o;
          }, n.loadFragment = function(r, o, t) {
            this.fragCurrent = r, r.sn === "initSegment" ? this._loadInitSegment(r, o) : (this.startFragRequested = !0, v.prototype.loadFragment.call(this, r, o, t));
          }, g(i, [{
            key: "mediaBufferTimeRanges",
            get: function() {
              return new m(this.tracksBuffered[this.currentTrackId] || []);
            }
          }]), i;
        }(L.default), m = function(i) {
          this.buffered = void 0;
          var n = function(r, o, t) {
            if (o = o >>> 0, o > t - 1)
              throw new DOMException("Failed to execute '" + r + "' on 'TimeRanges': The index provided (" + o + ") is greater than the maximum bound (" + t + ")");
            return i[o][r];
          };
          this.buffered = {
            get length() {
              return i.length;
            },
            end: function(r) {
              return n("end", r, i.length);
            },
            start: function(r) {
              return n("start", r, i.length);
            }
          };
        };
      },
      "./src/controller/subtitle-track-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => y
        });
        var P = p("./src/events.ts"), T = p("./src/utils/texttrack-utils.ts"), k = p("./src/controller/base-playlist-controller.ts"), C = p("./src/types/loader.ts");
        function B(l, u) {
          for (var a = 0; a < u.length; a++) {
            var s = u[a];
            s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(l, L(s.key), s);
          }
        }
        function I(l, u, a) {
          return u && B(l.prototype, u), a && B(l, a), Object.defineProperty(l, "prototype", { writable: !1 }), l;
        }
        function L(l) {
          var u = D(l, "string");
          return typeof u == "symbol" ? u : String(u);
        }
        function D(l, u) {
          if (typeof l != "object" || l === null)
            return l;
          var a = l[Symbol.toPrimitive];
          if (a !== void 0) {
            var s = a.call(l, u || "default");
            if (typeof s != "object")
              return s;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (u === "string" ? String : Number)(l);
        }
        function _(l, u) {
          l.prototype = Object.create(u.prototype), l.prototype.constructor = l, x(l, u);
        }
        function x(l, u) {
          return x = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(s, m) {
            return s.__proto__ = m, s;
          }, x(l, u);
        }
        var g = /* @__PURE__ */ function(l) {
          _(u, l);
          function u(s) {
            var m;
            return m = l.call(this, s, "[subtitle-track-controller]") || this, m.media = null, m.tracks = [], m.groupId = null, m.tracksInGroup = [], m.trackId = -1, m.selectDefaultTrack = !0, m.queuedDefaultTrack = -1, m.trackChangeListener = function() {
              return m.onTextTracksChanged();
            }, m.asyncPollTrackChange = function() {
              return m.pollTrackChange(0);
            }, m.useTextTrackPolling = !1, m.subtitlePollingInterval = -1, m._subtitleDisplay = !0, m.registerListeners(), m;
          }
          var a = u.prototype;
          return a.destroy = function() {
            this.unregisterListeners(), this.tracks.length = 0, this.tracksInGroup.length = 0, this.trackChangeListener = this.asyncPollTrackChange = null, l.prototype.destroy.call(this);
          }, a.registerListeners = function() {
            var m = this.hls;
            m.on(P.Events.MEDIA_ATTACHED, this.onMediaAttached, this), m.on(P.Events.MEDIA_DETACHING, this.onMediaDetaching, this), m.on(P.Events.MANIFEST_LOADING, this.onManifestLoading, this), m.on(P.Events.MANIFEST_PARSED, this.onManifestParsed, this), m.on(P.Events.LEVEL_LOADING, this.onLevelLoading, this), m.on(P.Events.LEVEL_SWITCHING, this.onLevelSwitching, this), m.on(P.Events.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), m.on(P.Events.ERROR, this.onError, this);
          }, a.unregisterListeners = function() {
            var m = this.hls;
            m.off(P.Events.MEDIA_ATTACHED, this.onMediaAttached, this), m.off(P.Events.MEDIA_DETACHING, this.onMediaDetaching, this), m.off(P.Events.MANIFEST_LOADING, this.onManifestLoading, this), m.off(P.Events.MANIFEST_PARSED, this.onManifestParsed, this), m.off(P.Events.LEVEL_LOADING, this.onLevelLoading, this), m.off(P.Events.LEVEL_SWITCHING, this.onLevelSwitching, this), m.off(P.Events.SUBTITLE_TRACK_LOADED, this.onSubtitleTrackLoaded, this), m.off(P.Events.ERROR, this.onError, this);
          }, a.onMediaAttached = function(m, v) {
            this.media = v.media, this.media && (this.queuedDefaultTrack > -1 && (this.subtitleTrack = this.queuedDefaultTrack, this.queuedDefaultTrack = -1), this.useTextTrackPolling = !(this.media.textTracks && "onchange" in this.media.textTracks), this.useTextTrackPolling ? this.pollTrackChange(500) : this.media.textTracks.addEventListener("change", this.asyncPollTrackChange));
          }, a.pollTrackChange = function(m) {
            self.clearInterval(this.subtitlePollingInterval), this.subtitlePollingInterval = self.setInterval(this.trackChangeListener, m);
          }, a.onMediaDetaching = function() {
            if (!!this.media) {
              self.clearInterval(this.subtitlePollingInterval), this.useTextTrackPolling || this.media.textTracks.removeEventListener("change", this.asyncPollTrackChange), this.trackId > -1 && (this.queuedDefaultTrack = this.trackId);
              var m = S(this.media.textTracks);
              m.forEach(function(v) {
                (0, T.clearCurrentCues)(v);
              }), this.subtitleTrack = -1, this.media = null;
            }
          }, a.onManifestLoading = function() {
            this.tracks = [], this.groupId = null, this.tracksInGroup = [], this.trackId = -1, this.selectDefaultTrack = !0;
          }, a.onManifestParsed = function(m, v) {
            this.tracks = v.subtitleTracks;
          }, a.onSubtitleTrackLoaded = function(m, v) {
            var i = v.id, n = v.details, E = this.trackId, r = this.tracksInGroup[E];
            if (!r) {
              this.warn("Invalid subtitle track id " + i);
              return;
            }
            var o = r.details;
            r.details = v.details, this.log("subtitle track " + i + " loaded [" + n.startSN + "-" + n.endSN + "]"), i === this.trackId && (this.retryCount = 0, this.playlistLoaded(i, v, o));
          }, a.onLevelLoading = function(m, v) {
            this.switchLevel(v.level);
          }, a.onLevelSwitching = function(m, v) {
            this.switchLevel(v.level);
          }, a.switchLevel = function(m) {
            var v = this.hls.levels[m];
            if (!!(v != null && v.textGroupIds)) {
              var i = v.textGroupIds[v.urlId];
              if (this.groupId !== i) {
                var n = this.tracksInGroup ? this.tracksInGroup[this.trackId] : void 0, E = this.tracks.filter(function(t) {
                  return !i || t.groupId === i;
                });
                this.tracksInGroup = E;
                var r = this.findTrackId(n == null ? void 0 : n.name) || this.findTrackId();
                this.groupId = i;
                var o = {
                  subtitleTracks: E
                };
                this.log("Updating subtitle tracks, " + E.length + ' track(s) found in "' + i + '" group-id'), this.hls.trigger(P.Events.SUBTITLE_TRACKS_UPDATED, o), r !== -1 && this.setSubtitleTrack(r, n);
              }
            }
          }, a.findTrackId = function(m) {
            for (var v = this.tracksInGroup, i = 0; i < v.length; i++) {
              var n = v[i];
              if ((!this.selectDefaultTrack || n.default) && (!m || m === n.name))
                return n.id;
            }
            return -1;
          }, a.onError = function(m, v) {
            l.prototype.onError.call(this, m, v), !(v.fatal || !v.context) && v.context.type === C.PlaylistContextType.SUBTITLE_TRACK && v.context.id === this.trackId && v.context.groupId === this.groupId && this.retryLoadingOrFail(v);
          }, a.loadPlaylist = function(m) {
            l.prototype.loadPlaylist.call(this);
            var v = this.tracksInGroup[this.trackId];
            if (this.shouldLoadTrack(v)) {
              var i = v.id, n = v.groupId, E = v.url;
              if (m)
                try {
                  E = m.addDirectives(E);
                } catch (r) {
                  this.warn("Could not construct new URL with HLS Delivery Directives: " + r);
                }
              this.log("Loading subtitle playlist for id " + i), this.hls.trigger(P.Events.SUBTITLE_TRACK_LOADING, {
                url: E,
                id: i,
                groupId: n,
                deliveryDirectives: m || null
              });
            }
          }, a.toggleTrackModes = function(m) {
            var v = this, i = this.media, n = this.trackId;
            if (!!i) {
              var E = S(i.textTracks), r = E.filter(function(d) {
                return d.groupId === v.groupId;
              });
              if (m === -1)
                [].slice.call(E).forEach(function(d) {
                  d.mode = "disabled";
                });
              else {
                var o = r[n];
                o && (o.mode = "disabled");
              }
              var t = r[m];
              t && (t.mode = this.subtitleDisplay ? "showing" : "hidden");
            }
          }, a.setSubtitleTrack = function(m, v) {
            var i, n = this.tracksInGroup;
            if (!this.media) {
              this.queuedDefaultTrack = m;
              return;
            }
            if (this.trackId !== m && this.toggleTrackModes(m), !(this.trackId === m && (m === -1 || (i = n[m]) !== null && i !== void 0 && i.details) || m < -1 || m >= n.length)) {
              this.clearTimer();
              var E = n[m];
              if (this.log("Switching to subtitle track " + m), this.trackId = m, E) {
                var r = E.id, o = E.groupId, t = o === void 0 ? "" : o, d = E.name, e = E.type, h = E.url;
                this.hls.trigger(P.Events.SUBTITLE_TRACK_SWITCH, {
                  id: r,
                  groupId: t,
                  name: d,
                  type: e,
                  url: h
                });
                var f = this.switchParams(E.url, v == null ? void 0 : v.details);
                this.loadPlaylist(f);
              } else
                this.hls.trigger(P.Events.SUBTITLE_TRACK_SWITCH, {
                  id: m
                });
            }
          }, a.onTextTracksChanged = function() {
            if (this.useTextTrackPolling || self.clearInterval(this.subtitlePollingInterval), !(!this.media || !this.hls.config.renderTextTracksNatively)) {
              for (var m = -1, v = S(this.media.textTracks), i = 0; i < v.length; i++)
                if (v[i].mode === "hidden")
                  m = i;
                else if (v[i].mode === "showing") {
                  m = i;
                  break;
                }
              this.subtitleTrack !== m && (this.subtitleTrack = m);
            }
          }, I(u, [{
            key: "subtitleDisplay",
            get: function() {
              return this._subtitleDisplay;
            },
            set: function(m) {
              this._subtitleDisplay = m, this.trackId > -1 && this.toggleTrackModes(this.trackId);
            }
          }, {
            key: "subtitleTracks",
            get: function() {
              return this.tracksInGroup;
            }
          }, {
            key: "subtitleTrack",
            get: function() {
              return this.trackId;
            },
            set: function(m) {
              this.selectDefaultTrack = !1;
              var v = this.tracksInGroup ? this.tracksInGroup[this.trackId] : void 0;
              this.setSubtitleTrack(m, v);
            }
          }]), u;
        }(k.default);
        function S(l) {
          for (var u = [], a = 0; a < l.length; a++) {
            var s = l[a];
            s.kind === "subtitles" && s.label && u.push(l[a]);
          }
          return u;
        }
        const y = g;
      },
      "./src/controller/timeline-controller.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          TimelineController: () => g
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/events.ts"), k = p("./src/utils/cea-608-parser.ts"), C = p("./src/utils/output-filter.ts"), B = p("./src/utils/webvtt-parser.ts"), I = p("./src/utils/texttrack-utils.ts"), L = p("./src/utils/imsc1-ttml-parser.ts"), D = p("./src/utils/mp4-tools.ts"), _ = p("./src/types/loader.ts"), x = p("./src/utils/logger.ts"), g = /* @__PURE__ */ function() {
          function u(s) {
            if (this.hls = void 0, this.media = null, this.config = void 0, this.enabled = !0, this.Cues = void 0, this.textTracks = [], this.tracks = [], this.initPTS = [], this.timescale = [], this.unparsedVttFrags = [], this.captionsTracks = {}, this.nonNativeCaptionsTracks = {}, this.cea608Parser1 = void 0, this.cea608Parser2 = void 0, this.lastSn = -1, this.lastPartIndex = -1, this.prevCC = -1, this.vttCCs = l(), this.captionsProperties = void 0, this.hls = s, this.config = s.config, this.Cues = s.config.cueHandler, this.captionsProperties = {
              textTrack1: {
                label: this.config.captionsTextTrack1Label,
                languageCode: this.config.captionsTextTrack1LanguageCode
              },
              textTrack2: {
                label: this.config.captionsTextTrack2Label,
                languageCode: this.config.captionsTextTrack2LanguageCode
              },
              textTrack3: {
                label: this.config.captionsTextTrack3Label,
                languageCode: this.config.captionsTextTrack3LanguageCode
              },
              textTrack4: {
                label: this.config.captionsTextTrack4Label,
                languageCode: this.config.captionsTextTrack4LanguageCode
              }
            }, this.config.enableCEA708Captions) {
              var m = new C.default(this, "textTrack1"), v = new C.default(this, "textTrack2"), i = new C.default(this, "textTrack3"), n = new C.default(this, "textTrack4");
              this.cea608Parser1 = new k.default(1, m, v), this.cea608Parser2 = new k.default(3, i, n);
            }
            s.on(T.Events.MEDIA_ATTACHING, this.onMediaAttaching, this), s.on(T.Events.MEDIA_DETACHING, this.onMediaDetaching, this), s.on(T.Events.MANIFEST_LOADING, this.onManifestLoading, this), s.on(T.Events.MANIFEST_LOADED, this.onManifestLoaded, this), s.on(T.Events.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), s.on(T.Events.FRAG_LOADING, this.onFragLoading, this), s.on(T.Events.FRAG_LOADED, this.onFragLoaded, this), s.on(T.Events.FRAG_PARSING_USERDATA, this.onFragParsingUserdata, this), s.on(T.Events.FRAG_DECRYPTED, this.onFragDecrypted, this), s.on(T.Events.INIT_PTS_FOUND, this.onInitPtsFound, this), s.on(T.Events.SUBTITLE_TRACKS_CLEARED, this.onSubtitleTracksCleared, this), s.on(T.Events.BUFFER_FLUSHING, this.onBufferFlushing, this);
          }
          var a = u.prototype;
          return a.destroy = function() {
            var m = this.hls;
            m.off(T.Events.MEDIA_ATTACHING, this.onMediaAttaching, this), m.off(T.Events.MEDIA_DETACHING, this.onMediaDetaching, this), m.off(T.Events.MANIFEST_LOADING, this.onManifestLoading, this), m.off(T.Events.MANIFEST_LOADED, this.onManifestLoaded, this), m.off(T.Events.SUBTITLE_TRACKS_UPDATED, this.onSubtitleTracksUpdated, this), m.off(T.Events.FRAG_LOADING, this.onFragLoading, this), m.off(T.Events.FRAG_LOADED, this.onFragLoaded, this), m.off(T.Events.FRAG_PARSING_USERDATA, this.onFragParsingUserdata, this), m.off(T.Events.FRAG_DECRYPTED, this.onFragDecrypted, this), m.off(T.Events.INIT_PTS_FOUND, this.onInitPtsFound, this), m.off(T.Events.SUBTITLE_TRACKS_CLEARED, this.onSubtitleTracksCleared, this), m.off(T.Events.BUFFER_FLUSHING, this.onBufferFlushing, this), this.hls = this.config = this.cea608Parser1 = this.cea608Parser2 = null;
          }, a.addCues = function(m, v, i, n, E) {
            for (var r = !1, o = E.length; o--; ) {
              var t = E[o], d = y(t[0], t[1], v, i);
              if (d >= 0 && (t[0] = Math.min(t[0], v), t[1] = Math.max(t[1], i), r = !0, d / (i - v) > 0.5))
                return;
            }
            if (r || E.push([v, i]), this.config.renderTextTracksNatively) {
              var e = this.captionsTracks[m];
              this.Cues.newCue(e, v, i, n);
            } else {
              var h = this.Cues.newCue(null, v, i, n);
              this.hls.trigger(T.Events.CUES_PARSED, {
                type: "captions",
                cues: h,
                track: m
              });
            }
          }, a.onInitPtsFound = function(m, v) {
            var i = this, n = v.frag, E = v.id, r = v.initPTS, o = v.timescale, t = this.unparsedVttFrags;
            E === "main" && (this.initPTS[n.cc] = r, this.timescale[n.cc] = o), t.length && (this.unparsedVttFrags = [], t.forEach(function(d) {
              i.onFragLoaded(T.Events.FRAG_LOADED, d);
            }));
          }, a.getExistingTrack = function(m) {
            var v = this.media;
            if (v)
              for (var i = 0; i < v.textTracks.length; i++) {
                var n = v.textTracks[i];
                if (n[m])
                  return n;
              }
            return null;
          }, a.createCaptionsTrack = function(m) {
            this.config.renderTextTracksNatively ? this.createNativeTrack(m) : this.createNonNativeTrack(m);
          }, a.createNativeTrack = function(m) {
            if (!this.captionsTracks[m]) {
              var v = this.captionsProperties, i = this.captionsTracks, n = this.media, E = v[m], r = E.label, o = E.languageCode, t = this.getExistingTrack(m);
              if (t)
                i[m] = t, (0, I.clearCurrentCues)(i[m]), (0, I.sendAddTrackEvent)(i[m], n);
              else {
                var d = this.createTextTrack("captions", r, o);
                d && (d[m] = !0, i[m] = d);
              }
            }
          }, a.createNonNativeTrack = function(m) {
            if (!this.nonNativeCaptionsTracks[m]) {
              var v = this.captionsProperties[m];
              if (!!v) {
                var i = v.label, n = {
                  _id: m,
                  label: i,
                  kind: "captions",
                  default: v.media ? !!v.media.default : !1,
                  closedCaptions: v.media
                };
                this.nonNativeCaptionsTracks[m] = n, this.hls.trigger(T.Events.NON_NATIVE_TEXT_TRACKS_FOUND, {
                  tracks: [n]
                });
              }
            }
          }, a.createTextTrack = function(m, v, i) {
            var n = this.media;
            if (!!n)
              return n.addTextTrack(m, v, i);
          }, a.onMediaAttaching = function(m, v) {
            this.media = v.media, this._cleanTracks();
          }, a.onMediaDetaching = function() {
            var m = this.captionsTracks;
            Object.keys(m).forEach(function(v) {
              (0, I.clearCurrentCues)(m[v]), delete m[v];
            }), this.nonNativeCaptionsTracks = {};
          }, a.onManifestLoading = function() {
            this.lastSn = -1, this.lastPartIndex = -1, this.prevCC = -1, this.vttCCs = l(), this._cleanTracks(), this.tracks = [], this.captionsTracks = {}, this.nonNativeCaptionsTracks = {}, this.textTracks = [], this.unparsedVttFrags = this.unparsedVttFrags || [], this.initPTS = [], this.timescale = [], this.cea608Parser1 && this.cea608Parser2 && (this.cea608Parser1.reset(), this.cea608Parser2.reset());
          }, a._cleanTracks = function() {
            var m = this.media;
            if (!!m) {
              var v = m.textTracks;
              if (v)
                for (var i = 0; i < v.length; i++)
                  (0, I.clearCurrentCues)(v[i]);
            }
          }, a.onSubtitleTracksUpdated = function(m, v) {
            var i = this;
            this.textTracks = [];
            var n = v.subtitleTracks || [], E = n.some(function(d) {
              return d.textCodec === L.IMSC1_CODEC;
            });
            if (this.config.enableWebVTT || E && this.config.enableIMSC1) {
              var r = this.tracks && n && this.tracks.length === n.length;
              if (this.tracks = n || [], this.config.renderTextTracksNatively) {
                var o = this.media ? this.media.textTracks : [];
                this.tracks.forEach(function(d, e) {
                  var h;
                  if (e < o.length) {
                    for (var f = null, c = 0; c < o.length; c++)
                      if (S(o[c], d)) {
                        f = o[c];
                        break;
                      }
                    f && (h = f);
                  }
                  if (h)
                    (0, I.clearCurrentCues)(h);
                  else {
                    var M = i._captionsOrSubtitlesFromCharacteristics(d);
                    h = i.createTextTrack(M, d.name, d.lang), h && (h.mode = "disabled");
                  }
                  h && (h.groupId = d.groupId, i.textTracks.push(h));
                });
              } else if (!r && this.tracks && this.tracks.length) {
                var t = this.tracks.map(function(d) {
                  return {
                    label: d.name,
                    kind: d.type.toLowerCase(),
                    default: d.default,
                    subtitleTrack: d
                  };
                });
                this.hls.trigger(T.Events.NON_NATIVE_TEXT_TRACKS_FOUND, {
                  tracks: t
                });
              }
            }
          }, a._captionsOrSubtitlesFromCharacteristics = function(m) {
            var v;
            if ((v = m.attrs) !== null && v !== void 0 && v.CHARACTERISTICS) {
              var i = /transcribes-spoken-dialog/gi.test(m.attrs.CHARACTERISTICS), n = /describes-music-and-sound/gi.test(m.attrs.CHARACTERISTICS);
              if (i && n)
                return "captions";
            }
            return "subtitles";
          }, a.onManifestLoaded = function(m, v) {
            var i = this;
            this.config.enableCEA708Captions && v.captions && v.captions.forEach(function(n) {
              var E = /(?:CC|SERVICE)([1-4])/.exec(n.instreamId);
              if (!!E) {
                var r = "textTrack" + E[1], o = i.captionsProperties[r];
                !o || (o.label = n.name, n.lang && (o.languageCode = n.lang), o.media = n);
              }
            });
          }, a.closedCaptionsForLevel = function(m) {
            var v = this.hls.levels[m.level];
            return v == null ? void 0 : v.attrs["CLOSED-CAPTIONS"];
          }, a.onFragLoading = function(m, v) {
            var i = this.cea608Parser1, n = this.cea608Parser2, E = this.lastSn, r = this.lastPartIndex;
            if (!(!this.enabled || !(i && n)) && v.frag.type === _.PlaylistLevelType.MAIN) {
              var o, t, d = v.frag.sn, e = (o = v == null || (t = v.part) === null || t === void 0 ? void 0 : t.index) != null ? o : -1;
              d === E + 1 || d === E && e === r + 1 || (i.reset(), n.reset()), this.lastSn = d, this.lastPartIndex = e;
            }
          }, a.onFragLoaded = function(m, v) {
            var i = v.frag, n = v.payload, E = this.initPTS, r = this.unparsedVttFrags;
            if (i.type === _.PlaylistLevelType.SUBTITLE)
              if (n.byteLength) {
                if (!(0, P.isFiniteNumber)(E[i.cc])) {
                  r.push(v), E.length && this.hls.trigger(T.Events.SUBTITLE_FRAG_PROCESSED, {
                    success: !1,
                    frag: i,
                    error: new Error("Missing initial subtitle PTS")
                  });
                  return;
                }
                var o = i.decryptdata, t = "stats" in v;
                if (o == null || !o.encrypted || t) {
                  var d = this.tracks[i.level], e = this.vttCCs;
                  e[i.cc] || (e[i.cc] = {
                    start: i.start,
                    prevCC: this.prevCC,
                    new: !0
                  }, this.prevCC = i.cc), d && d.textCodec === L.IMSC1_CODEC ? this._parseIMSC1(i, n) : this._parseVTTs(i, n, e);
                }
              } else
                this.hls.trigger(T.Events.SUBTITLE_FRAG_PROCESSED, {
                  success: !1,
                  frag: i,
                  error: new Error("Empty subtitle payload")
                });
          }, a._parseIMSC1 = function(m, v) {
            var i = this, n = this.hls;
            (0, L.parseIMSC1)(v, this.initPTS[m.cc], this.timescale[m.cc], function(E) {
              i._appendCues(E, m.level), n.trigger(T.Events.SUBTITLE_FRAG_PROCESSED, {
                success: !0,
                frag: m
              });
            }, function(E) {
              x.logger.log("Failed to parse IMSC1: " + E), n.trigger(T.Events.SUBTITLE_FRAG_PROCESSED, {
                success: !1,
                frag: m,
                error: E
              });
            });
          }, a._parseVTTs = function(m, v, i) {
            var n, E = this, r = this.hls, o = (n = m.initSegment) !== null && n !== void 0 && n.data ? (0, D.appendUint8Array)(m.initSegment.data, new Uint8Array(v)) : v;
            (0, B.parseWebVTT)(o, this.initPTS[m.cc], this.timescale[m.cc], i, m.cc, m.start, function(t) {
              E._appendCues(t, m.level), r.trigger(T.Events.SUBTITLE_FRAG_PROCESSED, {
                success: !0,
                frag: m
              });
            }, function(t) {
              E._fallbackToIMSC1(m, v), x.logger.log("Failed to parse VTT cue: " + t), r.trigger(T.Events.SUBTITLE_FRAG_PROCESSED, {
                success: !1,
                frag: m,
                error: t
              });
            });
          }, a._fallbackToIMSC1 = function(m, v) {
            var i = this, n = this.tracks[m.level];
            n.textCodec || (0, L.parseIMSC1)(v, this.initPTS[m.cc], this.timescale[m.cc], function() {
              n.textCodec = L.IMSC1_CODEC, i._parseIMSC1(m, v);
            }, function() {
              n.textCodec = "wvtt";
            });
          }, a._appendCues = function(m, v) {
            var i = this.hls;
            if (this.config.renderTextTracksNatively) {
              var n = this.textTracks[v];
              if (!n || n.mode === "disabled")
                return;
              m.forEach(function(o) {
                return (0, I.addCueToTrack)(n, o);
              });
            } else {
              var E = this.tracks[v];
              if (!E)
                return;
              var r = E.default ? "default" : "subtitles" + v;
              i.trigger(T.Events.CUES_PARSED, {
                type: "subtitles",
                cues: m,
                track: r
              });
            }
          }, a.onFragDecrypted = function(m, v) {
            var i = v.frag;
            if (i.type === _.PlaylistLevelType.SUBTITLE) {
              if (!(0, P.isFiniteNumber)(this.initPTS[i.cc])) {
                this.unparsedVttFrags.push(v);
                return;
              }
              this.onFragLoaded(T.Events.FRAG_LOADED, v);
            }
          }, a.onSubtitleTracksCleared = function() {
            this.tracks = [], this.captionsTracks = {};
          }, a.onFragParsingUserdata = function(m, v) {
            var i = this.cea608Parser1, n = this.cea608Parser2;
            if (!(!this.enabled || !(i && n))) {
              var E = v.frag, r = v.samples;
              if (!(E.type === _.PlaylistLevelType.MAIN && this.closedCaptionsForLevel(E) === "NONE"))
                for (var o = 0; o < r.length; o++) {
                  var t = r[o].bytes;
                  if (t) {
                    var d = this.extractCea608Data(t);
                    i.addData(r[o].pts, d[0]), n.addData(r[o].pts, d[1]);
                  }
                }
            }
          }, a.onBufferFlushing = function(m, v) {
            var i = v.startOffset, n = v.endOffset, E = v.endOffsetSubtitles, r = v.type, o = this.media;
            if (!(!o || o.currentTime < n)) {
              if (!r || r === "video") {
                var t = this.captionsTracks;
                Object.keys(t).forEach(function(e) {
                  return (0, I.removeCuesInRange)(t[e], i, n);
                });
              }
              if (this.config.renderTextTracksNatively && i === 0 && E !== void 0) {
                var d = this.textTracks;
                Object.keys(d).forEach(function(e) {
                  return (0, I.removeCuesInRange)(d[e], i, E);
                });
              }
            }
          }, a.extractCea608Data = function(m) {
            for (var v = [[], []], i = m[0] & 31, n = 2, E = 0; E < i; E++) {
              var r = m[n++], o = 127 & m[n++], t = 127 & m[n++];
              if (!(o === 0 && t === 0)) {
                var d = (4 & r) !== 0;
                if (d) {
                  var e = 3 & r;
                  (e === 0 || e === 1) && (v[e].push(o), v[e].push(t));
                }
              }
            }
            return v;
          }, u;
        }();
        function S(u, a) {
          return u && u.label === a.name && !(u.textTrack1 || u.textTrack2);
        }
        function y(u, a, s, m) {
          return Math.min(a, m) - Math.max(u, s);
        }
        function l() {
          return {
            ccOffset: 0,
            presentationOffset: 0,
            0: {
              start: 0,
              prevCC: -1,
              new: !0
            }
          };
        }
      },
      "./src/crypt/aes-crypto.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => P
        });
        var P = /* @__PURE__ */ function() {
          function T(C, B) {
            this.subtle = void 0, this.aesIV = void 0, this.subtle = C, this.aesIV = B;
          }
          var k = T.prototype;
          return k.decrypt = function(B, I) {
            return this.subtle.decrypt({
              name: "AES-CBC",
              iv: this.aesIV
            }, I, B);
          }, T;
        }();
      },
      "./src/crypt/aes-decryptor.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => k,
          removePadding: () => T
        });
        var P = p("./src/utils/typed-array.ts");
        function T(C) {
          var B = C.byteLength, I = B && new DataView(C.buffer).getUint8(B - 1);
          return I ? (0, P.sliceUint8)(C, 0, B - I) : C;
        }
        var k = /* @__PURE__ */ function() {
          function C() {
            this.rcon = [0, 1, 2, 4, 8, 16, 32, 64, 128, 27, 54], this.subMix = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)], this.invSubMix = [new Uint32Array(256), new Uint32Array(256), new Uint32Array(256), new Uint32Array(256)], this.sBox = new Uint32Array(256), this.invSBox = new Uint32Array(256), this.key = new Uint32Array(0), this.ksRows = 0, this.keySize = 0, this.keySchedule = void 0, this.invKeySchedule = void 0, this.initTable();
          }
          var B = C.prototype;
          return B.uint8ArrayToUint32Array_ = function(L) {
            for (var D = new DataView(L), _ = new Uint32Array(4), x = 0; x < 4; x++)
              _[x] = D.getUint32(x * 4);
            return _;
          }, B.initTable = function() {
            var L = this.sBox, D = this.invSBox, _ = this.subMix, x = _[0], g = _[1], S = _[2], y = _[3], l = this.invSubMix, u = l[0], a = l[1], s = l[2], m = l[3], v = new Uint32Array(256), i = 0, n = 0, E = 0;
            for (E = 0; E < 256; E++)
              E < 128 ? v[E] = E << 1 : v[E] = E << 1 ^ 283;
            for (E = 0; E < 256; E++) {
              var r = n ^ n << 1 ^ n << 2 ^ n << 3 ^ n << 4;
              r = r >>> 8 ^ r & 255 ^ 99, L[i] = r, D[r] = i;
              var o = v[i], t = v[o], d = v[t], e = v[r] * 257 ^ r * 16843008;
              x[i] = e << 24 | e >>> 8, g[i] = e << 16 | e >>> 16, S[i] = e << 8 | e >>> 24, y[i] = e, e = d * 16843009 ^ t * 65537 ^ o * 257 ^ i * 16843008, u[r] = e << 24 | e >>> 8, a[r] = e << 16 | e >>> 16, s[r] = e << 8 | e >>> 24, m[r] = e, i ? (i = o ^ v[v[v[d ^ o]]], n ^= v[v[n]]) : i = n = 1;
            }
          }, B.expandKey = function(L) {
            for (var D = this.uint8ArrayToUint32Array_(L), _ = !0, x = 0; x < D.length && _; )
              _ = D[x] === this.key[x], x++;
            if (!_) {
              this.key = D;
              var g = this.keySize = D.length;
              if (g !== 4 && g !== 6 && g !== 8)
                throw new Error("Invalid aes key size=" + g);
              var S = this.ksRows = (g + 6 + 1) * 4, y, l, u = this.keySchedule = new Uint32Array(S), a = this.invKeySchedule = new Uint32Array(S), s = this.sBox, m = this.rcon, v = this.invSubMix, i = v[0], n = v[1], E = v[2], r = v[3], o, t;
              for (y = 0; y < S; y++) {
                if (y < g) {
                  o = u[y] = D[y];
                  continue;
                }
                t = o, y % g === 0 ? (t = t << 8 | t >>> 24, t = s[t >>> 24] << 24 | s[t >>> 16 & 255] << 16 | s[t >>> 8 & 255] << 8 | s[t & 255], t ^= m[y / g | 0] << 24) : g > 6 && y % g === 4 && (t = s[t >>> 24] << 24 | s[t >>> 16 & 255] << 16 | s[t >>> 8 & 255] << 8 | s[t & 255]), u[y] = o = (u[y - g] ^ t) >>> 0;
              }
              for (l = 0; l < S; l++)
                y = S - l, l & 3 ? t = u[y] : t = u[y - 4], l < 4 || y <= 4 ? a[l] = t : a[l] = i[s[t >>> 24]] ^ n[s[t >>> 16 & 255]] ^ E[s[t >>> 8 & 255]] ^ r[s[t & 255]], a[l] = a[l] >>> 0;
            }
          }, B.networkToHostOrderSwap = function(L) {
            return L << 24 | (L & 65280) << 8 | (L & 16711680) >> 8 | L >>> 24;
          }, B.decrypt = function(L, D, _) {
            for (var x = this.keySize + 6, g = this.invKeySchedule, S = this.invSBox, y = this.invSubMix, l = y[0], u = y[1], a = y[2], s = y[3], m = this.uint8ArrayToUint32Array_(_), v = m[0], i = m[1], n = m[2], E = m[3], r = new Int32Array(L), o = new Int32Array(r.length), t, d, e, h, f, c, M, w, F, U, N, H, j, z, Y = this.networkToHostOrderSwap; D < r.length; ) {
              for (F = Y(r[D]), U = Y(r[D + 1]), N = Y(r[D + 2]), H = Y(r[D + 3]), f = F ^ g[0], c = H ^ g[1], M = N ^ g[2], w = U ^ g[3], j = 4, z = 1; z < x; z++)
                t = l[f >>> 24] ^ u[c >> 16 & 255] ^ a[M >> 8 & 255] ^ s[w & 255] ^ g[j], d = l[c >>> 24] ^ u[M >> 16 & 255] ^ a[w >> 8 & 255] ^ s[f & 255] ^ g[j + 1], e = l[M >>> 24] ^ u[w >> 16 & 255] ^ a[f >> 8 & 255] ^ s[c & 255] ^ g[j + 2], h = l[w >>> 24] ^ u[f >> 16 & 255] ^ a[c >> 8 & 255] ^ s[M & 255] ^ g[j + 3], f = t, c = d, M = e, w = h, j = j + 4;
              t = S[f >>> 24] << 24 ^ S[c >> 16 & 255] << 16 ^ S[M >> 8 & 255] << 8 ^ S[w & 255] ^ g[j], d = S[c >>> 24] << 24 ^ S[M >> 16 & 255] << 16 ^ S[w >> 8 & 255] << 8 ^ S[f & 255] ^ g[j + 1], e = S[M >>> 24] << 24 ^ S[w >> 16 & 255] << 16 ^ S[f >> 8 & 255] << 8 ^ S[c & 255] ^ g[j + 2], h = S[w >>> 24] << 24 ^ S[f >> 16 & 255] << 16 ^ S[c >> 8 & 255] << 8 ^ S[M & 255] ^ g[j + 3], o[D] = Y(t ^ v), o[D + 1] = Y(h ^ i), o[D + 2] = Y(e ^ n), o[D + 3] = Y(d ^ E), v = F, i = U, n = N, E = H, D = D + 4;
            }
            return o.buffer;
          }, C;
        }();
      },
      "./src/crypt/decrypter.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => D
        });
        var P = p("./src/crypt/aes-crypto.ts"), T = p("./src/crypt/fast-aes-key.ts"), k = p("./src/crypt/aes-decryptor.ts"), C = p("./src/utils/logger.ts"), B = p("./src/utils/mp4-tools.ts"), I = p("./src/utils/typed-array.ts"), L = 16, D = /* @__PURE__ */ function() {
          function _(g, S) {
            var y = S === void 0 ? {} : S, l = y.removePKCS7Padding, u = l === void 0 ? !0 : l;
            if (this.logEnabled = !0, this.removePKCS7Padding = void 0, this.subtle = null, this.softwareDecrypter = null, this.key = null, this.fastAesKey = null, this.remainderData = null, this.currentIV = null, this.currentResult = null, this.useSoftware = void 0, this.useSoftware = g.enableSoftwareAES, this.removePKCS7Padding = u, u)
              try {
                var a = self.crypto;
                a && (this.subtle = a.subtle || a.webkitSubtle);
              } catch {
              }
            this.subtle === null && (this.useSoftware = !0);
          }
          var x = _.prototype;
          return x.destroy = function() {
            this.subtle = null, this.softwareDecrypter = null, this.key = null, this.fastAesKey = null, this.remainderData = null, this.currentIV = null, this.currentResult = null;
          }, x.isSync = function() {
            return this.useSoftware;
          }, x.flush = function() {
            var S = this.currentResult, y = this.remainderData;
            if (!S || y)
              return this.reset(), null;
            var l = new Uint8Array(S);
            return this.reset(), this.removePKCS7Padding ? (0, k.removePadding)(l) : l;
          }, x.reset = function() {
            this.currentResult = null, this.currentIV = null, this.remainderData = null, this.softwareDecrypter && (this.softwareDecrypter = null);
          }, x.decrypt = function(S, y, l) {
            var u = this;
            return this.useSoftware ? new Promise(function(a, s) {
              u.softwareDecrypt(new Uint8Array(S), y, l);
              var m = u.flush();
              m ? a(m.buffer) : s(new Error("[softwareDecrypt] Failed to decrypt data"));
            }) : this.webCryptoDecrypt(new Uint8Array(S), y, l);
          }, x.softwareDecrypt = function(S, y, l) {
            var u = this.currentIV, a = this.currentResult, s = this.remainderData;
            this.logOnce("JS AES decrypt"), s && (S = (0, B.appendUint8Array)(s, S), this.remainderData = null);
            var m = this.getValidChunk(S);
            if (!m.length)
              return null;
            u && (l = u);
            var v = this.softwareDecrypter;
            v || (v = this.softwareDecrypter = new k.default()), v.expandKey(y);
            var i = a;
            return this.currentResult = v.decrypt(m.buffer, 0, l), this.currentIV = (0, I.sliceUint8)(m, -16).buffer, i || null;
          }, x.webCryptoDecrypt = function(S, y, l) {
            var u = this, a = this.subtle;
            return (this.key !== y || !this.fastAesKey) && (this.key = y, this.fastAesKey = new T.default(a, y)), this.fastAesKey.expandKey().then(function(s) {
              if (!a)
                return Promise.reject(new Error("web crypto not initialized"));
              u.logOnce("WebCrypto AES decrypt");
              var m = new P.default(a, new Uint8Array(l));
              return m.decrypt(S.buffer, s);
            }).catch(function(s) {
              return C.logger.warn("[decrypter]: WebCrypto Error, disable WebCrypto API, " + s.name + ": " + s.message), u.onWebCryptoError(S, y, l);
            });
          }, x.onWebCryptoError = function(S, y, l) {
            this.useSoftware = !0, this.logEnabled = !0, this.softwareDecrypt(S, y, l);
            var u = this.flush();
            if (u)
              return u.buffer;
            throw new Error("WebCrypto and softwareDecrypt: failed to decrypt data");
          }, x.getValidChunk = function(S) {
            var y = S, l = S.length - S.length % L;
            return l !== S.length && (y = (0, I.sliceUint8)(S, 0, l), this.remainderData = (0, I.sliceUint8)(S, l)), y;
          }, x.logOnce = function(S) {
            !this.logEnabled || (C.logger.log("[decrypter]: " + S), this.logEnabled = !1);
          }, _;
        }();
      },
      "./src/crypt/fast-aes-key.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => P
        });
        var P = /* @__PURE__ */ function() {
          function T(C, B) {
            this.subtle = void 0, this.key = void 0, this.subtle = C, this.key = B;
          }
          var k = T.prototype;
          return k.expandKey = function() {
            return this.subtle.importKey("raw", this.key, {
              name: "AES-CBC"
            }, !1, ["encrypt", "decrypt"]);
          }, T;
        }();
      },
      "./src/demux/aacdemuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => D
        });
        var P = p("./src/demux/base-audio-demuxer.ts"), T = p("./src/demux/adts.ts"), k = p("./src/utils/logger.ts"), C = p("./src/demux/id3.ts");
        function B(_, x) {
          _.prototype = Object.create(x.prototype), _.prototype.constructor = _, I(_, x);
        }
        function I(_, x) {
          return I = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(S, y) {
            return S.__proto__ = y, S;
          }, I(_, x);
        }
        var L = /* @__PURE__ */ function(_) {
          B(x, _);
          function x(S, y) {
            var l;
            return l = _.call(this) || this, l.observer = void 0, l.config = void 0, l.observer = S, l.config = y, l;
          }
          var g = x.prototype;
          return g.resetInitSegment = function(y, l, u, a) {
            _.prototype.resetInitSegment.call(this, y, l, u, a), this._audioTrack = {
              container: "audio/adts",
              type: "audio",
              id: 2,
              pid: -1,
              sequenceNumber: 0,
              segmentCodec: "aac",
              samples: [],
              manifestCodec: l,
              duration: a,
              inputTimeScale: 9e4,
              dropped: 0
            };
          }, x.probe = function(y) {
            if (!y)
              return !1;
            for (var l = C.getID3Data(y, 0) || [], u = l.length, a = y.length; u < a; u++)
              if (T.probe(y, u))
                return k.logger.log("ADTS sync word found !"), !0;
            return !1;
          }, g.canParse = function(y, l) {
            return T.canParse(y, l);
          }, g.appendFrame = function(y, l, u) {
            T.initTrackConfig(y, this.observer, l, u, y.manifestCodec);
            var a = T.appendFrame(y, l, u, this.basePTS, this.frameIndex);
            if (a && a.missing === 0)
              return a;
          }, x;
        }(P.default);
        const D = L;
      },
      "./src/demux/adts.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          appendFrame: () => u,
          canGetFrameLength: () => D,
          canParse: () => x,
          getAudioConfig: () => C,
          getFrameDuration: () => y,
          getFullFrameLength: () => L,
          getHeaderLength: () => I,
          initTrackConfig: () => S,
          isHeader: () => _,
          isHeaderPattern: () => B,
          parseFrameHeader: () => l,
          probe: () => g
        });
        var P = p("./src/utils/logger.ts"), T = p("./src/errors.ts"), k = p("./src/events.ts");
        function C(a, s, m, v) {
          var i, n, E, r, o = navigator.userAgent.toLowerCase(), t = v, d = [96e3, 88200, 64e3, 48e3, 44100, 32e3, 24e3, 22050, 16e3, 12e3, 11025, 8e3, 7350];
          i = ((s[m + 2] & 192) >>> 6) + 1;
          var e = (s[m + 2] & 60) >>> 2;
          if (e > d.length - 1) {
            a.trigger(k.Events.ERROR, {
              type: T.ErrorTypes.MEDIA_ERROR,
              details: T.ErrorDetails.FRAG_PARSING_ERROR,
              fatal: !0,
              reason: "invalid ADTS sampling index:" + e
            });
            return;
          }
          return E = (s[m + 2] & 1) << 2, E |= (s[m + 3] & 192) >>> 6, P.logger.log("manifest codec:" + v + ", ADTS type:" + i + ", samplingIndex:" + e), /firefox/i.test(o) ? e >= 6 ? (i = 5, r = new Array(4), n = e - 3) : (i = 2, r = new Array(2), n = e) : o.indexOf("android") !== -1 ? (i = 2, r = new Array(2), n = e) : (i = 5, r = new Array(4), v && (v.indexOf("mp4a.40.29") !== -1 || v.indexOf("mp4a.40.5") !== -1) || !v && e >= 6 ? n = e - 3 : ((v && v.indexOf("mp4a.40.2") !== -1 && (e >= 6 && E === 1 || /vivaldi/i.test(o)) || !v && E === 1) && (i = 2, r = new Array(2)), n = e)), r[0] = i << 3, r[0] |= (e & 14) >> 1, r[1] |= (e & 1) << 7, r[1] |= E << 3, i === 5 && (r[1] |= (n & 14) >> 1, r[2] = (n & 1) << 7, r[2] |= 8, r[3] = 0), {
            config: r,
            samplerate: d[e],
            channelCount: E,
            codec: "mp4a.40." + i,
            manifestCodec: t
          };
        }
        function B(a, s) {
          return a[s] === 255 && (a[s + 1] & 246) === 240;
        }
        function I(a, s) {
          return a[s + 1] & 1 ? 7 : 9;
        }
        function L(a, s) {
          return (a[s + 3] & 3) << 11 | a[s + 4] << 3 | (a[s + 5] & 224) >>> 5;
        }
        function D(a, s) {
          return s + 5 < a.length;
        }
        function _(a, s) {
          return s + 1 < a.length && B(a, s);
        }
        function x(a, s) {
          return D(a, s) && B(a, s) && L(a, s) <= a.length - s;
        }
        function g(a, s) {
          if (_(a, s)) {
            var m = I(a, s);
            if (s + m >= a.length)
              return !1;
            var v = L(a, s);
            if (v <= m)
              return !1;
            var i = s + v;
            return i === a.length || _(a, i);
          }
          return !1;
        }
        function S(a, s, m, v, i) {
          if (!a.samplerate) {
            var n = C(s, m, v, i);
            if (!n)
              return;
            a.config = n.config, a.samplerate = n.samplerate, a.channelCount = n.channelCount, a.codec = n.codec, a.manifestCodec = n.manifestCodec, P.logger.log("parsed codec:" + a.codec + ", rate:" + n.samplerate + ", channels:" + n.channelCount);
          }
        }
        function y(a) {
          return 9216e4 / a;
        }
        function l(a, s) {
          var m = I(a, s);
          if (s + m <= a.length) {
            var v = L(a, s) - m;
            if (v > 0)
              return {
                headerLength: m,
                frameLength: v
              };
          }
        }
        function u(a, s, m, v, i) {
          var n = y(a.samplerate), E = v + i * n, r = l(s, m), o;
          if (r) {
            var t = r.frameLength, d = r.headerLength, e = d + t, h = Math.max(0, m + e - s.length);
            h ? (o = new Uint8Array(e - d), o.set(s.subarray(m + d, s.length), 0)) : o = s.subarray(m + d, m + e);
            var f = {
              unit: o,
              pts: E
            };
            return h || a.samples.push(f), {
              sample: f,
              length: e,
              missing: h
            };
          }
          var c = s.length - m;
          o = new Uint8Array(c), o.set(s.subarray(m, s.length), 0);
          var M = {
            unit: o,
            pts: E
          };
          return {
            sample: M,
            length: c,
            missing: -1
          };
        }
      },
      "./src/demux/base-audio-demuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => _,
          initPTSFn: () => D
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/demux/id3.ts"), k = p("./src/types/demuxer.ts"), C = p("./src/demux/dummy-demuxed-track.ts"), B = p("./src/utils/mp4-tools.ts"), I = p("./src/utils/typed-array.ts"), L = /* @__PURE__ */ function() {
          function x() {
            this._audioTrack = void 0, this._id3Track = void 0, this.frameIndex = 0, this.cachedData = null, this.basePTS = null, this.initPTS = null, this.lastPTS = null;
          }
          var g = x.prototype;
          return g.resetInitSegment = function(y, l, u, a) {
            this._id3Track = {
              type: "id3",
              id: 3,
              pid: -1,
              inputTimeScale: 9e4,
              sequenceNumber: 0,
              samples: [],
              dropped: 0
            };
          }, g.resetTimeStamp = function(y) {
            this.initPTS = y, this.resetContiguity();
          }, g.resetContiguity = function() {
            this.basePTS = null, this.lastPTS = null, this.frameIndex = 0;
          }, g.canParse = function(y, l) {
            return !1;
          }, g.appendFrame = function(y, l, u) {
          }, g.demux = function(y, l) {
            this.cachedData && (y = (0, B.appendUint8Array)(this.cachedData, y), this.cachedData = null);
            var u = T.getID3Data(y, 0), a = u ? u.length : 0, s, m = this._audioTrack, v = this._id3Track, i = u ? T.getTimeStamp(u) : void 0, n = y.length;
            for ((this.basePTS === null || this.frameIndex === 0 && (0, P.isFiniteNumber)(i)) && (this.basePTS = D(i, l, this.initPTS), this.lastPTS = this.basePTS), this.lastPTS === null && (this.lastPTS = this.basePTS), u && u.length > 0 && v.samples.push({
              pts: this.lastPTS,
              dts: this.lastPTS,
              data: u,
              type: k.MetadataSchema.audioId3,
              duration: Number.POSITIVE_INFINITY
            }); a < n; ) {
              if (this.canParse(y, a)) {
                var E = this.appendFrame(m, y, a);
                E ? (this.frameIndex++, this.lastPTS = E.sample.pts, a += E.length, s = a) : a = n;
              } else
                T.canParse(y, a) ? (u = T.getID3Data(y, a), v.samples.push({
                  pts: this.lastPTS,
                  dts: this.lastPTS,
                  data: u,
                  type: k.MetadataSchema.audioId3,
                  duration: Number.POSITIVE_INFINITY
                }), a += u.length, s = a) : a++;
              if (a === n && s !== n) {
                var r = (0, I.sliceUint8)(y, s);
                this.cachedData ? this.cachedData = (0, B.appendUint8Array)(this.cachedData, r) : this.cachedData = r;
              }
            }
            return {
              audioTrack: m,
              videoTrack: (0, C.dummyTrack)(),
              id3Track: v,
              textTrack: (0, C.dummyTrack)()
            };
          }, g.demuxSampleAes = function(y, l, u) {
            return Promise.reject(new Error("[" + this + "] This demuxer does not support Sample-AES decryption"));
          }, g.flush = function(y) {
            var l = this.cachedData;
            return l && (this.cachedData = null, this.demux(l, 0)), {
              audioTrack: this._audioTrack,
              videoTrack: (0, C.dummyTrack)(),
              id3Track: this._id3Track,
              textTrack: (0, C.dummyTrack)()
            };
          }, g.destroy = function() {
          }, x;
        }(), D = function(g, S, y) {
          return (0, P.isFiniteNumber)(g) ? g * 90 : S * 9e4 + (y || 0);
        };
        const _ = L;
      },
      "./src/demux/chunk-cache.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => P
        });
        var P = /* @__PURE__ */ function() {
          function k() {
            this.chunks = [], this.dataLength = 0;
          }
          var C = k.prototype;
          return C.push = function(I) {
            this.chunks.push(I), this.dataLength += I.length;
          }, C.flush = function() {
            var I = this.chunks, L = this.dataLength, D;
            if (I.length)
              I.length === 1 ? D = I[0] : D = T(I, L);
            else
              return new Uint8Array(0);
            return this.reset(), D;
          }, C.reset = function() {
            this.chunks.length = 0, this.dataLength = 0;
          }, k;
        }();
        function T(k, C) {
          for (var B = new Uint8Array(C), I = 0, L = 0; L < k.length; L++) {
            var D = k[L];
            B.set(D, I), I += D.length;
          }
          return B;
        }
      },
      "./src/demux/dummy-demuxed-track.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          dummyTrack: () => P
        });
        function P(T, k) {
          return T === void 0 && (T = ""), k === void 0 && (k = 9e4), {
            type: T,
            id: -1,
            pid: -1,
            inputTimeScale: k,
            sequenceNumber: -1,
            samples: [],
            dropped: 0
          };
        }
      },
      "./src/demux/exp-golomb.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => k
        });
        var P = p("./src/utils/logger.ts"), T = /* @__PURE__ */ function() {
          function C(I) {
            this.data = void 0, this.bytesAvailable = void 0, this.word = void 0, this.bitsAvailable = void 0, this.data = I, this.bytesAvailable = I.byteLength, this.word = 0, this.bitsAvailable = 0;
          }
          var B = C.prototype;
          return B.loadWord = function() {
            var L = this.data, D = this.bytesAvailable, _ = L.byteLength - D, x = new Uint8Array(4), g = Math.min(4, D);
            if (g === 0)
              throw new Error("no bytes available");
            x.set(L.subarray(_, _ + g)), this.word = new DataView(x.buffer).getUint32(0), this.bitsAvailable = g * 8, this.bytesAvailable -= g;
          }, B.skipBits = function(L) {
            var D;
            L = Math.min(L, this.bytesAvailable * 8 + this.bitsAvailable), this.bitsAvailable > L ? (this.word <<= L, this.bitsAvailable -= L) : (L -= this.bitsAvailable, D = L >> 3, L -= D << 3, this.bytesAvailable -= D, this.loadWord(), this.word <<= L, this.bitsAvailable -= L);
          }, B.readBits = function(L) {
            var D = Math.min(this.bitsAvailable, L), _ = this.word >>> 32 - D;
            if (L > 32 && P.logger.error("Cannot read more than 32 bits at a time"), this.bitsAvailable -= D, this.bitsAvailable > 0)
              this.word <<= D;
            else if (this.bytesAvailable > 0)
              this.loadWord();
            else
              throw new Error("no bits available");
            return D = L - D, D > 0 && this.bitsAvailable ? _ << D | this.readBits(D) : _;
          }, B.skipLZ = function() {
            var L;
            for (L = 0; L < this.bitsAvailable; ++L)
              if ((this.word & 2147483648 >>> L) !== 0)
                return this.word <<= L, this.bitsAvailable -= L, L;
            return this.loadWord(), L + this.skipLZ();
          }, B.skipUEG = function() {
            this.skipBits(1 + this.skipLZ());
          }, B.skipEG = function() {
            this.skipBits(1 + this.skipLZ());
          }, B.readUEG = function() {
            var L = this.skipLZ();
            return this.readBits(L + 1) - 1;
          }, B.readEG = function() {
            var L = this.readUEG();
            return 1 & L ? 1 + L >>> 1 : -1 * (L >>> 1);
          }, B.readBoolean = function() {
            return this.readBits(1) === 1;
          }, B.readUByte = function() {
            return this.readBits(8);
          }, B.readUShort = function() {
            return this.readBits(16);
          }, B.readUInt = function() {
            return this.readBits(32);
          }, B.skipScalingList = function(L) {
            for (var D = 8, _ = 8, x, g = 0; g < L; g++)
              _ !== 0 && (x = this.readEG(), _ = (D + x + 256) % 256), D = _ === 0 ? D : _;
          }, B.readSPS = function() {
            var L = 0, D = 0, _ = 0, x = 0, g, S, y, l = this.readUByte.bind(this), u = this.readBits.bind(this), a = this.readUEG.bind(this), s = this.readBoolean.bind(this), m = this.skipBits.bind(this), v = this.skipEG.bind(this), i = this.skipUEG.bind(this), n = this.skipScalingList.bind(this);
            l();
            var E = l();
            if (u(5), m(3), l(), i(), E === 100 || E === 110 || E === 122 || E === 244 || E === 44 || E === 83 || E === 86 || E === 118 || E === 128) {
              var r = a();
              if (r === 3 && m(1), i(), i(), m(1), s())
                for (S = r !== 3 ? 8 : 12, y = 0; y < S; y++)
                  s() && (y < 6 ? n(16) : n(64));
            }
            i();
            var o = a();
            if (o === 0)
              a();
            else if (o === 1)
              for (m(1), v(), v(), g = a(), y = 0; y < g; y++)
                v();
            i(), m(1);
            var t = a(), d = a(), e = u(1);
            e === 0 && m(1), m(1), s() && (L = a(), D = a(), _ = a(), x = a());
            var h = [1, 1];
            if (s() && s()) {
              var f = l();
              switch (f) {
                case 1:
                  h = [1, 1];
                  break;
                case 2:
                  h = [12, 11];
                  break;
                case 3:
                  h = [10, 11];
                  break;
                case 4:
                  h = [16, 11];
                  break;
                case 5:
                  h = [40, 33];
                  break;
                case 6:
                  h = [24, 11];
                  break;
                case 7:
                  h = [20, 11];
                  break;
                case 8:
                  h = [32, 11];
                  break;
                case 9:
                  h = [80, 33];
                  break;
                case 10:
                  h = [18, 11];
                  break;
                case 11:
                  h = [15, 11];
                  break;
                case 12:
                  h = [64, 33];
                  break;
                case 13:
                  h = [160, 99];
                  break;
                case 14:
                  h = [4, 3];
                  break;
                case 15:
                  h = [3, 2];
                  break;
                case 16:
                  h = [2, 1];
                  break;
                case 255: {
                  h = [l() << 8 | l(), l() << 8 | l()];
                  break;
                }
              }
            }
            return {
              width: Math.ceil((t + 1) * 16 - L * 2 - D * 2),
              height: (2 - e) * (d + 1) * 16 - (e ? 2 : 4) * (_ + x),
              pixelRatio: h
            };
          }, B.readSliceType = function() {
            return this.readUByte(), this.readUEG(), this.readUEG();
          }, C;
        }();
        const k = T;
      },
      "./src/demux/id3.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          canParse: () => B,
          decodeFrame: () => x,
          getID3Data: () => k,
          getID3Frames: () => _,
          getTimeStamp: () => I,
          isFooter: () => T,
          isHeader: () => P,
          isTimeStampFrame: () => L,
          testables: () => a,
          utf8ArrayToStr: () => u
        });
        var P = function(i, n) {
          return n + 10 <= i.length && i[n] === 73 && i[n + 1] === 68 && i[n + 2] === 51 && i[n + 3] < 255 && i[n + 4] < 255 && i[n + 6] < 128 && i[n + 7] < 128 && i[n + 8] < 128 && i[n + 9] < 128;
        }, T = function(i, n) {
          return n + 10 <= i.length && i[n] === 51 && i[n + 1] === 68 && i[n + 2] === 73 && i[n + 3] < 255 && i[n + 4] < 255 && i[n + 6] < 128 && i[n + 7] < 128 && i[n + 8] < 128 && i[n + 9] < 128;
        }, k = function(i, n) {
          for (var E = n, r = 0; P(i, n); ) {
            r += 10;
            var o = C(i, n + 6);
            r += o, T(i, n + 10) && (r += 10), n += r;
          }
          if (r > 0)
            return i.subarray(E, E + r);
        }, C = function(i, n) {
          var E = 0;
          return E = (i[n] & 127) << 21, E |= (i[n + 1] & 127) << 14, E |= (i[n + 2] & 127) << 7, E |= i[n + 3] & 127, E;
        }, B = function(i, n) {
          return P(i, n) && C(i, n + 6) + 10 <= i.length - n;
        }, I = function(i) {
          for (var n = _(i), E = 0; E < n.length; E++) {
            var r = n[E];
            if (L(r))
              return l(r);
          }
        }, L = function(i) {
          return i && i.key === "PRIV" && i.info === "com.apple.streaming.transportStreamTimestamp";
        }, D = function(i) {
          var n = String.fromCharCode(i[0], i[1], i[2], i[3]), E = C(i, 4), r = 10;
          return {
            type: n,
            size: E,
            data: i.subarray(r, r + E)
          };
        }, _ = function(i) {
          for (var n = 0, E = []; P(i, n); ) {
            var r = C(i, n + 6);
            n += 10;
            for (var o = n + r; n + 8 < o; ) {
              var t = D(i.subarray(n)), d = x(t);
              d && E.push(d), n += t.size + 10;
            }
            T(i, n) && (n += 10);
          }
          return E;
        }, x = function(i) {
          return i.type === "PRIV" ? g(i) : i.type[0] === "W" ? y(i) : S(i);
        }, g = function(i) {
          if (!(i.size < 2)) {
            var n = u(i.data, !0), E = new Uint8Array(i.data.subarray(n.length + 1));
            return {
              key: i.type,
              info: n,
              data: E.buffer
            };
          }
        }, S = function(i) {
          if (!(i.size < 2)) {
            if (i.type === "TXXX") {
              var n = 1, E = u(i.data.subarray(n), !0);
              n += E.length + 1;
              var r = u(i.data.subarray(n));
              return {
                key: i.type,
                info: E,
                data: r
              };
            }
            var o = u(i.data.subarray(1));
            return {
              key: i.type,
              data: o
            };
          }
        }, y = function(i) {
          if (i.type === "WXXX") {
            if (i.size < 2)
              return;
            var n = 1, E = u(i.data.subarray(n), !0);
            n += E.length + 1;
            var r = u(i.data.subarray(n));
            return {
              key: i.type,
              info: E,
              data: r
            };
          }
          var o = u(i.data);
          return {
            key: i.type,
            data: o
          };
        }, l = function(i) {
          if (i.data.byteLength === 8) {
            var n = new Uint8Array(i.data), E = n[3] & 1, r = (n[4] << 23) + (n[5] << 15) + (n[6] << 7) + n[7];
            return r /= 45, E && (r += 4772185884e-2), Math.round(r);
          }
        }, u = function(i, n) {
          n === void 0 && (n = !1);
          var E = m();
          if (E) {
            var r = E.decode(i);
            if (n) {
              var o = r.indexOf("\0");
              return o !== -1 ? r.substring(0, o) : r;
            }
            return r.replace(/\0/g, "");
          }
          for (var t = i.length, d, e, h, f = "", c = 0; c < t; ) {
            if (d = i[c++], d === 0 && n)
              return f;
            if (d === 0 || d === 3)
              continue;
            switch (d >> 4) {
              case 0:
              case 1:
              case 2:
              case 3:
              case 4:
              case 5:
              case 6:
              case 7:
                f += String.fromCharCode(d);
                break;
              case 12:
              case 13:
                e = i[c++], f += String.fromCharCode((d & 31) << 6 | e & 63);
                break;
              case 14:
                e = i[c++], h = i[c++], f += String.fromCharCode((d & 15) << 12 | (e & 63) << 6 | (h & 63) << 0);
                break;
            }
          }
          return f;
        }, a = {
          decodeTextFrame: S
        }, s;
        function m() {
          return !s && typeof self.TextDecoder < "u" && (s = new self.TextDecoder("utf-8")), s;
        }
      },
      "./src/demux/mp3demuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => D
        });
        var P = p("./src/demux/base-audio-demuxer.ts"), T = p("./src/demux/id3.ts"), k = p("./src/utils/logger.ts"), C = p("./src/demux/mpegaudio.ts");
        function B(_, x) {
          _.prototype = Object.create(x.prototype), _.prototype.constructor = _, I(_, x);
        }
        function I(_, x) {
          return I = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(S, y) {
            return S.__proto__ = y, S;
          }, I(_, x);
        }
        var L = /* @__PURE__ */ function(_) {
          B(x, _);
          function x() {
            return _.apply(this, arguments) || this;
          }
          var g = x.prototype;
          return g.resetInitSegment = function(y, l, u, a) {
            _.prototype.resetInitSegment.call(this, y, l, u, a), this._audioTrack = {
              container: "audio/mpeg",
              type: "audio",
              id: 2,
              pid: -1,
              sequenceNumber: 0,
              segmentCodec: "mp3",
              samples: [],
              manifestCodec: l,
              duration: a,
              inputTimeScale: 9e4,
              dropped: 0
            };
          }, x.probe = function(y) {
            if (!y)
              return !1;
            for (var l = T.getID3Data(y, 0) || [], u = l.length, a = y.length; u < a; u++)
              if (C.probe(y, u))
                return k.logger.log("MPEG Audio sync word found !"), !0;
            return !1;
          }, g.canParse = function(y, l) {
            return C.canParse(y, l);
          }, g.appendFrame = function(y, l, u) {
            if (this.basePTS !== null)
              return C.appendFrame(y, l, u, this.basePTS, this.frameIndex);
          }, x;
        }(P.default);
        const D = L;
      },
      "./src/demux/mp4demuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => L
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/types/demuxer.ts"), k = p("./src/utils/mp4-tools.ts"), C = p("./src/demux/dummy-demuxed-track.ts"), B = /\/emsg[-/]ID3/i, I = /* @__PURE__ */ function() {
          function D(x, g) {
            this.remainderData = null, this.timeOffset = 0, this.config = void 0, this.videoTrack = void 0, this.audioTrack = void 0, this.id3Track = void 0, this.txtTrack = void 0, this.config = g;
          }
          var _ = D.prototype;
          return _.resetTimeStamp = function() {
          }, _.resetInitSegment = function(g, S, y, l) {
            var u = this.videoTrack = (0, C.dummyTrack)("video", 1), a = this.audioTrack = (0, C.dummyTrack)("audio", 1), s = this.txtTrack = (0, C.dummyTrack)("text", 1);
            if (this.id3Track = (0, C.dummyTrack)("id3", 1), this.timeOffset = 0, !(!g || !g.byteLength)) {
              var m = (0, k.parseInitSegment)(g);
              if (m.video) {
                var v = m.video, i = v.id, n = v.timescale, E = v.codec;
                u.id = i, u.timescale = s.timescale = n, u.codec = E;
              }
              if (m.audio) {
                var r = m.audio, o = r.id, t = r.timescale, d = r.codec;
                a.id = o, a.timescale = t, a.codec = d;
              }
              s.id = k.RemuxerTrackIdConfig.text, u.sampleDuration = 0, u.duration = a.duration = l;
            }
          }, _.resetContiguity = function() {
          }, D.probe = function(g) {
            return g = g.length > 16384 ? g.subarray(0, 16384) : g, (0, k.findBox)(g, ["moof"]).length > 0;
          }, _.demux = function(g, S) {
            this.timeOffset = S;
            var y = g, l = this.videoTrack, u = this.txtTrack;
            if (this.config.progressive) {
              this.remainderData && (y = (0, k.appendUint8Array)(this.remainderData, g));
              var a = (0, k.segmentValidRange)(y);
              this.remainderData = a.remainder, l.samples = a.valid || new Uint8Array();
            } else
              l.samples = y;
            var s = this.extractID3Track(l, S);
            return u.samples = (0, k.parseSamples)(S, l), {
              videoTrack: l,
              audioTrack: this.audioTrack,
              id3Track: s,
              textTrack: this.txtTrack
            };
          }, _.flush = function() {
            var g = this.timeOffset, S = this.videoTrack, y = this.txtTrack;
            S.samples = this.remainderData || new Uint8Array(), this.remainderData = null;
            var l = this.extractID3Track(S, this.timeOffset);
            return y.samples = (0, k.parseSamples)(g, S), {
              videoTrack: S,
              audioTrack: (0, C.dummyTrack)(),
              id3Track: l,
              textTrack: (0, C.dummyTrack)()
            };
          }, _.extractID3Track = function(g, S) {
            var y = this.id3Track;
            if (g.samples.length) {
              var l = (0, k.findBox)(g.samples, ["emsg"]);
              l && l.forEach(function(u) {
                var a = (0, k.parseEmsg)(u);
                if (B.test(a.schemeIdUri)) {
                  var s = (0, P.isFiniteNumber)(a.presentationTime) ? a.presentationTime / a.timeScale : S + a.presentationTimeDelta / a.timeScale, m = a.eventDuration === 4294967295 ? Number.POSITIVE_INFINITY : a.eventDuration / a.timeScale;
                  m <= 1e-3 && (m = Number.POSITIVE_INFINITY);
                  var v = a.payload;
                  y.samples.push({
                    data: v,
                    len: v.byteLength,
                    dts: s,
                    pts: s,
                    type: T.MetadataSchema.emsg,
                    duration: m
                  });
                }
              });
            }
            return y;
          }, _.demuxSampleAes = function(g, S, y) {
            return Promise.reject(new Error("The MP4 demuxer does not support SAMPLE-AES decryption"));
          }, _.destroy = function() {
          }, D;
        }();
        const L = I;
      },
      "./src/demux/mpegaudio.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          appendFrame: () => I,
          canParse: () => x,
          isHeader: () => _,
          isHeaderPattern: () => D,
          parseHeader: () => L,
          probe: () => g
        });
        var P = null, T = [32, 64, 96, 128, 160, 192, 224, 256, 288, 320, 352, 384, 416, 448, 32, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 384, 32, 40, 48, 56, 64, 80, 96, 112, 128, 160, 192, 224, 256, 320, 32, 48, 56, 64, 80, 96, 112, 128, 144, 160, 176, 192, 224, 256, 8, 16, 24, 32, 40, 48, 56, 64, 80, 96, 112, 128, 144, 160], k = [44100, 48e3, 32e3, 22050, 24e3, 16e3, 11025, 12e3, 8e3], C = [
          [
            0,
            72,
            144,
            12
          ],
          [
            0,
            0,
            0,
            0
          ],
          [
            0,
            72,
            144,
            12
          ],
          [
            0,
            144,
            144,
            12
          ]
        ], B = [
          0,
          1,
          1,
          4
        ];
        function I(S, y, l, u, a) {
          if (!(l + 24 > y.length)) {
            var s = L(y, l);
            if (s && l + s.frameLength <= y.length) {
              var m = s.samplesPerFrame * 9e4 / s.sampleRate, v = u + a * m, i = {
                unit: y.subarray(l, l + s.frameLength),
                pts: v,
                dts: v
              };
              return S.config = [], S.channelCount = s.channelCount, S.samplerate = s.sampleRate, S.samples.push(i), {
                sample: i,
                length: s.frameLength,
                missing: 0
              };
            }
          }
        }
        function L(S, y) {
          var l = S[y + 1] >> 3 & 3, u = S[y + 1] >> 1 & 3, a = S[y + 2] >> 4 & 15, s = S[y + 2] >> 2 & 3;
          if (l !== 1 && a !== 0 && a !== 15 && s !== 3) {
            var m = S[y + 2] >> 1 & 1, v = S[y + 3] >> 6, i = l === 3 ? 3 - u : u === 3 ? 3 : 4, n = T[i * 14 + a - 1] * 1e3, E = l === 3 ? 0 : l === 2 ? 1 : 2, r = k[E * 3 + s], o = v === 3 ? 1 : 2, t = C[l][u], d = B[u], e = t * 8 * d, h = Math.floor(t * n / r + m) * d;
            if (P === null) {
              var f = navigator.userAgent || "", c = f.match(/Chrome\/(\d+)/i);
              P = c ? parseInt(c[1]) : 0;
            }
            var M = !!P && P <= 87;
            return M && u === 2 && n >= 224e3 && v === 0 && (S[y + 3] = S[y + 3] | 128), {
              sampleRate: r,
              channelCount: o,
              frameLength: h,
              samplesPerFrame: e
            };
          }
        }
        function D(S, y) {
          return S[y] === 255 && (S[y + 1] & 224) === 224 && (S[y + 1] & 6) !== 0;
        }
        function _(S, y) {
          return y + 1 < S.length && D(S, y);
        }
        function x(S, y) {
          var l = 4;
          return D(S, y) && l <= S.length - y;
        }
        function g(S, y) {
          if (y + 1 < S.length && D(S, y)) {
            var l = 4, u = L(S, y), a = l;
            u != null && u.frameLength && (a = u.frameLength);
            var s = y + a;
            return s === S.length || _(S, s);
          }
          return !1;
        }
      },
      "./src/demux/sample-aes.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => C
        });
        var P = p("./src/crypt/decrypter.ts"), T = p("./src/utils/mp4-tools.ts"), k = /* @__PURE__ */ function() {
          function B(L, D, _) {
            this.keyData = void 0, this.decrypter = void 0, this.keyData = _, this.decrypter = new P.default(D, {
              removePKCS7Padding: !1
            });
          }
          var I = B.prototype;
          return I.decryptBuffer = function(D) {
            return this.decrypter.decrypt(D, this.keyData.key.buffer, this.keyData.iv.buffer);
          }, I.decryptAacSample = function(D, _, x) {
            var g = this, S = D[_].unit;
            if (!(S.length <= 16)) {
              var y = S.subarray(16, S.length - S.length % 16), l = y.buffer.slice(y.byteOffset, y.byteOffset + y.length);
              this.decryptBuffer(l).then(function(u) {
                var a = new Uint8Array(u);
                S.set(a, 16), g.decrypter.isSync() || g.decryptAacSamples(D, _ + 1, x);
              });
            }
          }, I.decryptAacSamples = function(D, _, x) {
            for (; ; _++) {
              if (_ >= D.length) {
                x();
                return;
              }
              if (!(D[_].unit.length < 32) && (this.decryptAacSample(D, _, x), !this.decrypter.isSync()))
                return;
            }
          }, I.getAvcEncryptedData = function(D) {
            for (var _ = Math.floor((D.length - 48) / 160) * 16 + 16, x = new Int8Array(_), g = 0, S = 32; S < D.length - 16; S += 160, g += 16)
              x.set(D.subarray(S, S + 16), g);
            return x;
          }, I.getAvcDecryptedUnit = function(D, _) {
            for (var x = new Uint8Array(_), g = 0, S = 32; S < D.length - 16; S += 160, g += 16)
              D.set(x.subarray(g, g + 16), S);
            return D;
          }, I.decryptAvcSample = function(D, _, x, g, S) {
            var y = this, l = (0, T.discardEPB)(S.data), u = this.getAvcEncryptedData(l);
            this.decryptBuffer(u.buffer).then(function(a) {
              S.data = y.getAvcDecryptedUnit(l, a), y.decrypter.isSync() || y.decryptAvcSamples(D, _, x + 1, g);
            });
          }, I.decryptAvcSamples = function(D, _, x, g) {
            if (D instanceof Uint8Array)
              throw new Error("Cannot decrypt samples of type Uint8Array");
            for (; ; _++, x = 0) {
              if (_ >= D.length) {
                g();
                return;
              }
              for (var S = D[_].units; !(x >= S.length); x++) {
                var y = S[x];
                if (!(y.data.length <= 48 || y.type !== 1 && y.type !== 5) && (this.decryptAvcSample(D, _, x, g, y), !this.decrypter.isSync()))
                  return;
              }
            }
          }, B;
        }();
        const C = k;
      },
      "./src/demux/transmuxer-interface.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => _
        });
        var P = p("./src/demux/webworkify-webpack.js"), T = p("./src/events.ts"), k = p("./src/demux/transmuxer.ts"), C = p("./src/utils/logger.ts"), B = p("./src/errors.ts"), I = p("./src/utils/mediasource-helper.ts"), L = p("./node_modules/eventemitter3/index.js"), D = (0, I.getMediaSource)() || {
          isTypeSupported: function() {
            return !1;
          }
        }, _ = /* @__PURE__ */ function() {
          function x(S, y, l, u) {
            var a = this;
            this.hls = void 0, this.id = void 0, this.observer = void 0, this.frag = null, this.part = null, this.useWorker = void 0, this.worker = void 0, this.onwmsg = void 0, this.transmuxer = null, this.onTransmuxComplete = void 0, this.onFlush = void 0;
            var s = S.config;
            this.hls = S, this.id = y, this.useWorker = !!s.enableWorker, this.onTransmuxComplete = l, this.onFlush = u;
            var m = function(r, o) {
              o = o || {}, o.frag = a.frag, o.id = a.id, a.hls.trigger(r, o);
            };
            this.observer = new L.EventEmitter(), this.observer.on(T.Events.FRAG_DECRYPTED, m), this.observer.on(T.Events.ERROR, m);
            var v = {
              mp4: D.isTypeSupported("video/mp4"),
              mpeg: D.isTypeSupported("audio/mpeg"),
              mp3: D.isTypeSupported('audio/mp4; codecs="mp3"')
            }, i = navigator.vendor;
            if (this.useWorker && typeof Worker < "u") {
              C.logger.log("demuxing in webworker");
              var n;
              try {
                n = this.worker = (0, P.default)("./src/demux/transmuxer-worker.ts"), this.onwmsg = this.onWorkerMessage.bind(this), n.addEventListener("message", this.onwmsg), n.onerror = function(E) {
                  a.useWorker = !1, C.logger.warn("Exception in webworker, fallback to inline"), a.hls.trigger(T.Events.ERROR, {
                    type: B.ErrorTypes.OTHER_ERROR,
                    details: B.ErrorDetails.INTERNAL_EXCEPTION,
                    fatal: !1,
                    event: "demuxerWorker",
                    error: new Error(E.message + "  (" + E.filename + ":" + E.lineno + ")")
                  });
                }, n.postMessage({
                  cmd: "init",
                  typeSupported: v,
                  vendor: i,
                  id: y,
                  config: JSON.stringify(s)
                });
              } catch (E) {
                C.logger.warn("Error in worker:", E), C.logger.error("Error while initializing DemuxerWorker, fallback to inline"), n && self.URL.revokeObjectURL(n.objectURL), this.transmuxer = new k.default(this.observer, v, s, i, y), this.worker = null;
              }
            } else
              this.transmuxer = new k.default(this.observer, v, s, i, y);
          }
          var g = x.prototype;
          return g.destroy = function() {
            var y = this.worker;
            if (y)
              y.removeEventListener("message", this.onwmsg), y.terminate(), this.worker = null, this.onwmsg = void 0;
            else {
              var l = this.transmuxer;
              l && (l.destroy(), this.transmuxer = null);
            }
            var u = this.observer;
            u && u.removeAllListeners(), this.frag = null, this.observer = null, this.hls = null;
          }, g.push = function(y, l, u, a, s, m, v, i, n, E) {
            var r, o, t = this;
            n.transmuxing.start = self.performance.now();
            var d = this.transmuxer, e = this.worker, h = m ? m.start : s.start, f = s.decryptdata, c = this.frag, M = !(c && s.cc === c.cc), w = !(c && n.level === c.level), F = c ? n.sn - c.sn : -1, U = this.part ? n.part - this.part.index : -1, N = F === 0 && n.id > 1 && n.id === (c == null ? void 0 : c.stats.chunkCount), H = !w && (F === 1 || F === 0 && (U === 1 || N && U <= 0)), j = self.performance.now();
            (w || F || s.stats.parsing.start === 0) && (s.stats.parsing.start = j), m && (U || !H) && (m.stats.parsing.start = j);
            var z = !(c && ((r = s.initSegment) === null || r === void 0 ? void 0 : r.url) === ((o = c.initSegment) === null || o === void 0 ? void 0 : o.url)), Y = new k.TransmuxState(M, H, i, w, h, z);
            if (!H || M || z) {
              C.logger.log("[transmuxer-interface, " + s.type + "]: Starting new transmux session for sn: " + n.sn + " p: " + n.part + " level: " + n.level + " id: " + n.id + `
        discontinuity: ` + M + `
        trackSwitch: ` + w + `
        contiguous: ` + H + `
        accurateTimeOffset: ` + i + `
        timeOffset: ` + h + `
        initSegmentChange: ` + z);
              var X = new k.TransmuxConfig(u, a, l, v, E);
              this.configureTransmuxer(X);
            }
            if (this.frag = s, this.part = m, e)
              e.postMessage({
                cmd: "demux",
                data: y,
                decryptdata: f,
                chunkMeta: n,
                state: Y
              }, y instanceof ArrayBuffer ? [y] : []);
            else if (d) {
              var Z = d.push(y, f, n, Y);
              (0, k.isPromise)(Z) ? (d.async = !0, Z.then(function(te) {
                t.handleTransmuxComplete(te);
              }).catch(function(te) {
                t.transmuxerError(te, n, "transmuxer-interface push error");
              })) : (d.async = !1, this.handleTransmuxComplete(Z));
            }
          }, g.flush = function(y) {
            var l = this;
            y.transmuxing.start = self.performance.now();
            var u = this.transmuxer, a = this.worker;
            if (a)
              a.postMessage({
                cmd: "flush",
                chunkMeta: y
              });
            else if (u) {
              var s = u.flush(y), m = (0, k.isPromise)(s);
              m || u.async ? ((0, k.isPromise)(s) || (s = Promise.resolve(s)), s.then(function(v) {
                l.handleFlushResult(v, y);
              }).catch(function(v) {
                l.transmuxerError(v, y, "transmuxer-interface flush error");
              })) : this.handleFlushResult(s, y);
            }
          }, g.transmuxerError = function(y, l, u) {
            !this.hls || this.hls.trigger(T.Events.ERROR, {
              type: B.ErrorTypes.MEDIA_ERROR,
              details: B.ErrorDetails.FRAG_PARSING_ERROR,
              chunkMeta: l,
              fatal: !1,
              error: y,
              err: y,
              reason: u
            });
          }, g.handleFlushResult = function(y, l) {
            var u = this;
            y.forEach(function(a) {
              u.handleTransmuxComplete(a);
            }), this.onFlush(l);
          }, g.onWorkerMessage = function(y) {
            var l = y.data, u = this.hls;
            switch (l.event) {
              case "init": {
                self.URL.revokeObjectURL(this.worker.objectURL);
                break;
              }
              case "transmuxComplete": {
                this.handleTransmuxComplete(l.data);
                break;
              }
              case "flush": {
                this.onFlush(l.data);
                break;
              }
              case "workerLog":
                C.logger[l.data.logType] && C.logger[l.data.logType](l.data.message);
                break;
              default: {
                l.data = l.data || {}, l.data.frag = this.frag, l.data.id = this.id, u.trigger(l.event, l.data);
                break;
              }
            }
          }, g.configureTransmuxer = function(y) {
            var l = this.worker, u = this.transmuxer;
            l ? l.postMessage({
              cmd: "configure",
              config: y
            }) : u && u.configure(y);
          }, g.handleTransmuxComplete = function(y) {
            y.chunkMeta.transmuxing.end = self.performance.now(), this.onTransmuxComplete(y);
          }, x;
        }();
      },
      "./src/demux/transmuxer-worker.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => I
        });
        var P = p("./src/demux/transmuxer.ts"), T = p("./src/events.ts"), k = p("./src/utils/logger.ts"), C = p("./node_modules/eventemitter3/index.js"), B = p("./src/errors.ts");
        function I(g) {
          var S = new C.EventEmitter(), y = function(a, s) {
            g.postMessage({
              event: a,
              data: s
            });
          };
          S.on(T.Events.FRAG_DECRYPTED, y), S.on(T.Events.ERROR, y);
          var l = function() {
            var a = function(v) {
              var i = function(E) {
                y("workerLog", {
                  logType: v,
                  message: E
                });
              };
              k.logger[v] = i;
            };
            for (var s in k.logger)
              a(s);
          };
          g.addEventListener("message", function(u) {
            var a = u.data;
            switch (a.cmd) {
              case "init": {
                var s = JSON.parse(a.config);
                g.transmuxer = new P.default(S, a.typeSupported, s, a.vendor, a.id), (0, k.enableLogs)(s.debug, a.id), l(), y("init", null);
                break;
              }
              case "configure": {
                g.transmuxer.configure(a.config);
                break;
              }
              case "demux": {
                var m = g.transmuxer.push(a.data, a.decryptdata, a.chunkMeta, a.state);
                (0, P.isPromise)(m) ? (g.transmuxer.async = !0, m.then(function(E) {
                  L(g, E);
                }).catch(function(E) {
                  y(T.Events.ERROR, {
                    type: B.ErrorTypes.MEDIA_ERROR,
                    details: B.ErrorDetails.FRAG_PARSING_ERROR,
                    chunkMeta: a.chunkMeta,
                    fatal: !1,
                    error: E,
                    err: E,
                    reason: "transmuxer-worker push error"
                  });
                })) : (g.transmuxer.async = !1, L(g, m));
                break;
              }
              case "flush": {
                var v = a.chunkMeta, i = g.transmuxer.flush(v), n = (0, P.isPromise)(i);
                n || g.transmuxer.async ? ((0, P.isPromise)(i) || (i = Promise.resolve(i)), i.then(function(E) {
                  _(g, E, v);
                }).catch(function(E) {
                  y(T.Events.ERROR, {
                    type: B.ErrorTypes.MEDIA_ERROR,
                    details: B.ErrorDetails.FRAG_PARSING_ERROR,
                    chunkMeta: a.chunkMeta,
                    fatal: !1,
                    error: E,
                    err: E,
                    reason: "transmuxer-worker flush error"
                  });
                })) : _(g, i, v);
                break;
              }
            }
          });
        }
        function L(g, S) {
          if (x(S.remuxResult))
            return !1;
          var y = [], l = S.remuxResult, u = l.audio, a = l.video;
          return u && D(y, u), a && D(y, a), g.postMessage({
            event: "transmuxComplete",
            data: S
          }, y), !0;
        }
        function D(g, S) {
          S.data1 && g.push(S.data1.buffer), S.data2 && g.push(S.data2.buffer);
        }
        function _(g, S, y) {
          var l = S.reduce(function(u, a) {
            return L(g, a) || u;
          }, !1);
          l || g.postMessage({
            event: "transmuxComplete",
            data: S[0]
          }), g.postMessage({
            event: "flush",
            data: y
          });
        }
        function x(g) {
          return !g.audio && !g.video && !g.text && !g.id3 && !g.initSegment;
        }
      },
      "./src/demux/transmuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          TransmuxConfig: () => s,
          TransmuxState: () => m,
          default: () => y,
          isPromise: () => a
        });
        var P = p("./src/events.ts"), T = p("./src/errors.ts"), k = p("./src/crypt/decrypter.ts"), C = p("./src/demux/aacdemuxer.ts"), B = p("./src/demux/mp4demuxer.ts"), I = p("./src/demux/tsdemuxer.ts"), L = p("./src/demux/mp3demuxer.ts"), D = p("./src/remux/mp4-remuxer.ts"), _ = p("./src/remux/passthrough-remuxer.ts"), x = p("./src/utils/logger.ts"), g;
        try {
          g = self.performance.now.bind(self.performance);
        } catch {
          x.logger.debug("Unable to use Performance API on this environment"), g = self.Date.now;
        }
        var S = [{
          demux: B.default,
          remux: _.default
        }, {
          demux: I.default,
          remux: D.default
        }, {
          demux: C.default,
          remux: D.default
        }, {
          demux: L.default,
          remux: D.default
        }], y = /* @__PURE__ */ function() {
          function v(n, E, r, o, t) {
            this.async = !1, this.observer = void 0, this.typeSupported = void 0, this.config = void 0, this.vendor = void 0, this.id = void 0, this.demuxer = void 0, this.remuxer = void 0, this.decrypter = void 0, this.probe = void 0, this.decryptionPromise = null, this.transmuxConfig = void 0, this.currentTransmuxState = void 0, this.observer = n, this.typeSupported = E, this.config = r, this.vendor = o, this.id = t;
          }
          var i = v.prototype;
          return i.configure = function(E) {
            this.transmuxConfig = E, this.decrypter && this.decrypter.reset();
          }, i.push = function(E, r, o, t) {
            var d = this, e = o.transmuxing;
            e.executeStart = g();
            var h = new Uint8Array(E), f = this.currentTransmuxState, c = this.transmuxConfig;
            t && (this.currentTransmuxState = t);
            var M = t || f, w = M.contiguous, F = M.discontinuity, U = M.trackSwitch, N = M.accurateTimeOffset, H = M.timeOffset, j = M.initSegmentChange, z = c.audioCodec, Y = c.videoCodec, X = c.defaultInitPts, Z = c.duration, te = c.initSegmentData, $ = l(h, r);
            if ($ && $.method === "AES-128") {
              var ee = this.getDecrypter();
              if (ee.isSync()) {
                var ne = ee.softwareDecrypt(h, $.key.buffer, $.iv.buffer), oe = o.part > -1;
                if (oe && (ne = ee.flush()), !ne)
                  return e.executeEnd = g(), u(o);
                h = new Uint8Array(ne);
              } else
                return this.decryptionPromise = ee.webCryptoDecrypt(h, $.key.buffer, $.iv.buffer).then(function(me) {
                  var pe = d.push(me, null, o);
                  return d.decryptionPromise = null, pe;
                }), this.decryptionPromise;
            }
            var ae = this.needsProbing(F, U);
            ae && this.configureTransmuxer(h), (F || U || j || ae) && this.resetInitSegment(te, z, Y, Z, r), (F || j || ae) && this.resetInitialTimestamp(X), w || this.resetContiguity();
            var ie = this.transmux(h, $, H, N, o), ce = this.currentTransmuxState;
            return ce.contiguous = !0, ce.discontinuity = !1, ce.trackSwitch = !1, e.executeEnd = g(), ie;
          }, i.flush = function(E) {
            var r = this, o = E.transmuxing;
            o.executeStart = g();
            var t = this.decrypter, d = this.currentTransmuxState, e = this.decryptionPromise;
            if (e)
              return e.then(function() {
                return r.flush(E);
              });
            var h = [], f = d.timeOffset;
            if (t) {
              var c = t.flush();
              c && h.push(this.push(c, null, E));
            }
            var M = this.demuxer, w = this.remuxer;
            if (!M || !w)
              return this.observer.emit(P.Events.ERROR, P.Events.ERROR, {
                type: T.ErrorTypes.MEDIA_ERROR,
                details: T.ErrorDetails.FRAG_PARSING_ERROR,
                fatal: !0,
                reason: "no demux matching with content found"
              }), o.executeEnd = g(), [u(E)];
            var F = M.flush(f);
            return a(F) ? F.then(function(U) {
              return r.flushRemux(h, U, E), h;
            }) : (this.flushRemux(h, F, E), h);
          }, i.flushRemux = function(E, r, o) {
            var t = r.audioTrack, d = r.videoTrack, e = r.id3Track, h = r.textTrack, f = this.currentTransmuxState, c = f.accurateTimeOffset, M = f.timeOffset;
            x.logger.log("[transmuxer.ts]: Flushed fragment " + o.sn + (o.part > -1 ? " p: " + o.part : "") + " of level " + o.level);
            var w = this.remuxer.remux(t, d, e, h, M, c, !0, this.id);
            E.push({
              remuxResult: w,
              chunkMeta: o
            }), o.transmuxing.executeEnd = g();
          }, i.resetInitialTimestamp = function(E) {
            var r = this.demuxer, o = this.remuxer;
            !r || !o || (r.resetTimeStamp(E), o.resetTimeStamp(E));
          }, i.resetContiguity = function() {
            var E = this.demuxer, r = this.remuxer;
            !E || !r || (E.resetContiguity(), r.resetNextTimestamp());
          }, i.resetInitSegment = function(E, r, o, t, d) {
            var e = this.demuxer, h = this.remuxer;
            !e || !h || (e.resetInitSegment(E, r, o, t), h.resetInitSegment(E, r, o, d));
          }, i.destroy = function() {
            this.demuxer && (this.demuxer.destroy(), this.demuxer = void 0), this.remuxer && (this.remuxer.destroy(), this.remuxer = void 0);
          }, i.transmux = function(E, r, o, t, d) {
            var e;
            return r && r.method === "SAMPLE-AES" ? e = this.transmuxSampleAes(E, r, o, t, d) : e = this.transmuxUnencrypted(E, o, t, d), e;
          }, i.transmuxUnencrypted = function(E, r, o, t) {
            var d = this.demuxer.demux(E, r, !1, !this.config.progressive), e = d.audioTrack, h = d.videoTrack, f = d.id3Track, c = d.textTrack, M = this.remuxer.remux(e, h, f, c, r, o, !1, this.id);
            return {
              remuxResult: M,
              chunkMeta: t
            };
          }, i.transmuxSampleAes = function(E, r, o, t, d) {
            var e = this;
            return this.demuxer.demuxSampleAes(E, r, o).then(function(h) {
              var f = e.remuxer.remux(h.audioTrack, h.videoTrack, h.id3Track, h.textTrack, o, t, !1, e.id);
              return {
                remuxResult: f,
                chunkMeta: d
              };
            });
          }, i.configureTransmuxer = function(E) {
            for (var r = this.config, o = this.observer, t = this.typeSupported, d = this.vendor, e, h = 0, f = S.length; h < f; h++)
              if (S[h].demux.probe(E)) {
                e = S[h];
                break;
              }
            e || (x.logger.warn("Failed to find demuxer by probing frag, treating as mp4 passthrough"), e = {
              demux: B.default,
              remux: _.default
            });
            var c = this.demuxer, M = this.remuxer, w = e.remux, F = e.demux;
            (!M || !(M instanceof w)) && (this.remuxer = new w(o, r, t, d)), (!c || !(c instanceof F)) && (this.demuxer = new F(o, r, t), this.probe = F.probe);
          }, i.needsProbing = function(E, r) {
            return !this.demuxer || !this.remuxer || E || r;
          }, i.getDecrypter = function() {
            var E = this.decrypter;
            return E || (E = this.decrypter = new k.default(this.config)), E;
          }, v;
        }();
        function l(v, i) {
          var n = null;
          return v.byteLength > 0 && i != null && i.key != null && i.iv !== null && i.method != null && (n = i), n;
        }
        var u = function(i) {
          return {
            remuxResult: {},
            chunkMeta: i
          };
        };
        function a(v) {
          return "then" in v && v.then instanceof Function;
        }
        var s = function(i, n, E, r, o) {
          this.audioCodec = void 0, this.videoCodec = void 0, this.initSegmentData = void 0, this.duration = void 0, this.defaultInitPts = void 0, this.audioCodec = i, this.videoCodec = n, this.initSegmentData = E, this.duration = r, this.defaultInitPts = o;
        }, m = function(i, n, E, r, o, t) {
          this.discontinuity = void 0, this.contiguous = void 0, this.accurateTimeOffset = void 0, this.trackSwitch = void 0, this.timeOffset = void 0, this.initSegmentChange = void 0, this.discontinuity = i, this.contiguous = n, this.accurateTimeOffset = E, this.trackSwitch = r, this.timeOffset = o, this.initSegmentChange = t;
        };
      },
      "./src/demux/tsdemuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => v
        });
        var P = p("./src/demux/adts.ts"), T = p("./src/demux/mpegaudio.ts"), k = p("./src/demux/exp-golomb.ts"), C = p("./src/demux/sample-aes.ts"), B = p("./src/events.ts"), I = p("./src/utils/mp4-tools.ts"), L = p("./src/utils/logger.ts"), D = p("./src/errors.ts"), _ = p("./src/types/demuxer.ts");
        function x() {
          return x = Object.assign ? Object.assign.bind() : function(i) {
            for (var n = 1; n < arguments.length; n++) {
              var E = arguments[n];
              for (var r in E)
                Object.prototype.hasOwnProperty.call(E, r) && (i[r] = E[r]);
            }
            return i;
          }, x.apply(this, arguments);
        }
        var g = 188, S = /* @__PURE__ */ function() {
          function i(E, r, o) {
            this.observer = void 0, this.config = void 0, this.typeSupported = void 0, this.sampleAes = null, this.pmtParsed = !1, this.audioCodec = void 0, this.videoCodec = void 0, this._duration = 0, this._pmtId = -1, this._avcTrack = void 0, this._audioTrack = void 0, this._id3Track = void 0, this._txtTrack = void 0, this.aacOverFlow = null, this.avcSample = null, this.remainderData = null, this.observer = E, this.config = r, this.typeSupported = o;
          }
          i.probe = function(r) {
            var o = i.syncOffset(r);
            return o > 0 && L.logger.warn("MPEG2-TS detected but first sync word found @ offset " + o), o !== -1;
          }, i.syncOffset = function(r) {
            for (var o = Math.min(g * 5, r.length - g) + 1, t = 0; t < o; ) {
              for (var d = !1, e = 0; e < o && r[e] === 71; e += g)
                if (!d && l(r, e) === 0 && (d = !0), d && e + g > o)
                  return t;
              t++;
            }
            return -1;
          }, i.createTrack = function(r, o) {
            return {
              container: r === "video" || r === "audio" ? "video/mp2t" : void 0,
              type: r,
              id: I.RemuxerTrackIdConfig[r],
              pid: -1,
              inputTimeScale: 9e4,
              sequenceNumber: 0,
              samples: [],
              dropped: 0,
              duration: r === "audio" ? o : void 0
            };
          };
          var n = i.prototype;
          return n.resetInitSegment = function(r, o, t, d) {
            this.pmtParsed = !1, this._pmtId = -1, this._avcTrack = i.createTrack("video"), this._audioTrack = i.createTrack("audio", d), this._id3Track = i.createTrack("id3"), this._txtTrack = i.createTrack("text"), this._audioTrack.segmentCodec = "aac", this.aacOverFlow = null, this.avcSample = null, this.remainderData = null, this.audioCodec = o, this.videoCodec = t, this._duration = d;
          }, n.resetTimeStamp = function() {
          }, n.resetContiguity = function() {
            var r = this._audioTrack, o = this._avcTrack, t = this._id3Track;
            r && (r.pesData = null), o && (o.pesData = null), t && (t.pesData = null), this.aacOverFlow = null, this.avcSample = null, this.remainderData = null;
          }, n.demux = function(r, o, t, d) {
            t === void 0 && (t = !1), d === void 0 && (d = !1), t || (this.sampleAes = null);
            var e, h = this._avcTrack, f = this._audioTrack, c = this._id3Track, M = this._txtTrack, w = h.pid, F = h.pesData, U = f.pid, N = c.pid, H = f.pesData, j = c.pesData, z = null, Y = this.pmtParsed, X = this._pmtId, Z = r.length;
            if (this.remainderData && (r = (0, I.appendUint8Array)(this.remainderData, r), Z = r.length, this.remainderData = null), Z < g && !d)
              return this.remainderData = r, {
                audioTrack: f,
                videoTrack: h,
                id3Track: c,
                textTrack: M
              };
            var te = Math.max(0, i.syncOffset(r));
            Z -= (Z - te) % g, Z < r.byteLength && !d && (this.remainderData = new Uint8Array(r.buffer, Z, r.buffer.byteLength - Z));
            for (var $ = 0, ee = te; ee < Z; ee += g)
              if (r[ee] === 71) {
                var ne = !!(r[ee + 1] & 64), oe = l(r, ee), ae = (r[ee + 3] & 48) >> 4, ie = void 0;
                if (ae > 1) {
                  if (ie = ee + 5 + r[ee + 4], ie === ee + g)
                    continue;
                } else
                  ie = ee + 4;
                switch (oe) {
                  case w:
                    ne && (F && (e = s(F)) && this.parseAVCPES(h, M, e, !1), F = {
                      data: [],
                      size: 0
                    }), F && (F.data.push(r.subarray(ie, ee + g)), F.size += ee + g - ie);
                    break;
                  case U:
                    if (ne) {
                      if (H && (e = s(H)))
                        switch (f.segmentCodec) {
                          case "aac":
                            this.parseAACPES(f, e);
                            break;
                          case "mp3":
                            this.parseMPEGPES(f, e);
                            break;
                        }
                      H = {
                        data: [],
                        size: 0
                      };
                    }
                    H && (H.data.push(r.subarray(ie, ee + g)), H.size += ee + g - ie);
                    break;
                  case N:
                    ne && (j && (e = s(j)) && this.parseID3PES(c, e), j = {
                      data: [],
                      size: 0
                    }), j && (j.data.push(r.subarray(ie, ee + g)), j.size += ee + g - ie);
                    break;
                  case 0:
                    ne && (ie += r[ie] + 1), X = this._pmtId = u(r, ie);
                    break;
                  case X: {
                    ne && (ie += r[ie] + 1);
                    var ce = a(r, ie, this.typeSupported, t);
                    w = ce.avc, w > 0 && (h.pid = w), U = ce.audio, U > 0 && (f.pid = U, f.segmentCodec = ce.segmentCodec), N = ce.id3, N > 0 && (c.pid = N), z !== null && !Y && (L.logger.log("unknown PID '" + z + "' in TS found"), z = null, ee = te - 188), Y = this.pmtParsed = !0;
                    break;
                  }
                  case 17:
                  case 8191:
                    break;
                  default:
                    z = oe;
                    break;
                }
              } else
                $++;
            $ > 0 && this.observer.emit(B.Events.ERROR, B.Events.ERROR, {
              type: D.ErrorTypes.MEDIA_ERROR,
              details: D.ErrorDetails.FRAG_PARSING_ERROR,
              fatal: !1,
              reason: "Found " + $ + " TS packet/s that do not start with 0x47"
            }), h.pesData = F, f.pesData = H, c.pesData = j;
            var me = {
              audioTrack: f,
              videoTrack: h,
              id3Track: c,
              textTrack: M
            };
            return d && this.extractRemainingSamples(me), me;
          }, n.flush = function() {
            var r = this.remainderData;
            this.remainderData = null;
            var o;
            return r ? o = this.demux(r, -1, !1, !0) : o = {
              videoTrack: this._avcTrack,
              audioTrack: this._audioTrack,
              id3Track: this._id3Track,
              textTrack: this._txtTrack
            }, this.extractRemainingSamples(o), this.sampleAes ? this.decrypt(o, this.sampleAes) : o;
          }, n.extractRemainingSamples = function(r) {
            var o = r.audioTrack, t = r.videoTrack, d = r.id3Track, e = r.textTrack, h = t.pesData, f = o.pesData, c = d.pesData, M;
            if (h && (M = s(h)) ? (this.parseAVCPES(t, e, M, !0), t.pesData = null) : t.pesData = h, f && (M = s(f))) {
              switch (o.segmentCodec) {
                case "aac":
                  this.parseAACPES(o, M);
                  break;
                case "mp3":
                  this.parseMPEGPES(o, M);
                  break;
              }
              o.pesData = null;
            } else
              f != null && f.size && L.logger.log("last AAC PES packet truncated,might overlap between fragments"), o.pesData = f;
            c && (M = s(c)) ? (this.parseID3PES(d, M), d.pesData = null) : d.pesData = c;
          }, n.demuxSampleAes = function(r, o, t) {
            var d = this.demux(r, t, !0, !this.config.progressive), e = this.sampleAes = new C.default(this.observer, this.config, o);
            return this.decrypt(d, e);
          }, n.decrypt = function(r, o) {
            return new Promise(function(t) {
              var d = r.audioTrack, e = r.videoTrack;
              d.samples && d.segmentCodec === "aac" ? o.decryptAacSamples(d.samples, 0, function() {
                e.samples ? o.decryptAvcSamples(e.samples, 0, 0, function() {
                  t(r);
                }) : t(r);
              }) : e.samples && o.decryptAvcSamples(e.samples, 0, 0, function() {
                t(r);
              });
            });
          }, n.destroy = function() {
            this._duration = 0;
          }, n.parseAVCPES = function(r, o, t, d) {
            var e = this, h = this.parseAVCNALu(r, t.data), f = this.avcSample, c, M = !1;
            t.data = null, f && h.length && !r.audFound && (m(f, r), f = this.avcSample = y(!1, t.pts, t.dts, "")), h.forEach(function(w) {
              switch (w.type) {
                case 1: {
                  c = !0, f || (f = e.avcSample = y(!0, t.pts, t.dts, "")), f.frame = !0;
                  var F = w.data;
                  if (M && F.length > 4) {
                    var U = new k.default(F).readSliceType();
                    (U === 2 || U === 4 || U === 7 || U === 9) && (f.key = !0);
                  }
                  break;
                }
                case 5:
                  c = !0, f || (f = e.avcSample = y(!0, t.pts, t.dts, "")), f.key = !0, f.frame = !0;
                  break;
                case 6: {
                  c = !0, (0, I.parseSEIMessageFromNALu)(w.data, 1, t.pts, o.samples);
                  break;
                }
                case 7:
                  if (c = !0, M = !0, !r.sps) {
                    var N = new k.default(w.data), H = N.readSPS();
                    r.width = H.width, r.height = H.height, r.pixelRatio = H.pixelRatio, r.sps = [w.data], r.duration = e._duration;
                    for (var j = w.data.subarray(1, 4), z = "avc1.", Y = 0; Y < 3; Y++) {
                      var X = j[Y].toString(16);
                      X.length < 2 && (X = "0" + X), z += X;
                    }
                    r.codec = z;
                  }
                  break;
                case 8:
                  c = !0, r.pps || (r.pps = [w.data]);
                  break;
                case 9:
                  c = !1, r.audFound = !0, f && m(f, r), f = e.avcSample = y(!1, t.pts, t.dts, "");
                  break;
                case 12:
                  c = !0;
                  break;
                default:
                  c = !1, f && (f.debug += "unknown NAL " + w.type + " ");
                  break;
              }
              if (f && c) {
                var Z = f.units;
                Z.push(w);
              }
            }), d && f && (m(f, r), this.avcSample = null);
          }, n.getLastNalUnit = function(r) {
            var o, t = this.avcSample, d;
            if ((!t || t.units.length === 0) && (t = r[r.length - 1]), (o = t) !== null && o !== void 0 && o.units) {
              var e = t.units;
              d = e[e.length - 1];
            }
            return d;
          }, n.parseAVCNALu = function(r, o) {
            var t = o.byteLength, d = r.naluState || 0, e = d, h = [], f = 0, c, M, w, F = -1, U = 0;
            for (d === -1 && (F = 0, U = o[0] & 31, d = 0, f = 1); f < t; ) {
              if (c = o[f++], !d) {
                d = c ? 0 : 1;
                continue;
              }
              if (d === 1) {
                d = c ? 0 : 2;
                continue;
              }
              if (!c)
                d = 3;
              else if (c === 1) {
                if (F >= 0) {
                  var N = {
                    data: o.subarray(F, f - d - 1),
                    type: U
                  };
                  h.push(N);
                } else {
                  var H = this.getLastNalUnit(r.samples);
                  if (H && (e && f <= 4 - e && H.state && (H.data = H.data.subarray(0, H.data.byteLength - e)), M = f - d - 1, M > 0)) {
                    var j = new Uint8Array(H.data.byteLength + M);
                    j.set(H.data, 0), j.set(o.subarray(0, M), H.data.byteLength), H.data = j, H.state = 0;
                  }
                }
                f < t ? (w = o[f] & 31, F = f, U = w, d = 0) : d = -1;
              } else
                d = 0;
            }
            if (F >= 0 && d >= 0) {
              var z = {
                data: o.subarray(F, t),
                type: U,
                state: d
              };
              h.push(z);
            }
            if (h.length === 0) {
              var Y = this.getLastNalUnit(r.samples);
              if (Y) {
                var X = new Uint8Array(Y.data.byteLength + o.byteLength);
                X.set(Y.data, 0), X.set(o, Y.data.byteLength), Y.data = X;
              }
            }
            return r.naluState = d, h;
          }, n.parseAACPES = function(r, o) {
            var t = 0, d = this.aacOverFlow, e = o.data;
            if (d) {
              this.aacOverFlow = null;
              var h = d.missing, f = d.sample.unit.byteLength;
              if (h === -1) {
                var c = new Uint8Array(f + e.byteLength);
                c.set(d.sample.unit, 0), c.set(e, f), e = c;
              } else {
                var M = f - h;
                d.sample.unit.set(e.subarray(0, h), M), r.samples.push(d.sample), t = d.missing;
              }
            }
            var w, F;
            for (w = t, F = e.length; w < F - 1 && !P.isHeader(e, w); w++)
              ;
            if (w !== t) {
              var U, N;
              if (w < F - 1 ? (U = "AAC PES did not start with ADTS header,offset:" + w, N = !1) : (U = "no ADTS header found in AAC PES", N = !0), L.logger.warn("parsing error:" + U), this.observer.emit(B.Events.ERROR, B.Events.ERROR, {
                type: D.ErrorTypes.MEDIA_ERROR,
                details: D.ErrorDetails.FRAG_PARSING_ERROR,
                fatal: N,
                reason: U
              }), N)
                return;
            }
            P.initTrackConfig(r, this.observer, e, w, this.audioCodec);
            var H;
            if (o.pts !== void 0)
              H = o.pts;
            else if (d) {
              var j = P.getFrameDuration(r.samplerate);
              H = d.sample.pts + j;
            } else {
              L.logger.warn("[tsdemuxer]: AAC PES unknown PTS");
              return;
            }
            for (var z = 0, Y; w < F; )
              if (Y = P.appendFrame(r, e, w, H, z), w += Y.length, Y.missing) {
                this.aacOverFlow = Y;
                break;
              } else
                for (z++; w < F - 1 && !P.isHeader(e, w); w++)
                  ;
          }, n.parseMPEGPES = function(r, o) {
            var t = o.data, d = t.length, e = 0, h = 0, f = o.pts;
            if (f === void 0) {
              L.logger.warn("[tsdemuxer]: MPEG PES unknown PTS");
              return;
            }
            for (; h < d; )
              if (T.isHeader(t, h)) {
                var c = T.appendFrame(r, t, h, f, e);
                if (c)
                  h += c.length, e++;
                else
                  break;
              } else
                h++;
          }, n.parseID3PES = function(r, o) {
            if (o.pts === void 0) {
              L.logger.warn("[tsdemuxer]: ID3 PES unknown PTS");
              return;
            }
            var t = x({}, o, {
              type: this._avcTrack ? _.MetadataSchema.emsg : _.MetadataSchema.audioId3,
              duration: Number.POSITIVE_INFINITY
            });
            r.samples.push(t);
          }, i;
        }();
        function y(i, n, E, r) {
          return {
            key: i,
            frame: !1,
            pts: n,
            dts: E,
            units: [],
            debug: r,
            length: 0
          };
        }
        function l(i, n) {
          return ((i[n + 1] & 31) << 8) + i[n + 2];
        }
        function u(i, n) {
          return (i[n + 10] & 31) << 8 | i[n + 11];
        }
        function a(i, n, E, r) {
          var o = {
            audio: -1,
            avc: -1,
            id3: -1,
            segmentCodec: "aac"
          }, t = (i[n + 1] & 15) << 8 | i[n + 2], d = n + 3 + t - 4, e = (i[n + 10] & 15) << 8 | i[n + 11];
          for (n += 12 + e; n < d; ) {
            var h = l(i, n);
            switch (i[n]) {
              case 207:
                if (!r) {
                  L.logger.log("ADTS AAC with AES-128-CBC frame encryption found in unencrypted stream");
                  break;
                }
              case 15:
                o.audio === -1 && (o.audio = h);
                break;
              case 21:
                o.id3 === -1 && (o.id3 = h);
                break;
              case 219:
                if (!r) {
                  L.logger.log("H.264 with AES-128-CBC slice encryption found in unencrypted stream");
                  break;
                }
              case 27:
                o.avc === -1 && (o.avc = h);
                break;
              case 3:
              case 4:
                E.mpeg !== !0 && E.mp3 !== !0 ? L.logger.log("MPEG audio found, not supported in this browser") : o.audio === -1 && (o.audio = h, o.segmentCodec = "mp3");
                break;
              case 36:
                L.logger.warn("Unsupported HEVC stream type found");
                break;
            }
            n += ((i[n + 3] & 15) << 8 | i[n + 4]) + 5;
          }
          return o;
        }
        function s(i) {
          var n = 0, E, r, o, t, d, e = i.data;
          if (!i || i.size === 0)
            return null;
          for (; e[0].length < 19 && e.length > 1; ) {
            var h = new Uint8Array(e[0].length + e[1].length);
            h.set(e[0]), h.set(e[1], e[0].length), e[0] = h, e.splice(1, 1);
          }
          E = e[0];
          var f = (E[0] << 16) + (E[1] << 8) + E[2];
          if (f === 1) {
            if (r = (E[4] << 8) + E[5], r && r > i.size - 6)
              return null;
            var c = E[7];
            c & 192 && (t = (E[9] & 14) * 536870912 + (E[10] & 255) * 4194304 + (E[11] & 254) * 16384 + (E[12] & 255) * 128 + (E[13] & 254) / 2, c & 64 ? (d = (E[14] & 14) * 536870912 + (E[15] & 255) * 4194304 + (E[16] & 254) * 16384 + (E[17] & 255) * 128 + (E[18] & 254) / 2, t - d > 54e5 && (L.logger.warn(Math.round((t - d) / 9e4) + "s delta between PTS and DTS, align them"), t = d)) : d = t), o = E[8];
            var M = o + 9;
            if (i.size <= M)
              return null;
            i.size -= M;
            for (var w = new Uint8Array(i.size), F = 0, U = e.length; F < U; F++) {
              E = e[F];
              var N = E.byteLength;
              if (M)
                if (M > N) {
                  M -= N;
                  continue;
                } else
                  E = E.subarray(M), N -= M, M = 0;
              w.set(E, n), n += N;
            }
            return r && (r -= o + 3), {
              data: w,
              pts: t,
              dts: d,
              len: r
            };
          }
          return null;
        }
        function m(i, n) {
          if (i.units.length && i.frame) {
            if (i.pts === void 0) {
              var E = n.samples, r = E.length;
              if (r) {
                var o = E[r - 1];
                i.pts = o.pts, i.dts = o.dts;
              } else {
                n.dropped++;
                return;
              }
            }
            n.samples.push(i);
          }
          i.debug.length && L.logger.log(i.pts + "/" + i.dts + ":" + i.debug);
        }
        const v = S;
      },
      "./src/demux/webworkify-webpack.js": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => g
        });
        var P = function() {
          var y = ENTRY_MODULE, l = {}, u = function s(m) {
            var v = l[m];
            if (v !== void 0)
              return v.exports;
            var i = l[m] = {
              exports: {}
            };
            return y[m].call(i.exports, i, i.exports, s), i.exports;
          };
          u.m = y, function() {
            u.n = function(s) {
              var m = s && s.__esModule ? function() {
                return s.default;
              } : function() {
                return s;
              };
              return u.d(m, {
                a: m
              }), m;
            };
          }(), function() {
            u.d = function(s, m) {
              for (var v in m)
                u.o(m, v) && !u.o(s, v) && Object.defineProperty(s, v, {
                  enumerable: !0,
                  get: m[v]
                });
            };
          }(), function() {
            u.o = function(s, m) {
              return Object.prototype.hasOwnProperty.call(s, m);
            };
          }(), function() {
            u.r = function(s) {
              typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(s, Symbol.toStringTag, {
                value: "Module"
              }), Object.defineProperty(s, "__esModule", {
                value: !0
              });
            };
          }();
          var a = u(ENTRY_MODULE);
          return a.default || a;
        }, T = P.toString().split("ENTRY_MODULE"), k = "[\\.|\\-|\\+|\\w|/|@]+", C = "\\(\\s*(/\\*.*?\\*/)?\\s*.*?(" + k + ").*?\\)";
        function B(S) {
          return (S + "").replace(/[.?*+^$[\]\\(){}|-]/g, "\\$&");
        }
        function I(S) {
          return !isNaN(1 * S);
        }
        function L(S, y, l) {
          var u = {};
          u[l] = [];
          var a = y.toString().replace(/^"[^"]+"/, "function"), s = a.match(/^function\s?\w*\(\w+,\s*\w+,\s*(\w+)\)/) || a.match(/^\(\w+,\s*\w+,\s*(\w+)\)\s?\=\s?\>/);
          if (!s)
            return u;
          for (var m = s[1], v = new RegExp("(\\\\n|\\W)" + B(m) + C, "g"), i; i = v.exec(a); )
            i[3] !== "dll-reference" && u[l].push(i[3]);
          for (v = new RegExp("\\(" + B(m) + '\\("(dll-reference\\s(' + k + '))"\\)\\)' + C, "g"); i = v.exec(a); )
            S[i[2]] || (u[l].push(i[1]), S[i[2]] = p(i[1]).m), u[i[2]] = u[i[2]] || [], u[i[2]].push(i[4]);
          for (var n = Object.keys(u), E = 0; E < n.length; E++)
            for (var r = 0; r < u[n[E]].length; r++)
              I(u[n[E]][r]) && (u[n[E]][r] = 1 * u[n[E]][r]);
          return u;
        }
        function D(S) {
          var y = Object.keys(S);
          return y.reduce(function(l, u) {
            return l || S[u].length > 0;
          }, !1);
        }
        function _(S, y) {
          for (var l = {
            main: [y]
          }, u = {
            main: []
          }, a = {
            main: {}
          }; D(l); )
            for (var s = Object.keys(l), m = 0; m < s.length; m++) {
              var v = s[m], i = l[v], n = i.pop();
              if (a[v] = a[v] || {}, !(a[v][n] || !S[v][n])) {
                a[v][n] = !0, u[v] = u[v] || [], u[v].push(n);
                for (var E = L(S, S[v][n], v), r = Object.keys(E), o = 0; o < r.length; o++)
                  l[r[o]] = l[r[o]] || [], l[r[o]] = l[r[o]].concat(E[r[o]]);
              }
            }
          return u;
        }
        function x(S, y, l, u) {
          var a = S[u].map(function(s) {
            return '"' + s + '": ' + y[u][s].toString().replace(/^"[^"]+"/, "function");
          }).join(",");
          return T[0] + "{" + a + "}" + T[1] + '"' + l + '"' + T[2];
        }
        function g(S, y) {
          y = y || {};
          var l = {
            main: p.m
          }, u = y.all ? {
            main: Object.keys(l.main)
          } : _(l, S), a = "";
          Object.keys(u).filter(function(n) {
            return n !== "main";
          }).forEach(function(n) {
            for (var E = 0; u[n][E]; )
              E++;
            u[n].push(E), l[n][E] = "(function(module, exports, __webpack_require__) { module.exports = __webpack_require__; })", a = a + ("var " + n + " = (" + x(u, l, E, modules) + `)();
`);
          }), a = a + ("new ((" + x(u, l, S, "main") + ")())(self);");
          var s = new window.Blob([a], {
            type: "text/javascript"
          }), m = window.URL || window.webkitURL || window.mozURL || window.msURL, v = m.createObjectURL(s), i = new window.Worker(v);
          return i.objectURL = v, i;
        }
      },
      "./src/errors.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          ErrorDetails: () => T,
          ErrorTypes: () => P
        });
        var P;
        (function(k) {
          k.NETWORK_ERROR = "networkError", k.MEDIA_ERROR = "mediaError", k.KEY_SYSTEM_ERROR = "keySystemError", k.MUX_ERROR = "muxError", k.OTHER_ERROR = "otherError";
        })(P || (P = {}));
        var T;
        (function(k) {
          k.KEY_SYSTEM_NO_KEYS = "keySystemNoKeys", k.KEY_SYSTEM_NO_ACCESS = "keySystemNoAccess", k.KEY_SYSTEM_NO_SESSION = "keySystemNoSession", k.KEY_SYSTEM_NO_CONFIGURED_LICENSE = "keySystemNoConfiguredLicense", k.KEY_SYSTEM_LICENSE_REQUEST_FAILED = "keySystemLicenseRequestFailed", k.KEY_SYSTEM_SERVER_CERTIFICATE_REQUEST_FAILED = "keySystemServerCertificateRequestFailed", k.KEY_SYSTEM_SERVER_CERTIFICATE_UPDATE_FAILED = "keySystemServerCertificateUpdateFailed", k.KEY_SYSTEM_SESSION_UPDATE_FAILED = "keySystemSessionUpdateFailed", k.KEY_SYSTEM_STATUS_OUTPUT_RESTRICTED = "keySystemStatusOutputRestricted", k.KEY_SYSTEM_STATUS_INTERNAL_ERROR = "keySystemStatusInternalError", k.MANIFEST_LOAD_ERROR = "manifestLoadError", k.MANIFEST_LOAD_TIMEOUT = "manifestLoadTimeOut", k.MANIFEST_PARSING_ERROR = "manifestParsingError", k.MANIFEST_INCOMPATIBLE_CODECS_ERROR = "manifestIncompatibleCodecsError", k.LEVEL_EMPTY_ERROR = "levelEmptyError", k.LEVEL_LOAD_ERROR = "levelLoadError", k.LEVEL_LOAD_TIMEOUT = "levelLoadTimeOut", k.LEVEL_SWITCH_ERROR = "levelSwitchError", k.AUDIO_TRACK_LOAD_ERROR = "audioTrackLoadError", k.AUDIO_TRACK_LOAD_TIMEOUT = "audioTrackLoadTimeOut", k.SUBTITLE_LOAD_ERROR = "subtitleTrackLoadError", k.SUBTITLE_TRACK_LOAD_TIMEOUT = "subtitleTrackLoadTimeOut", k.FRAG_LOAD_ERROR = "fragLoadError", k.FRAG_LOAD_TIMEOUT = "fragLoadTimeOut", k.FRAG_DECRYPT_ERROR = "fragDecryptError", k.FRAG_PARSING_ERROR = "fragParsingError", k.REMUX_ALLOC_ERROR = "remuxAllocError", k.KEY_LOAD_ERROR = "keyLoadError", k.KEY_LOAD_TIMEOUT = "keyLoadTimeOut", k.BUFFER_ADD_CODEC_ERROR = "bufferAddCodecError", k.BUFFER_INCOMPATIBLE_CODECS_ERROR = "bufferIncompatibleCodecsError", k.BUFFER_APPEND_ERROR = "bufferAppendError", k.BUFFER_APPENDING_ERROR = "bufferAppendingError", k.BUFFER_STALLED_ERROR = "bufferStalledError", k.BUFFER_FULL_ERROR = "bufferFullError", k.BUFFER_SEEK_OVER_HOLE = "bufferSeekOverHole", k.BUFFER_NUDGE_ON_STALL = "bufferNudgeOnStall", k.INTERNAL_EXCEPTION = "internalException", k.INTERNAL_ABORTED = "aborted", k.UNKNOWN = "unknown";
        })(T || (T = {}));
      },
      "./src/events.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          Events: () => P
        });
        var P;
        (function(T) {
          T.MEDIA_ATTACHING = "hlsMediaAttaching", T.MEDIA_ATTACHED = "hlsMediaAttached", T.MEDIA_DETACHING = "hlsMediaDetaching", T.MEDIA_DETACHED = "hlsMediaDetached", T.BUFFER_RESET = "hlsBufferReset", T.BUFFER_CODECS = "hlsBufferCodecs", T.BUFFER_CREATED = "hlsBufferCreated", T.BUFFER_APPENDING = "hlsBufferAppending", T.BUFFER_APPENDED = "hlsBufferAppended", T.BUFFER_EOS = "hlsBufferEos", T.BUFFER_FLUSHING = "hlsBufferFlushing", T.BUFFER_FLUSHED = "hlsBufferFlushed", T.MANIFEST_LOADING = "hlsManifestLoading", T.MANIFEST_LOADED = "hlsManifestLoaded", T.MANIFEST_PARSED = "hlsManifestParsed", T.LEVEL_SWITCHING = "hlsLevelSwitching", T.LEVEL_SWITCHED = "hlsLevelSwitched", T.LEVEL_LOADING = "hlsLevelLoading", T.LEVEL_LOADED = "hlsLevelLoaded", T.LEVEL_UPDATED = "hlsLevelUpdated", T.LEVEL_PTS_UPDATED = "hlsLevelPtsUpdated", T.LEVELS_UPDATED = "hlsLevelsUpdated", T.AUDIO_TRACKS_UPDATED = "hlsAudioTracksUpdated", T.AUDIO_TRACK_SWITCHING = "hlsAudioTrackSwitching", T.AUDIO_TRACK_SWITCHED = "hlsAudioTrackSwitched", T.AUDIO_TRACK_LOADING = "hlsAudioTrackLoading", T.AUDIO_TRACK_LOADED = "hlsAudioTrackLoaded", T.SUBTITLE_TRACKS_UPDATED = "hlsSubtitleTracksUpdated", T.SUBTITLE_TRACKS_CLEARED = "hlsSubtitleTracksCleared", T.SUBTITLE_TRACK_SWITCH = "hlsSubtitleTrackSwitch", T.SUBTITLE_TRACK_LOADING = "hlsSubtitleTrackLoading", T.SUBTITLE_TRACK_LOADED = "hlsSubtitleTrackLoaded", T.SUBTITLE_FRAG_PROCESSED = "hlsSubtitleFragProcessed", T.CUES_PARSED = "hlsCuesParsed", T.NON_NATIVE_TEXT_TRACKS_FOUND = "hlsNonNativeTextTracksFound", T.INIT_PTS_FOUND = "hlsInitPtsFound", T.FRAG_LOADING = "hlsFragLoading", T.FRAG_LOAD_EMERGENCY_ABORTED = "hlsFragLoadEmergencyAborted", T.FRAG_LOADED = "hlsFragLoaded", T.FRAG_DECRYPTED = "hlsFragDecrypted", T.FRAG_PARSING_INIT_SEGMENT = "hlsFragParsingInitSegment", T.FRAG_PARSING_USERDATA = "hlsFragParsingUserdata", T.FRAG_PARSING_METADATA = "hlsFragParsingMetadata", T.FRAG_PARSED = "hlsFragParsed", T.FRAG_BUFFERED = "hlsFragBuffered", T.FRAG_CHANGED = "hlsFragChanged", T.FPS_DROP = "hlsFpsDrop", T.FPS_DROP_LEVEL_CAPPING = "hlsFpsDropLevelCapping", T.ERROR = "hlsError", T.DESTROYING = "hlsDestroying", T.KEY_LOADING = "hlsKeyLoading", T.KEY_LOADED = "hlsKeyLoaded", T.LIVE_BACK_BUFFER_REACHED = "hlsLiveBackBufferReached", T.BACK_BUFFER_REACHED = "hlsBackBufferReached";
        })(P || (P = {}));
      },
      "./src/hls.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => i
        });
        var P = p("./node_modules/url-toolkit/src/url-toolkit.js"), T = p("./src/loader/playlist-loader.ts"), k = p("./src/controller/id3-track-controller.ts"), C = p("./src/controller/latency-controller.ts"), B = p("./src/controller/level-controller.ts"), I = p("./src/controller/fragment-tracker.ts"), L = p("./src/loader/key-loader.ts"), D = p("./src/controller/stream-controller.ts"), _ = p("./src/is-supported.ts"), x = p("./src/utils/logger.ts"), g = p("./src/config.ts"), S = p("./node_modules/eventemitter3/index.js"), y = p("./src/events.ts"), l = p("./src/errors.ts"), u = p("./src/types/level.ts");
        function a(n, E) {
          for (var r = 0; r < E.length; r++) {
            var o = E[r];
            o.enumerable = o.enumerable || !1, o.configurable = !0, "value" in o && (o.writable = !0), Object.defineProperty(n, m(o.key), o);
          }
        }
        function s(n, E, r) {
          return E && a(n.prototype, E), r && a(n, r), Object.defineProperty(n, "prototype", { writable: !1 }), n;
        }
        function m(n) {
          var E = v(n, "string");
          return typeof E == "symbol" ? E : String(E);
        }
        function v(n, E) {
          if (typeof n != "object" || n === null)
            return n;
          var r = n[Symbol.toPrimitive];
          if (r !== void 0) {
            var o = r.call(n, E || "default");
            if (typeof o != "object")
              return o;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (E === "string" ? String : Number)(n);
        }
        var i = /* @__PURE__ */ function() {
          n.isSupported = function() {
            return (0, _.isSupported)();
          };
          function n(r) {
            r === void 0 && (r = {}), this.config = void 0, this.userConfig = void 0, this.coreComponents = void 0, this.networkControllers = void 0, this._emitter = new S.EventEmitter(), this._autoLevelCapping = void 0, this._maxHdcpLevel = null, this.abrController = void 0, this.bufferController = void 0, this.capLevelController = void 0, this.latencyController = void 0, this.levelController = void 0, this.streamController = void 0, this.audioTrackController = void 0, this.subtitleTrackController = void 0, this.emeController = void 0, this.cmcdController = void 0, this._media = null, this.url = null;
            var o = this.config = (0, g.mergeConfig)(n.DefaultConfig, r);
            this.userConfig = r, (0, x.enableLogs)(o.debug, "Hls instance"), this._autoLevelCapping = -1, o.progressive && (0, g.enableStreamingMode)(o);
            var t = o.abrController, d = o.bufferController, e = o.capLevelController, h = o.fpsController, f = this.abrController = new t(this), c = this.bufferController = new d(this), M = this.capLevelController = new e(this), w = new h(this), F = new T.default(this), U = new k.default(this), N = this.levelController = new B.default(this), H = new I.FragmentTracker(this), j = new L.default(this.config), z = this.streamController = new D.default(this, H, j);
            M.setStreamController(z), w.setStreamController(z);
            var Y = [F, N, z];
            this.networkControllers = Y;
            var X = [f, c, M, w, U, H];
            this.audioTrackController = this.createController(o.audioTrackController, Y);
            var Z = o.audioStreamController;
            Z && Y.push(new Z(this, H, j)), this.subtitleTrackController = this.createController(o.subtitleTrackController, Y);
            var te = o.subtitleStreamController;
            te && Y.push(new te(this, H, j)), this.createController(o.timelineController, X), j.emeController = this.emeController = this.createController(o.emeController, X), this.cmcdController = this.createController(o.cmcdController, X), this.latencyController = this.createController(C.default, X), this.coreComponents = X;
          }
          var E = n.prototype;
          return E.createController = function(o, t) {
            if (o) {
              var d = new o(this);
              return t && t.push(d), d;
            }
            return null;
          }, E.on = function(o, t, d) {
            d === void 0 && (d = this), this._emitter.on(o, t, d);
          }, E.once = function(o, t, d) {
            d === void 0 && (d = this), this._emitter.once(o, t, d);
          }, E.removeAllListeners = function(o) {
            this._emitter.removeAllListeners(o);
          }, E.off = function(o, t, d, e) {
            d === void 0 && (d = this), this._emitter.off(o, t, d, e);
          }, E.listeners = function(o) {
            return this._emitter.listeners(o);
          }, E.emit = function(o, t, d) {
            return this._emitter.emit(o, t, d);
          }, E.trigger = function(o, t) {
            if (this.config.debug)
              return this.emit(o, o, t);
            try {
              return this.emit(o, o, t);
            } catch (d) {
              x.logger.error("An internal error happened while handling event " + o + '. Error message: "' + d.message + '". Here is a stacktrace:', d), this.trigger(y.Events.ERROR, {
                type: l.ErrorTypes.OTHER_ERROR,
                details: l.ErrorDetails.INTERNAL_EXCEPTION,
                fatal: !1,
                event: o,
                error: d
              });
            }
            return !1;
          }, E.listenerCount = function(o) {
            return this._emitter.listenerCount(o);
          }, E.destroy = function() {
            x.logger.log("destroy"), this.trigger(y.Events.DESTROYING, void 0), this.detachMedia(), this.removeAllListeners(), this._autoLevelCapping = -1, this.url = null, this.networkControllers.forEach(function(o) {
              return o.destroy();
            }), this.networkControllers.length = 0, this.coreComponents.forEach(function(o) {
              return o.destroy();
            }), this.coreComponents.length = 0;
          }, E.attachMedia = function(o) {
            x.logger.log("attachMedia"), this._media = o, this.trigger(y.Events.MEDIA_ATTACHING, {
              media: o
            });
          }, E.detachMedia = function() {
            x.logger.log("detachMedia"), this.trigger(y.Events.MEDIA_DETACHING, void 0), this._media = null;
          }, E.loadSource = function(o) {
            this.stopLoad();
            var t = this.media, d = this.url, e = this.url = P.buildAbsoluteURL(self.location.href, o, {
              alwaysNormalize: !0
            });
            x.logger.log("loadSource:" + e), t && d && d !== e && this.bufferController.hasSourceTypes() && (this.detachMedia(), this.attachMedia(t)), this.trigger(y.Events.MANIFEST_LOADING, {
              url: o
            });
          }, E.startLoad = function(o) {
            o === void 0 && (o = -1), x.logger.log("startLoad(" + o + ")"), this.networkControllers.forEach(function(t) {
              t.startLoad(o);
            });
          }, E.stopLoad = function() {
            x.logger.log("stopLoad"), this.networkControllers.forEach(function(o) {
              o.stopLoad();
            });
          }, E.swapAudioCodec = function() {
            x.logger.log("swapAudioCodec"), this.streamController.swapAudioCodec();
          }, E.recoverMediaError = function() {
            x.logger.log("recoverMediaError");
            var o = this._media;
            this.detachMedia(), o && this.attachMedia(o);
          }, E.removeLevel = function(o, t) {
            t === void 0 && (t = 0), this.levelController.removeLevel(o, t);
          }, s(n, [{
            key: "levels",
            get: function() {
              var o = this.levelController.levels;
              return o || [];
            }
          }, {
            key: "currentLevel",
            get: function() {
              return this.streamController.currentLevel;
            },
            set: function(o) {
              x.logger.log("set currentLevel:" + o), this.loadLevel = o, this.abrController.clearTimer(), this.streamController.immediateLevelSwitch();
            }
          }, {
            key: "nextLevel",
            get: function() {
              return this.streamController.nextLevel;
            },
            set: function(o) {
              x.logger.log("set nextLevel:" + o), this.levelController.manualLevel = o, this.streamController.nextLevelSwitch();
            }
          }, {
            key: "loadLevel",
            get: function() {
              return this.levelController.level;
            },
            set: function(o) {
              x.logger.log("set loadLevel:" + o), this.levelController.manualLevel = o;
            }
          }, {
            key: "nextLoadLevel",
            get: function() {
              return this.levelController.nextLoadLevel;
            },
            set: function(o) {
              this.levelController.nextLoadLevel = o;
            }
          }, {
            key: "firstLevel",
            get: function() {
              return Math.max(this.levelController.firstLevel, this.minAutoLevel);
            },
            set: function(o) {
              x.logger.log("set firstLevel:" + o), this.levelController.firstLevel = o;
            }
          }, {
            key: "startLevel",
            get: function() {
              return this.levelController.startLevel;
            },
            set: function(o) {
              x.logger.log("set startLevel:" + o), o !== -1 && (o = Math.max(o, this.minAutoLevel)), this.levelController.startLevel = o;
            }
          }, {
            key: "capLevelToPlayerSize",
            get: function() {
              return this.config.capLevelToPlayerSize;
            },
            set: function(o) {
              var t = !!o;
              t !== this.config.capLevelToPlayerSize && (t ? this.capLevelController.startCapping() : (this.capLevelController.stopCapping(), this.autoLevelCapping = -1, this.streamController.nextLevelSwitch()), this.config.capLevelToPlayerSize = t);
            }
          }, {
            key: "autoLevelCapping",
            get: function() {
              return this._autoLevelCapping;
            },
            set: function(o) {
              this._autoLevelCapping !== o && (x.logger.log("set autoLevelCapping:" + o), this._autoLevelCapping = o);
            }
          }, {
            key: "bandwidthEstimate",
            get: function() {
              var o = this.abrController.bwEstimator;
              return o ? o.getEstimate() : NaN;
            }
          }, {
            key: "maxHdcpLevel",
            get: function() {
              return this._maxHdcpLevel;
            },
            set: function(o) {
              u.HdcpLevels.indexOf(o) > -1 && (this._maxHdcpLevel = o);
            }
          }, {
            key: "autoLevelEnabled",
            get: function() {
              return this.levelController.manualLevel === -1;
            }
          }, {
            key: "manualLevel",
            get: function() {
              return this.levelController.manualLevel;
            }
          }, {
            key: "minAutoLevel",
            get: function() {
              var o = this.levels, t = this.config.minAutoBitrate;
              if (!o)
                return 0;
              for (var d = o.length, e = 0; e < d; e++)
                if (o[e].maxBitrate >= t)
                  return e;
              return 0;
            }
          }, {
            key: "maxAutoLevel",
            get: function() {
              var o = this.levels, t = this.autoLevelCapping, d = this.maxHdcpLevel, e;
              if (t === -1 && o && o.length ? e = o.length - 1 : e = t, d)
                for (var h = e; h--; ) {
                  var f = o[h].attrs["HDCP-LEVEL"];
                  if (f && f <= d)
                    return h;
                }
              return e;
            }
          }, {
            key: "nextAutoLevel",
            get: function() {
              return Math.min(Math.max(this.abrController.nextAutoLevel, this.minAutoLevel), this.maxAutoLevel);
            },
            set: function(o) {
              this.abrController.nextAutoLevel = Math.max(this.minAutoLevel, o);
            }
          }, {
            key: "playingDate",
            get: function() {
              return this.streamController.currentProgramDateTime;
            }
          }, {
            key: "mainForwardBufferInfo",
            get: function() {
              return this.streamController.getMainFwdBufferInfo();
            }
          }, {
            key: "audioTracks",
            get: function() {
              var o = this.audioTrackController;
              return o ? o.audioTracks : [];
            }
          }, {
            key: "audioTrack",
            get: function() {
              var o = this.audioTrackController;
              return o ? o.audioTrack : -1;
            },
            set: function(o) {
              var t = this.audioTrackController;
              t && (t.audioTrack = o);
            }
          }, {
            key: "subtitleTracks",
            get: function() {
              var o = this.subtitleTrackController;
              return o ? o.subtitleTracks : [];
            }
          }, {
            key: "subtitleTrack",
            get: function() {
              var o = this.subtitleTrackController;
              return o ? o.subtitleTrack : -1;
            },
            set: function(o) {
              var t = this.subtitleTrackController;
              t && (t.subtitleTrack = o);
            }
          }, {
            key: "media",
            get: function() {
              return this._media;
            }
          }, {
            key: "subtitleDisplay",
            get: function() {
              var o = this.subtitleTrackController;
              return o ? o.subtitleDisplay : !1;
            },
            set: function(o) {
              var t = this.subtitleTrackController;
              t && (t.subtitleDisplay = o);
            }
          }, {
            key: "lowLatencyMode",
            get: function() {
              return this.config.lowLatencyMode;
            },
            set: function(o) {
              this.config.lowLatencyMode = o;
            }
          }, {
            key: "liveSyncPosition",
            get: function() {
              return this.latencyController.liveSyncPosition;
            }
          }, {
            key: "latency",
            get: function() {
              return this.latencyController.latency;
            }
          }, {
            key: "maxLatency",
            get: function() {
              return this.latencyController.maxLatency;
            }
          }, {
            key: "targetLatency",
            get: function() {
              return this.latencyController.targetLatency;
            }
          }, {
            key: "drift",
            get: function() {
              return this.latencyController.drift;
            }
          }, {
            key: "forceStartLoad",
            get: function() {
              return this.streamController.forceStartLoad;
            }
          }], [{
            key: "version",
            get: function() {
              return "1.3.3";
            }
          }, {
            key: "Events",
            get: function() {
              return y.Events;
            }
          }, {
            key: "ErrorTypes",
            get: function() {
              return l.ErrorTypes;
            }
          }, {
            key: "ErrorDetails",
            get: function() {
              return l.ErrorDetails;
            }
          }, {
            key: "DefaultConfig",
            get: function() {
              return n.defaultConfig ? n.defaultConfig : g.hlsDefaultConfig;
            },
            set: function(o) {
              n.defaultConfig = o;
            }
          }]), n;
        }();
        i.defaultConfig = void 0;
      },
      "./src/is-supported.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          changeTypeSupported: () => C,
          isSupported: () => k
        });
        var P = p("./src/utils/mediasource-helper.ts");
        function T() {
          return self.SourceBuffer || self.WebKitSourceBuffer;
        }
        function k() {
          var B = (0, P.getMediaSource)();
          if (!B)
            return !1;
          var I = T(), L = B && typeof B.isTypeSupported == "function" && B.isTypeSupported('video/mp4; codecs="avc1.42E01E,mp4a.40.2"'), D = !I || I.prototype && typeof I.prototype.appendBuffer == "function" && typeof I.prototype.remove == "function";
          return !!L && !!D;
        }
        function C() {
          var B, I = T();
          return typeof (I == null || (B = I.prototype) === null || B === void 0 ? void 0 : B.changeType) == "function";
        }
      },
      "./src/loader/date-range.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          DateRange: () => x,
          DateRangeAttribute: () => _
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/utils/attr-list.ts"), k = p("./src/utils/logger.ts");
        function C() {
          return C = Object.assign ? Object.assign.bind() : function(g) {
            for (var S = 1; S < arguments.length; S++) {
              var y = arguments[S];
              for (var l in y)
                Object.prototype.hasOwnProperty.call(y, l) && (g[l] = y[l]);
            }
            return g;
          }, C.apply(this, arguments);
        }
        function B(g, S) {
          for (var y = 0; y < S.length; y++) {
            var l = S[y];
            l.enumerable = l.enumerable || !1, l.configurable = !0, "value" in l && (l.writable = !0), Object.defineProperty(g, L(l.key), l);
          }
        }
        function I(g, S, y) {
          return S && B(g.prototype, S), y && B(g, y), Object.defineProperty(g, "prototype", { writable: !1 }), g;
        }
        function L(g) {
          var S = D(g, "string");
          return typeof S == "symbol" ? S : String(S);
        }
        function D(g, S) {
          if (typeof g != "object" || g === null)
            return g;
          var y = g[Symbol.toPrimitive];
          if (y !== void 0) {
            var l = y.call(g, S || "default");
            if (typeof l != "object")
              return l;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (S === "string" ? String : Number)(g);
        }
        var _;
        (function(g) {
          g.ID = "ID", g.CLASS = "CLASS", g.START_DATE = "START-DATE", g.DURATION = "DURATION", g.END_DATE = "END-DATE", g.END_ON_NEXT = "END-ON-NEXT", g.PLANNED_DURATION = "PLANNED-DURATION", g.SCTE35_OUT = "SCTE35-OUT", g.SCTE35_IN = "SCTE35-IN";
        })(_ || (_ = {}));
        var x = /* @__PURE__ */ function() {
          function g(S, y) {
            if (this.attr = void 0, this._startDate = void 0, this._endDate = void 0, this._badValueForSameId = void 0, y) {
              var l = y.attr;
              for (var u in l)
                if (Object.prototype.hasOwnProperty.call(S, u) && S[u] !== l[u]) {
                  k.logger.warn('DATERANGE tag attribute: "' + u + '" does not match for tags with ID: "' + S.ID + '"'), this._badValueForSameId = u;
                  break;
                }
              S = C(new T.AttrList({}), l, S);
            }
            if (this.attr = S, this._startDate = new Date(S[_.START_DATE]), _.END_DATE in this.attr) {
              var a = new Date(this.attr[_.END_DATE]);
              (0, P.isFiniteNumber)(a.getTime()) && (this._endDate = a);
            }
          }
          return I(g, [{
            key: "id",
            get: function() {
              return this.attr.ID;
            }
          }, {
            key: "class",
            get: function() {
              return this.attr.CLASS;
            }
          }, {
            key: "startDate",
            get: function() {
              return this._startDate;
            }
          }, {
            key: "endDate",
            get: function() {
              if (this._endDate)
                return this._endDate;
              var y = this.duration;
              return y !== null ? new Date(this._startDate.getTime() + y * 1e3) : null;
            }
          }, {
            key: "duration",
            get: function() {
              if (_.DURATION in this.attr) {
                var y = this.attr.decimalFloatingPoint(_.DURATION);
                if ((0, P.isFiniteNumber)(y))
                  return y;
              } else if (this._endDate)
                return (this._endDate.getTime() - this._startDate.getTime()) / 1e3;
              return null;
            }
          }, {
            key: "plannedDuration",
            get: function() {
              return _.PLANNED_DURATION in this.attr ? this.attr.decimalFloatingPoint(_.PLANNED_DURATION) : null;
            }
          }, {
            key: "endOnNext",
            get: function() {
              return this.attr.bool(_.END_ON_NEXT);
            }
          }, {
            key: "isValid",
            get: function() {
              return !!this.id && !this._badValueForSameId && (0, P.isFiniteNumber)(this.startDate.getTime()) && (this.duration === null || this.duration >= 0) && (!this.endOnNext || !!this.class);
            }
          }]), g;
        }();
      },
      "./src/loader/fragment-loader.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          LoadError: () => y,
          default: () => g
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/errors.ts");
        function k(l, u) {
          l.prototype = Object.create(u.prototype), l.prototype.constructor = l, D(l, u);
        }
        function C(l) {
          var u = typeof Map == "function" ? /* @__PURE__ */ new Map() : void 0;
          return C = function(s) {
            if (s === null || !L(s))
              return s;
            if (typeof s != "function")
              throw new TypeError("Super expression must either be null or a function");
            if (typeof u < "u") {
              if (u.has(s))
                return u.get(s);
              u.set(s, m);
            }
            function m() {
              return B(s, arguments, _(this).constructor);
            }
            return m.prototype = Object.create(s.prototype, { constructor: { value: m, enumerable: !1, writable: !0, configurable: !0 } }), D(m, s);
          }, C(l);
        }
        function B(l, u, a) {
          return I() ? B = Reflect.construct.bind() : B = function(m, v, i) {
            var n = [null];
            n.push.apply(n, v);
            var E = Function.bind.apply(m, n), r = new E();
            return i && D(r, i.prototype), r;
          }, B.apply(null, arguments);
        }
        function I() {
          if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham)
            return !1;
          if (typeof Proxy == "function")
            return !0;
          try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
            })), !0;
          } catch {
            return !1;
          }
        }
        function L(l) {
          return Function.toString.call(l).indexOf("[native code]") !== -1;
        }
        function D(l, u) {
          return D = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(s, m) {
            return s.__proto__ = m, s;
          }, D(l, u);
        }
        function _(l) {
          return _ = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(a) {
            return a.__proto__ || Object.getPrototypeOf(a);
          }, _(l);
        }
        var x = Math.pow(2, 17), g = /* @__PURE__ */ function() {
          function l(a) {
            this.config = void 0, this.loader = null, this.partLoadTimeout = -1, this.config = a;
          }
          var u = l.prototype;
          return u.destroy = function() {
            this.loader && (this.loader.destroy(), this.loader = null);
          }, u.abort = function() {
            this.loader && this.loader.abort();
          }, u.load = function(s, m) {
            var v = this, i = s.url;
            if (!i)
              return Promise.reject(new y({
                type: T.ErrorTypes.NETWORK_ERROR,
                details: T.ErrorDetails.FRAG_LOAD_ERROR,
                fatal: !1,
                frag: s,
                networkDetails: null
              }, "Fragment does not have a " + (i ? "part list" : "url")));
            this.abort();
            var n = this.config, E = n.fLoader, r = n.loader;
            return new Promise(function(o, t) {
              v.loader && v.loader.destroy();
              var d = v.loader = s.loader = E ? new E(n) : new r(n), e = S(s), h = {
                timeout: n.fragLoadingTimeOut,
                maxRetry: 0,
                retryDelay: 0,
                maxRetryDelay: n.fragLoadingMaxRetryTimeout,
                highWaterMark: s.sn === "initSegment" ? 1 / 0 : x
              };
              s.stats = d.stats, d.load(e, h, {
                onSuccess: function(c, M, w, F) {
                  v.resetLoader(s, d);
                  var U = c.data;
                  w.resetIV && s.decryptdata && (s.decryptdata.iv = new Uint8Array(U.slice(0, 16)), U = U.slice(16)), o({
                    frag: s,
                    part: null,
                    payload: U,
                    networkDetails: F
                  });
                },
                onError: function(c, M, w) {
                  v.resetLoader(s, d), t(new y({
                    type: T.ErrorTypes.NETWORK_ERROR,
                    details: T.ErrorDetails.FRAG_LOAD_ERROR,
                    fatal: !1,
                    frag: s,
                    response: c,
                    networkDetails: w
                  }));
                },
                onAbort: function(c, M, w) {
                  v.resetLoader(s, d), t(new y({
                    type: T.ErrorTypes.NETWORK_ERROR,
                    details: T.ErrorDetails.INTERNAL_ABORTED,
                    fatal: !1,
                    frag: s,
                    networkDetails: w
                  }));
                },
                onTimeout: function(c, M, w) {
                  v.resetLoader(s, d), t(new y({
                    type: T.ErrorTypes.NETWORK_ERROR,
                    details: T.ErrorDetails.FRAG_LOAD_TIMEOUT,
                    fatal: !1,
                    frag: s,
                    networkDetails: w
                  }));
                },
                onProgress: function(c, M, w, F) {
                  m && m({
                    frag: s,
                    part: null,
                    payload: w,
                    networkDetails: F
                  });
                }
              });
            });
          }, u.loadPart = function(s, m, v) {
            var i = this;
            this.abort();
            var n = this.config, E = n.fLoader, r = n.loader;
            return new Promise(function(o, t) {
              i.loader && i.loader.destroy();
              var d = i.loader = s.loader = E ? new E(n) : new r(n), e = S(s, m), h = {
                timeout: n.fragLoadingTimeOut,
                maxRetry: 0,
                retryDelay: 0,
                maxRetryDelay: n.fragLoadingMaxRetryTimeout,
                highWaterMark: x
              };
              m.stats = d.stats, d.load(e, h, {
                onSuccess: function(c, M, w, F) {
                  i.resetLoader(s, d), i.updateStatsFromPart(s, m);
                  var U = {
                    frag: s,
                    part: m,
                    payload: c.data,
                    networkDetails: F
                  };
                  v(U), o(U);
                },
                onError: function(c, M, w) {
                  i.resetLoader(s, d), t(new y({
                    type: T.ErrorTypes.NETWORK_ERROR,
                    details: T.ErrorDetails.FRAG_LOAD_ERROR,
                    fatal: !1,
                    frag: s,
                    part: m,
                    response: c,
                    networkDetails: w
                  }));
                },
                onAbort: function(c, M, w) {
                  s.stats.aborted = m.stats.aborted, i.resetLoader(s, d), t(new y({
                    type: T.ErrorTypes.NETWORK_ERROR,
                    details: T.ErrorDetails.INTERNAL_ABORTED,
                    fatal: !1,
                    frag: s,
                    part: m,
                    networkDetails: w
                  }));
                },
                onTimeout: function(c, M, w) {
                  i.resetLoader(s, d), t(new y({
                    type: T.ErrorTypes.NETWORK_ERROR,
                    details: T.ErrorDetails.FRAG_LOAD_TIMEOUT,
                    fatal: !1,
                    frag: s,
                    part: m,
                    networkDetails: w
                  }));
                }
              });
            });
          }, u.updateStatsFromPart = function(s, m) {
            var v = s.stats, i = m.stats, n = i.total;
            if (v.loaded += i.loaded, n) {
              var E = Math.round(s.duration / m.duration), r = Math.min(Math.round(v.loaded / n), E), o = E - r, t = o * Math.round(v.loaded / r);
              v.total = v.loaded + t;
            } else
              v.total = Math.max(v.loaded, v.total);
            var d = v.loading, e = i.loading;
            d.start ? d.first += e.first - e.start : (d.start = e.start, d.first = e.first), d.end = e.end;
          }, u.resetLoader = function(s, m) {
            s.loader = null, this.loader === m && (self.clearTimeout(this.partLoadTimeout), this.loader = null), m.destroy();
          }, l;
        }();
        function S(l, u) {
          u === void 0 && (u = null);
          var a = u || l, s = {
            frag: l,
            part: u,
            responseType: "arraybuffer",
            url: a.url,
            headers: {},
            rangeStart: 0,
            rangeEnd: 0
          }, m = a.byteRangeStartOffset, v = a.byteRangeEndOffset;
          if ((0, P.isFiniteNumber)(m) && (0, P.isFiniteNumber)(v)) {
            var i, n = m, E = v;
            if (l.sn === "initSegment" && ((i = l.decryptdata) === null || i === void 0 ? void 0 : i.method) === "AES-128") {
              var r = v - m;
              r % 16 && (E = v + (16 - r % 16)), m !== 0 && (s.resetIV = !0, n = m - 16);
            }
            s.rangeStart = n, s.rangeEnd = E;
          }
          return s;
        }
        var y = /* @__PURE__ */ function(l) {
          k(u, l);
          function u(a) {
            for (var s, m = arguments.length, v = new Array(m > 1 ? m - 1 : 0), i = 1; i < m; i++)
              v[i - 1] = arguments[i];
            return s = l.call.apply(l, [this].concat(v)) || this, s.data = void 0, s.data = a, s;
          }
          return u;
        }(/* @__PURE__ */ C(Error));
      },
      "./src/loader/fragment.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          BaseSegment: () => g,
          ElementaryStreamTypes: () => x,
          Fragment: () => S,
          Part: () => y
        });
        var P = p("./src/polyfills/number.ts"), T = p("./node_modules/url-toolkit/src/url-toolkit.js"), k = p("./src/loader/load-stats.ts");
        function C(l, u) {
          l.prototype = Object.create(u.prototype), l.prototype.constructor = l, B(l, u);
        }
        function B(l, u) {
          return B = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(s, m) {
            return s.__proto__ = m, s;
          }, B(l, u);
        }
        function I(l, u) {
          for (var a = 0; a < u.length; a++) {
            var s = u[a];
            s.enumerable = s.enumerable || !1, s.configurable = !0, "value" in s && (s.writable = !0), Object.defineProperty(l, D(s.key), s);
          }
        }
        function L(l, u, a) {
          return u && I(l.prototype, u), a && I(l, a), Object.defineProperty(l, "prototype", { writable: !1 }), l;
        }
        function D(l) {
          var u = _(l, "string");
          return typeof u == "symbol" ? u : String(u);
        }
        function _(l, u) {
          if (typeof l != "object" || l === null)
            return l;
          var a = l[Symbol.toPrimitive];
          if (a !== void 0) {
            var s = a.call(l, u || "default");
            if (typeof s != "object")
              return s;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (u === "string" ? String : Number)(l);
        }
        var x;
        (function(l) {
          l.AUDIO = "audio", l.VIDEO = "video", l.AUDIOVIDEO = "audiovideo";
        })(x || (x = {}));
        var g = /* @__PURE__ */ function() {
          function l(a) {
            var s;
            this._byteRange = null, this._url = null, this.baseurl = void 0, this.relurl = void 0, this.elementaryStreams = (s = {}, s[x.AUDIO] = null, s[x.VIDEO] = null, s[x.AUDIOVIDEO] = null, s), this.baseurl = a;
          }
          var u = l.prototype;
          return u.setByteRange = function(s, m) {
            var v = s.split("@", 2), i = [];
            v.length === 1 ? i[0] = m ? m.byteRangeEndOffset : 0 : i[0] = parseInt(v[1]), i[1] = parseInt(v[0]) + i[0], this._byteRange = i;
          }, L(l, [{
            key: "byteRange",
            get: function() {
              return this._byteRange ? this._byteRange : [];
            }
          }, {
            key: "byteRangeStartOffset",
            get: function() {
              return this.byteRange[0];
            }
          }, {
            key: "byteRangeEndOffset",
            get: function() {
              return this.byteRange[1];
            }
          }, {
            key: "url",
            get: function() {
              return !this._url && this.baseurl && this.relurl && (this._url = (0, T.buildAbsoluteURL)(this.baseurl, this.relurl, {
                alwaysNormalize: !0
              })), this._url || "";
            },
            set: function(s) {
              this._url = s;
            }
          }]), l;
        }(), S = /* @__PURE__ */ function(l) {
          C(u, l);
          function u(s, m) {
            var v;
            return v = l.call(this, m) || this, v._decryptdata = null, v.rawProgramDateTime = null, v.programDateTime = null, v.tagList = [], v.duration = 0, v.sn = 0, v.levelkeys = void 0, v.type = void 0, v.loader = null, v.keyLoader = null, v.level = -1, v.cc = 0, v.startPTS = void 0, v.endPTS = void 0, v.appendedPTS = void 0, v.startDTS = void 0, v.endDTS = void 0, v.start = 0, v.deltaPTS = void 0, v.maxStartPTS = void 0, v.minEndPTS = void 0, v.stats = new k.LoadStats(), v.urlId = 0, v.data = void 0, v.bitrateTest = !1, v.title = null, v.initSegment = null, v.endList = void 0, v.type = s, v;
          }
          var a = u.prototype;
          return a.setKeyFormat = function(m) {
            if (this.levelkeys) {
              var v = this.levelkeys[m];
              v && !this._decryptdata && (this._decryptdata = v.getDecryptData(this.sn));
            }
          }, a.abortRequests = function() {
            var m, v;
            (m = this.loader) === null || m === void 0 || m.abort(), (v = this.keyLoader) === null || v === void 0 || v.abort();
          }, a.setElementaryStreamInfo = function(m, v, i, n, E, r) {
            r === void 0 && (r = !1);
            var o = this.elementaryStreams, t = o[m];
            if (!t) {
              o[m] = {
                startPTS: v,
                endPTS: i,
                startDTS: n,
                endDTS: E,
                partial: r
              };
              return;
            }
            t.startPTS = Math.min(t.startPTS, v), t.endPTS = Math.max(t.endPTS, i), t.startDTS = Math.min(t.startDTS, n), t.endDTS = Math.max(t.endDTS, E);
          }, a.clearElementaryStreamInfo = function() {
            var m = this.elementaryStreams;
            m[x.AUDIO] = null, m[x.VIDEO] = null, m[x.AUDIOVIDEO] = null;
          }, L(u, [{
            key: "decryptdata",
            get: function() {
              var m = this.levelkeys;
              if (!m && !this._decryptdata)
                return null;
              if (!this._decryptdata && this.levelkeys && !this.levelkeys.NONE) {
                var v = this.levelkeys.identity;
                if (v)
                  this._decryptdata = v.getDecryptData(this.sn);
                else {
                  var i = Object.keys(this.levelkeys);
                  if (i.length === 1)
                    return this._decryptdata = this.levelkeys[i[0]].getDecryptData(this.sn);
                }
              }
              return this._decryptdata;
            }
          }, {
            key: "end",
            get: function() {
              return this.start + this.duration;
            }
          }, {
            key: "endProgramDateTime",
            get: function() {
              if (this.programDateTime === null || !(0, P.isFiniteNumber)(this.programDateTime))
                return null;
              var m = (0, P.isFiniteNumber)(this.duration) ? this.duration : 0;
              return this.programDateTime + m * 1e3;
            }
          }, {
            key: "encrypted",
            get: function() {
              var m;
              if ((m = this._decryptdata) !== null && m !== void 0 && m.encrypted)
                return !0;
              if (this.levelkeys) {
                var v = Object.keys(this.levelkeys), i = v.length;
                if (i > 1 || i === 1 && this.levelkeys[v[0]].encrypted)
                  return !0;
              }
              return !1;
            }
          }]), u;
        }(g), y = /* @__PURE__ */ function(l) {
          C(u, l);
          function u(a, s, m, v, i) {
            var n;
            n = l.call(this, m) || this, n.fragOffset = 0, n.duration = 0, n.gap = !1, n.independent = !1, n.relurl = void 0, n.fragment = void 0, n.index = void 0, n.stats = new k.LoadStats(), n.duration = a.decimalFloatingPoint("DURATION"), n.gap = a.bool("GAP"), n.independent = a.bool("INDEPENDENT"), n.relurl = a.enumeratedString("URI"), n.fragment = s, n.index = v;
            var E = a.enumeratedString("BYTERANGE");
            return E && n.setByteRange(E, i), i && (n.fragOffset = i.fragOffset + i.duration), n;
          }
          return L(u, [{
            key: "start",
            get: function() {
              return this.fragment.start + this.fragOffset;
            }
          }, {
            key: "end",
            get: function() {
              return this.start + this.duration;
            }
          }, {
            key: "loaded",
            get: function() {
              var s = this.elementaryStreams;
              return !!(s.audio || s.video || s.audiovideo);
            }
          }]), u;
        }(g);
      },
      "./src/loader/key-loader.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => k
        });
        var P = p("./src/errors.ts"), T = p("./src/loader/fragment-loader.ts"), k = /* @__PURE__ */ function() {
          function C(I) {
            this.config = void 0, this.keyUriToKeyInfo = {}, this.emeController = null, this.config = I;
          }
          var B = C.prototype;
          return B.abort = function() {
            for (var L in this.keyUriToKeyInfo) {
              var D = this.keyUriToKeyInfo[L].loader;
              D && D.abort();
            }
          }, B.detach = function() {
            for (var L in this.keyUriToKeyInfo) {
              var D = this.keyUriToKeyInfo[L];
              (D.mediaKeySessionContext || D.decryptdata.isCommonEncryption) && delete this.keyUriToKeyInfo[L];
            }
          }, B.destroy = function() {
            this.detach();
            for (var L in this.keyUriToKeyInfo) {
              var D = this.keyUriToKeyInfo[L].loader;
              D && D.destroy();
            }
            this.keyUriToKeyInfo = {};
          }, B.createKeyLoadError = function(L, D, _, x) {
            return D === void 0 && (D = P.ErrorDetails.KEY_LOAD_ERROR), new T.LoadError({
              type: P.ErrorTypes.NETWORK_ERROR,
              details: D,
              fatal: !1,
              frag: L,
              networkDetails: _
            });
          }, B.loadClear = function(L, D) {
            var _ = this;
            if (this.emeController && this.config.emeEnabled)
              for (var x = L.sn, g = L.cc, S = function(a) {
                var s = D[a];
                if (g <= s.cc && (x === "initSegment" || x < s.sn))
                  return _.emeController.selectKeySystemFormat(s).then(function(m) {
                    s.setKeyFormat(m);
                  }), "break";
              }, y = 0; y < D.length; y++) {
                var l = S(y);
                if (l === "break")
                  break;
              }
          }, B.load = function(L) {
            var D = this;
            return !L.decryptdata && L.encrypted && this.emeController ? this.emeController.selectKeySystemFormat(L).then(function(_) {
              return D.loadInternal(L, _);
            }) : this.loadInternal(L);
          }, B.loadInternal = function(L, D) {
            var _, x;
            D && L.setKeyFormat(D);
            var g = L.decryptdata;
            if (!g) {
              var S = D ? "Expected frag.decryptdata to be defined after setting format " + D : "Missing decryption data on fragment in onKeyLoading";
              return Promise.reject(this.createKeyLoadError(L, P.ErrorDetails.KEY_LOAD_ERROR, null, S));
            }
            var y = g.uri;
            if (!y)
              return Promise.reject(this.createKeyLoadError(L, P.ErrorDetails.KEY_LOAD_ERROR, null, 'Invalid key URI: "' + y + '"'));
            var l = this.keyUriToKeyInfo[y];
            if ((_ = l) !== null && _ !== void 0 && _.decryptdata.key)
              return g.key = l.decryptdata.key, Promise.resolve({
                frag: L,
                keyInfo: l
              });
            if ((x = l) !== null && x !== void 0 && x.keyLoadPromise) {
              var u;
              switch ((u = l.mediaKeySessionContext) === null || u === void 0 ? void 0 : u.keyStatus) {
                case void 0:
                case "status-pending":
                case "usable":
                case "usable-in-future":
                  return l.keyLoadPromise;
              }
            }
            switch (l = this.keyUriToKeyInfo[y] = {
              decryptdata: g,
              keyLoadPromise: null,
              loader: null,
              mediaKeySessionContext: null
            }, g.method) {
              case "ISO-23001-7":
              case "SAMPLE-AES":
              case "SAMPLE-AES-CENC":
              case "SAMPLE-AES-CTR":
                return g.keyFormat === "identity" ? this.loadKeyHTTP(l, L) : this.loadKeyEME(l, L);
              case "AES-128":
                return this.loadKeyHTTP(l, L);
              default:
                return Promise.reject(this.createKeyLoadError(L, P.ErrorDetails.KEY_LOAD_ERROR, null, 'Key supplied with unsupported METHOD: "' + g.method + '"'));
            }
          }, B.loadKeyEME = function(L, D) {
            var _ = {
              frag: D,
              keyInfo: L
            };
            if (this.emeController && this.config.emeEnabled) {
              var x = this.emeController.loadKey(_);
              if (x)
                return (L.keyLoadPromise = x.then(function(g) {
                  return L.mediaKeySessionContext = g, _;
                })).catch(function(g) {
                  throw L.keyLoadPromise = null, g;
                });
            }
            return Promise.resolve(_);
          }, B.loadKeyHTTP = function(L, D) {
            var _ = this, x = this.config, g = x.loader, S = new g(x);
            return D.keyLoader = L.loader = S, L.keyLoadPromise = new Promise(function(y, l) {
              var u = {
                keyInfo: L,
                frag: D,
                responseType: "arraybuffer",
                url: L.decryptdata.uri
              }, a = {
                timeout: x.fragLoadingTimeOut,
                maxRetry: 0,
                retryDelay: x.fragLoadingRetryDelay,
                maxRetryDelay: x.fragLoadingMaxRetryTimeout,
                highWaterMark: 0
              }, s = {
                onSuccess: function(v, i, n, E) {
                  var r = n.frag, o = n.keyInfo, t = n.url;
                  if (!r.decryptdata || o !== _.keyUriToKeyInfo[t])
                    return l(_.createKeyLoadError(r, P.ErrorDetails.KEY_LOAD_ERROR, E, "after key load, decryptdata unset or changed"));
                  o.decryptdata.key = r.decryptdata.key = new Uint8Array(v.data), r.keyLoader = null, o.loader = null, y({
                    frag: r,
                    keyInfo: o
                  });
                },
                onError: function(v, i, n) {
                  _.resetLoader(i), l(_.createKeyLoadError(D, P.ErrorDetails.KEY_LOAD_ERROR, n));
                },
                onTimeout: function(v, i, n) {
                  _.resetLoader(i), l(_.createKeyLoadError(D, P.ErrorDetails.KEY_LOAD_TIMEOUT, n));
                },
                onAbort: function(v, i, n) {
                  _.resetLoader(i), l(_.createKeyLoadError(D, P.ErrorDetails.INTERNAL_ABORTED, n));
                }
              };
              S.load(u, a, s);
            });
          }, B.resetLoader = function(L) {
            var D = L.frag, _ = L.keyInfo, x = L.url, g = _.loader;
            D.keyLoader === g && (D.keyLoader = null, _.loader = null), delete this.keyUriToKeyInfo[x], g && g.destroy();
          }, C;
        }();
      },
      "./src/loader/level-details.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          LevelDetails: () => L
        });
        var P = p("./src/polyfills/number.ts");
        function T(D, _) {
          for (var x = 0; x < _.length; x++) {
            var g = _[x];
            g.enumerable = g.enumerable || !1, g.configurable = !0, "value" in g && (g.writable = !0), Object.defineProperty(D, C(g.key), g);
          }
        }
        function k(D, _, x) {
          return _ && T(D.prototype, _), x && T(D, x), Object.defineProperty(D, "prototype", { writable: !1 }), D;
        }
        function C(D) {
          var _ = B(D, "string");
          return typeof _ == "symbol" ? _ : String(_);
        }
        function B(D, _) {
          if (typeof D != "object" || D === null)
            return D;
          var x = D[Symbol.toPrimitive];
          if (x !== void 0) {
            var g = x.call(D, _ || "default");
            if (typeof g != "object")
              return g;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (_ === "string" ? String : Number)(D);
        }
        var I = 10, L = /* @__PURE__ */ function() {
          function D(x) {
            this.PTSKnown = !1, this.alignedSliding = !1, this.averagetargetduration = void 0, this.endCC = 0, this.endSN = 0, this.fragments = void 0, this.fragmentHint = void 0, this.partList = null, this.dateRanges = void 0, this.live = !0, this.ageHeader = 0, this.advancedDateTime = void 0, this.updated = !0, this.advanced = !0, this.availabilityDelay = void 0, this.misses = 0, this.startCC = 0, this.startSN = 0, this.startTimeOffset = null, this.targetduration = 0, this.totalduration = 0, this.type = null, this.url = void 0, this.m3u8 = "", this.version = null, this.canBlockReload = !1, this.canSkipUntil = 0, this.canSkipDateRanges = !1, this.skippedSegments = 0, this.recentlyRemovedDateranges = void 0, this.partHoldBack = 0, this.holdBack = 0, this.partTarget = 0, this.preloadHint = void 0, this.renditionReports = void 0, this.tuneInGoal = 0, this.deltaUpdateFailed = void 0, this.driftStartTime = 0, this.driftEndTime = 0, this.driftStart = 0, this.driftEnd = 0, this.encryptedFragments = void 0, this.fragments = [], this.encryptedFragments = [], this.dateRanges = {}, this.url = x;
          }
          var _ = D.prototype;
          return _.reloaded = function(g) {
            if (!g) {
              this.advanced = !0, this.updated = !0;
              return;
            }
            var S = this.lastPartSn - g.lastPartSn, y = this.lastPartIndex - g.lastPartIndex;
            this.updated = this.endSN !== g.endSN || !!y || !!S, this.advanced = this.endSN > g.endSN || S > 0 || S === 0 && y > 0, this.updated || this.advanced ? this.misses = Math.floor(g.misses * 0.6) : this.misses = g.misses + 1, this.availabilityDelay = g.availabilityDelay;
          }, k(D, [{
            key: "hasProgramDateTime",
            get: function() {
              return this.fragments.length ? (0, P.isFiniteNumber)(this.fragments[this.fragments.length - 1].programDateTime) : !1;
            }
          }, {
            key: "levelTargetDuration",
            get: function() {
              return this.averagetargetduration || this.targetduration || I;
            }
          }, {
            key: "drift",
            get: function() {
              var g = this.driftEndTime - this.driftStartTime;
              if (g > 0) {
                var S = this.driftEnd - this.driftStart;
                return S * 1e3 / g;
              }
              return 1;
            }
          }, {
            key: "edge",
            get: function() {
              return this.partEnd || this.fragmentEnd;
            }
          }, {
            key: "partEnd",
            get: function() {
              var g;
              return (g = this.partList) !== null && g !== void 0 && g.length ? this.partList[this.partList.length - 1].end : this.fragmentEnd;
            }
          }, {
            key: "fragmentEnd",
            get: function() {
              var g;
              return (g = this.fragments) !== null && g !== void 0 && g.length ? this.fragments[this.fragments.length - 1].end : 0;
            }
          }, {
            key: "age",
            get: function() {
              return this.advancedDateTime ? Math.max(Date.now() - this.advancedDateTime, 0) / 1e3 : 0;
            }
          }, {
            key: "lastPartIndex",
            get: function() {
              var g;
              return (g = this.partList) !== null && g !== void 0 && g.length ? this.partList[this.partList.length - 1].index : -1;
            }
          }, {
            key: "lastPartSn",
            get: function() {
              var g;
              return (g = this.partList) !== null && g !== void 0 && g.length ? this.partList[this.partList.length - 1].fragment.sn : this.endSN;
            }
          }]), D;
        }();
      },
      "./src/loader/level-key.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          LevelKey: () => L
        });
        var P = p("./src/utils/keysystem-util.ts"), T = p("./src/utils/mediakeys-helper.ts"), k = p("./src/utils/mp4-tools.ts"), C = p("./src/utils/logger.ts"), B = p("./src/utils/numeric-encoding-utils.ts"), I = {}, L = /* @__PURE__ */ function() {
          _.clearKeyUriToKeyIdMap = function() {
            I = {};
          };
          function _(g, S, y, l, u) {
            l === void 0 && (l = [1]), u === void 0 && (u = null), this.uri = void 0, this.method = void 0, this.keyFormat = void 0, this.keyFormatVersions = void 0, this.encrypted = void 0, this.isCommonEncryption = void 0, this.iv = null, this.key = null, this.keyId = null, this.pssh = null, this.method = g, this.uri = S, this.keyFormat = y, this.keyFormatVersions = l, this.iv = u, this.encrypted = g ? g !== "NONE" : !1, this.isCommonEncryption = this.encrypted && g !== "AES-128";
          }
          var x = _.prototype;
          return x.isSupported = function() {
            if (this.method) {
              if (this.method === "AES-128" || this.method === "NONE")
                return !0;
              switch (this.keyFormat) {
                case "identity":
                  return this.method === "SAMPLE-AES";
                case T.KeySystemFormats.FAIRPLAY:
                case T.KeySystemFormats.WIDEVINE:
                case T.KeySystemFormats.PLAYREADY:
                case T.KeySystemFormats.CLEARKEY:
                  return ["ISO-23001-7", "SAMPLE-AES", "SAMPLE-AES-CENC", "SAMPLE-AES-CTR"].indexOf(this.method) !== -1;
              }
            }
            return !1;
          }, x.getDecryptData = function(S) {
            if (!this.encrypted || !this.uri)
              return null;
            if (this.method === "AES-128" && this.uri && !this.iv) {
              typeof S != "number" && (this.method === "AES-128" && !this.iv && C.logger.warn('missing IV for initialization segment with method="' + this.method + '" - compliance issue'), S = 0);
              var y = D(S), l = new _(this.method, this.uri, "identity", this.keyFormatVersions, y);
              return l;
            }
            var u = (0, P.convertDataUriToArrayBytes)(this.uri);
            if (u)
              switch (this.keyFormat) {
                case T.KeySystemFormats.WIDEVINE:
                  this.pssh = u, u.length >= 22 && (this.keyId = u.subarray(u.length - 22, u.length - 6));
                  break;
                case T.KeySystemFormats.PLAYREADY: {
                  var a = new Uint8Array([154, 4, 240, 121, 152, 64, 66, 134, 171, 146, 230, 91, 224, 136, 95, 149]);
                  this.pssh = (0, k.mp4pssh)(a, null, u);
                  var s = new Uint16Array(u.buffer, u.byteOffset, u.byteLength / 2), m = String.fromCharCode.apply(null, Array.from(s)), v = m.substring(m.indexOf("<"), m.length), i = new DOMParser(), n = i.parseFromString(v, "text/xml"), E = n.getElementsByTagName("KID")[0];
                  if (E) {
                    var r = E.childNodes[0] ? E.childNodes[0].nodeValue : E.getAttribute("VALUE");
                    if (r) {
                      var o = (0, B.base64Decode)(r).subarray(0, 16);
                      (0, P.changeEndianness)(o), this.keyId = o;
                    }
                  }
                  break;
                }
                default: {
                  var t = u.subarray(0, 16);
                  if (t.length !== 16) {
                    var d = new Uint8Array(16);
                    d.set(t, 16 - t.length), t = d;
                  }
                  this.keyId = t;
                  break;
                }
              }
            if (!this.keyId || this.keyId.byteLength !== 16) {
              var e = I[this.uri];
              if (!e) {
                var h = Object.keys(I).length % Number.MAX_SAFE_INTEGER;
                e = new Uint8Array(16);
                var f = new DataView(e.buffer, 12, 4);
                f.setUint32(0, h), I[this.uri] = e;
              }
              this.keyId = e;
            }
            return this;
          }, _;
        }();
        function D(_) {
          for (var x = new Uint8Array(16), g = 12; g < 16; g++)
            x[g] = _ >> 8 * (15 - g) & 255;
          return x;
        }
      },
      "./src/loader/load-stats.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          LoadStats: () => P
        });
        var P = function() {
          this.aborted = !1, this.loaded = 0, this.retry = 0, this.total = 0, this.chunkCount = 0, this.bwEstimate = 0, this.loading = {
            start: 0,
            first: 0,
            end: 0
          }, this.parsing = {
            start: 0,
            end: 0
          }, this.buffering = {
            start: 0,
            first: 0,
            end: 0
          };
        };
      },
      "./src/loader/m3u8-parser.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => u
        });
        var P = p("./src/polyfills/number.ts"), T = p("./node_modules/url-toolkit/src/url-toolkit.js"), k = p("./src/loader/date-range.ts"), C = p("./src/loader/fragment.ts"), B = p("./src/loader/level-details.ts"), I = p("./src/loader/level-key.ts"), L = p("./src/utils/attr-list.ts"), D = p("./src/utils/logger.ts"), _ = p("./src/utils/codecs.ts");
        function x() {
          return x = Object.assign ? Object.assign.bind() : function(r) {
            for (var o = 1; o < arguments.length; o++) {
              var t = arguments[o];
              for (var d in t)
                Object.prototype.hasOwnProperty.call(t, d) && (r[d] = t[d]);
            }
            return r;
          }, x.apply(this, arguments);
        }
        var g = /#EXT-X-STREAM-INF:([^\r\n]*)(?:[\r\n](?:#[^\r\n]*)?)*([^\r\n]+)|#EXT-X-SESSION-DATA:([^\r\n]*)[\r\n]+|#EXT-X-SESSION-KEY:([^\n\r]*)[\r\n]+/g, S = /#EXT-X-MEDIA:(.*)/g, y = new RegExp([
          /#EXTINF:\s*(\d*(?:\.\d+)?)(?:,(.*)\s+)?/.source,
          /(?!#) *(\S[\S ]*)/.source,
          /#EXT-X-BYTERANGE:*(.+)/.source,
          /#EXT-X-PROGRAM-DATE-TIME:(.+)/.source,
          /#.*/.source
        ].join("|"), "g"), l = new RegExp([/#(EXTM3U)/.source, /#EXT-X-(DATERANGE|KEY|MAP|PART|PART-INF|PLAYLIST-TYPE|PRELOAD-HINT|RENDITION-REPORT|SERVER-CONTROL|SKIP|START):(.+)/.source, /#EXT-X-(BITRATE|DISCONTINUITY-SEQUENCE|MEDIA-SEQUENCE|TARGETDURATION|VERSION): *(\d+)/.source, /#EXT-X-(DISCONTINUITY|ENDLIST|GAP)/.source, /(#)([^:]*):(.*)/.source, /(#)(.*)(?:.*)\r?\n?/.source].join("|")), u = /* @__PURE__ */ function() {
          function r() {
          }
          return r.findGroup = function(t, d) {
            for (var e = 0; e < t.length; e++) {
              var h = t[e];
              if (h.id === d)
                return h;
            }
          }, r.convertAVC1ToAVCOTI = function(t) {
            var d = t.split(".");
            if (d.length > 2) {
              var e = d.shift() + ".";
              return e += parseInt(d.shift()).toString(16), e += ("000" + parseInt(d.shift()).toString(16)).slice(-4), e;
            }
            return t;
          }, r.resolve = function(t, d) {
            return (0, T.buildAbsoluteURL)(d, t, {
              alwaysNormalize: !0
            });
          }, r.parseMasterPlaylist = function(t, d) {
            var e = [], h = [], f = {}, c = [], M = !1;
            g.lastIndex = 0;
            for (var w; (w = g.exec(t)) != null; )
              if (w[1]) {
                var F, U = new L.AttrList(w[1]), N = {
                  attrs: U,
                  bitrate: U.decimalInteger("AVERAGE-BANDWIDTH") || U.decimalInteger("BANDWIDTH"),
                  name: U.NAME,
                  url: r.resolve(w[2], d)
                }, H = U.decimalResolution("RESOLUTION");
                H && (N.width = H.width, N.height = H.height), s((U.CODECS || "").split(/[ ,]+/).filter(function(Z) {
                  return Z;
                }), N), N.videoCodec && N.videoCodec.indexOf("avc1") !== -1 && (N.videoCodec = r.convertAVC1ToAVCOTI(N.videoCodec)), (F = N.unknownCodecs) !== null && F !== void 0 && F.length || h.push(N), e.push(N);
              } else if (w[3]) {
                var j = new L.AttrList(w[3]);
                j["DATA-ID"] && (M = !0, f[j["DATA-ID"]] = j);
              } else if (w[4]) {
                var z = w[4], Y = a(z, d);
                Y.encrypted && Y.isSupported() ? c.push(Y) : D.logger.warn('[Keys] Ignoring invalid EXT-X-SESSION-KEY tag: "' + z + '"');
              }
            var X = h.length > 0 && h.length < e.length;
            return {
              levels: X ? h : e,
              sessionData: M ? f : null,
              sessionKeys: c.length ? c : null
            };
          }, r.parseMasterPlaylistMedia = function(t, d, e, h) {
            h === void 0 && (h = []);
            var f, c = [], M = 0;
            for (S.lastIndex = 0; (f = S.exec(t)) !== null; ) {
              var w = new L.AttrList(f[1]);
              if (w.TYPE === e) {
                var F = {
                  attrs: w,
                  bitrate: 0,
                  id: M++,
                  groupId: w["GROUP-ID"],
                  instreamId: w["INSTREAM-ID"],
                  name: w.NAME || w.LANGUAGE || "",
                  type: e,
                  default: w.bool("DEFAULT"),
                  autoselect: w.bool("AUTOSELECT"),
                  forced: w.bool("FORCED"),
                  lang: w.LANGUAGE,
                  url: w.URI ? r.resolve(w.URI, d) : ""
                };
                if (h.length) {
                  var U = r.findGroup(h, F.groupId) || h[0];
                  m(F, U, "audioCodec"), m(F, U, "textCodec");
                }
                c.push(F);
              }
            }
            return c;
          }, r.parseLevelPlaylist = function(t, d, e, h, f) {
            var c = new B.LevelDetails(d), M = c.fragments, w = null, F = 0, U = 0, N = 0, H = 0, j = null, z = new C.Fragment(h, d), Y, X, Z, te = -1, $ = !1;
            for (y.lastIndex = 0, c.m3u8 = t; (Y = y.exec(t)) !== null; ) {
              $ && ($ = !1, z = new C.Fragment(h, d), z.start = N, z.sn = F, z.cc = H, z.level = e, w && (z.initSegment = w, z.rawProgramDateTime = w.rawProgramDateTime, w.rawProgramDateTime = null));
              var ee = Y[1];
              if (ee) {
                z.duration = parseFloat(ee);
                var ne = (" " + Y[2]).slice(1);
                z.title = ne || null, z.tagList.push(ne ? ["INF", ee, ne] : ["INF", ee]);
              } else if (Y[3])
                (0, P.isFiniteNumber)(z.duration) && (z.start = N, Z && E(z, Z, c), z.sn = F, z.level = e, z.cc = H, z.urlId = f, M.push(z), z.relurl = (" " + Y[3]).slice(1), i(z, j), j = z, N += z.duration, F++, U = 0, $ = !0);
              else if (Y[4]) {
                var oe = (" " + Y[4]).slice(1);
                j ? z.setByteRange(oe, j) : z.setByteRange(oe);
              } else if (Y[5])
                z.rawProgramDateTime = (" " + Y[5]).slice(1), z.tagList.push(["PROGRAM-DATE-TIME", z.rawProgramDateTime]), te === -1 && (te = M.length);
              else {
                if (Y = Y[0].match(l), !Y) {
                  D.logger.warn("No matches on slow regex match for level playlist!");
                  continue;
                }
                for (X = 1; X < Y.length && !(typeof Y[X] < "u"); X++)
                  ;
                var ae = (" " + Y[X]).slice(1), ie = (" " + Y[X + 1]).slice(1), ce = Y[X + 2] ? (" " + Y[X + 2]).slice(1) : "";
                switch (ae) {
                  case "PLAYLIST-TYPE":
                    c.type = ie.toUpperCase();
                    break;
                  case "MEDIA-SEQUENCE":
                    F = c.startSN = parseInt(ie);
                    break;
                  case "SKIP": {
                    var me = new L.AttrList(ie), pe = me.decimalInteger("SKIPPED-SEGMENTS");
                    if ((0, P.isFiniteNumber)(pe)) {
                      c.skippedSegments = pe;
                      for (var Ie = pe; Ie--; )
                        M.unshift(null);
                      F += pe;
                    }
                    var Ee = me.enumeratedString("RECENTLY-REMOVED-DATERANGES");
                    Ee && (c.recentlyRemovedDateranges = Ee.split("	"));
                    break;
                  }
                  case "TARGETDURATION":
                    c.targetduration = parseFloat(ie);
                    break;
                  case "VERSION":
                    c.version = parseInt(ie);
                    break;
                  case "EXTM3U":
                    break;
                  case "ENDLIST":
                    c.live = !1;
                    break;
                  case "#":
                    (ie || ce) && z.tagList.push(ce ? [ie, ce] : [ie]);
                    break;
                  case "DISCONTINUITY":
                    H++, z.tagList.push(["DIS"]);
                    break;
                  case "GAP":
                    z.tagList.push([ae]);
                    break;
                  case "BITRATE":
                    z.tagList.push([ae, ie]);
                    break;
                  case "DATERANGE": {
                    var _e = new L.AttrList(ie), Te = new k.DateRange(_e, c.dateRanges[_e.ID]);
                    Te.isValid || c.skippedSegments ? c.dateRanges[Te.id] = Te : D.logger.warn('Ignoring invalid DATERANGE tag: "' + ie + '"'), z.tagList.push(["EXT-X-DATERANGE", ie]);
                    break;
                  }
                  case "DISCONTINUITY-SEQUENCE":
                    H = parseInt(ie);
                    break;
                  case "KEY": {
                    var Se = a(ie, d);
                    if (Se.isSupported()) {
                      if (Se.method === "NONE") {
                        Z = void 0;
                        break;
                      }
                      Z || (Z = {}), Z[Se.keyFormat] && (Z = x({}, Z)), Z[Se.keyFormat] = Se;
                    } else
                      D.logger.warn('[Keys] Ignoring invalid EXT-X-KEY tag: "' + ie + '"');
                    break;
                  }
                  case "START": {
                    var xe = new L.AttrList(ie), Re = xe.decimalFloatingPoint("TIME-OFFSET");
                    (0, P.isFiniteNumber)(Re) && (c.startTimeOffset = Re);
                    break;
                  }
                  case "MAP": {
                    var we = new L.AttrList(ie);
                    if (z.duration) {
                      var Ce = new C.Fragment(h, d);
                      n(Ce, we, e, Z), w = Ce, z.initSegment = w, w.rawProgramDateTime && !z.rawProgramDateTime && (z.rawProgramDateTime = w.rawProgramDateTime);
                    } else
                      n(z, we, e, Z), w = z, $ = !0;
                    break;
                  }
                  case "SERVER-CONTROL": {
                    var Me = new L.AttrList(ie);
                    c.canBlockReload = Me.bool("CAN-BLOCK-RELOAD"), c.canSkipUntil = Me.optionalFloat("CAN-SKIP-UNTIL", 0), c.canSkipDateRanges = c.canSkipUntil > 0 && Me.bool("CAN-SKIP-DATERANGES"), c.partHoldBack = Me.optionalFloat("PART-HOLD-BACK", 0), c.holdBack = Me.optionalFloat("HOLD-BACK", 0);
                    break;
                  }
                  case "PART-INF": {
                    var Ge = new L.AttrList(ie);
                    c.partTarget = Ge.decimalFloatingPoint("PART-TARGET");
                    break;
                  }
                  case "PART": {
                    var ye = c.partList;
                    ye || (ye = c.partList = []);
                    var st = U > 0 ? ye[ye.length - 1] : void 0, Xe = U++, He = new C.Part(new L.AttrList(ie), z, d, Xe, st);
                    ye.push(He), z.duration += He.duration;
                    break;
                  }
                  case "PRELOAD-HINT": {
                    var Ve = new L.AttrList(ie);
                    c.preloadHint = Ve;
                    break;
                  }
                  case "RENDITION-REPORT": {
                    var Ue = new L.AttrList(ie);
                    c.renditionReports = c.renditionReports || [], c.renditionReports.push(Ue);
                    break;
                  }
                  default:
                    D.logger.warn("line parsed but not handled: " + Y);
                    break;
                }
              }
            }
            j && !j.relurl ? (M.pop(), N -= j.duration, c.partList && (c.fragmentHint = j)) : c.partList && (i(z, j), z.cc = H, c.fragmentHint = z, Z && E(z, Z, c));
            var Be = M.length, je = M[0], Qe = M[Be - 1];
            if (N += c.skippedSegments * c.targetduration, N > 0 && Be && Qe) {
              c.averagetargetduration = N / Be;
              var Oe = Qe.sn;
              c.endSN = Oe !== "initSegment" ? Oe : 0, c.live || (Qe.endList = !0), je && (c.startCC = je.cc);
            } else
              c.endSN = 0, c.startCC = 0;
            return c.fragmentHint && (N += c.fragmentHint.duration), c.totalduration = N, c.endCC = H, te > 0 && v(M, te), c;
          }, r;
        }();
        function a(r, o) {
          var t, d, e = new L.AttrList(r), h = (t = e.enumeratedString("METHOD")) != null ? t : "", f = e.URI, c = e.hexadecimalInteger("IV"), M = e.enumeratedString("KEYFORMATVERSIONS"), w = (d = e.enumeratedString("KEYFORMAT")) != null ? d : "identity";
          f && e.IV && !c && D.logger.error("Invalid IV: " + e.IV);
          var F = f ? u.resolve(f, o) : "", U = (M || "1").split("/").map(Number).filter(Number.isFinite);
          return new I.LevelKey(h, F, w, U, c);
        }
        function s(r, o) {
          ["video", "audio", "text"].forEach(function(t) {
            var d = r.filter(function(h) {
              return (0, _.isCodecType)(h, t);
            });
            if (d.length) {
              var e = d.filter(function(h) {
                return h.lastIndexOf("avc1", 0) === 0 || h.lastIndexOf("mp4a", 0) === 0;
              });
              o[t + "Codec"] = e.length > 0 ? e[0] : d[0], r = r.filter(function(h) {
                return d.indexOf(h) === -1;
              });
            }
          }), o.unknownCodecs = r;
        }
        function m(r, o, t) {
          var d = o[t];
          d && (r[t] = d);
        }
        function v(r, o) {
          for (var t = r[o], d = o; d--; ) {
            var e = r[d];
            if (!e)
              return;
            e.programDateTime = t.programDateTime - e.duration * 1e3, t = e;
          }
        }
        function i(r, o) {
          r.rawProgramDateTime ? r.programDateTime = Date.parse(r.rawProgramDateTime) : o != null && o.programDateTime && (r.programDateTime = o.endProgramDateTime), (0, P.isFiniteNumber)(r.programDateTime) || (r.programDateTime = null, r.rawProgramDateTime = null);
        }
        function n(r, o, t, d) {
          r.relurl = o.URI, o.BYTERANGE && r.setByteRange(o.BYTERANGE), r.level = t, r.sn = "initSegment", d && (r.levelkeys = d), r.initSegment = null;
        }
        function E(r, o, t) {
          r.levelkeys = o;
          var d = t.encryptedFragments;
          (!d.length || d[d.length - 1].levelkeys !== o) && Object.keys(o).some(function(e) {
            return o[e].isCommonEncryption;
          }) && d.push(r);
        }
      },
      "./src/loader/playlist-loader.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => g
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/events.ts"), k = p("./src/errors.ts"), C = p("./src/utils/logger.ts"), B = p("./src/loader/m3u8-parser.ts"), I = p("./src/types/loader.ts"), L = p("./src/utils/attr-list.ts");
        function D(S) {
          var y = S.type;
          switch (y) {
            case I.PlaylistContextType.AUDIO_TRACK:
              return I.PlaylistLevelType.AUDIO;
            case I.PlaylistContextType.SUBTITLE_TRACK:
              return I.PlaylistLevelType.SUBTITLE;
            default:
              return I.PlaylistLevelType.MAIN;
          }
        }
        function _(S, y) {
          var l = S.url;
          return (l === void 0 || l.indexOf("data:") === 0) && (l = y.url), l;
        }
        var x = /* @__PURE__ */ function() {
          function S(l) {
            this.hls = void 0, this.loaders = /* @__PURE__ */ Object.create(null), this.hls = l, this.registerListeners();
          }
          var y = S.prototype;
          return y.startLoad = function(u) {
          }, y.stopLoad = function() {
            this.destroyInternalLoaders();
          }, y.registerListeners = function() {
            var u = this.hls;
            u.on(T.Events.MANIFEST_LOADING, this.onManifestLoading, this), u.on(T.Events.LEVEL_LOADING, this.onLevelLoading, this), u.on(T.Events.AUDIO_TRACK_LOADING, this.onAudioTrackLoading, this), u.on(T.Events.SUBTITLE_TRACK_LOADING, this.onSubtitleTrackLoading, this);
          }, y.unregisterListeners = function() {
            var u = this.hls;
            u.off(T.Events.MANIFEST_LOADING, this.onManifestLoading, this), u.off(T.Events.LEVEL_LOADING, this.onLevelLoading, this), u.off(T.Events.AUDIO_TRACK_LOADING, this.onAudioTrackLoading, this), u.off(T.Events.SUBTITLE_TRACK_LOADING, this.onSubtitleTrackLoading, this);
          }, y.createInternalLoader = function(u) {
            var a = this.hls.config, s = a.pLoader, m = a.loader, v = s || m, i = new v(a);
            return u.loader = i, this.loaders[u.type] = i, i;
          }, y.getInternalLoader = function(u) {
            return this.loaders[u.type];
          }, y.resetInternalLoader = function(u) {
            this.loaders[u] && delete this.loaders[u];
          }, y.destroyInternalLoaders = function() {
            for (var u in this.loaders) {
              var a = this.loaders[u];
              a && a.destroy(), this.resetInternalLoader(u);
            }
          }, y.destroy = function() {
            this.unregisterListeners(), this.destroyInternalLoaders();
          }, y.onManifestLoading = function(u, a) {
            var s = a.url;
            this.load({
              id: null,
              groupId: null,
              level: 0,
              responseType: "text",
              type: I.PlaylistContextType.MANIFEST,
              url: s,
              deliveryDirectives: null
            });
          }, y.onLevelLoading = function(u, a) {
            var s = a.id, m = a.level, v = a.url, i = a.deliveryDirectives;
            this.load({
              id: s,
              groupId: null,
              level: m,
              responseType: "text",
              type: I.PlaylistContextType.LEVEL,
              url: v,
              deliveryDirectives: i
            });
          }, y.onAudioTrackLoading = function(u, a) {
            var s = a.id, m = a.groupId, v = a.url, i = a.deliveryDirectives;
            this.load({
              id: s,
              groupId: m,
              level: null,
              responseType: "text",
              type: I.PlaylistContextType.AUDIO_TRACK,
              url: v,
              deliveryDirectives: i
            });
          }, y.onSubtitleTrackLoading = function(u, a) {
            var s = a.id, m = a.groupId, v = a.url, i = a.deliveryDirectives;
            this.load({
              id: s,
              groupId: m,
              level: null,
              responseType: "text",
              type: I.PlaylistContextType.SUBTITLE_TRACK,
              url: v,
              deliveryDirectives: i
            });
          }, y.load = function(u) {
            var a, s = this.hls.config, m = this.getInternalLoader(u);
            if (m) {
              var v = m.context;
              if (v && v.url === u.url) {
                C.logger.trace("[playlist-loader]: playlist request ongoing");
                return;
              }
              C.logger.log("[playlist-loader]: aborting previous loader for type: " + u.type), m.abort();
            }
            var i, n, E, r;
            switch (u.type) {
              case I.PlaylistContextType.MANIFEST:
                i = s.manifestLoadingMaxRetry, n = s.manifestLoadingTimeOut, E = s.manifestLoadingRetryDelay, r = s.manifestLoadingMaxRetryTimeout;
                break;
              case I.PlaylistContextType.LEVEL:
              case I.PlaylistContextType.AUDIO_TRACK:
              case I.PlaylistContextType.SUBTITLE_TRACK:
                i = 0, n = s.levelLoadingTimeOut;
                break;
              default:
                i = s.levelLoadingMaxRetry, n = s.levelLoadingTimeOut, E = s.levelLoadingRetryDelay, r = s.levelLoadingMaxRetryTimeout;
                break;
            }
            if (m = this.createInternalLoader(u), (a = u.deliveryDirectives) !== null && a !== void 0 && a.part) {
              var o;
              if (u.type === I.PlaylistContextType.LEVEL && u.level !== null ? o = this.hls.levels[u.level].details : u.type === I.PlaylistContextType.AUDIO_TRACK && u.id !== null ? o = this.hls.audioTracks[u.id].details : u.type === I.PlaylistContextType.SUBTITLE_TRACK && u.id !== null && (o = this.hls.subtitleTracks[u.id].details), o) {
                var t = o.partTarget, d = o.targetduration;
                t && d && (n = Math.min(Math.max(t * 3, d * 0.8) * 1e3, n));
              }
            }
            var e = {
              timeout: n,
              maxRetry: i,
              retryDelay: E,
              maxRetryDelay: r,
              highWaterMark: 0
            }, h = {
              onSuccess: this.loadsuccess.bind(this),
              onError: this.loaderror.bind(this),
              onTimeout: this.loadtimeout.bind(this)
            };
            m.load(u, e, h);
          }, y.loadsuccess = function(u, a, s, m) {
            m === void 0 && (m = null), this.resetInternalLoader(s.type);
            var v = u.data;
            if (v.indexOf("#EXTM3U") !== 0) {
              this.handleManifestParsingError(u, s, "no EXTM3U delimiter", m);
              return;
            }
            a.parsing.start = performance.now(), v.indexOf("#EXTINF:") > 0 || v.indexOf("#EXT-X-TARGETDURATION:") > 0 ? this.handleTrackOrLevelPlaylist(u, a, s, m) : this.handleMasterPlaylist(u, a, s, m);
          }, y.loaderror = function(u, a, s) {
            s === void 0 && (s = null), this.handleNetworkError(a, s, !1, u);
          }, y.loadtimeout = function(u, a, s) {
            s === void 0 && (s = null), this.handleNetworkError(a, s, !0);
          }, y.handleMasterPlaylist = function(u, a, s, m) {
            var v = this.hls, i = u.data, n = _(u, s), E = B.default.parseMasterPlaylist(i, n), r = E.levels, o = E.sessionData, t = E.sessionKeys;
            if (!r.length) {
              this.handleManifestParsingError(u, s, "no level found in manifest", m);
              return;
            }
            var d = r.map(function(w) {
              return {
                id: w.attrs.AUDIO,
                audioCodec: w.audioCodec
              };
            }), e = r.map(function(w) {
              return {
                id: w.attrs.SUBTITLES,
                textCodec: w.textCodec
              };
            }), h = B.default.parseMasterPlaylistMedia(i, n, "AUDIO", d), f = B.default.parseMasterPlaylistMedia(i, n, "SUBTITLES", e), c = B.default.parseMasterPlaylistMedia(i, n, "CLOSED-CAPTIONS");
            if (h.length) {
              var M = h.some(function(w) {
                return !w.url;
              });
              !M && r[0].audioCodec && !r[0].attrs.AUDIO && (C.logger.log("[playlist-loader]: audio codec signaled in quality level, but no embedded audio track signaled, create one"), h.unshift({
                type: "main",
                name: "main",
                default: !1,
                autoselect: !1,
                forced: !1,
                id: -1,
                attrs: new L.AttrList({}),
                bitrate: 0,
                url: ""
              }));
            }
            v.trigger(T.Events.MANIFEST_LOADED, {
              levels: r,
              audioTracks: h,
              subtitles: f,
              captions: c,
              url: n,
              stats: a,
              networkDetails: m,
              sessionData: o,
              sessionKeys: t
            });
          }, y.handleTrackOrLevelPlaylist = function(u, a, s, m) {
            var v = this.hls, i = s.id, n = s.level, E = s.type, r = _(u, s), o = (0, P.isFiniteNumber)(i) ? i : 0, t = (0, P.isFiniteNumber)(n) ? n : o, d = D(s), e = B.default.parseLevelPlaylist(u.data, r, t, d, o);
            if (!e.fragments.length) {
              v.trigger(T.Events.ERROR, {
                type: k.ErrorTypes.NETWORK_ERROR,
                details: k.ErrorDetails.LEVEL_EMPTY_ERROR,
                fatal: !1,
                url: r,
                reason: "no fragments found in level",
                level: typeof s.level == "number" ? s.level : void 0
              });
              return;
            }
            if (E === I.PlaylistContextType.MANIFEST) {
              var h = {
                attrs: new L.AttrList({}),
                bitrate: 0,
                details: e,
                name: "",
                url: r
              };
              v.trigger(T.Events.MANIFEST_LOADED, {
                levels: [h],
                audioTracks: [],
                url: r,
                stats: a,
                networkDetails: m,
                sessionData: null,
                sessionKeys: null
              });
            }
            a.parsing.end = performance.now(), s.levelDetails = e, this.handlePlaylistLoaded(u, a, s, m);
          }, y.handleManifestParsingError = function(u, a, s, m) {
            this.hls.trigger(T.Events.ERROR, {
              type: k.ErrorTypes.NETWORK_ERROR,
              details: k.ErrorDetails.MANIFEST_PARSING_ERROR,
              fatal: a.type === I.PlaylistContextType.MANIFEST,
              url: u.url,
              reason: s,
              response: u,
              context: a,
              networkDetails: m
            });
          }, y.handleNetworkError = function(u, a, s, m) {
            s === void 0 && (s = !1), C.logger.warn("[playlist-loader]: A network " + (s ? "timeout" : "error") + " occurred while loading " + u.type + " level: " + u.level + " id: " + u.id + ' group-id: "' + u.groupId + '"');
            var v = k.ErrorDetails.UNKNOWN, i = !1, n = this.getInternalLoader(u);
            switch (u.type) {
              case I.PlaylistContextType.MANIFEST:
                v = s ? k.ErrorDetails.MANIFEST_LOAD_TIMEOUT : k.ErrorDetails.MANIFEST_LOAD_ERROR, i = !0;
                break;
              case I.PlaylistContextType.LEVEL:
                v = s ? k.ErrorDetails.LEVEL_LOAD_TIMEOUT : k.ErrorDetails.LEVEL_LOAD_ERROR, i = !1;
                break;
              case I.PlaylistContextType.AUDIO_TRACK:
                v = s ? k.ErrorDetails.AUDIO_TRACK_LOAD_TIMEOUT : k.ErrorDetails.AUDIO_TRACK_LOAD_ERROR, i = !1;
                break;
              case I.PlaylistContextType.SUBTITLE_TRACK:
                v = s ? k.ErrorDetails.SUBTITLE_TRACK_LOAD_TIMEOUT : k.ErrorDetails.SUBTITLE_LOAD_ERROR, i = !1;
                break;
            }
            n && this.resetInternalLoader(u.type);
            var E = {
              type: k.ErrorTypes.NETWORK_ERROR,
              details: v,
              fatal: i,
              url: u.url,
              loader: n,
              context: u,
              networkDetails: a
            };
            m && (E.response = m), this.hls.trigger(T.Events.ERROR, E);
          }, y.handlePlaylistLoaded = function(u, a, s, m) {
            var v = s.type, i = s.level, n = s.id, E = s.groupId, r = s.loader, o = s.levelDetails, t = s.deliveryDirectives;
            if (!(o != null && o.targetduration)) {
              this.handleManifestParsingError(u, s, "invalid target duration", m);
              return;
            }
            if (!!r)
              switch (o.live && (r.getCacheAge && (o.ageHeader = r.getCacheAge() || 0), (!r.getCacheAge || isNaN(o.ageHeader)) && (o.ageHeader = 0)), v) {
                case I.PlaylistContextType.MANIFEST:
                case I.PlaylistContextType.LEVEL:
                  this.hls.trigger(T.Events.LEVEL_LOADED, {
                    details: o,
                    level: i || 0,
                    id: n || 0,
                    stats: a,
                    networkDetails: m,
                    deliveryDirectives: t
                  });
                  break;
                case I.PlaylistContextType.AUDIO_TRACK:
                  this.hls.trigger(T.Events.AUDIO_TRACK_LOADED, {
                    details: o,
                    id: n || 0,
                    groupId: E || "",
                    stats: a,
                    networkDetails: m,
                    deliveryDirectives: t
                  });
                  break;
                case I.PlaylistContextType.SUBTITLE_TRACK:
                  this.hls.trigger(T.Events.SUBTITLE_TRACK_LOADED, {
                    details: o,
                    id: n || 0,
                    groupId: E || "",
                    stats: a,
                    networkDetails: m,
                    deliveryDirectives: t
                  });
                  break;
              }
          }, S;
        }();
        const g = x;
      },
      "./src/polyfills/number.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          MAX_SAFE_INTEGER: () => T,
          isFiniteNumber: () => P
        });
        var P = Number.isFinite || function(k) {
          return typeof k == "number" && isFinite(k);
        }, T = Number.MAX_SAFE_INTEGER || 9007199254740991;
      },
      "./src/remux/aac-helper.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => T
        });
        var P = /* @__PURE__ */ function() {
          function k() {
          }
          return k.getSilentFrame = function(B, I) {
            switch (B) {
              case "mp4a.40.2":
                if (I === 1)
                  return new Uint8Array([0, 200, 0, 128, 35, 128]);
                if (I === 2)
                  return new Uint8Array([33, 0, 73, 144, 2, 25, 0, 35, 128]);
                if (I === 3)
                  return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 142]);
                if (I === 4)
                  return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 128, 44, 128, 8, 2, 56]);
                if (I === 5)
                  return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 56]);
                if (I === 6)
                  return new Uint8Array([0, 200, 0, 128, 32, 132, 1, 38, 64, 8, 100, 0, 130, 48, 4, 153, 0, 33, 144, 2, 0, 178, 0, 32, 8, 224]);
                break;
              default:
                if (I === 1)
                  return new Uint8Array([1, 64, 34, 128, 163, 78, 230, 128, 186, 8, 0, 0, 0, 28, 6, 241, 193, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
                if (I === 2)
                  return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
                if (I === 3)
                  return new Uint8Array([1, 64, 34, 128, 163, 94, 230, 128, 186, 8, 0, 0, 0, 0, 149, 0, 6, 241, 161, 10, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 90, 94]);
                break;
            }
          }, k;
        }();
        const T = P;
      },
      "./src/remux/mp4-generator.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => k
        });
        var P = Math.pow(2, 32) - 1, T = /* @__PURE__ */ function() {
          function C() {
          }
          return C.init = function() {
            C.types = {
              avc1: [],
              avcC: [],
              btrt: [],
              dinf: [],
              dref: [],
              esds: [],
              ftyp: [],
              hdlr: [],
              mdat: [],
              mdhd: [],
              mdia: [],
              mfhd: [],
              minf: [],
              moof: [],
              moov: [],
              mp4a: [],
              ".mp3": [],
              mvex: [],
              mvhd: [],
              pasp: [],
              sdtp: [],
              stbl: [],
              stco: [],
              stsc: [],
              stsd: [],
              stsz: [],
              stts: [],
              tfdt: [],
              tfhd: [],
              traf: [],
              trak: [],
              trun: [],
              trex: [],
              tkhd: [],
              vmhd: [],
              smhd: []
            };
            var I;
            for (I in C.types)
              C.types.hasOwnProperty(I) && (C.types[I] = [I.charCodeAt(0), I.charCodeAt(1), I.charCodeAt(2), I.charCodeAt(3)]);
            var L = new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              118,
              105,
              100,
              101,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              86,
              105,
              100,
              101,
              111,
              72,
              97,
              110,
              100,
              108,
              101,
              114,
              0
            ]), D = new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              115,
              111,
              117,
              110,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              83,
              111,
              117,
              110,
              100,
              72,
              97,
              110,
              100,
              108,
              101,
              114,
              0
            ]);
            C.HDLR_TYPES = {
              video: L,
              audio: D
            };
            var _ = new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              12,
              117,
              114,
              108,
              32,
              0,
              0,
              0,
              1
            ]), x = new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0
            ]);
            C.STTS = C.STSC = C.STCO = x, C.STSZ = new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0
            ]), C.VMHD = new Uint8Array([
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0
            ]), C.SMHD = new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0
            ]), C.STSD = new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1
            ]);
            var g = new Uint8Array([105, 115, 111, 109]), S = new Uint8Array([97, 118, 99, 49]), y = new Uint8Array([0, 0, 0, 1]);
            C.FTYP = C.box(C.types.ftyp, g, y, g, S), C.DINF = C.box(C.types.dinf, C.box(C.types.dref, _));
          }, C.box = function(I) {
            for (var L = 8, D = arguments.length, _ = new Array(D > 1 ? D - 1 : 0), x = 1; x < D; x++)
              _[x - 1] = arguments[x];
            for (var g = _.length, S = g; g--; )
              L += _[g].byteLength;
            var y = new Uint8Array(L);
            for (y[0] = L >> 24 & 255, y[1] = L >> 16 & 255, y[2] = L >> 8 & 255, y[3] = L & 255, y.set(I, 4), g = 0, L = 8; g < S; g++)
              y.set(_[g], L), L += _[g].byteLength;
            return y;
          }, C.hdlr = function(I) {
            return C.box(C.types.hdlr, C.HDLR_TYPES[I]);
          }, C.mdat = function(I) {
            return C.box(C.types.mdat, I);
          }, C.mdhd = function(I, L) {
            L *= I;
            var D = Math.floor(L / (P + 1)), _ = Math.floor(L % (P + 1));
            return C.box(C.types.mdhd, new Uint8Array([
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              3,
              I >> 24 & 255,
              I >> 16 & 255,
              I >> 8 & 255,
              I & 255,
              D >> 24,
              D >> 16 & 255,
              D >> 8 & 255,
              D & 255,
              _ >> 24,
              _ >> 16 & 255,
              _ >> 8 & 255,
              _ & 255,
              85,
              196,
              0,
              0
            ]));
          }, C.mdia = function(I) {
            return C.box(C.types.mdia, C.mdhd(I.timescale, I.duration), C.hdlr(I.type), C.minf(I));
          }, C.mfhd = function(I) {
            return C.box(C.types.mfhd, new Uint8Array([
              0,
              0,
              0,
              0,
              I >> 24,
              I >> 16 & 255,
              I >> 8 & 255,
              I & 255
            ]));
          }, C.minf = function(I) {
            return I.type === "audio" ? C.box(C.types.minf, C.box(C.types.smhd, C.SMHD), C.DINF, C.stbl(I)) : C.box(C.types.minf, C.box(C.types.vmhd, C.VMHD), C.DINF, C.stbl(I));
          }, C.moof = function(I, L, D) {
            return C.box(C.types.moof, C.mfhd(I), C.traf(D, L));
          }, C.moov = function(I) {
            for (var L = I.length, D = []; L--; )
              D[L] = C.trak(I[L]);
            return C.box.apply(null, [C.types.moov, C.mvhd(I[0].timescale, I[0].duration)].concat(D).concat(C.mvex(I)));
          }, C.mvex = function(I) {
            for (var L = I.length, D = []; L--; )
              D[L] = C.trex(I[L]);
            return C.box.apply(null, [C.types.mvex].concat(D));
          }, C.mvhd = function(I, L) {
            L *= I;
            var D = Math.floor(L / (P + 1)), _ = Math.floor(L % (P + 1)), x = new Uint8Array([
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              3,
              I >> 24 & 255,
              I >> 16 & 255,
              I >> 8 & 255,
              I & 255,
              D >> 24,
              D >> 16 & 255,
              D >> 8 & 255,
              D & 255,
              _ >> 24,
              _ >> 16 & 255,
              _ >> 8 & 255,
              _ & 255,
              0,
              1,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              64,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              255,
              255,
              255,
              255
            ]);
            return C.box(C.types.mvhd, x);
          }, C.sdtp = function(I) {
            var L = I.samples || [], D = new Uint8Array(4 + L.length), _, x;
            for (_ = 0; _ < L.length; _++)
              x = L[_].flags, D[_ + 4] = x.dependsOn << 4 | x.isDependedOn << 2 | x.hasRedundancy;
            return C.box(C.types.sdtp, D);
          }, C.stbl = function(I) {
            return C.box(C.types.stbl, C.stsd(I), C.box(C.types.stts, C.STTS), C.box(C.types.stsc, C.STSC), C.box(C.types.stsz, C.STSZ), C.box(C.types.stco, C.STCO));
          }, C.avc1 = function(I) {
            var L = [], D = [], _, x, g;
            for (_ = 0; _ < I.sps.length; _++)
              x = I.sps[_], g = x.byteLength, L.push(g >>> 8 & 255), L.push(g & 255), L = L.concat(Array.prototype.slice.call(x));
            for (_ = 0; _ < I.pps.length; _++)
              x = I.pps[_], g = x.byteLength, D.push(g >>> 8 & 255), D.push(g & 255), D = D.concat(Array.prototype.slice.call(x));
            var S = C.box(C.types.avcC, new Uint8Array([
              1,
              L[3],
              L[4],
              L[5],
              255,
              224 | I.sps.length
            ].concat(L).concat([
              I.pps.length
            ]).concat(D))), y = I.width, l = I.height, u = I.pixelRatio[0], a = I.pixelRatio[1];
            return C.box(
              C.types.avc1,
              new Uint8Array([
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                1,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                y >> 8 & 255,
                y & 255,
                l >> 8 & 255,
                l & 255,
                0,
                72,
                0,
                0,
                0,
                72,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                1,
                18,
                100,
                97,
                105,
                108,
                121,
                109,
                111,
                116,
                105,
                111,
                110,
                47,
                104,
                108,
                115,
                46,
                106,
                115,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                0,
                24,
                17,
                17
              ]),
              S,
              C.box(C.types.btrt, new Uint8Array([
                0,
                28,
                156,
                128,
                0,
                45,
                198,
                192,
                0,
                45,
                198,
                192
              ])),
              C.box(C.types.pasp, new Uint8Array([
                u >> 24,
                u >> 16 & 255,
                u >> 8 & 255,
                u & 255,
                a >> 24,
                a >> 16 & 255,
                a >> 8 & 255,
                a & 255
              ]))
            );
          }, C.esds = function(I) {
            var L = I.config.length;
            return new Uint8Array([
              0,
              0,
              0,
              0,
              3,
              23 + L,
              0,
              1,
              0,
              4,
              15 + L,
              64,
              21,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              5
            ].concat([L]).concat(I.config).concat([6, 1, 2]));
          }, C.mp4a = function(I) {
            var L = I.samplerate;
            return C.box(C.types.mp4a, new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              I.channelCount,
              0,
              16,
              0,
              0,
              0,
              0,
              L >> 8 & 255,
              L & 255,
              0,
              0
            ]), C.box(C.types.esds, C.esds(I)));
          }, C.mp3 = function(I) {
            var L = I.samplerate;
            return C.box(C.types[".mp3"], new Uint8Array([
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              I.channelCount,
              0,
              16,
              0,
              0,
              0,
              0,
              L >> 8 & 255,
              L & 255,
              0,
              0
            ]));
          }, C.stsd = function(I) {
            return I.type === "audio" ? I.segmentCodec === "mp3" && I.codec === "mp3" ? C.box(C.types.stsd, C.STSD, C.mp3(I)) : C.box(C.types.stsd, C.STSD, C.mp4a(I)) : C.box(C.types.stsd, C.STSD, C.avc1(I));
          }, C.tkhd = function(I) {
            var L = I.id, D = I.duration * I.timescale, _ = I.width, x = I.height, g = Math.floor(D / (P + 1)), S = Math.floor(D % (P + 1));
            return C.box(C.types.tkhd, new Uint8Array([
              1,
              0,
              0,
              7,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              2,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              3,
              L >> 24 & 255,
              L >> 16 & 255,
              L >> 8 & 255,
              L & 255,
              0,
              0,
              0,
              0,
              g >> 24,
              g >> 16 & 255,
              g >> 8 & 255,
              g & 255,
              S >> 24,
              S >> 16 & 255,
              S >> 8 & 255,
              S & 255,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              64,
              0,
              0,
              0,
              _ >> 8 & 255,
              _ & 255,
              0,
              0,
              x >> 8 & 255,
              x & 255,
              0,
              0
            ]));
          }, C.traf = function(I, L) {
            var D = C.sdtp(I), _ = I.id, x = Math.floor(L / (P + 1)), g = Math.floor(L % (P + 1));
            return C.box(
              C.types.traf,
              C.box(C.types.tfhd, new Uint8Array([
                0,
                0,
                0,
                0,
                _ >> 24,
                _ >> 16 & 255,
                _ >> 8 & 255,
                _ & 255
              ])),
              C.box(C.types.tfdt, new Uint8Array([
                1,
                0,
                0,
                0,
                x >> 24,
                x >> 16 & 255,
                x >> 8 & 255,
                x & 255,
                g >> 24,
                g >> 16 & 255,
                g >> 8 & 255,
                g & 255
              ])),
              C.trun(I, D.length + 16 + 20 + 8 + 16 + 8 + 8),
              D
            );
          }, C.trak = function(I) {
            return I.duration = I.duration || 4294967295, C.box(C.types.trak, C.tkhd(I), C.mdia(I));
          }, C.trex = function(I) {
            var L = I.id;
            return C.box(C.types.trex, new Uint8Array([
              0,
              0,
              0,
              0,
              L >> 24,
              L >> 16 & 255,
              L >> 8 & 255,
              L & 255,
              0,
              0,
              0,
              1,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              0,
              1,
              0,
              1
            ]));
          }, C.trun = function(I, L) {
            var D = I.samples || [], _ = D.length, x = 12 + 16 * _, g = new Uint8Array(x), S, y, l, u, a, s;
            for (L += 8 + x, g.set([
              I.type === "video" ? 1 : 0,
              0,
              15,
              1,
              _ >>> 24 & 255,
              _ >>> 16 & 255,
              _ >>> 8 & 255,
              _ & 255,
              L >>> 24 & 255,
              L >>> 16 & 255,
              L >>> 8 & 255,
              L & 255
            ], 0), S = 0; S < _; S++)
              y = D[S], l = y.duration, u = y.size, a = y.flags, s = y.cts, g.set([
                l >>> 24 & 255,
                l >>> 16 & 255,
                l >>> 8 & 255,
                l & 255,
                u >>> 24 & 255,
                u >>> 16 & 255,
                u >>> 8 & 255,
                u & 255,
                a.isLeading << 2 | a.dependsOn,
                a.isDependedOn << 6 | a.hasRedundancy << 4 | a.paddingValue << 1 | a.isNonSync,
                a.degradPrio & 240 << 8,
                a.degradPrio & 15,
                s >>> 24 & 255,
                s >>> 16 & 255,
                s >>> 8 & 255,
                s & 255
              ], 12 + 16 * S);
            return C.box(C.types.trun, g);
          }, C.initSegment = function(I) {
            C.types || C.init();
            var L = C.moov(I), D = new Uint8Array(C.FTYP.byteLength + L.byteLength);
            return D.set(C.FTYP), D.set(L, C.FTYP.byteLength), D;
          }, C;
        }();
        T.types = void 0, T.HDLR_TYPES = void 0, T.STTS = void 0, T.STSC = void 0, T.STCO = void 0, T.STSZ = void 0, T.VMHD = void 0, T.SMHD = void 0, T.STSD = void 0, T.FTYP = void 0, T.DINF = void 0;
        const k = T;
      },
      "./src/remux/mp4-remuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => u,
          flushTextTrackMetadataCueSamples: () => m,
          flushTextTrackUserdataCueSamples: () => v,
          normalizePts: () => a
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/remux/aac-helper.ts"), k = p("./src/remux/mp4-generator.ts"), C = p("./src/events.ts"), B = p("./src/errors.ts"), I = p("./src/utils/logger.ts"), L = p("./src/types/loader.ts"), D = p("./src/utils/timescale-conversion.ts");
        function _() {
          return _ = Object.assign ? Object.assign.bind() : function(E) {
            for (var r = 1; r < arguments.length; r++) {
              var o = arguments[r];
              for (var t in o)
                Object.prototype.hasOwnProperty.call(o, t) && (E[t] = o[t]);
            }
            return E;
          }, _.apply(this, arguments);
        }
        var x = 10 * 1e3, g = 1024, S = 1152, y = null, l = null, u = /* @__PURE__ */ function() {
          function E(o, t, d, e) {
            if (this.observer = void 0, this.config = void 0, this.typeSupported = void 0, this.ISGenerated = !1, this._initPTS = void 0, this._initDTS = void 0, this.nextAvcDts = null, this.nextAudioPts = null, this.videoSampleDuration = null, this.isAudioContiguous = !1, this.isVideoContiguous = !1, this.observer = o, this.config = t, this.typeSupported = d, this.ISGenerated = !1, y === null) {
              var h = navigator.userAgent || "", f = h.match(/Chrome\/(\d+)/i);
              y = f ? parseInt(f[1]) : 0;
            }
            if (l === null) {
              var c = navigator.userAgent.match(/Safari\/(\d+)/i);
              l = c ? parseInt(c[1]) : 0;
            }
          }
          var r = E.prototype;
          return r.destroy = function() {
          }, r.resetTimeStamp = function(t) {
            I.logger.log("[mp4-remuxer]: initPTS & initDTS reset"), this._initPTS = this._initDTS = t;
          }, r.resetNextTimestamp = function() {
            I.logger.log("[mp4-remuxer]: reset next timestamp"), this.isVideoContiguous = !1, this.isAudioContiguous = !1;
          }, r.resetInitSegment = function() {
            I.logger.log("[mp4-remuxer]: ISGenerated flag reset"), this.ISGenerated = !1;
          }, r.getVideoStartPts = function(t) {
            var d = !1, e = t.reduce(function(h, f) {
              var c = f.pts - h;
              return c < -4294967296 ? (d = !0, a(h, f.pts)) : c > 0 ? h : f.pts;
            }, t[0].pts);
            return d && I.logger.debug("PTS rollover detected"), e;
          }, r.remux = function(t, d, e, h, f, c, M, w) {
            var F, U, N, H, j, z, Y = f, X = f, Z = t.pid > -1, te = d.pid > -1, $ = d.samples.length, ee = t.samples.length > 0, ne = M && $ > 0 || $ > 1, oe = (!Z || ee) && (!te || ne) || this.ISGenerated || M;
            if (oe) {
              this.ISGenerated || (N = this.generateIS(t, d, f));
              var ae = this.isVideoContiguous, ie = -1, ce;
              if (ne && (ie = s(d.samples), !ae && this.config.forceKeyFrameOnDiscontinuity))
                if (z = !0, ie > 0) {
                  I.logger.warn("[mp4-remuxer]: Dropped " + ie + " out of " + $ + " video samples due to a missing keyframe");
                  var me = this.getVideoStartPts(d.samples);
                  d.samples = d.samples.slice(ie), d.dropped += ie, X += (d.samples[0].pts - me) / d.inputTimeScale, ce = X;
                } else
                  ie === -1 && (I.logger.warn("[mp4-remuxer]: No keyframe found out of " + $ + " video samples"), z = !1);
              if (this.ISGenerated) {
                if (ee && ne) {
                  var pe = this.getVideoStartPts(d.samples), Ie = a(t.samples[0].pts, pe) - pe, Ee = Ie / d.inputTimeScale;
                  Y += Math.max(0, Ee), X += Math.max(0, -Ee);
                }
                if (ee) {
                  if (t.samplerate || (I.logger.warn("[mp4-remuxer]: regenerate InitSegment as audio detected"), N = this.generateIS(t, d, f)), U = this.remuxAudio(t, Y, this.isAudioContiguous, c, te || ne || w === L.PlaylistLevelType.AUDIO ? X : void 0), ne) {
                    var _e = U ? U.endPTS - U.startPTS : 0;
                    d.inputTimeScale || (I.logger.warn("[mp4-remuxer]: regenerate InitSegment as video detected"), N = this.generateIS(t, d, f)), F = this.remuxVideo(d, X, ae, _e);
                  }
                } else
                  ne && (F = this.remuxVideo(d, X, ae, 0));
                F && (F.firstKeyFrame = ie, F.independent = ie !== -1, F.firstKeyFramePTS = ce);
              }
            }
            return this.ISGenerated && (e.samples.length && (j = m(e, f, this._initPTS, this._initDTS)), h.samples.length && (H = v(h, f, this._initPTS))), {
              audio: U,
              video: F,
              initSegment: N,
              independent: z,
              text: H,
              id3: j
            };
          }, r.generateIS = function(t, d, e) {
            var h = t.samples, f = d.samples, c = this.typeSupported, M = {}, w = !(0, P.isFiniteNumber)(this._initPTS), F = "audio/mp4", U, N, H;
            if (w && (U = N = 1 / 0), t.config && h.length) {
              switch (t.timescale = t.samplerate, t.segmentCodec) {
                case "mp3":
                  c.mpeg ? (F = "audio/mpeg", t.codec = "") : c.mp3 && (t.codec = "mp3");
                  break;
              }
              M.audio = {
                id: "audio",
                container: F,
                codec: t.codec,
                initSegment: t.segmentCodec === "mp3" && c.mpeg ? new Uint8Array(0) : k.default.initSegment([t]),
                metadata: {
                  channelCount: t.channelCount
                }
              }, w && (H = t.inputTimeScale, U = N = h[0].pts - Math.round(H * e));
            }
            if (d.sps && d.pps && f.length && (d.timescale = d.inputTimeScale, M.video = {
              id: "main",
              container: "video/mp4",
              codec: d.codec,
              initSegment: k.default.initSegment([d]),
              metadata: {
                width: d.width,
                height: d.height
              }
            }, w)) {
              H = d.inputTimeScale;
              var j = this.getVideoStartPts(f), z = Math.round(H * e);
              N = Math.min(N, a(f[0].dts, j) - z), U = Math.min(U, j - z);
            }
            if (Object.keys(M).length)
              return this.ISGenerated = !0, w && (this._initPTS = U, this._initDTS = N), {
                tracks: M,
                initPTS: U,
                timescale: H
              };
          }, r.remuxVideo = function(t, d, e, h) {
            var f = t.inputTimeScale, c = t.samples, M = [], w = c.length, F = this._initPTS, U = this.nextAvcDts, N = 8, H = this.videoSampleDuration, j, z, Y = Number.POSITIVE_INFINITY, X = Number.NEGATIVE_INFINITY, Z = !1;
            if (!e || U === null) {
              var te = d * f, $ = c[0].pts - a(c[0].dts, c[0].pts);
              U = te - $;
            }
            for (var ee = 0; ee < w; ee++) {
              var ne = c[ee];
              ne.pts = a(ne.pts - F, U), ne.dts = a(ne.dts - F, U), ne.dts < c[ee > 0 ? ee - 1 : ee].dts && (Z = !0);
            }
            Z && c.sort(function(Ut, Zt) {
              var si = Ut.dts - Zt.dts, ai = Ut.pts - Zt.pts;
              return si || ai;
            }), j = c[0].dts, z = c[c.length - 1].dts;
            var oe = z - j, ae = oe ? Math.round(oe / (w - 1)) : H || t.inputTimeScale / 30;
            if (e) {
              var ie = j - U, ce = ie > ae, me = ie < -1;
              if ((ce || me) && (ce ? I.logger.warn("AVC: " + (0, D.toMsFromMpegTsClock)(ie, !0) + " ms (" + ie + "dts) hole between fragments detected, filling it") : I.logger.warn("AVC: " + (0, D.toMsFromMpegTsClock)(-ie, !0) + " ms (" + ie + "dts) overlapping between fragments detected"), !me || U > c[0].pts)) {
                j = U;
                var pe = c[0].pts - ie;
                c[0].dts = j, c[0].pts = pe, I.logger.log("Video: First PTS/DTS adjusted: " + (0, D.toMsFromMpegTsClock)(pe, !0) + "/" + (0, D.toMsFromMpegTsClock)(j, !0) + ", delta: " + (0, D.toMsFromMpegTsClock)(ie, !0) + " ms");
              }
            }
            j = Math.max(0, j);
            for (var Ie = 0, Ee = 0, _e = 0; _e < w; _e++) {
              for (var Te = c[_e], Se = Te.units, xe = Se.length, Re = 0, we = 0; we < xe; we++)
                Re += Se[we].data.length;
              Ee += Re, Ie += xe, Te.length = Re, Te.dts = Math.max(Te.dts, j), Y = Math.min(Te.pts, Y), X = Math.max(Te.pts, X);
            }
            z = c[w - 1].dts;
            var Ce = Ee + 4 * Ie + 8, Me;
            try {
              Me = new Uint8Array(Ce);
            } catch {
              this.observer.emit(C.Events.ERROR, C.Events.ERROR, {
                type: B.ErrorTypes.MUX_ERROR,
                details: B.ErrorDetails.REMUX_ALLOC_ERROR,
                fatal: !1,
                bytes: Ce,
                reason: "fail allocating video mdat " + Ce
              });
              return;
            }
            var Ge = new DataView(Me.buffer);
            Ge.setUint32(0, Ce), Me.set(k.default.types.mdat, 4);
            for (var ye = !1, st = Number.POSITIVE_INFINITY, Xe = Number.POSITIVE_INFINITY, He = Number.NEGATIVE_INFINITY, Ve = Number.NEGATIVE_INFINITY, Ue = 0; Ue < w; Ue++) {
              for (var Be = c[Ue], je = Be.units, Qe = 0, Oe = 0, qe = je.length; Oe < qe; Oe++) {
                var Ze = je[Oe], pt = Ze.data, ut = Ze.data.byteLength;
                Ge.setUint32(N, ut), N += 4, Me.set(pt, N), N += ut, Qe += 4 + ut;
              }
              var ht = void 0;
              if (Ue < w - 1)
                H = c[Ue + 1].dts - Be.dts, ht = c[Ue + 1].pts - Be.pts;
              else {
                var Pt = this.config, yt = Ue > 0 ? Be.dts - c[Ue - 1].dts : ae;
                if (ht = Ue > 0 ? Be.pts - c[Ue - 1].pts : ae, Pt.stretchShortVideoTrack && this.nextAudioPts !== null) {
                  var Bt = Math.floor(Pt.maxBufferHole * f), q = (h ? Y + h * f : this.nextAudioPts) - Be.pts;
                  q > Bt ? (H = q - yt, H < 0 ? H = yt : ye = !0, I.logger.log("[mp4-remuxer]: It is approximately " + q / 90 + " ms to the next segment; using duration " + H / 90 + " ms for the last video frame.")) : H = yt;
                } else
                  H = yt;
              }
              var ge = Math.round(Be.pts - Be.dts);
              st = Math.min(st, H), He = Math.max(He, H), Xe = Math.min(Xe, ht), Ve = Math.max(Ve, ht), M.push(new i(Be.key, H, Qe, ge));
            }
            if (M.length) {
              if (y) {
                if (y < 70) {
                  var Ne = M[0].flags;
                  Ne.dependsOn = 2, Ne.isNonSync = 0;
                }
              } else if (l && Ve - Xe < He - st && ae / He < 0.025 && M[0].cts === 0) {
                I.logger.warn("Found irregular gaps in sample duration. Using PTS instead of DTS to determine MP4 sample duration.");
                for (var Je = j, ze = 0, Xt = M.length; ze < Xt; ze++) {
                  var Qt = Je + M[ze].duration, ei = Je + M[ze].cts;
                  if (ze < Xt - 1) {
                    var ti = Qt + M[ze + 1].cts;
                    M[ze].duration = ti - ei;
                  } else
                    M[ze].duration = ze ? M[ze - 1].duration : ae;
                  M[ze].cts = 0, Je = Qt;
                }
              }
            }
            console.assert(H !== null, "mp4SampleDuration must be computed"), H = ye || !H ? ae : H, this.nextAvcDts = U = z + H, this.videoSampleDuration = H, this.isVideoContiguous = !0;
            var ri = k.default.moof(t.sequenceNumber++, j, _({}, t, {
              samples: M
            })), ii = "video", ni = {
              data1: ri,
              data2: Me,
              startPTS: Y / f,
              endPTS: (X + H) / f,
              startDTS: j / f,
              endDTS: U / f,
              type: ii,
              hasAudio: !1,
              hasVideo: !0,
              nb: M.length,
              dropped: t.dropped
            };
            return t.samples = [], t.dropped = 0, console.assert(Me.length, "MDAT length must not be zero"), ni;
          }, r.remuxAudio = function(t, d, e, h, f) {
            var c = t.inputTimeScale, M = t.samplerate ? t.samplerate : c, w = c / M, F = t.segmentCodec === "aac" ? g : S, U = F * w, N = this._initPTS, H = t.segmentCodec === "mp3" && this.typeSupported.mpeg, j = [], z = f !== void 0, Y = t.samples, X = H ? 0 : 8, Z = this.nextAudioPts || -1, te = d * c;
            if (this.isAudioContiguous = e = e || Y.length && Z > 0 && (h && Math.abs(te - Z) < 9e3 || Math.abs(a(Y[0].pts - N, te) - Z) < 20 * U), Y.forEach(function(Ze) {
              Ze.pts = a(Ze.pts - N, te);
            }), !e || Z < 0) {
              if (Y = Y.filter(function(Ze) {
                return Ze.pts >= 0;
              }), !Y.length)
                return;
              f === 0 ? Z = 0 : h && !z ? Z = Math.max(0, te) : Z = Y[0].pts;
            }
            if (t.segmentCodec === "aac")
              for (var $ = this.config.maxAudioFramesDrift, ee = 0, ne = Z; ee < Y.length; ee++) {
                var oe = Y[ee], ae = oe.pts, ie = ae - ne, ce = Math.abs(1e3 * ie / c);
                if (ie <= -$ * U && z)
                  ee === 0 && (I.logger.warn("Audio frame @ " + (ae / c).toFixed(3) + "s overlaps nextAudioPts by " + Math.round(1e3 * ie / c) + " ms."), this.nextAudioPts = Z = ne = ae);
                else if (ie >= $ * U && ce < x && z) {
                  var me = Math.round(ie / U);
                  ne = ae - me * U, ne < 0 && (me--, ne += U), ee === 0 && (this.nextAudioPts = Z = ne), I.logger.warn("[mp4-remuxer]: Injecting " + me + " audio frame @ " + (ne / c).toFixed(3) + "s due to " + Math.round(1e3 * ie / c) + " ms gap.");
                  for (var pe = 0; pe < me; pe++) {
                    var Ie = Math.max(ne, 0), Ee = T.default.getSilentFrame(t.manifestCodec || t.codec, t.channelCount);
                    Ee || (I.logger.log("[mp4-remuxer]: Unable to get silent frame for given audio codec; duplicating last frame instead."), Ee = oe.unit.subarray()), Y.splice(ee, 0, {
                      unit: Ee,
                      pts: Ie
                    }), ne += U, ee++;
                  }
                }
                oe.pts = ne, ne += U;
              }
            for (var _e = null, Te = null, Se, xe = 0, Re = Y.length; Re--; )
              xe += Y[Re].unit.byteLength;
            for (var we = 0, Ce = Y.length; we < Ce; we++) {
              var Me = Y[we], Ge = Me.unit, ye = Me.pts;
              if (Te !== null) {
                var st = j[we - 1];
                st.duration = Math.round((ye - Te) / w);
              } else if (e && t.segmentCodec === "aac" && (ye = Z), _e = ye, xe > 0) {
                xe += X;
                try {
                  Se = new Uint8Array(xe);
                } catch {
                  this.observer.emit(C.Events.ERROR, C.Events.ERROR, {
                    type: B.ErrorTypes.MUX_ERROR,
                    details: B.ErrorDetails.REMUX_ALLOC_ERROR,
                    fatal: !1,
                    bytes: xe,
                    reason: "fail allocating audio mdat " + xe
                  });
                  return;
                }
                if (!H) {
                  var Xe = new DataView(Se.buffer);
                  Xe.setUint32(0, xe), Se.set(k.default.types.mdat, 4);
                }
              } else
                return;
              Se.set(Ge, X);
              var He = Ge.byteLength;
              X += He, j.push(new i(!0, F, He, 0)), Te = ye;
            }
            var Ve = j.length;
            if (!!Ve) {
              var Ue = j[j.length - 1];
              this.nextAudioPts = Z = Te + w * Ue.duration;
              var Be = H ? new Uint8Array(0) : k.default.moof(t.sequenceNumber++, _e / w, _({}, t, {
                samples: j
              }));
              t.samples = [];
              var je = _e / c, Qe = Z / c, Oe = "audio", qe = {
                data1: Be,
                data2: Se,
                startPTS: je,
                endPTS: Qe,
                startDTS: je,
                endDTS: Qe,
                type: Oe,
                hasAudio: !0,
                hasVideo: !1,
                nb: Ve
              };
              return this.isAudioContiguous = !0, console.assert(Se.length, "MDAT length must not be zero"), qe;
            }
          }, r.remuxEmptyAudio = function(t, d, e, h) {
            var f = t.inputTimeScale, c = t.samplerate ? t.samplerate : f, M = f / c, w = this.nextAudioPts, F = (w !== null ? w : h.startDTS * f) + this._initDTS, U = h.endDTS * f + this._initDTS, N = M * g, H = Math.ceil((U - F) / N), j = T.default.getSilentFrame(t.manifestCodec || t.codec, t.channelCount);
            if (I.logger.warn("[mp4-remuxer]: remux empty Audio"), !j) {
              I.logger.trace("[mp4-remuxer]: Unable to remuxEmptyAudio since we were unable to get a silent frame for given audio codec");
              return;
            }
            for (var z = [], Y = 0; Y < H; Y++) {
              var X = F + Y * N;
              z.push({
                unit: j,
                pts: X,
                dts: X
              });
            }
            return t.samples = z, this.remuxAudio(t, d, e, !1);
          }, E;
        }();
        function a(E, r) {
          var o;
          if (r === null)
            return E;
          for (r < E ? o = -8589934592 : o = 8589934592; Math.abs(E - r) > 4294967296; )
            E += o;
          return E;
        }
        function s(E) {
          for (var r = 0; r < E.length; r++)
            if (E[r].key)
              return r;
          return -1;
        }
        function m(E, r, o, t) {
          var d = E.samples.length;
          if (!!d) {
            for (var e = E.inputTimeScale, h = 0; h < d; h++) {
              var f = E.samples[h];
              f.pts = a(f.pts - o, r * e) / e, f.dts = a(f.dts - t, r * e) / e;
            }
            var c = E.samples;
            return E.samples = [], {
              samples: c
            };
          }
        }
        function v(E, r, o) {
          var t = E.samples.length;
          if (!!t) {
            for (var d = E.inputTimeScale, e = 0; e < t; e++) {
              var h = E.samples[e];
              h.pts = a(h.pts - o, r * d) / d;
            }
            E.samples.sort(function(c, M) {
              return c.pts - M.pts;
            });
            var f = E.samples;
            return E.samples = [], {
              samples: f
            };
          }
        }
        var i = function(r, o, t, d) {
          this.size = void 0, this.duration = void 0, this.cts = void 0, this.flags = void 0, this.duration = o, this.size = t, this.cts = d, this.flags = new n(r);
        }, n = function(r) {
          this.isLeading = 0, this.isDependedOn = 0, this.hasRedundancy = 0, this.degradPrio = 0, this.dependsOn = 1, this.isNonSync = 1, this.dependsOn = r ? 2 : 1, this.isNonSync = r ? 0 : 1;
        };
      },
      "./src/remux/passthrough-remuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => D
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/remux/mp4-remuxer.ts"), k = p("./src/utils/mp4-tools.ts"), C = p("./src/loader/fragment.ts"), B = p("./src/utils/logger.ts"), I = /* @__PURE__ */ function() {
          function _() {
            this.emitInitSegment = !1, this.audioCodec = void 0, this.videoCodec = void 0, this.initData = void 0, this.initPTS = void 0, this.initTracks = void 0, this.lastEndTime = null;
          }
          var x = _.prototype;
          return x.destroy = function() {
          }, x.resetTimeStamp = function(S) {
            this.initPTS = S, this.lastEndTime = null;
          }, x.resetNextTimestamp = function() {
            this.lastEndTime = null;
          }, x.resetInitSegment = function(S, y, l, u) {
            this.audioCodec = y, this.videoCodec = l, this.generateInitSegment((0, k.patchEncyptionData)(S, u)), this.emitInitSegment = !0;
          }, x.generateInitSegment = function(S) {
            var y = this.audioCodec, l = this.videoCodec;
            if (!S || !S.byteLength) {
              this.initTracks = void 0, this.initData = void 0;
              return;
            }
            var u = this.initData = (0, k.parseInitSegment)(S);
            y || (y = L(u.audio, C.ElementaryStreamTypes.AUDIO)), l || (l = L(u.video, C.ElementaryStreamTypes.VIDEO));
            var a = {};
            u.audio && u.video ? a.audiovideo = {
              container: "video/mp4",
              codec: y + "," + l,
              initSegment: S,
              id: "main"
            } : u.audio ? a.audio = {
              container: "audio/mp4",
              codec: y,
              initSegment: S,
              id: "audio"
            } : u.video ? a.video = {
              container: "video/mp4",
              codec: l,
              initSegment: S,
              id: "main"
            } : B.logger.warn("[passthrough-remuxer.ts]: initSegment does not contain moov or trak boxes."), this.initTracks = a;
          }, x.remux = function(S, y, l, u, a) {
            var s, m = this.initPTS, v = this.lastEndTime, i = {
              audio: void 0,
              video: void 0,
              text: u,
              id3: l,
              initSegment: void 0
            };
            (0, P.isFiniteNumber)(v) || (v = this.lastEndTime = a || 0);
            var n = y.samples;
            if (!n || !n.length)
              return i;
            var E = {
              initPTS: void 0,
              timescale: 1
            }, r = this.initData;
            if ((!r || !r.length) && (this.generateInitSegment(n), r = this.initData), !r || !r.length)
              return B.logger.warn("[passthrough-remuxer.ts]: Failed to generate initSegment."), i;
            this.emitInitSegment && (E.tracks = this.initTracks, this.emitInitSegment = !1);
            var o = (0, k.getStartDTS)(r, n);
            (0, P.isFiniteNumber)(m) || (this.initPTS = E.initPTS = m = o - a);
            var t = (0, k.getDuration)(n, r), d = S ? o - m : v, e = d + t;
            (0, k.offsetStartDTS)(r, n, m), t > 0 ? this.lastEndTime = e : (B.logger.warn("Duration parsed from mp4 should be greater than zero"), this.resetNextTimestamp());
            var h = !!r.audio, f = !!r.video, c = "";
            h && (c += "audio"), f && (c += "video");
            var M = {
              data1: n,
              startPTS: d,
              startDTS: d,
              endPTS: e,
              endDTS: e,
              type: c,
              hasAudio: h,
              hasVideo: f,
              nb: 1,
              dropped: 0
            };
            i.audio = M.type === "audio" ? M : void 0, i.video = M.type !== "audio" ? M : void 0, i.initSegment = E;
            var w = (s = this.initPTS) != null ? s : 0;
            return i.id3 = (0, T.flushTextTrackMetadataCueSamples)(l, a, w, w), u.samples.length && (i.text = (0, T.flushTextTrackUserdataCueSamples)(u, a, w)), i;
          }, _;
        }();
        function L(_, x) {
          var g = _ == null ? void 0 : _.codec;
          return g && g.length > 4 ? g : g === "hvc1" || g === "hev1" ? "hvc1.1.c.L120.90" : g === "av01" ? "av01.0.04M.08" : g === "avc1" || x === C.ElementaryStreamTypes.VIDEO ? "avc1.42e01e" : "mp4a.40.5";
        }
        const D = I;
      },
      "./src/task-loop.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => P
        });
        var P = /* @__PURE__ */ function() {
          function T() {
            this._boundTick = void 0, this._tickTimer = null, this._tickInterval = null, this._tickCallCount = 0, this._boundTick = this.tick.bind(this);
          }
          var k = T.prototype;
          return k.destroy = function() {
            this.onHandlerDestroying(), this.onHandlerDestroyed();
          }, k.onHandlerDestroying = function() {
            this.clearNextTick(), this.clearInterval();
          }, k.onHandlerDestroyed = function() {
          }, k.hasInterval = function() {
            return !!this._tickInterval;
          }, k.hasNextTick = function() {
            return !!this._tickTimer;
          }, k.setInterval = function(B) {
            return this._tickInterval ? !1 : (this._tickInterval = self.setInterval(this._boundTick, B), !0);
          }, k.clearInterval = function() {
            return this._tickInterval ? (self.clearInterval(this._tickInterval), this._tickInterval = null, !0) : !1;
          }, k.clearNextTick = function() {
            return this._tickTimer ? (self.clearTimeout(this._tickTimer), this._tickTimer = null, !0) : !1;
          }, k.tick = function() {
            this._tickCallCount++, this._tickCallCount === 1 && (this.doTick(), this._tickCallCount > 1 && this.tickImmediate(), this._tickCallCount = 0);
          }, k.tickImmediate = function() {
            this.clearNextTick(), this._tickTimer = self.setTimeout(this._boundTick, 0);
          }, k.doTick = function() {
          }, T;
        }();
      },
      "./src/types/cmcd.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          CMCDObjectType: () => T,
          CMCDStreamType: () => C,
          CMCDStreamingFormat: () => k,
          CMCDVersion: () => P
        });
        var P = 1, T;
        (function(B) {
          B.MANIFEST = "m", B.AUDIO = "a", B.VIDEO = "v", B.MUXED = "av", B.INIT = "i", B.CAPTION = "c", B.TIMED_TEXT = "tt", B.KEY = "k", B.OTHER = "o";
        })(T || (T = {}));
        var k;
        (function(B) {
          B.DASH = "d", B.HLS = "h", B.SMOOTH = "s", B.OTHER = "o";
        })(k || (k = {}));
        var C;
        (function(B) {
          B.VOD = "v", B.LIVE = "l";
        })(C || (C = {}));
      },
      "./src/types/demuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          MetadataSchema: () => P
        });
        var P;
        (function(T) {
          T.audioId3 = "org.id3", T.dateRange = "com.apple.quicktime.HLS", T.emsg = "https://aomedia.org/emsg/ID3";
        })(P || (P = {}));
      },
      "./src/types/level.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          HdcpLevels: () => B,
          HlsSkip: () => I,
          HlsUrlParameters: () => D,
          Level: () => _,
          getSkipValue: () => L
        });
        function P(x, g) {
          for (var S = 0; S < g.length; S++) {
            var y = g[S];
            y.enumerable = y.enumerable || !1, y.configurable = !0, "value" in y && (y.writable = !0), Object.defineProperty(x, k(y.key), y);
          }
        }
        function T(x, g, S) {
          return g && P(x.prototype, g), S && P(x, S), Object.defineProperty(x, "prototype", { writable: !1 }), x;
        }
        function k(x) {
          var g = C(x, "string");
          return typeof g == "symbol" ? g : String(g);
        }
        function C(x, g) {
          if (typeof x != "object" || x === null)
            return x;
          var S = x[Symbol.toPrimitive];
          if (S !== void 0) {
            var y = S.call(x, g || "default");
            if (typeof y != "object")
              return y;
            throw new TypeError("@@toPrimitive must return a primitive value.");
          }
          return (g === "string" ? String : Number)(x);
        }
        var B = ["NONE", "TYPE-0", "TYPE-1", "TYPE-2", null], I;
        (function(x) {
          x.No = "", x.Yes = "YES", x.v2 = "v2";
        })(I || (I = {}));
        function L(x, g) {
          var S = x.canSkipUntil, y = x.canSkipDateRanges, l = x.endSN, u = g !== void 0 ? g - l : 0;
          return S && u < S ? y ? I.v2 : I.Yes : I.No;
        }
        var D = /* @__PURE__ */ function() {
          function x(S, y, l) {
            this.msn = void 0, this.part = void 0, this.skip = void 0, this.msn = S, this.part = y, this.skip = l;
          }
          var g = x.prototype;
          return g.addDirectives = function(y) {
            var l = new self.URL(y);
            return this.msn !== void 0 && l.searchParams.set("_HLS_msn", this.msn.toString()), this.part !== void 0 && l.searchParams.set("_HLS_part", this.part.toString()), this.skip && l.searchParams.set("_HLS_skip", this.skip), l.href;
          }, x;
        }(), _ = /* @__PURE__ */ function() {
          function x(g) {
            this.attrs = void 0, this.audioCodec = void 0, this.bitrate = void 0, this.codecSet = void 0, this.height = void 0, this.id = void 0, this.name = void 0, this.videoCodec = void 0, this.width = void 0, this.unknownCodecs = void 0, this.audioGroupIds = void 0, this.details = void 0, this.fragmentError = 0, this.loadError = 0, this.loaded = void 0, this.realBitrate = 0, this.textGroupIds = void 0, this.url = void 0, this._urlId = 0, this.url = [g.url], this.attrs = g.attrs, this.bitrate = g.bitrate, g.details && (this.details = g.details), this.id = g.id || 0, this.name = g.name, this.width = g.width || 0, this.height = g.height || 0, this.audioCodec = g.audioCodec, this.videoCodec = g.videoCodec, this.unknownCodecs = g.unknownCodecs, this.codecSet = [g.videoCodec, g.audioCodec].filter(function(S) {
              return S;
            }).join(",").replace(/\.[^.,]+/g, "");
          }
          return T(x, [{
            key: "maxBitrate",
            get: function() {
              return Math.max(this.realBitrate, this.bitrate);
            }
          }, {
            key: "uri",
            get: function() {
              return this.url[this._urlId] || "";
            }
          }, {
            key: "urlId",
            get: function() {
              return this._urlId;
            },
            set: function(S) {
              var y = S % this.url.length;
              this._urlId !== y && (this.details = void 0, this._urlId = y);
            }
          }]), x;
        }();
      },
      "./src/types/loader.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          PlaylistContextType: () => P,
          PlaylistLevelType: () => T
        });
        var P;
        (function(k) {
          k.MANIFEST = "manifest", k.LEVEL = "level", k.AUDIO_TRACK = "audioTrack", k.SUBTITLE_TRACK = "subtitleTrack";
        })(P || (P = {}));
        var T;
        (function(k) {
          k.MAIN = "main", k.AUDIO = "audio", k.SUBTITLE = "subtitle";
        })(T || (T = {}));
      },
      "./src/types/transmuxer.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          ChunkMetadata: () => P
        });
        var P = function(C, B, I, L, D, _) {
          L === void 0 && (L = 0), D === void 0 && (D = -1), _ === void 0 && (_ = !1), this.level = void 0, this.sn = void 0, this.part = void 0, this.id = void 0, this.size = void 0, this.partial = void 0, this.transmuxing = T(), this.buffering = {
            audio: T(),
            video: T(),
            audiovideo: T()
          }, this.level = C, this.sn = B, this.id = I, this.size = L, this.part = D, this.partial = _;
        };
        function T() {
          return {
            start: 0,
            executeStart: 0,
            executeEnd: 0,
            end: 0
          };
        }
      },
      "./src/utils/attr-list.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          AttrList: () => k
        });
        var P = /^(\d+)x(\d+)$/, T = /\s*(.+?)\s*=((?:\".*?\")|.*?)(?:,|$)/g, k = /* @__PURE__ */ function() {
          function C(I) {
            typeof I == "string" && (I = C.parseAttrList(I));
            for (var L in I)
              I.hasOwnProperty(L) && (this[L] = I[L]);
          }
          var B = C.prototype;
          return B.decimalInteger = function(L) {
            var D = parseInt(this[L], 10);
            return D > Number.MAX_SAFE_INTEGER ? 1 / 0 : D;
          }, B.hexadecimalInteger = function(L) {
            if (this[L]) {
              var D = (this[L] || "0x").slice(2);
              D = (D.length & 1 ? "0" : "") + D;
              for (var _ = new Uint8Array(D.length / 2), x = 0; x < D.length / 2; x++)
                _[x] = parseInt(D.slice(x * 2, x * 2 + 2), 16);
              return _;
            } else
              return null;
          }, B.hexadecimalIntegerAsNumber = function(L) {
            var D = parseInt(this[L], 16);
            return D > Number.MAX_SAFE_INTEGER ? 1 / 0 : D;
          }, B.decimalFloatingPoint = function(L) {
            return parseFloat(this[L]);
          }, B.optionalFloat = function(L, D) {
            var _ = this[L];
            return _ ? parseFloat(_) : D;
          }, B.enumeratedString = function(L) {
            return this[L];
          }, B.bool = function(L) {
            return this[L] === "YES";
          }, B.decimalResolution = function(L) {
            var D = P.exec(this[L]);
            if (D !== null)
              return {
                width: parseInt(D[1], 10),
                height: parseInt(D[2], 10)
              };
          }, C.parseAttrList = function(L) {
            var D, _ = {}, x = '"';
            for (T.lastIndex = 0; (D = T.exec(L)) !== null; ) {
              var g = D[2];
              g.indexOf(x) === 0 && g.lastIndexOf(x) === g.length - 1 && (g = g.slice(1, -1)), _[D[1]] = g;
            }
            return _;
          }, C;
        }();
      },
      "./src/utils/binary-search.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => T
        });
        var P = {
          search: function(C, B) {
            for (var I = 0, L = C.length - 1, D = null, _ = null; I <= L; ) {
              D = (I + L) / 2 | 0, _ = C[D];
              var x = B(_);
              if (x > 0)
                I = D + 1;
              else if (x < 0)
                L = D - 1;
              else
                return _;
            }
            return null;
          }
        };
        const T = P;
      },
      "./src/utils/buffer-helper.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          BufferHelper: () => k
        });
        var P = p("./src/utils/logger.ts"), T = {
          length: 0,
          start: function() {
            return 0;
          },
          end: function() {
            return 0;
          }
        }, k = /* @__PURE__ */ function() {
          function C() {
          }
          return C.isBuffered = function(I, L) {
            try {
              if (I) {
                for (var D = C.getBuffered(I), _ = 0; _ < D.length; _++)
                  if (L >= D.start(_) && L <= D.end(_))
                    return !0;
              }
            } catch {
            }
            return !1;
          }, C.bufferInfo = function(I, L, D) {
            try {
              if (I) {
                var _ = C.getBuffered(I), x = [], g;
                for (g = 0; g < _.length; g++)
                  x.push({
                    start: _.start(g),
                    end: _.end(g)
                  });
                return this.bufferedInfo(x, L, D);
              }
            } catch {
            }
            return {
              len: 0,
              start: L,
              end: L,
              nextStart: void 0
            };
          }, C.bufferedInfo = function(I, L, D) {
            L = Math.max(0, L), I.sort(function(i, n) {
              var E = i.start - n.start;
              return E || n.end - i.end;
            });
            var _ = [];
            if (D)
              for (var x = 0; x < I.length; x++) {
                var g = _.length;
                if (g) {
                  var S = _[g - 1].end;
                  I[x].start - S < D ? I[x].end > S && (_[g - 1].end = I[x].end) : _.push(I[x]);
                } else
                  _.push(I[x]);
              }
            else
              _ = I;
            for (var y = 0, l, u = L, a = L, s = 0; s < _.length; s++) {
              var m = _[s].start, v = _[s].end;
              if (L + D >= m && L < v)
                u = m, a = v, y = a - L;
              else if (L + D < m) {
                l = m;
                break;
              }
            }
            return {
              len: y,
              start: u || 0,
              end: a || 0,
              nextStart: l
            };
          }, C.getBuffered = function(I) {
            try {
              return I.buffered;
            } catch (L) {
              return P.logger.log("failed to get media.buffered", L), T;
            }
          }, C;
        }();
      },
      "./src/utils/cea-608-parser.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          CaptionScreen: () => s,
          Row: () => a,
          default: () => r
        });
        var P = p("./src/utils/logger.ts"), T = {
          42: 225,
          92: 233,
          94: 237,
          95: 243,
          96: 250,
          123: 231,
          124: 247,
          125: 209,
          126: 241,
          127: 9608,
          128: 174,
          129: 176,
          130: 189,
          131: 191,
          132: 8482,
          133: 162,
          134: 163,
          135: 9834,
          136: 224,
          137: 32,
          138: 232,
          139: 226,
          140: 234,
          141: 238,
          142: 244,
          143: 251,
          144: 193,
          145: 201,
          146: 211,
          147: 218,
          148: 220,
          149: 252,
          150: 8216,
          151: 161,
          152: 42,
          153: 8217,
          154: 9473,
          155: 169,
          156: 8480,
          157: 8226,
          158: 8220,
          159: 8221,
          160: 192,
          161: 194,
          162: 199,
          163: 200,
          164: 202,
          165: 203,
          166: 235,
          167: 206,
          168: 207,
          169: 239,
          170: 212,
          171: 217,
          172: 249,
          173: 219,
          174: 171,
          175: 187,
          176: 195,
          177: 227,
          178: 205,
          179: 204,
          180: 236,
          181: 210,
          182: 242,
          183: 213,
          184: 245,
          185: 123,
          186: 125,
          187: 92,
          188: 94,
          189: 95,
          190: 124,
          191: 8764,
          192: 196,
          193: 228,
          194: 214,
          195: 246,
          196: 223,
          197: 165,
          198: 164,
          199: 9475,
          200: 197,
          201: 229,
          202: 216,
          203: 248,
          204: 9487,
          205: 9491,
          206: 9495,
          207: 9499
        }, k = function(t) {
          var d = t;
          return T.hasOwnProperty(t) && (d = T[t]), String.fromCharCode(d);
        }, C = 15, B = 100, I = {
          17: 1,
          18: 3,
          21: 5,
          22: 7,
          23: 9,
          16: 11,
          19: 12,
          20: 14
        }, L = {
          17: 2,
          18: 4,
          21: 6,
          22: 8,
          23: 10,
          19: 13,
          20: 15
        }, D = {
          25: 1,
          26: 3,
          29: 5,
          30: 7,
          31: 9,
          24: 11,
          27: 12,
          28: 14
        }, _ = {
          25: 2,
          26: 4,
          29: 6,
          30: 8,
          31: 10,
          27: 13,
          28: 15
        }, x = ["white", "green", "blue", "cyan", "red", "yellow", "magenta", "black", "transparent"], g;
        (function(o) {
          o[o.ERROR = 0] = "ERROR", o[o.TEXT = 1] = "TEXT", o[o.WARNING = 2] = "WARNING", o[o.INFO = 2] = "INFO", o[o.DEBUG = 3] = "DEBUG", o[o.DATA = 3] = "DATA";
        })(g || (g = {}));
        var S = /* @__PURE__ */ function() {
          function o() {
            this.time = null, this.verboseLevel = g.ERROR;
          }
          var t = o.prototype;
          return t.log = function(e, h) {
            if (this.verboseLevel >= e) {
              var f = typeof h == "function" ? h() : h;
              P.logger.log(this.time + " [" + e + "] " + f);
            }
          }, o;
        }(), y = function(t) {
          for (var d = [], e = 0; e < t.length; e++)
            d.push(t[e].toString(16));
          return d;
        }, l = /* @__PURE__ */ function() {
          function o(d, e, h, f, c) {
            this.foreground = void 0, this.underline = void 0, this.italics = void 0, this.background = void 0, this.flash = void 0, this.foreground = d || "white", this.underline = e || !1, this.italics = h || !1, this.background = f || "black", this.flash = c || !1;
          }
          var t = o.prototype;
          return t.reset = function() {
            this.foreground = "white", this.underline = !1, this.italics = !1, this.background = "black", this.flash = !1;
          }, t.setStyles = function(e) {
            for (var h = ["foreground", "underline", "italics", "background", "flash"], f = 0; f < h.length; f++) {
              var c = h[f];
              e.hasOwnProperty(c) && (this[c] = e[c]);
            }
          }, t.isDefault = function() {
            return this.foreground === "white" && !this.underline && !this.italics && this.background === "black" && !this.flash;
          }, t.equals = function(e) {
            return this.foreground === e.foreground && this.underline === e.underline && this.italics === e.italics && this.background === e.background && this.flash === e.flash;
          }, t.copy = function(e) {
            this.foreground = e.foreground, this.underline = e.underline, this.italics = e.italics, this.background = e.background, this.flash = e.flash;
          }, t.toString = function() {
            return "color=" + this.foreground + ", underline=" + this.underline + ", italics=" + this.italics + ", background=" + this.background + ", flash=" + this.flash;
          }, o;
        }(), u = /* @__PURE__ */ function() {
          function o(d, e, h, f, c, M) {
            this.uchar = void 0, this.penState = void 0, this.uchar = d || " ", this.penState = new l(e, h, f, c, M);
          }
          var t = o.prototype;
          return t.reset = function() {
            this.uchar = " ", this.penState.reset();
          }, t.setChar = function(e, h) {
            this.uchar = e, this.penState.copy(h);
          }, t.setPenState = function(e) {
            this.penState.copy(e);
          }, t.equals = function(e) {
            return this.uchar === e.uchar && this.penState.equals(e.penState);
          }, t.copy = function(e) {
            this.uchar = e.uchar, this.penState.copy(e.penState);
          }, t.isEmpty = function() {
            return this.uchar === " " && this.penState.isDefault();
          }, o;
        }(), a = /* @__PURE__ */ function() {
          function o(d) {
            this.chars = void 0, this.pos = void 0, this.currPenState = void 0, this.cueStartTime = void 0, this.logger = void 0, this.chars = [];
            for (var e = 0; e < B; e++)
              this.chars.push(new u());
            this.logger = d, this.pos = 0, this.currPenState = new l();
          }
          var t = o.prototype;
          return t.equals = function(e) {
            for (var h = !0, f = 0; f < B; f++)
              if (!this.chars[f].equals(e.chars[f])) {
                h = !1;
                break;
              }
            return h;
          }, t.copy = function(e) {
            for (var h = 0; h < B; h++)
              this.chars[h].copy(e.chars[h]);
          }, t.isEmpty = function() {
            for (var e = !0, h = 0; h < B; h++)
              if (!this.chars[h].isEmpty()) {
                e = !1;
                break;
              }
            return e;
          }, t.setCursor = function(e) {
            this.pos !== e && (this.pos = e), this.pos < 0 ? (this.logger.log(g.DEBUG, "Negative cursor position " + this.pos), this.pos = 0) : this.pos > B && (this.logger.log(g.DEBUG, "Too large cursor position " + this.pos), this.pos = B);
          }, t.moveCursor = function(e) {
            var h = this.pos + e;
            if (e > 1)
              for (var f = this.pos + 1; f < h + 1; f++)
                this.chars[f].setPenState(this.currPenState);
            this.setCursor(h);
          }, t.backSpace = function() {
            this.moveCursor(-1), this.chars[this.pos].setChar(" ", this.currPenState);
          }, t.insertChar = function(e) {
            var h = this;
            e >= 144 && this.backSpace();
            var f = k(e);
            if (this.pos >= B) {
              this.logger.log(g.ERROR, function() {
                return "Cannot insert " + e.toString(16) + " (" + f + ") at position " + h.pos + ". Skipping it!";
              });
              return;
            }
            this.chars[this.pos].setChar(f, this.currPenState), this.moveCursor(1);
          }, t.clearFromPos = function(e) {
            var h;
            for (h = e; h < B; h++)
              this.chars[h].reset();
          }, t.clear = function() {
            this.clearFromPos(0), this.pos = 0, this.currPenState.reset();
          }, t.clearToEndOfRow = function() {
            this.clearFromPos(this.pos);
          }, t.getTextString = function() {
            for (var e = [], h = !0, f = 0; f < B; f++) {
              var c = this.chars[f].uchar;
              c !== " " && (h = !1), e.push(c);
            }
            return h ? "" : e.join("");
          }, t.setPenStyles = function(e) {
            this.currPenState.setStyles(e);
            var h = this.chars[this.pos];
            h.setPenState(this.currPenState);
          }, o;
        }(), s = /* @__PURE__ */ function() {
          function o(d) {
            this.rows = void 0, this.currRow = void 0, this.nrRollUpRows = void 0, this.lastOutputScreen = void 0, this.logger = void 0, this.rows = [];
            for (var e = 0; e < C; e++)
              this.rows.push(new a(d));
            this.logger = d, this.currRow = C - 1, this.nrRollUpRows = null, this.lastOutputScreen = null, this.reset();
          }
          var t = o.prototype;
          return t.reset = function() {
            for (var e = 0; e < C; e++)
              this.rows[e].clear();
            this.currRow = C - 1;
          }, t.equals = function(e) {
            for (var h = !0, f = 0; f < C; f++)
              if (!this.rows[f].equals(e.rows[f])) {
                h = !1;
                break;
              }
            return h;
          }, t.copy = function(e) {
            for (var h = 0; h < C; h++)
              this.rows[h].copy(e.rows[h]);
          }, t.isEmpty = function() {
            for (var e = !0, h = 0; h < C; h++)
              if (!this.rows[h].isEmpty()) {
                e = !1;
                break;
              }
            return e;
          }, t.backSpace = function() {
            var e = this.rows[this.currRow];
            e.backSpace();
          }, t.clearToEndOfRow = function() {
            var e = this.rows[this.currRow];
            e.clearToEndOfRow();
          }, t.insertChar = function(e) {
            var h = this.rows[this.currRow];
            h.insertChar(e);
          }, t.setPen = function(e) {
            var h = this.rows[this.currRow];
            h.setPenStyles(e);
          }, t.moveCursor = function(e) {
            var h = this.rows[this.currRow];
            h.moveCursor(e);
          }, t.setCursor = function(e) {
            this.logger.log(g.INFO, "setCursor: " + e);
            var h = this.rows[this.currRow];
            h.setCursor(e);
          }, t.setPAC = function(e) {
            this.logger.log(g.INFO, function() {
              return "pacData = " + JSON.stringify(e);
            });
            var h = e.row - 1;
            if (this.nrRollUpRows && h < this.nrRollUpRows - 1 && (h = this.nrRollUpRows - 1), this.nrRollUpRows && this.currRow !== h) {
              for (var f = 0; f < C; f++)
                this.rows[f].clear();
              var c = this.currRow + 1 - this.nrRollUpRows, M = this.lastOutputScreen;
              if (M) {
                var w = M.rows[c].cueStartTime, F = this.logger.time;
                if (w && F !== null && w < F)
                  for (var U = 0; U < this.nrRollUpRows; U++)
                    this.rows[h - this.nrRollUpRows + U + 1].copy(M.rows[c + U]);
              }
            }
            this.currRow = h;
            var N = this.rows[this.currRow];
            if (e.indent !== null) {
              var H = e.indent, j = Math.max(H - 1, 0);
              N.setCursor(e.indent), e.color = N.chars[j].penState.foreground;
            }
            var z = {
              foreground: e.color,
              underline: e.underline,
              italics: e.italics,
              background: "black",
              flash: !1
            };
            this.setPen(z);
          }, t.setBkgData = function(e) {
            this.logger.log(g.INFO, function() {
              return "bkgData = " + JSON.stringify(e);
            }), this.backSpace(), this.setPen(e), this.insertChar(32);
          }, t.setRollUpRows = function(e) {
            this.nrRollUpRows = e;
          }, t.rollUp = function() {
            var e = this;
            if (this.nrRollUpRows === null) {
              this.logger.log(g.DEBUG, "roll_up but nrRollUpRows not set yet");
              return;
            }
            this.logger.log(g.TEXT, function() {
              return e.getDisplayText();
            });
            var h = this.currRow + 1 - this.nrRollUpRows, f = this.rows.splice(h, 1)[0];
            f.clear(), this.rows.splice(this.currRow, 0, f), this.logger.log(g.INFO, "Rolling up");
          }, t.getDisplayText = function(e) {
            e = e || !1;
            for (var h = [], f = "", c = -1, M = 0; M < C; M++) {
              var w = this.rows[M].getTextString();
              w && (c = M + 1, e ? h.push("Row " + c + ": '" + w + "'") : h.push(w.trim()));
            }
            return h.length > 0 && (e ? f = "[" + h.join(" | ") + "]" : f = h.join(`
`)), f;
          }, t.getTextAndFormat = function() {
            return this.rows;
          }, o;
        }(), m = /* @__PURE__ */ function() {
          function o(d, e, h) {
            this.chNr = void 0, this.outputFilter = void 0, this.mode = void 0, this.verbose = void 0, this.displayedMemory = void 0, this.nonDisplayedMemory = void 0, this.lastOutputScreen = void 0, this.currRollUpRow = void 0, this.writeScreen = void 0, this.cueStartTime = void 0, this.logger = void 0, this.chNr = d, this.outputFilter = e, this.mode = null, this.verbose = 0, this.displayedMemory = new s(h), this.nonDisplayedMemory = new s(h), this.lastOutputScreen = new s(h), this.currRollUpRow = this.displayedMemory.rows[C - 1], this.writeScreen = this.displayedMemory, this.mode = null, this.cueStartTime = null, this.logger = h;
          }
          var t = o.prototype;
          return t.reset = function() {
            this.mode = null, this.displayedMemory.reset(), this.nonDisplayedMemory.reset(), this.lastOutputScreen.reset(), this.outputFilter.reset(), this.currRollUpRow = this.displayedMemory.rows[C - 1], this.writeScreen = this.displayedMemory, this.mode = null, this.cueStartTime = null;
          }, t.getHandler = function() {
            return this.outputFilter;
          }, t.setHandler = function(e) {
            this.outputFilter = e;
          }, t.setPAC = function(e) {
            this.writeScreen.setPAC(e);
          }, t.setBkgData = function(e) {
            this.writeScreen.setBkgData(e);
          }, t.setMode = function(e) {
            e !== this.mode && (this.mode = e, this.logger.log(g.INFO, function() {
              return "MODE=" + e;
            }), this.mode === "MODE_POP-ON" ? this.writeScreen = this.nonDisplayedMemory : (this.writeScreen = this.displayedMemory, this.writeScreen.reset()), this.mode !== "MODE_ROLL-UP" && (this.displayedMemory.nrRollUpRows = null, this.nonDisplayedMemory.nrRollUpRows = null), this.mode = e);
          }, t.insertChars = function(e) {
            for (var h = this, f = 0; f < e.length; f++)
              this.writeScreen.insertChar(e[f]);
            var c = this.writeScreen === this.displayedMemory ? "DISP" : "NON_DISP";
            this.logger.log(g.INFO, function() {
              return c + ": " + h.writeScreen.getDisplayText(!0);
            }), (this.mode === "MODE_PAINT-ON" || this.mode === "MODE_ROLL-UP") && (this.logger.log(g.TEXT, function() {
              return "DISPLAYED: " + h.displayedMemory.getDisplayText(!0);
            }), this.outputDataUpdate());
          }, t.ccRCL = function() {
            this.logger.log(g.INFO, "RCL - Resume Caption Loading"), this.setMode("MODE_POP-ON");
          }, t.ccBS = function() {
            this.logger.log(g.INFO, "BS - BackSpace"), this.mode !== "MODE_TEXT" && (this.writeScreen.backSpace(), this.writeScreen === this.displayedMemory && this.outputDataUpdate());
          }, t.ccAOF = function() {
          }, t.ccAON = function() {
          }, t.ccDER = function() {
            this.logger.log(g.INFO, "DER- Delete to End of Row"), this.writeScreen.clearToEndOfRow(), this.outputDataUpdate();
          }, t.ccRU = function(e) {
            this.logger.log(g.INFO, "RU(" + e + ") - Roll Up"), this.writeScreen = this.displayedMemory, this.setMode("MODE_ROLL-UP"), this.writeScreen.setRollUpRows(e);
          }, t.ccFON = function() {
            this.logger.log(g.INFO, "FON - Flash On"), this.writeScreen.setPen({
              flash: !0
            });
          }, t.ccRDC = function() {
            this.logger.log(g.INFO, "RDC - Resume Direct Captioning"), this.setMode("MODE_PAINT-ON");
          }, t.ccTR = function() {
            this.logger.log(g.INFO, "TR"), this.setMode("MODE_TEXT");
          }, t.ccRTD = function() {
            this.logger.log(g.INFO, "RTD"), this.setMode("MODE_TEXT");
          }, t.ccEDM = function() {
            this.logger.log(g.INFO, "EDM - Erase Displayed Memory"), this.displayedMemory.reset(), this.outputDataUpdate(!0);
          }, t.ccCR = function() {
            this.logger.log(g.INFO, "CR - Carriage Return"), this.writeScreen.rollUp(), this.outputDataUpdate(!0);
          }, t.ccENM = function() {
            this.logger.log(g.INFO, "ENM - Erase Non-displayed Memory"), this.nonDisplayedMemory.reset();
          }, t.ccEOC = function() {
            var e = this;
            if (this.logger.log(g.INFO, "EOC - End Of Caption"), this.mode === "MODE_POP-ON") {
              var h = this.displayedMemory;
              this.displayedMemory = this.nonDisplayedMemory, this.nonDisplayedMemory = h, this.writeScreen = this.nonDisplayedMemory, this.logger.log(g.TEXT, function() {
                return "DISP: " + e.displayedMemory.getDisplayText();
              });
            }
            this.outputDataUpdate(!0);
          }, t.ccTO = function(e) {
            this.logger.log(g.INFO, "TO(" + e + ") - Tab Offset"), this.writeScreen.moveCursor(e);
          }, t.ccMIDROW = function(e) {
            var h = {
              flash: !1
            };
            if (h.underline = e % 2 === 1, h.italics = e >= 46, h.italics)
              h.foreground = "white";
            else {
              var f = Math.floor(e / 2) - 16, c = ["white", "green", "blue", "cyan", "red", "yellow", "magenta"];
              h.foreground = c[f];
            }
            this.logger.log(g.INFO, "MIDROW: " + JSON.stringify(h)), this.writeScreen.setPen(h);
          }, t.outputDataUpdate = function(e) {
            e === void 0 && (e = !1);
            var h = this.logger.time;
            h !== null && this.outputFilter && (this.cueStartTime === null && !this.displayedMemory.isEmpty() ? this.cueStartTime = h : this.displayedMemory.equals(this.lastOutputScreen) || (this.outputFilter.newCue(this.cueStartTime, h, this.lastOutputScreen), e && this.outputFilter.dispatchCue && this.outputFilter.dispatchCue(), this.cueStartTime = this.displayedMemory.isEmpty() ? null : h), this.lastOutputScreen.copy(this.displayedMemory));
          }, t.cueSplitAtTime = function(e) {
            this.outputFilter && (this.displayedMemory.isEmpty() || (this.outputFilter.newCue && this.outputFilter.newCue(this.cueStartTime, e, this.displayedMemory), this.cueStartTime = e));
          }, o;
        }(), v = /* @__PURE__ */ function() {
          function o(d, e, h) {
            this.channels = void 0, this.currentChannel = 0, this.cmdHistory = void 0, this.logger = void 0;
            var f = new S();
            this.channels = [null, new m(d, e, f), new m(d + 1, h, f)], this.cmdHistory = E(), this.logger = f;
          }
          var t = o.prototype;
          return t.getHandler = function(e) {
            return this.channels[e].getHandler();
          }, t.setHandler = function(e, h) {
            this.channels[e].setHandler(h);
          }, t.addData = function(e, h) {
            var f, c, M, w = !1;
            this.logger.time = e;
            for (var F = 0; F < h.length; F += 2)
              if (c = h[F] & 127, M = h[F + 1] & 127, !(c === 0 && M === 0)) {
                if (this.logger.log(g.DATA, "[" + y([h[F], h[F + 1]]) + "] -> (" + y([c, M]) + ")"), f = this.parseCmd(c, M), f || (f = this.parseMidrow(c, M)), f || (f = this.parsePAC(c, M)), f || (f = this.parseBackgroundAttributes(c, M)), !f && (w = this.parseChars(c, M), w)) {
                  var U = this.currentChannel;
                  if (U && U > 0) {
                    var N = this.channels[U];
                    N.insertChars(w);
                  } else
                    this.logger.log(g.WARNING, "No channel found yet. TEXT-MODE?");
                }
                !f && !w && this.logger.log(g.WARNING, "Couldn't parse cleaned data " + y([c, M]) + " orig: " + y([h[F], h[F + 1]]));
              }
          }, t.parseCmd = function(e, h) {
            var f = this.cmdHistory, c = (e === 20 || e === 28 || e === 21 || e === 29) && h >= 32 && h <= 47, M = (e === 23 || e === 31) && h >= 33 && h <= 35;
            if (!(c || M))
              return !1;
            if (n(e, h, f))
              return i(null, null, f), this.logger.log(g.DEBUG, "Repeated command (" + y([e, h]) + ") is dropped"), !0;
            var w = e === 20 || e === 21 || e === 23 ? 1 : 2, F = this.channels[w];
            return e === 20 || e === 21 || e === 28 || e === 29 ? h === 32 ? F.ccRCL() : h === 33 ? F.ccBS() : h === 34 ? F.ccAOF() : h === 35 ? F.ccAON() : h === 36 ? F.ccDER() : h === 37 ? F.ccRU(2) : h === 38 ? F.ccRU(3) : h === 39 ? F.ccRU(4) : h === 40 ? F.ccFON() : h === 41 ? F.ccRDC() : h === 42 ? F.ccTR() : h === 43 ? F.ccRTD() : h === 44 ? F.ccEDM() : h === 45 ? F.ccCR() : h === 46 ? F.ccENM() : h === 47 && F.ccEOC() : F.ccTO(h - 32), i(e, h, f), this.currentChannel = w, !0;
          }, t.parseMidrow = function(e, h) {
            var f = 0;
            if ((e === 17 || e === 25) && h >= 32 && h <= 47) {
              if (e === 17 ? f = 1 : f = 2, f !== this.currentChannel)
                return this.logger.log(g.ERROR, "Mismatch channel in midrow parsing"), !1;
              var c = this.channels[f];
              return c ? (c.ccMIDROW(h), this.logger.log(g.DEBUG, "MIDROW (" + y([e, h]) + ")"), !0) : !1;
            }
            return !1;
          }, t.parsePAC = function(e, h) {
            var f, c = this.cmdHistory, M = (e >= 17 && e <= 23 || e >= 25 && e <= 31) && h >= 64 && h <= 127, w = (e === 16 || e === 24) && h >= 64 && h <= 95;
            if (!(M || w))
              return !1;
            if (n(e, h, c))
              return i(null, null, c), !0;
            var F = e <= 23 ? 1 : 2;
            h >= 64 && h <= 95 ? f = F === 1 ? I[e] : D[e] : f = F === 1 ? L[e] : _[e];
            var U = this.channels[F];
            return U ? (U.setPAC(this.interpretPAC(f, h)), i(e, h, c), this.currentChannel = F, !0) : !1;
          }, t.interpretPAC = function(e, h) {
            var f, c = {
              color: null,
              italics: !1,
              indent: null,
              underline: !1,
              row: e
            };
            return h > 95 ? f = h - 96 : f = h - 64, c.underline = (f & 1) === 1, f <= 13 ? c.color = ["white", "green", "blue", "cyan", "red", "yellow", "magenta", "white"][Math.floor(f / 2)] : f <= 15 ? (c.italics = !0, c.color = "white") : c.indent = Math.floor((f - 16) / 2) * 4, c;
          }, t.parseChars = function(e, h) {
            var f, c = null, M = null;
            if (e >= 25 ? (f = 2, M = e - 8) : (f = 1, M = e), M >= 17 && M <= 19) {
              var w;
              M === 17 ? w = h + 80 : M === 18 ? w = h + 112 : w = h + 144, this.logger.log(g.INFO, "Special char '" + k(w) + "' in channel " + f), c = [w];
            } else
              e >= 32 && e <= 127 && (c = h === 0 ? [e] : [e, h]);
            if (c) {
              var F = y(c);
              this.logger.log(g.DEBUG, "Char codes =  " + F.join(",")), i(e, h, this.cmdHistory);
            }
            return c;
          }, t.parseBackgroundAttributes = function(e, h) {
            var f = (e === 16 || e === 24) && h >= 32 && h <= 47, c = (e === 23 || e === 31) && h >= 45 && h <= 47;
            if (!(f || c))
              return !1;
            var M, w = {};
            e === 16 || e === 24 ? (M = Math.floor((h - 32) / 2), w.background = x[M], h % 2 === 1 && (w.background = w.background + "_semi")) : h === 45 ? w.background = "transparent" : (w.foreground = "black", h === 47 && (w.underline = !0));
            var F = e <= 23 ? 1 : 2, U = this.channels[F];
            return U.setBkgData(w), i(e, h, this.cmdHistory), !0;
          }, t.reset = function() {
            for (var e = 0; e < Object.keys(this.channels).length; e++) {
              var h = this.channels[e];
              h && h.reset();
            }
            this.cmdHistory = E();
          }, t.cueSplitAtTime = function(e) {
            for (var h = 0; h < this.channels.length; h++) {
              var f = this.channels[h];
              f && f.cueSplitAtTime(e);
            }
          }, o;
        }();
        function i(o, t, d) {
          d.a = o, d.b = t;
        }
        function n(o, t, d) {
          return d.a === o && d.b === t;
        }
        function E() {
          return {
            a: null,
            b: null
          };
        }
        const r = v;
      },
      "./src/utils/codecs.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          isCodecSupportedInMp4: () => k,
          isCodecType: () => T
        });
        var P = {
          audio: {
            a3ds: !0,
            "ac-3": !0,
            "ac-4": !0,
            alac: !0,
            alaw: !0,
            dra1: !0,
            "dts+": !0,
            "dts-": !0,
            dtsc: !0,
            dtse: !0,
            dtsh: !0,
            "ec-3": !0,
            enca: !0,
            g719: !0,
            g726: !0,
            m4ae: !0,
            mha1: !0,
            mha2: !0,
            mhm1: !0,
            mhm2: !0,
            mlpa: !0,
            mp4a: !0,
            "raw ": !0,
            Opus: !0,
            opus: !0,
            samr: !0,
            sawb: !0,
            sawp: !0,
            sevc: !0,
            sqcp: !0,
            ssmv: !0,
            twos: !0,
            ulaw: !0
          },
          video: {
            avc1: !0,
            avc2: !0,
            avc3: !0,
            avc4: !0,
            avcp: !0,
            av01: !0,
            drac: !0,
            dva1: !0,
            dvav: !0,
            dvh1: !0,
            dvhe: !0,
            encv: !0,
            hev1: !0,
            hvc1: !0,
            mjp2: !0,
            mp4v: !0,
            mvc1: !0,
            mvc2: !0,
            mvc3: !0,
            mvc4: !0,
            resv: !0,
            rv60: !0,
            s263: !0,
            svc1: !0,
            svc2: !0,
            "vc-1": !0,
            vp08: !0,
            vp09: !0
          },
          text: {
            stpp: !0,
            wvtt: !0
          }
        };
        function T(C, B) {
          var I = P[B];
          return !!I && I[C.slice(0, 4)] === !0;
        }
        function k(C, B) {
          return MediaSource.isTypeSupported((B || "video") + '/mp4;codecs="' + C + '"');
        }
      },
      "./src/utils/cues.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => I
        });
        var P = p("./src/utils/vttparser.ts"), T = p("./src/utils/webvtt-parser.ts"), k = p("./src/utils/texttrack-utils.ts"), C = /\s/, B = {
          newCue: function(D, _, x, g) {
            for (var S = [], y, l, u, a, s, m = self.VTTCue || self.TextTrackCue, v = 0; v < g.rows.length; v++)
              if (y = g.rows[v], u = !0, a = 0, s = "", !y.isEmpty()) {
                for (var i = 0; i < y.chars.length; i++)
                  C.test(y.chars[i].uchar) && u ? a++ : (s += y.chars[i].uchar, u = !1);
                y.cueStartTime = _, _ === x && (x += 1e-4), a >= 16 ? a-- : a++;
                var n = (0, P.fixLineBreaks)(s.trim()), E = (0, T.generateCueId)(_, x, n);
                (!D || !D.cues || !D.cues.getCueById(E)) && (l = new m(_, x, n), l.id = E, l.line = v + 1, l.align = "left", l.position = 10 + Math.min(80, Math.floor(a * 8 / 32) * 10), S.push(l));
              }
            return D && S.length && (S.sort(function(r, o) {
              return r.line === "auto" || o.line === "auto" ? 0 : r.line > 8 && o.line > 8 ? o.line - r.line : r.line - o.line;
            }), S.forEach(function(r) {
              return (0, k.addCueToTrack)(D, r);
            })), S;
          }
        };
        const I = B;
      },
      "./src/utils/discontinuities.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          adjustSlidingStart: () => D,
          alignMediaPlaylistByPDT: () => S,
          alignPDT: () => g,
          alignStream: () => _,
          findDiscontinuousReferenceFrag: () => I,
          findFirstFragWithCC: () => C,
          shouldAlignOnDiscontinuities: () => B
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/utils/logger.ts"), k = p("./src/controller/level-helper.ts");
        function C(y, l) {
          for (var u = null, a = 0, s = y.length; a < s; a++) {
            var m = y[a];
            if (m && m.cc === l) {
              u = m;
              break;
            }
          }
          return u;
        }
        function B(y, l, u) {
          return !!(l.details && (u.endCC > u.startCC || y && y.cc < u.startCC));
        }
        function I(y, l, u) {
          var a = y.fragments, s = l.fragments;
          if (!s.length || !a.length) {
            T.logger.log("No fragments to align");
            return;
          }
          var m = C(a, s[0].cc);
          if (!m || m && !m.startPTS) {
            T.logger.log("No frag in previous level to align on");
            return;
          }
          return m;
        }
        function L(y, l) {
          if (y) {
            var u = y.start + l;
            y.start = y.startPTS = u, y.endPTS = u + y.duration;
          }
        }
        function D(y, l) {
          for (var u = l.fragments, a = 0, s = u.length; a < s; a++)
            L(u[a], y);
          l.fragmentHint && L(l.fragmentHint, y), l.alignedSliding = !0;
        }
        function _(y, l, u) {
          !l || (x(y, u, l), !u.alignedSliding && l.details && g(u, l.details), !u.alignedSliding && l.details && !u.skippedSegments && (0, k.adjustSliding)(l.details, u));
        }
        function x(y, l, u) {
          if (B(y, u, l)) {
            var a = I(u.details, l);
            a && (0, P.isFiniteNumber)(a.start) && (T.logger.log("Adjusting PTS using last level due to CC increase within current level " + l.url), D(a.start, l));
          }
        }
        function g(y, l) {
          if (!(!l.fragments.length || !y.hasProgramDateTime || !l.hasProgramDateTime)) {
            var u = l.fragments[0].programDateTime, a = y.fragments[0].programDateTime, s = (a - u) / 1e3 + l.fragments[0].start;
            s && (0, P.isFiniteNumber)(s) && (T.logger.log("Adjusting PTS using programDateTime delta " + (a - u) + "ms, sliding:" + s.toFixed(3) + " " + y.url + " "), D(s, y));
          }
        }
        function S(y, l) {
          if (!(!y.hasProgramDateTime || !l.hasProgramDateTime)) {
            var u = y.fragments, a = l.fragments;
            if (!(!u.length || !a.length)) {
              var s = Math.round(a.length / 2) - 1, m = a[s], v = C(u, m.cc) || u[Math.round(u.length / 2) - 1], i = m.programDateTime, n = v.programDateTime;
              if (!(i === null || n === null)) {
                var E = (n - i) / 1e3 - (v.start - m.start);
                D(E, y);
              }
            }
          }
        }
      },
      "./src/utils/ewma-bandwidth-estimator.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => k
        });
        var P = p("./src/utils/ewma.ts"), T = /* @__PURE__ */ function() {
          function C(I, L, D) {
            this.defaultEstimate_ = void 0, this.minWeight_ = void 0, this.minDelayMs_ = void 0, this.slow_ = void 0, this.fast_ = void 0, this.defaultEstimate_ = D, this.minWeight_ = 1e-3, this.minDelayMs_ = 50, this.slow_ = new P.default(I), this.fast_ = new P.default(L);
          }
          var B = C.prototype;
          return B.update = function(L, D) {
            var _ = this.slow_, x = this.fast_;
            this.slow_.halfLife !== L && (this.slow_ = new P.default(L, _.getEstimate(), _.getTotalWeight())), this.fast_.halfLife !== D && (this.fast_ = new P.default(D, x.getEstimate(), x.getTotalWeight()));
          }, B.sample = function(L, D) {
            L = Math.max(L, this.minDelayMs_);
            var _ = 8 * D, x = L / 1e3, g = _ / x;
            this.fast_.sample(x, g), this.slow_.sample(x, g);
          }, B.canEstimate = function() {
            var L = this.fast_;
            return L && L.getTotalWeight() >= this.minWeight_;
          }, B.getEstimate = function() {
            return this.canEstimate() ? Math.min(this.fast_.getEstimate(), this.slow_.getEstimate()) : this.defaultEstimate_;
          }, B.destroy = function() {
          }, C;
        }();
        const k = T;
      },
      "./src/utils/ewma.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => T
        });
        var P = /* @__PURE__ */ function() {
          function k(B, I, L) {
            I === void 0 && (I = 0), L === void 0 && (L = 0), this.halfLife = void 0, this.alpha_ = void 0, this.estimate_ = void 0, this.totalWeight_ = void 0, this.halfLife = B, this.alpha_ = B ? Math.exp(Math.log(0.5) / B) : 0, this.estimate_ = I, this.totalWeight_ = L;
          }
          var C = k.prototype;
          return C.sample = function(I, L) {
            var D = Math.pow(this.alpha_, I);
            this.estimate_ = L * (1 - D) + D * this.estimate_, this.totalWeight_ += I;
          }, C.getTotalWeight = function() {
            return this.totalWeight_;
          }, C.getEstimate = function() {
            if (this.alpha_) {
              var I = 1 - Math.pow(this.alpha_, this.totalWeight_);
              if (I)
                return this.estimate_ / I;
            }
            return this.estimate_;
          }, k;
        }();
        const T = P;
      },
      "./src/utils/fetch-loader.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => s,
          fetchSupported: () => S
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/loader/load-stats.ts"), k = p("./src/demux/chunk-cache.ts");
        function C(m, v) {
          m.prototype = Object.create(v.prototype), m.prototype.constructor = m, _(m, v);
        }
        function B(m) {
          var v = typeof Map == "function" ? /* @__PURE__ */ new Map() : void 0;
          return B = function(n) {
            if (n === null || !D(n))
              return n;
            if (typeof n != "function")
              throw new TypeError("Super expression must either be null or a function");
            if (typeof v < "u") {
              if (v.has(n))
                return v.get(n);
              v.set(n, E);
            }
            function E() {
              return I(n, arguments, x(this).constructor);
            }
            return E.prototype = Object.create(n.prototype, { constructor: { value: E, enumerable: !1, writable: !0, configurable: !0 } }), _(E, n);
          }, B(m);
        }
        function I(m, v, i) {
          return L() ? I = Reflect.construct.bind() : I = function(E, r, o) {
            var t = [null];
            t.push.apply(t, r);
            var d = Function.bind.apply(E, t), e = new d();
            return o && _(e, o.prototype), e;
          }, I.apply(null, arguments);
        }
        function L() {
          if (typeof Reflect > "u" || !Reflect.construct || Reflect.construct.sham)
            return !1;
          if (typeof Proxy == "function")
            return !0;
          try {
            return Boolean.prototype.valueOf.call(Reflect.construct(Boolean, [], function() {
            })), !0;
          } catch {
            return !1;
          }
        }
        function D(m) {
          return Function.toString.call(m).indexOf("[native code]") !== -1;
        }
        function _(m, v) {
          return _ = Object.setPrototypeOf ? Object.setPrototypeOf.bind() : function(n, E) {
            return n.__proto__ = E, n;
          }, _(m, v);
        }
        function x(m) {
          return x = Object.setPrototypeOf ? Object.getPrototypeOf.bind() : function(i) {
            return i.__proto__ || Object.getPrototypeOf(i);
          }, x(m);
        }
        function g() {
          return g = Object.assign ? Object.assign.bind() : function(m) {
            for (var v = 1; v < arguments.length; v++) {
              var i = arguments[v];
              for (var n in i)
                Object.prototype.hasOwnProperty.call(i, n) && (m[n] = i[n]);
            }
            return m;
          }, g.apply(this, arguments);
        }
        function S() {
          if (self.fetch && self.AbortController && self.ReadableStream && self.Request)
            try {
              return new self.ReadableStream({}), !0;
            } catch {
            }
          return !1;
        }
        var y = /* @__PURE__ */ function() {
          function m(i) {
            this.fetchSetup = void 0, this.requestTimeout = void 0, this.request = void 0, this.response = void 0, this.controller = void 0, this.context = void 0, this.config = null, this.callbacks = null, this.stats = void 0, this.loader = null, this.fetchSetup = i.fetchSetup || u, this.controller = new self.AbortController(), this.stats = new T.LoadStats();
          }
          var v = m.prototype;
          return v.destroy = function() {
            this.loader = this.callbacks = null, this.abortInternal();
          }, v.abortInternal = function() {
            var n = this.response;
            (!n || !n.ok) && (this.stats.aborted = !0, this.controller.abort());
          }, v.abort = function() {
            var n;
            this.abortInternal(), (n = this.callbacks) !== null && n !== void 0 && n.onAbort && this.callbacks.onAbort(this.stats, this.context, this.response);
          }, v.load = function(n, E, r) {
            var o = this, t = this.stats;
            if (t.loading.start)
              throw new Error("Loader can only be used once.");
            t.loading.start = self.performance.now();
            var d = l(n, this.controller.signal), e = r.onProgress, h = n.responseType === "arraybuffer", f = h ? "byteLength" : "length";
            this.context = n, this.config = E, this.callbacks = r, this.request = this.fetchSetup(n, d), self.clearTimeout(this.requestTimeout), this.requestTimeout = self.setTimeout(function() {
              o.abortInternal(), r.onTimeout(t, n, o.response);
            }, E.timeout), self.fetch(this.request).then(function(c) {
              if (o.response = o.loader = c, !c.ok) {
                var M = c.status, w = c.statusText;
                throw new a(w || "fetch, bad network response", M, c);
              }
              return t.loading.first = Math.max(self.performance.now(), t.loading.start), t.total = parseInt(c.headers.get("Content-Length") || "0"), e && (0, P.isFiniteNumber)(E.highWaterMark) ? o.loadProgressively(c, t, n, E.highWaterMark, e) : h ? c.arrayBuffer() : c.text();
            }).then(function(c) {
              var M = o.response;
              self.clearTimeout(o.requestTimeout), t.loading.end = Math.max(self.performance.now(), t.loading.first);
              var w = c[f];
              w && (t.loaded = t.total = w);
              var F = {
                url: M.url,
                data: c
              };
              e && !(0, P.isFiniteNumber)(E.highWaterMark) && e(t, n, c, M), r.onSuccess(F, t, n, M);
            }).catch(function(c) {
              if (self.clearTimeout(o.requestTimeout), !t.aborted) {
                var M = c && c.code || 0, w = c ? c.message : null;
                r.onError({
                  code: M,
                  text: w
                }, n, c ? c.details : null);
              }
            });
          }, v.getCacheAge = function() {
            var n = null;
            if (this.response) {
              var E = this.response.headers.get("age");
              n = E ? parseFloat(E) : null;
            }
            return n;
          }, v.loadProgressively = function(n, E, r, o, t) {
            o === void 0 && (o = 0);
            var d = new k.default(), e = n.body.getReader(), h = function f() {
              return e.read().then(function(c) {
                if (c.done)
                  return d.dataLength && t(E, r, d.flush(), n), Promise.resolve(new ArrayBuffer(0));
                var M = c.value, w = M.length;
                return E.loaded += w, w < o || d.dataLength ? (d.push(M), d.dataLength >= o && t(E, r, d.flush(), n)) : t(E, r, M, n), f();
              }).catch(function() {
                return Promise.reject();
              });
            };
            return h();
          }, m;
        }();
        function l(m, v) {
          var i = {
            method: "GET",
            mode: "cors",
            credentials: "same-origin",
            signal: v,
            headers: new self.Headers(g({}, m.headers))
          };
          return m.rangeEnd && i.headers.set("Range", "bytes=" + m.rangeStart + "-" + String(m.rangeEnd - 1)), i;
        }
        function u(m, v) {
          return new self.Request(m.url, v);
        }
        var a = /* @__PURE__ */ function(m) {
          C(v, m);
          function v(i, n, E) {
            var r;
            return r = m.call(this, i) || this, r.code = void 0, r.details = void 0, r.code = n, r.details = E, r;
          }
          return v;
        }(/* @__PURE__ */ B(Error));
        const s = y;
      },
      "./src/utils/hex.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => T
        });
        var P = {
          hexDump: function(C) {
            for (var B = "", I = 0; I < C.length; I++) {
              var L = C[I].toString(16);
              L.length < 2 && (L = "0" + L), B += L;
            }
            return B;
          }
        };
        const T = P;
      },
      "./src/utils/imsc1-ttml-parser.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          IMSC1_CODEC: () => D,
          parseIMSC1: () => S
        });
        var P = p("./src/utils/mp4-tools.ts"), T = p("./src/utils/vttparser.ts"), k = p("./src/utils/vttcue.ts"), C = p("./src/demux/id3.ts"), B = p("./src/utils/timescale-conversion.ts"), I = p("./src/utils/webvtt-parser.ts");
        function L() {
          return L = Object.assign ? Object.assign.bind() : function(r) {
            for (var o = 1; o < arguments.length; o++) {
              var t = arguments[o];
              for (var d in t)
                Object.prototype.hasOwnProperty.call(t, d) && (r[d] = t[d]);
            }
            return r;
          }, L.apply(this, arguments);
        }
        var D = "stpp.ttml.im1t", _ = /^(\d{2,}):(\d{2}):(\d{2}):(\d{2})\.?(\d+)?$/, x = /^(\d*(?:\.\d*)?)(h|m|s|ms|f|t)$/, g = {
          left: "start",
          center: "center",
          right: "end",
          start: "start",
          end: "end"
        };
        function S(r, o, t, d, e) {
          var h = (0, P.findBox)(new Uint8Array(r), ["mdat"]);
          if (h.length === 0) {
            e(new Error("Could not parse IMSC1 mdat"));
            return;
          }
          var f = h.map(function(M) {
            return (0, C.utf8ArrayToStr)(M);
          }), c = (0, B.toTimescaleFromScale)(o, 1, t);
          try {
            f.forEach(function(M) {
              return d(y(M, c));
            });
          } catch (M) {
            e(M);
          }
        }
        function y(r, o) {
          var t = new DOMParser(), d = t.parseFromString(r, "text/xml"), e = d.getElementsByTagName("tt")[0];
          if (!e)
            throw new Error("Invalid ttml");
          var h = {
            frameRate: 30,
            subFrameRate: 1,
            frameRateMultiplier: 0,
            tickRate: 0
          }, f = Object.keys(h).reduce(function(U, N) {
            return U[N] = e.getAttribute("ttp:" + N) || h[N], U;
          }, {}), c = e.getAttribute("xml:space") !== "preserve", M = u(l(e, "styling", "style")), w = u(l(e, "layout", "region")), F = l(e, "body", "[begin]");
          return [].map.call(F, function(U) {
            var N = a(U, c);
            if (!N || !U.hasAttribute("begin"))
              return null;
            var H = i(U.getAttribute("begin"), f), j = i(U.getAttribute("dur"), f), z = i(U.getAttribute("end"), f);
            if (H === null)
              throw v(U);
            if (z === null) {
              if (j === null)
                throw v(U);
              z = H + j;
            }
            var Y = new k.default(H - o, z - o, N);
            Y.id = (0, I.generateCueId)(Y.startTime, Y.endTime, Y.text);
            var X = w[U.getAttribute("region")], Z = M[U.getAttribute("style")], te = s(X, Z, M), $ = te.textAlign;
            if ($) {
              var ee = g[$];
              ee && (Y.lineAlign = ee), Y.align = $;
            }
            return L(Y, te), Y;
          }).filter(function(U) {
            return U !== null;
          });
        }
        function l(r, o, t) {
          var d = r.getElementsByTagName(o)[0];
          return d ? [].slice.call(d.querySelectorAll(t)) : [];
        }
        function u(r) {
          return r.reduce(function(o, t) {
            var d = t.getAttribute("xml:id");
            return d && (o[d] = t), o;
          }, {});
        }
        function a(r, o) {
          return [].slice.call(r.childNodes).reduce(function(t, d, e) {
            var h;
            return d.nodeName === "br" && e ? t + `
` : (h = d.childNodes) !== null && h !== void 0 && h.length ? a(d, o) : o ? t + d.textContent.trim().replace(/\s+/g, " ") : t + d.textContent;
          }, "");
        }
        function s(r, o, t) {
          var d = "http://www.w3.org/ns/ttml#styling", e = null, h = [
            "displayAlign",
            "textAlign",
            "color",
            "backgroundColor",
            "fontSize",
            "fontFamily"
          ], f = r != null && r.hasAttribute("style") ? r.getAttribute("style") : null;
          return f && t.hasOwnProperty(f) && (e = t[f]), h.reduce(function(c, M) {
            var w = m(o, d, M) || m(r, d, M) || m(e, d, M);
            return w && (c[M] = w), c;
          }, {});
        }
        function m(r, o, t) {
          return r && r.hasAttributeNS(o, t) ? r.getAttributeNS(o, t) : null;
        }
        function v(r) {
          return new Error("Could not parse ttml timestamp " + r);
        }
        function i(r, o) {
          if (!r)
            return null;
          var t = (0, T.parseTimeStamp)(r);
          return t === null && (_.test(r) ? t = n(r, o) : x.test(r) && (t = E(r, o))), t;
        }
        function n(r, o) {
          var t = _.exec(r), d = (t[4] | 0) + (t[5] | 0) / o.subFrameRate;
          return (t[1] | 0) * 3600 + (t[2] | 0) * 60 + (t[3] | 0) + d / o.frameRate;
        }
        function E(r, o) {
          var t = x.exec(r), d = Number(t[1]), e = t[2];
          switch (e) {
            case "h":
              return d * 3600;
            case "m":
              return d * 60;
            case "ms":
              return d * 1e3;
            case "f":
              return d / o.frameRate;
            case "t":
              return d / o.tickRate;
          }
          return d;
        }
      },
      "./src/utils/keysystem-util.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          changeEndianness: () => k,
          convertDataUriToArrayBytes: () => C,
          strToUtf8array: () => B
        });
        var P = p("./src/utils/numeric-encoding-utils.ts");
        function T(I) {
          var L = B(I).subarray(0, 16), D = new Uint8Array(16);
          return D.set(L, 16 - L.length), D;
        }
        function k(I) {
          var L = function(_, x, g) {
            var S = _[x];
            _[x] = _[g], _[g] = S;
          };
          L(I, 0, 3), L(I, 1, 2), L(I, 4, 5), L(I, 6, 7);
        }
        function C(I) {
          var L = I.split(":"), D = null;
          if (L[0] === "data" && L.length === 2) {
            var _ = L[1].split(";"), x = _[_.length - 1].split(",");
            if (x.length === 2) {
              var g = x[0] === "base64", S = x[1];
              g ? (_.splice(-1, 1), D = (0, P.base64Decode)(S)) : D = T(S);
            }
          }
          return D;
        }
        function B(I) {
          return Uint8Array.from(unescape(encodeURIComponent(I)), function(L) {
            return L.charCodeAt(0);
          });
        }
      },
      "./src/utils/logger.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          enableLogs: () => I,
          logger: () => L
        });
        var P = function() {
        }, T = {
          trace: P,
          debug: P,
          log: P,
          warn: P,
          info: P,
          error: P
        }, k = T;
        function C(D) {
          var _ = self.console[D];
          return _ ? _.bind(self.console, "[" + D + "] >") : P;
        }
        function B(D) {
          for (var _ = arguments.length, x = new Array(_ > 1 ? _ - 1 : 0), g = 1; g < _; g++)
            x[g - 1] = arguments[g];
          x.forEach(function(S) {
            k[S] = D[S] ? D[S].bind(D) : C(S);
          });
        }
        function I(D, _) {
          if (self.console && D === !0 || typeof D == "object") {
            B(
              D,
              "debug",
              "log",
              "info",
              "warn",
              "error"
            );
            try {
              k.log('Debug logs enabled for "' + _ + '"');
            } catch {
              k = T;
            }
          } else
            k = T;
        }
        var L = k;
      },
      "./src/utils/mediakeys-helper.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          KeySystemFormats: () => T,
          KeySystemIds: () => C,
          KeySystems: () => P,
          getKeySystemsForConfig: () => L,
          getSupportedMediaKeySystemConfigurations: () => _,
          keySystemDomainToKeySystemFormat: () => I,
          keySystemFormatToKeySystemDomain: () => k,
          keySystemIdToKeySystemDomain: () => B,
          requestMediaKeySystemAccess: () => D
        });
        var P;
        (function(g) {
          g.CLEARKEY = "org.w3.clearkey", g.FAIRPLAY = "com.apple.fps", g.PLAYREADY = "com.microsoft.playready", g.WIDEVINE = "com.widevine.alpha";
        })(P || (P = {}));
        var T;
        (function(g) {
          g.CLEARKEY = "org.w3.clearkey", g.FAIRPLAY = "com.apple.streamingkeydelivery", g.PLAYREADY = "com.microsoft.playready", g.WIDEVINE = "urn:uuid:edef8ba9-79d6-4ace-a3c8-27dcd51d21ed";
        })(T || (T = {}));
        function k(g) {
          switch (g) {
            case T.FAIRPLAY:
              return P.FAIRPLAY;
            case T.PLAYREADY:
              return P.PLAYREADY;
            case T.WIDEVINE:
              return P.WIDEVINE;
            case T.CLEARKEY:
              return P.CLEARKEY;
          }
        }
        var C;
        (function(g) {
          g.WIDEVINE = "edef8ba979d64acea3c827dcd51d21ed";
        })(C || (C = {}));
        function B(g) {
          if (g === C.WIDEVINE)
            return P.WIDEVINE;
        }
        function I(g) {
          switch (g) {
            case P.FAIRPLAY:
              return T.FAIRPLAY;
            case P.PLAYREADY:
              return T.PLAYREADY;
            case P.WIDEVINE:
              return T.WIDEVINE;
            case P.CLEARKEY:
              return T.CLEARKEY;
          }
        }
        function L(g) {
          var S = g.drmSystems, y = g.widevineLicenseUrl, l = S ? [P.FAIRPLAY, P.WIDEVINE, P.PLAYREADY, P.CLEARKEY].filter(function(u) {
            return !!S[u];
          }) : [];
          return !l[P.WIDEVINE] && y && l.push(P.WIDEVINE), l;
        }
        var D = function() {
          return typeof self < "u" && self.navigator && self.navigator.requestMediaKeySystemAccess ? self.navigator.requestMediaKeySystemAccess.bind(self.navigator) : null;
        }();
        function _(g, S, y, l) {
          var u;
          switch (g) {
            case P.FAIRPLAY:
              u = ["cenc", "sinf"];
              break;
            case P.WIDEVINE:
            case P.PLAYREADY:
              u = ["cenc"];
              break;
            case P.CLEARKEY:
              u = ["cenc", "keyids"];
              break;
            default:
              throw new Error("Unknown key-system: " + g);
          }
          return x(u, S, y, l);
        }
        function x(g, S, y, l) {
          var u = {
            initDataTypes: g,
            persistentState: l.persistentState || "not-allowed",
            distinctiveIdentifier: l.distinctiveIdentifier || "not-allowed",
            sessionTypes: l.sessionTypes || [l.sessionType || "temporary"],
            audioCapabilities: S.map(function(a) {
              return {
                contentType: 'audio/mp4; codecs="' + a + '"',
                robustness: l.audioRobustness || "",
                encryptionScheme: l.audioEncryptionScheme || null
              };
            }),
            videoCapabilities: y.map(function(a) {
              return {
                contentType: 'video/mp4; codecs="' + a + '"',
                robustness: l.videoRobustness || "",
                encryptionScheme: l.videoEncryptionScheme || null
              };
            })
          };
          return [u];
        }
      },
      "./src/utils/mediasource-helper.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          getMediaSource: () => P
        });
        function P() {
          return self.MediaSource || self.WebKitMediaSource;
        }
      },
      "./src/utils/mp4-tools.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          RemuxerTrackIdConfig: () => D,
          appendUint8Array: () => o,
          bin2str: () => _,
          computeRawDurationFromSamples: () => n,
          discardEPB: () => f,
          findBox: () => l,
          getDuration: () => i,
          getStartDTS: () => v,
          mp4Box: () => M,
          mp4pssh: () => w,
          offsetStartDTS: () => E,
          parseEmsg: () => c,
          parseInitSegment: () => a,
          parsePssh: () => F,
          parseSEIMessageFromNALu: () => h,
          parseSamples: () => t,
          parseSegmentIndex: () => u,
          parseSinf: () => m,
          patchEncyptionData: () => s,
          readSint32: () => S,
          readUint16: () => x,
          readUint32: () => g,
          segmentValidRange: () => r,
          writeUint32: () => y
        });
        var P = p("./src/loader/fragment.ts"), T = p("./src/utils/typed-array.ts"), k = p("./src/demux/id3.ts"), C = p("./src/utils/logger.ts"), B = p("./src/utils/hex.ts"), I = Math.pow(2, 32) - 1, L = [].push, D = {
          video: 1,
          audio: 2,
          id3: 3,
          text: 4
        };
        function _(U) {
          return String.fromCharCode.apply(null, U);
        }
        function x(U, N) {
          var H = U[N] << 8 | U[N + 1];
          return H < 0 ? 65536 + H : H;
        }
        function g(U, N) {
          var H = S(U, N);
          return H < 0 ? 4294967296 + H : H;
        }
        function S(U, N) {
          return U[N] << 24 | U[N + 1] << 16 | U[N + 2] << 8 | U[N + 3];
        }
        function y(U, N, H) {
          U[N] = H >> 24, U[N + 1] = H >> 16 & 255, U[N + 2] = H >> 8 & 255, U[N + 3] = H & 255;
        }
        function l(U, N) {
          var H = [];
          if (!N.length)
            return H;
          for (var j = U.byteLength, z = 0; z < j; ) {
            var Y = g(U, z), X = _(U.subarray(z + 4, z + 8)), Z = Y > 1 ? z + Y : j;
            if (X === N[0])
              if (N.length === 1)
                H.push(U.subarray(z + 8, Z));
              else {
                var te = l(U.subarray(z + 8, Z), N.slice(1));
                te.length && L.apply(H, te);
              }
            z = Z;
          }
          return H;
        }
        function u(U) {
          var N = [], H = U[0], j = 8, z = g(U, j);
          j += 4;
          var Y = 0, X = 0;
          H === 0 ? j += 8 : j += 16, j += 2;
          var Z = U.length + X, te = x(U, j);
          j += 2;
          for (var $ = 0; $ < te; $++) {
            var ee = j, ne = g(U, ee);
            ee += 4;
            var oe = ne & 2147483647, ae = (ne & 2147483648) >>> 31;
            if (ae === 1)
              return console.warn("SIDX has hierarchical references (not supported)"), null;
            var ie = g(U, ee);
            ee += 4, N.push({
              referenceSize: oe,
              subsegmentDuration: ie,
              info: {
                duration: ie / z,
                start: Z,
                end: Z + oe - 1
              }
            }), Z += oe, ee += 4, j = ee;
          }
          return {
            earliestPresentationTime: Y,
            timescale: z,
            version: H,
            referencesCount: te,
            references: N
          };
        }
        function a(U) {
          for (var N = [], H = l(U, ["moov", "trak"]), j = 0; j < H.length; j++) {
            var z = H[j], Y = l(z, ["tkhd"])[0];
            if (Y) {
              var X = Y[0], Z = X === 0 ? 12 : 20, te = g(Y, Z), $ = l(z, ["mdia", "mdhd"])[0];
              if ($) {
                X = $[0], Z = X === 0 ? 12 : 20;
                var ee = g($, Z), ne = l(z, ["mdia", "hdlr"])[0];
                if (ne) {
                  var oe = _(ne.subarray(8, 12)), ae = {
                    soun: P.ElementaryStreamTypes.AUDIO,
                    vide: P.ElementaryStreamTypes.VIDEO
                  }[oe];
                  if (ae) {
                    var ie = l(z, ["mdia", "minf", "stbl", "stsd"])[0], ce = void 0;
                    ie && (ce = _(ie.subarray(12, 16))), N[te] = {
                      timescale: ee,
                      type: ae
                    }, N[ae] = {
                      timescale: ee,
                      id: te,
                      codec: ce
                    };
                  }
                }
              }
            }
          }
          var me = l(U, ["moov", "mvex", "trex"]);
          return me.forEach(function(pe) {
            var Ie = g(pe, 4), Ee = N[Ie];
            Ee && (Ee.default = {
              duration: g(pe, 12),
              flags: g(pe, 20)
            });
          }), N;
        }
        function s(U, N) {
          if (!U || !N)
            return U;
          var H = N.keyId;
          if (H && N.isCommonEncryption) {
            var j = l(U, ["moov", "trak"]);
            j.forEach(function(z) {
              var Y = l(z, ["mdia", "minf", "stbl", "stsd"])[0], X = Y.subarray(8), Z = l(X, ["enca"]), te = Z.length > 0;
              te || (Z = l(X, ["encv"])), Z.forEach(function($) {
                var ee = te ? $.subarray(28) : $.subarray(78), ne = l(ee, ["sinf"]);
                ne.forEach(function(oe) {
                  var ae = m(oe);
                  if (ae) {
                    var ie = ae.subarray(8, 24);
                    ie.some(function(ce) {
                      return ce !== 0;
                    }) || (C.logger.log("[eme] Patching keyId in 'enc" + (te ? "a" : "v") + ">sinf>>tenc' box: " + B.default.hexDump(ie) + " -> " + B.default.hexDump(H)), ae.set(H, 8));
                  }
                });
              });
            });
          }
          return U;
        }
        function m(U) {
          var N = l(U, ["schm"])[0];
          if (N) {
            var H = _(N.subarray(4, 8));
            if (H === "cbcs" || H === "cenc")
              return l(U, ["schi", "tenc"])[0];
          }
          return C.logger.error("[eme] missing 'schm' box"), null;
        }
        function v(U, N) {
          return l(N, ["moof", "traf"]).reduce(function(H, j) {
            var z = l(j, ["tfdt"])[0], Y = z[0], X = l(j, ["tfhd"]).reduce(function(Z, te) {
              var $ = g(te, 4), ee = U[$];
              if (ee) {
                var ne = g(z, 4);
                Y === 1 && (ne *= Math.pow(2, 32), ne += g(z, 8));
                var oe = ee.timescale || 9e4, ae = ne / oe;
                if (isFinite(ae) && (Z === null || ae < Z))
                  return ae;
              }
              return Z;
            }, null);
            return X !== null && isFinite(X) && (H === null || X < H) ? X : H;
          }, null) || 0;
        }
        function i(U, N) {
          for (var H = 0, j = 0, z = 0, Y = l(U, ["moof", "traf"]), X = 0; X < Y.length; X++) {
            var Z = Y[X], te = l(Z, ["tfhd"])[0], $ = g(te, 4), ee = N[$];
            if (!!ee) {
              var ne = ee.default, oe = g(te, 0) | (ne == null ? void 0 : ne.flags), ae = ne == null ? void 0 : ne.duration;
              oe & 8 && (oe & 2 ? ae = g(te, 12) : ae = g(te, 8));
              for (var ie = ee.timescale || 9e4, ce = l(Z, ["trun"]), me = 0; me < ce.length; me++) {
                if (H = n(ce[me]), !H && ae) {
                  var pe = g(ce[me], 4);
                  H = ae * pe;
                }
                ee.type === P.ElementaryStreamTypes.VIDEO ? j += H / ie : ee.type === P.ElementaryStreamTypes.AUDIO && (z += H / ie);
              }
            }
          }
          if (j === 0 && z === 0) {
            for (var Ie = 0, Ee = l(U, ["sidx"]), _e = 0; _e < Ee.length; _e++) {
              var Te = u(Ee[_e]);
              Te != null && Te.references && (Ie += Te.references.reduce(function(Se, xe) {
                return Se + xe.info.duration || 0;
              }, 0));
            }
            return Ie;
          }
          return j || z;
        }
        function n(U) {
          var N = g(U, 0), H = 8;
          N & 1 && (H += 4), N & 4 && (H += 4);
          for (var j = 0, z = g(U, 4), Y = 0; Y < z; Y++) {
            if (N & 256) {
              var X = g(U, H);
              j += X, H += 4;
            }
            N & 512 && (H += 4), N & 1024 && (H += 4), N & 2048 && (H += 4);
          }
          return j;
        }
        function E(U, N, H) {
          l(N, ["moof", "traf"]).forEach(function(j) {
            l(j, ["tfhd"]).forEach(function(z) {
              var Y = g(z, 4), X = U[Y];
              if (!!X) {
                var Z = X.timescale || 9e4;
                l(j, ["tfdt"]).forEach(function(te) {
                  var $ = te[0], ee = g(te, 4);
                  if ($ === 0)
                    ee -= H * Z, ee = Math.max(ee, 0), y(te, 4, ee);
                  else {
                    ee *= Math.pow(2, 32), ee += g(te, 8), ee -= H * Z, ee = Math.max(ee, 0);
                    var ne = Math.floor(ee / (I + 1)), oe = Math.floor(ee % (I + 1));
                    y(te, 4, ne), y(te, 8, oe);
                  }
                });
              }
            });
          });
        }
        function r(U) {
          var N = {
            valid: null,
            remainder: null
          }, H = l(U, ["moof"]);
          if (H) {
            if (H.length < 2)
              return N.remainder = U, N;
          } else
            return N;
          var j = H[H.length - 1];
          return N.valid = (0, T.sliceUint8)(U, 0, j.byteOffset - 8), N.remainder = (0, T.sliceUint8)(U, j.byteOffset - 8), N;
        }
        function o(U, N) {
          var H = new Uint8Array(U.length + N.length);
          return H.set(U), H.set(N, U.length), H;
        }
        function t(U, N) {
          var H = [], j = N.samples, z = N.timescale, Y = N.id, X = !1, Z = l(j, ["moof"]);
          return Z.map(function(te) {
            var $ = te.byteOffset - 8, ee = l(te, ["traf"]);
            ee.map(function(ne) {
              var oe = l(ne, ["tfdt"]).map(function(ae) {
                var ie = ae[0], ce = g(ae, 4);
                return ie === 1 && (ce *= Math.pow(2, 32), ce += g(ae, 8)), ce / z;
              })[0];
              return oe !== void 0 && (U = oe), l(ne, ["tfhd"]).map(function(ae) {
                var ie = g(ae, 4), ce = g(ae, 0) & 16777215, me = (ce & 1) !== 0, pe = (ce & 2) !== 0, Ie = (ce & 8) !== 0, Ee = 0, _e = (ce & 16) !== 0, Te = 0, Se = (ce & 32) !== 0, xe = 8;
                ie === Y && (me && (xe += 8), pe && (xe += 4), Ie && (Ee = g(ae, xe), xe += 4), _e && (Te = g(ae, xe), xe += 4), Se && (xe += 4), N.type === "video" && (X = d(N.codec)), l(ne, ["trun"]).map(function(Re) {
                  var we = Re[0], Ce = g(Re, 0) & 16777215, Me = (Ce & 1) !== 0, Ge = 0, ye = (Ce & 4) !== 0, st = (Ce & 256) !== 0, Xe = 0, He = (Ce & 512) !== 0, Ve = 0, Ue = (Ce & 1024) !== 0, Be = (Ce & 2048) !== 0, je = 0, Qe = g(Re, 4), Oe = 8;
                  Me && (Ge = g(Re, Oe), Oe += 4), ye && (Oe += 4);
                  for (var qe = Ge + $, Ze = 0; Ze < Qe; Ze++) {
                    if (st ? (Xe = g(Re, Oe), Oe += 4) : Xe = Ee, He ? (Ve = g(Re, Oe), Oe += 4) : Ve = Te, Ue && (Oe += 4), Be && (we === 0 ? je = g(Re, Oe) : je = S(Re, Oe), Oe += 4), N.type === P.ElementaryStreamTypes.VIDEO)
                      for (var pt = 0; pt < Ve; ) {
                        var ut = g(j, qe);
                        if (qe += 4, e(X, j[qe])) {
                          var ht = j.subarray(qe, qe + ut);
                          h(ht, X ? 2 : 1, U + je / z, H);
                        }
                        qe += ut, pt += ut + 4;
                      }
                    U += Xe / z;
                  }
                }));
              });
            });
          }), H;
        }
        function d(U) {
          if (!U)
            return !1;
          var N = U.indexOf("."), H = N < 0 ? U : U.substring(0, N);
          return H === "hvc1" || H === "hev1" || H === "dvh1" || H === "dvhe";
        }
        function e(U, N) {
          if (U) {
            var H = N >> 1 & 63;
            return H === 39 || H === 40;
          } else {
            var j = N & 31;
            return j === 6;
          }
        }
        function h(U, N, H, j) {
          var z = f(U), Y = 0;
          Y += N;
          for (var X = 0, Z = 0, te = !1, $ = 0; Y < z.length; ) {
            X = 0;
            do {
              if (Y >= z.length)
                break;
              $ = z[Y++], X += $;
            } while ($ === 255);
            Z = 0;
            do {
              if (Y >= z.length)
                break;
              $ = z[Y++], Z += $;
            } while ($ === 255);
            var ee = z.length - Y;
            if (!te && X === 4 && Y < z.length) {
              te = !0;
              var ne = z[Y++];
              if (ne === 181) {
                var oe = x(z, Y);
                if (Y += 2, oe === 49) {
                  var ae = g(z, Y);
                  if (Y += 4, ae === 1195456820) {
                    var ie = z[Y++];
                    if (ie === 3) {
                      var ce = z[Y++], me = 31 & ce, pe = 64 & ce, Ie = pe ? 2 + me * 3 : 0, Ee = new Uint8Array(Ie);
                      if (pe) {
                        Ee[0] = ce;
                        for (var _e = 1; _e < Ie; _e++)
                          Ee[_e] = z[Y++];
                      }
                      j.push({
                        type: ie,
                        payloadType: X,
                        pts: H,
                        bytes: Ee
                      });
                    }
                  }
                }
              }
            } else if (X === 5 && Z < ee) {
              if (te = !0, Z > 16) {
                for (var Te = [], Se = 0; Se < 16; Se++) {
                  var xe = z[Y++].toString(16);
                  Te.push(xe.length == 1 ? "0" + xe : xe), (Se === 3 || Se === 5 || Se === 7 || Se === 9) && Te.push("-");
                }
                for (var Re = Z - 16, we = new Uint8Array(Re), Ce = 0; Ce < Re; Ce++)
                  we[Ce] = z[Y++];
                j.push({
                  payloadType: X,
                  pts: H,
                  uuid: Te.join(""),
                  userData: (0, k.utf8ArrayToStr)(we),
                  userDataBytes: we
                });
              }
            } else if (Z < ee)
              Y += Z;
            else if (Z > ee)
              break;
          }
        }
        function f(U) {
          for (var N = U.byteLength, H = [], j = 1; j < N - 2; )
            U[j] === 0 && U[j + 1] === 0 && U[j + 2] === 3 ? (H.push(j + 2), j += 2) : j++;
          if (H.length === 0)
            return U;
          var z = N - H.length, Y = new Uint8Array(z), X = 0;
          for (j = 0; j < z; X++, j++)
            X === H[0] && (X++, H.shift()), Y[j] = U[X];
          return Y;
        }
        function c(U) {
          var N = U[0], H = "", j = "", z = 0, Y = 0, X = 0, Z = 0, te = 0, $ = 0;
          if (N === 0) {
            for (; _(U.subarray($, $ + 1)) !== "\0"; )
              H += _(U.subarray($, $ + 1)), $ += 1;
            for (H += _(U.subarray($, $ + 1)), $ += 1; _(U.subarray($, $ + 1)) !== "\0"; )
              j += _(U.subarray($, $ + 1)), $ += 1;
            j += _(U.subarray($, $ + 1)), $ += 1, z = g(U, 12), Y = g(U, 16), Z = g(U, 20), te = g(U, 24), $ = 28;
          } else if (N === 1) {
            $ += 4, z = g(U, $), $ += 4;
            var ee = g(U, $);
            $ += 4;
            var ne = g(U, $);
            for ($ += 4, X = Math.pow(2, 32) * ee + ne, Number.isSafeInteger(X) || (X = Number.MAX_SAFE_INTEGER, console.warn("Presentation time exceeds safe integer limit and wrapped to max safe integer in parsing emsg box")), Z = g(U, $), $ += 4, te = g(U, $), $ += 4; _(U.subarray($, $ + 1)) !== "\0"; )
              H += _(U.subarray($, $ + 1)), $ += 1;
            for (H += _(U.subarray($, $ + 1)), $ += 1; _(U.subarray($, $ + 1)) !== "\0"; )
              j += _(U.subarray($, $ + 1)), $ += 1;
            j += _(U.subarray($, $ + 1)), $ += 1;
          }
          var oe = U.subarray($, U.byteLength);
          return {
            schemeIdUri: H,
            value: j,
            timeScale: z,
            presentationTime: X,
            presentationTimeDelta: Y,
            eventDuration: Z,
            id: te,
            payload: oe
          };
        }
        function M(U) {
          for (var N = arguments.length, H = new Array(N > 1 ? N - 1 : 0), j = 1; j < N; j++)
            H[j - 1] = arguments[j];
          for (var z = H.length, Y = 8, X = z; X--; )
            Y += H[X].byteLength;
          var Z = new Uint8Array(Y);
          for (Z[0] = Y >> 24 & 255, Z[1] = Y >> 16 & 255, Z[2] = Y >> 8 & 255, Z[3] = Y & 255, Z.set(U, 4), X = 0, Y = 8; X < z; X++)
            Z.set(H[X], Y), Y += H[X].byteLength;
          return Z;
        }
        function w(U, N, H) {
          if (U.byteLength !== 16)
            throw new RangeError("Invalid system id");
          var j, z;
          if (N) {
            j = 1, z = new Uint8Array(N.length * 16);
            for (var Y = 0; Y < N.length; Y++) {
              var X = N[Y];
              if (X.byteLength !== 16)
                throw new RangeError("Invalid key");
              z.set(X, Y * 16);
            }
          } else
            j = 0, z = new Uint8Array();
          var Z;
          j > 0 ? (Z = new Uint8Array(4), N.length > 0 && new DataView(Z.buffer).setUint32(0, N.length, !1)) : Z = new Uint8Array();
          var te = new Uint8Array(4);
          return H && H.byteLength > 0 && new DataView(te.buffer).setUint32(0, H.byteLength, !1), M(
            [112, 115, 115, 104],
            new Uint8Array([
              j,
              0,
              0,
              0
            ]),
            U,
            Z,
            z,
            te,
            H || new Uint8Array()
          );
        }
        function F(U) {
          if (!(U instanceof ArrayBuffer) || U.byteLength < 32)
            return null;
          var N = {
            version: 0,
            systemId: "",
            kids: null,
            data: null
          }, H = new DataView(U), j = H.getUint32(0);
          if (U.byteLength !== j && j > 44)
            return null;
          var z = H.getUint32(4);
          if (z !== 1886614376 || (N.version = H.getUint32(8) >>> 24, N.version > 1))
            return null;
          N.systemId = B.default.hexDump(new Uint8Array(U, 12, 16));
          var Y = H.getUint32(28);
          if (N.version === 0) {
            if (j - 32 < Y)
              return null;
            N.data = new Uint8Array(U, 32, Y);
          } else if (N.version === 1) {
            N.kids = [];
            for (var X = 0; X < Y; X++)
              N.kids.push(new Uint8Array(U, 32 + X * 16, 16));
          }
          return N;
        }
      },
      "./src/utils/numeric-encoding-utils.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          base64Decode: () => I,
          base64DecodeToStr: () => k,
          base64Encode: () => C,
          base64ToBase64Url: () => P,
          base64UrlEncode: () => B,
          strToBase64Encode: () => T
        });
        function P(L) {
          return L.replace(/\+/g, "-").replace(/\//g, "_").replace(/=+$/, "");
        }
        function T(L) {
          return btoa(L);
        }
        function k(L) {
          return atob(L);
        }
        function C(L) {
          return btoa(String.fromCharCode.apply(String, L));
        }
        function B(L) {
          return P(C(L));
        }
        function I(L) {
          return Uint8Array.from(atob(L), function(D) {
            return D.charCodeAt(0);
          });
        }
      },
      "./src/utils/output-filter.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => P
        });
        var P = /* @__PURE__ */ function() {
          function T(C, B) {
            this.timelineController = void 0, this.cueRanges = [], this.trackName = void 0, this.startTime = null, this.endTime = null, this.screen = null, this.timelineController = C, this.trackName = B;
          }
          var k = T.prototype;
          return k.dispatchCue = function() {
            this.startTime !== null && (this.timelineController.addCues(this.trackName, this.startTime, this.endTime, this.screen, this.cueRanges), this.startTime = null);
          }, k.newCue = function(B, I, L) {
            (this.startTime === null || this.startTime > B) && (this.startTime = B), this.endTime = I, this.screen = L, this.timelineController.createCaptionsTrack(this.trackName);
          }, k.reset = function() {
            this.cueRanges = [], this.startTime = null;
          }, T;
        }();
      },
      "./src/utils/texttrack-utils.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          addCueToTrack: () => k,
          clearCurrentCues: () => C,
          getCuesInRange: () => L,
          removeCuesInRange: () => B,
          sendAddTrackEvent: () => T
        });
        var P = p("./src/utils/logger.ts");
        function T(D, _) {
          var x;
          try {
            x = new Event("addtrack");
          } catch {
            x = document.createEvent("Event"), x.initEvent("addtrack", !1, !1);
          }
          x.track = D, _.dispatchEvent(x);
        }
        function k(D, _) {
          var x = D.mode;
          if (x === "disabled" && (D.mode = "hidden"), D.cues && !D.cues.getCueById(_.id))
            try {
              if (D.addCue(_), !D.cues.getCueById(_.id))
                throw new Error("addCue is failed for: " + _);
            } catch (S) {
              P.logger.debug("[texttrack-utils]: " + S);
              var g = new self.TextTrackCue(_.startTime, _.endTime, _.text);
              g.id = _.id, D.addCue(g);
            }
          x === "disabled" && (D.mode = x);
        }
        function C(D) {
          var _ = D.mode;
          if (_ === "disabled" && (D.mode = "hidden"), D.cues)
            for (var x = D.cues.length; x--; )
              D.removeCue(D.cues[x]);
          _ === "disabled" && (D.mode = _);
        }
        function B(D, _, x, g) {
          var S = D.mode;
          if (S === "disabled" && (D.mode = "hidden"), D.cues && D.cues.length > 0)
            for (var y = L(D.cues, _, x), l = 0; l < y.length; l++)
              (!g || g(y[l])) && D.removeCue(y[l]);
          S === "disabled" && (D.mode = S);
        }
        function I(D, _) {
          if (_ < D[0].startTime)
            return 0;
          var x = D.length - 1;
          if (_ > D[x].endTime)
            return -1;
          for (var g = 0, S = x; g <= S; ) {
            var y = Math.floor((S + g) / 2);
            if (_ < D[y].startTime)
              S = y - 1;
            else if (_ > D[y].startTime && g < x)
              g = y + 1;
            else
              return y;
          }
          return D[g].startTime - _ < _ - D[S].startTime ? g : S;
        }
        function L(D, _, x) {
          var g = [], S = I(D, _);
          if (S > -1)
            for (var y = S, l = D.length; y < l; y++) {
              var u = D[y];
              if (u.startTime >= _ && u.endTime <= x)
                g.push(u);
              else if (u.startTime > x)
                return g;
            }
          return g;
        }
      },
      "./src/utils/time-ranges.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => T
        });
        var P = {
          toString: function(C) {
            for (var B = "", I = C.length, L = 0; L < I; L++)
              B += "[" + C.start(L).toFixed(3) + "-" + C.end(L).toFixed(3) + "]";
            return B;
          }
        };
        const T = P;
      },
      "./src/utils/timescale-conversion.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          toMpegTsClockFromTimescale: () => B,
          toMsFromMpegTsClock: () => C,
          toTimescaleFromBase: () => T,
          toTimescaleFromScale: () => k
        });
        var P = 9e4;
        function T(I, L, D, _) {
          D === void 0 && (D = 1), _ === void 0 && (_ = !1);
          var x = I * L * D;
          return _ ? Math.round(x) : x;
        }
        function k(I, L, D, _) {
          return D === void 0 && (D = 1), _ === void 0 && (_ = !1), T(I, L, 1 / D, _);
        }
        function C(I, L) {
          return L === void 0 && (L = !1), T(I, 1e3, 1 / P, L);
        }
        function B(I, L) {
          return L === void 0 && (L = 1), T(I, P, 1 / L);
        }
      },
      "./src/utils/typed-array.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          sliceUint8: () => P
        });
        function P(T, k, C) {
          return Uint8Array.prototype.slice ? T.slice(k, C) : new Uint8Array(Array.prototype.slice.call(T, k, C));
        }
      },
      "./src/utils/vttcue.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => P
        });
        const P = function() {
          if (typeof self < "u" && self.VTTCue)
            return self.VTTCue;
          var T = ["", "lr", "rl"], k = ["start", "middle", "end", "left", "right"];
          function C(_, x) {
            if (typeof x != "string" || !Array.isArray(_))
              return !1;
            var g = x.toLowerCase();
            return ~_.indexOf(g) ? g : !1;
          }
          function B(_) {
            return C(T, _);
          }
          function I(_) {
            return C(k, _);
          }
          function L(_) {
            for (var x = arguments.length, g = new Array(x > 1 ? x - 1 : 0), S = 1; S < x; S++)
              g[S - 1] = arguments[S];
            for (var y = 1; y < arguments.length; y++) {
              var l = arguments[y];
              for (var u in l)
                _[u] = l[u];
            }
            return _;
          }
          function D(_, x, g) {
            var S = this, y = {
              enumerable: !0
            };
            S.hasBeenReset = !1;
            var l = "", u = !1, a = _, s = x, m = g, v = null, i = "", n = !0, E = "auto", r = "start", o = 50, t = "middle", d = 50, e = "middle";
            Object.defineProperty(S, "id", L({}, y, {
              get: function() {
                return l;
              },
              set: function(f) {
                l = "" + f;
              }
            })), Object.defineProperty(S, "pauseOnExit", L({}, y, {
              get: function() {
                return u;
              },
              set: function(f) {
                u = !!f;
              }
            })), Object.defineProperty(S, "startTime", L({}, y, {
              get: function() {
                return a;
              },
              set: function(f) {
                if (typeof f != "number")
                  throw new TypeError("Start time must be set to a number.");
                a = f, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "endTime", L({}, y, {
              get: function() {
                return s;
              },
              set: function(f) {
                if (typeof f != "number")
                  throw new TypeError("End time must be set to a number.");
                s = f, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "text", L({}, y, {
              get: function() {
                return m;
              },
              set: function(f) {
                m = "" + f, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "region", L({}, y, {
              get: function() {
                return v;
              },
              set: function(f) {
                v = f, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "vertical", L({}, y, {
              get: function() {
                return i;
              },
              set: function(f) {
                var c = B(f);
                if (c === !1)
                  throw new SyntaxError("An invalid or illegal string was specified.");
                i = c, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "snapToLines", L({}, y, {
              get: function() {
                return n;
              },
              set: function(f) {
                n = !!f, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "line", L({}, y, {
              get: function() {
                return E;
              },
              set: function(f) {
                if (typeof f != "number" && f !== "auto")
                  throw new SyntaxError("An invalid number or illegal string was specified.");
                E = f, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "lineAlign", L({}, y, {
              get: function() {
                return r;
              },
              set: function(f) {
                var c = I(f);
                if (!c)
                  throw new SyntaxError("An invalid or illegal string was specified.");
                r = c, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "position", L({}, y, {
              get: function() {
                return o;
              },
              set: function(f) {
                if (f < 0 || f > 100)
                  throw new Error("Position must be between 0 and 100.");
                o = f, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "positionAlign", L({}, y, {
              get: function() {
                return t;
              },
              set: function(f) {
                var c = I(f);
                if (!c)
                  throw new SyntaxError("An invalid or illegal string was specified.");
                t = c, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "size", L({}, y, {
              get: function() {
                return d;
              },
              set: function(f) {
                if (f < 0 || f > 100)
                  throw new Error("Size must be between 0 and 100.");
                d = f, this.hasBeenReset = !0;
              }
            })), Object.defineProperty(S, "align", L({}, y, {
              get: function() {
                return e;
              },
              set: function(f) {
                var c = I(f);
                if (!c)
                  throw new SyntaxError("An invalid or illegal string was specified.");
                e = c, this.hasBeenReset = !0;
              }
            })), S.displayState = void 0;
          }
          return D.prototype.getCueAsHTML = function() {
            var _ = self.WebVTT;
            return _.convertCueToDOMTree(self, this.text);
          }, D;
        }();
      },
      "./src/utils/vttparser.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          VTTParser: () => x,
          fixLineBreaks: () => _,
          parseTimeStamp: () => k
        });
        var P = p("./src/utils/vttcue.ts"), T = /* @__PURE__ */ function() {
          function g() {
          }
          var S = g.prototype;
          return S.decode = function(l, u) {
            if (!l)
              return "";
            if (typeof l != "string")
              throw new Error("Error - expected string data.");
            return decodeURIComponent(encodeURIComponent(l));
          }, g;
        }();
        function k(g) {
          function S(l, u, a, s) {
            return (l | 0) * 3600 + (u | 0) * 60 + (a | 0) + parseFloat(s || 0);
          }
          var y = g.match(/^(?:(\d+):)?(\d{2}):(\d{2})(\.\d+)?/);
          return y ? parseFloat(y[2]) > 59 ? S(y[2], y[3], 0, y[4]) : S(y[1], y[2], y[3], y[4]) : null;
        }
        var C = /* @__PURE__ */ function() {
          function g() {
            this.values = /* @__PURE__ */ Object.create(null);
          }
          var S = g.prototype;
          return S.set = function(l, u) {
            !this.get(l) && u !== "" && (this.values[l] = u);
          }, S.get = function(l, u, a) {
            return a ? this.has(l) ? this.values[l] : u[a] : this.has(l) ? this.values[l] : u;
          }, S.has = function(l) {
            return l in this.values;
          }, S.alt = function(l, u, a) {
            for (var s = 0; s < a.length; ++s)
              if (u === a[s]) {
                this.set(l, u);
                break;
              }
          }, S.integer = function(l, u) {
            /^-?\d+$/.test(u) && this.set(l, parseInt(u, 10));
          }, S.percent = function(l, u) {
            if (/^([\d]{1,3})(\.[\d]*)?%$/.test(u)) {
              var a = parseFloat(u);
              if (a >= 0 && a <= 100)
                return this.set(l, a), !0;
            }
            return !1;
          }, g;
        }();
        function B(g, S, y, l) {
          var u = l ? g.split(l) : [g];
          for (var a in u)
            if (typeof u[a] == "string") {
              var s = u[a].split(y);
              if (s.length === 2) {
                var m = s[0], v = s[1];
                S(m, v);
              }
            }
        }
        var I = new P.default(0, 0, ""), L = I.align === "middle" ? "middle" : "center";
        function D(g, S, y) {
          var l = g;
          function u() {
            var m = k(g);
            if (m === null)
              throw new Error("Malformed timestamp: " + l);
            return g = g.replace(/^[^\sa-zA-Z-]+/, ""), m;
          }
          function a(m, v) {
            var i = new C();
            B(m, function(r, o) {
              var t;
              switch (r) {
                case "region":
                  for (var d = y.length - 1; d >= 0; d--)
                    if (y[d].id === o) {
                      i.set(r, y[d].region);
                      break;
                    }
                  break;
                case "vertical":
                  i.alt(r, o, ["rl", "lr"]);
                  break;
                case "line":
                  t = o.split(","), i.integer(r, t[0]), i.percent(r, t[0]) && i.set("snapToLines", !1), i.alt(r, t[0], ["auto"]), t.length === 2 && i.alt("lineAlign", t[1], ["start", L, "end"]);
                  break;
                case "position":
                  t = o.split(","), i.percent(r, t[0]), t.length === 2 && i.alt("positionAlign", t[1], ["start", L, "end", "line-left", "line-right", "auto"]);
                  break;
                case "size":
                  i.percent(r, o);
                  break;
                case "align":
                  i.alt(r, o, ["start", L, "end", "left", "right"]);
                  break;
              }
            }, /:/, /\s/), v.region = i.get("region", null), v.vertical = i.get("vertical", "");
            var n = i.get("line", "auto");
            n === "auto" && I.line === -1 && (n = -1), v.line = n, v.lineAlign = i.get("lineAlign", "start"), v.snapToLines = i.get("snapToLines", !0), v.size = i.get("size", 100), v.align = i.get("align", L);
            var E = i.get("position", "auto");
            E === "auto" && I.position === 50 && (E = v.align === "start" || v.align === "left" ? 0 : v.align === "end" || v.align === "right" ? 100 : 50), v.position = E;
          }
          function s() {
            g = g.replace(/^\s+/, "");
          }
          if (s(), S.startTime = u(), s(), g.slice(0, 3) !== "-->")
            throw new Error("Malformed time stamp (time stamps must be separated by '-->'): " + l);
          g = g.slice(3), s(), S.endTime = u(), s(), a(g, S);
        }
        function _(g) {
          return g.replace(/<br(?: \/)?>/gi, `
`);
        }
        var x = /* @__PURE__ */ function() {
          function g() {
            this.state = "INITIAL", this.buffer = "", this.decoder = new T(), this.regionList = [], this.cue = null, this.oncue = void 0, this.onparsingerror = void 0, this.onflush = void 0;
          }
          var S = g.prototype;
          return S.parse = function(l) {
            var u = this;
            l && (u.buffer += u.decoder.decode(l, {
              stream: !0
            }));
            function a() {
              var E = u.buffer, r = 0;
              for (E = _(E); r < E.length && E[r] !== "\r" && E[r] !== `
`; )
                ++r;
              var o = E.slice(0, r);
              return E[r] === "\r" && ++r, E[r] === `
` && ++r, u.buffer = E.slice(r), o;
            }
            function s(E) {
              B(E, function(r, o) {
              }, /:/);
            }
            try {
              var m = "";
              if (u.state === "INITIAL") {
                if (!/\r\n|\n/.test(u.buffer))
                  return this;
                m = a();
                var v = m.match(/^(ï»¿)?WEBVTT([ \t].*)?$/);
                if (!v || !v[0])
                  throw new Error("Malformed WebVTT signature.");
                u.state = "HEADER";
              }
              for (var i = !1; u.buffer; ) {
                if (!/\r\n|\n/.test(u.buffer))
                  return this;
                switch (i ? i = !1 : m = a(), u.state) {
                  case "HEADER":
                    /:/.test(m) ? s(m) : m || (u.state = "ID");
                    continue;
                  case "NOTE":
                    m || (u.state = "ID");
                    continue;
                  case "ID":
                    if (/^NOTE($|[ \t])/.test(m)) {
                      u.state = "NOTE";
                      break;
                    }
                    if (!m)
                      continue;
                    if (u.cue = new P.default(0, 0, ""), u.state = "CUE", m.indexOf("-->") === -1) {
                      u.cue.id = m;
                      continue;
                    }
                  case "CUE":
                    if (!u.cue) {
                      u.state = "BADCUE";
                      continue;
                    }
                    try {
                      D(m, u.cue, u.regionList);
                    } catch {
                      u.cue = null, u.state = "BADCUE";
                      continue;
                    }
                    u.state = "CUETEXT";
                    continue;
                  case "CUETEXT":
                    {
                      var n = m.indexOf("-->") !== -1;
                      if (!m || n && (i = !0)) {
                        u.oncue && u.cue && u.oncue(u.cue), u.cue = null, u.state = "ID";
                        continue;
                      }
                      if (u.cue === null)
                        continue;
                      u.cue.text && (u.cue.text += `
`), u.cue.text += m;
                    }
                    continue;
                  case "BADCUE":
                    m || (u.state = "ID");
                }
              }
            } catch {
              u.state === "CUETEXT" && u.cue && u.oncue && u.oncue(u.cue), u.cue = null, u.state = u.state === "INITIAL" ? "BADWEBVTT" : "BADCUE";
            }
            return this;
          }, S.flush = function() {
            var l = this;
            try {
              if ((l.cue || l.state === "HEADER") && (l.buffer += `

`, l.parse()), l.state === "INITIAL" || l.state === "BADWEBVTT")
                throw new Error("Malformed WebVTT signature.");
            } catch (u) {
              l.onparsingerror && l.onparsingerror(u);
            }
            return l.onflush && l.onflush(), this;
          }, g;
        }();
      },
      "./src/utils/webvtt-parser.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          generateCueId: () => x,
          parseWebVTT: () => S
        });
        var P = p("./src/polyfills/number.ts"), T = p("./src/utils/vttparser.ts"), k = p("./src/demux/id3.ts"), C = p("./src/utils/timescale-conversion.ts"), B = p("./src/remux/mp4-remuxer.ts"), I = /\r\n|\n\r|\n|\r/g, L = function(l, u, a) {
          return a === void 0 && (a = 0), l.slice(a, a + u.length) === u;
        }, D = function(l) {
          var u = parseInt(l.slice(-3)), a = parseInt(l.slice(-6, -4)), s = parseInt(l.slice(-9, -7)), m = l.length > 9 ? parseInt(l.substring(0, l.indexOf(":"))) : 0;
          if (!(0, P.isFiniteNumber)(u) || !(0, P.isFiniteNumber)(a) || !(0, P.isFiniteNumber)(s) || !(0, P.isFiniteNumber)(m))
            throw Error("Malformed X-TIMESTAMP-MAP: Local:" + l);
          return u += 1e3 * a, u += 60 * 1e3 * s, u += 60 * 60 * 1e3 * m, u;
        }, _ = function(l) {
          for (var u = 5381, a = l.length; a; )
            u = u * 33 ^ l.charCodeAt(--a);
          return (u >>> 0).toString();
        };
        function x(y, l, u) {
          return _(y.toString()) + _(l.toString()) + _(u);
        }
        var g = function(l, u, a) {
          var s = l[u], m = l[s.prevCC];
          if (!m || !m.new && s.new) {
            l.ccOffset = l.presentationOffset = s.start, s.new = !1;
            return;
          }
          for (; (v = m) !== null && v !== void 0 && v.new; ) {
            var v;
            l.ccOffset += s.start - m.start, s.new = !1, s = m, m = l[s.prevCC];
          }
          l.presentationOffset = a;
        };
        function S(y, l, u, a, s, m, v, i) {
          var n = new T.VTTParser(), E = (0, k.utf8ArrayToStr)(new Uint8Array(y)).trim().replace(I, `
`).split(`
`), r = [], o = (0, C.toMpegTsClockFromTimescale)(l, u), t = "00:00.000", d = 0, e = 0, h, f = !0;
          n.oncue = function(c) {
            var M = a[s], w = a.ccOffset, F = (d - o) / 9e4;
            M != null && M.new && (e !== void 0 ? w = a.ccOffset = M.start : g(a, s, F)), F && (w = F - a.presentationOffset);
            var U = c.endTime - c.startTime, N = (0, B.normalizePts)((c.startTime + w - e) * 9e4, m * 9e4) / 9e4;
            c.startTime = Math.max(N, 0), c.endTime = Math.max(N + U, 0);
            var H = c.text.trim();
            c.text = decodeURIComponent(encodeURIComponent(H)), c.id || (c.id = x(c.startTime, c.endTime, H)), c.endTime > 0 && r.push(c);
          }, n.onparsingerror = function(c) {
            h = c;
          }, n.onflush = function() {
            if (h) {
              i(h);
              return;
            }
            v(r);
          }, E.forEach(function(c) {
            if (f)
              if (L(c, "X-TIMESTAMP-MAP=")) {
                f = !1, c.slice(16).split(",").forEach(function(M) {
                  L(M, "LOCAL:") ? t = M.slice(6) : L(M, "MPEGTS:") && (d = parseInt(M.slice(7)));
                });
                try {
                  e = D(t) / 1e3;
                } catch (M) {
                  h = M;
                }
                return;
              } else
                c === "" && (f = !1);
            n.parse(c + `
`);
          }), n.flush();
        }
      },
      "./src/utils/xhr-loader.ts": (W, O, p) => {
        p.r(O), p.d(O, {
          default: () => B
        });
        var P = p("./src/utils/logger.ts"), T = p("./src/loader/load-stats.ts"), k = /^age:\s*[\d.]+\s*$/m, C = /* @__PURE__ */ function() {
          function I(D) {
            this.xhrSetup = void 0, this.requestTimeout = void 0, this.retryTimeout = void 0, this.retryDelay = void 0, this.config = null, this.callbacks = null, this.context = void 0, this.loader = null, this.stats = void 0, this.xhrSetup = D ? D.xhrSetup : null, this.stats = new T.LoadStats(), this.retryDelay = 0;
          }
          var L = I.prototype;
          return L.destroy = function() {
            this.callbacks = null, this.abortInternal(), this.loader = null, this.config = null;
          }, L.abortInternal = function() {
            var _ = this.loader;
            self.clearTimeout(this.requestTimeout), self.clearTimeout(this.retryTimeout), _ && (_.onreadystatechange = null, _.onprogress = null, _.readyState !== 4 && (this.stats.aborted = !0, _.abort()));
          }, L.abort = function() {
            var _;
            this.abortInternal(), (_ = this.callbacks) !== null && _ !== void 0 && _.onAbort && this.callbacks.onAbort(this.stats, this.context, this.loader);
          }, L.load = function(_, x, g) {
            if (this.stats.loading.start)
              throw new Error("Loader can only be used once.");
            this.stats.loading.start = self.performance.now(), this.context = _, this.config = x, this.callbacks = g, this.retryDelay = x.retryDelay, this.loadInternal();
          }, L.loadInternal = function() {
            var _ = this.config, x = this.context;
            if (!!_) {
              var g = this.loader = new self.XMLHttpRequest(), S = this.stats;
              S.loading.first = 0, S.loaded = 0;
              var y = this.xhrSetup;
              try {
                if (y)
                  try {
                    y(g, x.url);
                  } catch {
                    g.open("GET", x.url, !0), y(g, x.url);
                  }
                g.readyState || g.open("GET", x.url, !0);
                var l = this.context.headers;
                if (l)
                  for (var u in l)
                    g.setRequestHeader(u, l[u]);
              } catch (a) {
                this.callbacks.onError({
                  code: g.status,
                  text: a.message
                }, x, g);
                return;
              }
              x.rangeEnd && g.setRequestHeader("Range", "bytes=" + x.rangeStart + "-" + (x.rangeEnd - 1)), g.onreadystatechange = this.readystatechange.bind(this), g.onprogress = this.loadprogress.bind(this), g.responseType = x.responseType, self.clearTimeout(this.requestTimeout), this.requestTimeout = self.setTimeout(this.loadtimeout.bind(this), _.timeout), g.send();
            }
          }, L.readystatechange = function() {
            var _ = this.context, x = this.loader, g = this.stats;
            if (!(!_ || !x)) {
              var S = x.readyState, y = this.config;
              if (!g.aborted && S >= 2)
                if (self.clearTimeout(this.requestTimeout), g.loading.first === 0 && (g.loading.first = Math.max(self.performance.now(), g.loading.start)), S === 4) {
                  x.onreadystatechange = null, x.onprogress = null;
                  var l = x.status, u = x.responseType === "arraybuffer";
                  if (l >= 200 && l < 300 && (u && x.response || x.responseText !== null)) {
                    g.loading.end = Math.max(self.performance.now(), g.loading.first);
                    var a, s;
                    if (u ? (a = x.response, s = a.byteLength) : (a = x.responseText, s = a.length), g.loaded = g.total = s, !this.callbacks)
                      return;
                    var m = this.callbacks.onProgress;
                    if (m && m(g, _, a, x), !this.callbacks)
                      return;
                    var v = {
                      url: x.responseURL,
                      data: a
                    };
                    this.callbacks.onSuccess(v, g, _, x);
                  } else
                    g.retry >= y.maxRetry || l >= 400 && l < 499 ? (P.logger.error(l + " while loading " + _.url), this.callbacks.onError({
                      code: l,
                      text: x.statusText
                    }, _, x)) : (P.logger.warn(l + " while loading " + _.url + ", retrying in " + this.retryDelay + "..."), this.abortInternal(), this.loader = null, self.clearTimeout(this.retryTimeout), this.retryTimeout = self.setTimeout(this.loadInternal.bind(this), this.retryDelay), this.retryDelay = Math.min(2 * this.retryDelay, y.maxRetryDelay), g.retry++);
                } else
                  self.clearTimeout(this.requestTimeout), this.requestTimeout = self.setTimeout(this.loadtimeout.bind(this), y.timeout);
            }
          }, L.loadtimeout = function() {
            P.logger.warn("timeout while loading " + this.context.url);
            var _ = this.callbacks;
            _ && (this.abortInternal(), _.onTimeout(this.stats, this.context, this.loader));
          }, L.loadprogress = function(_) {
            var x = this.stats;
            x.loaded = _.loaded, _.lengthComputable && (x.total = _.total);
          }, L.getCacheAge = function() {
            var _ = null;
            if (this.loader && k.test(this.loader.getAllResponseHeaders())) {
              var x = this.loader.getResponseHeader("age");
              _ = x ? parseFloat(x) : null;
            }
            return _;
          }, I;
        }();
        const B = C;
      },
      "./node_modules/eventemitter3/index.js": (W) => {
        var O = Object.prototype.hasOwnProperty, p = "~";
        function P() {
        }
        Object.create && (P.prototype = /* @__PURE__ */ Object.create(null), new P().__proto__ || (p = !1));
        function T(I, L, D) {
          this.fn = I, this.context = L, this.once = D || !1;
        }
        function k(I, L, D, _, x) {
          if (typeof D != "function")
            throw new TypeError("The listener must be a function");
          var g = new T(D, _ || I, x), S = p ? p + L : L;
          return I._events[S] ? I._events[S].fn ? I._events[S] = [I._events[S], g] : I._events[S].push(g) : (I._events[S] = g, I._eventsCount++), I;
        }
        function C(I, L) {
          --I._eventsCount === 0 ? I._events = new P() : delete I._events[L];
        }
        function B() {
          this._events = new P(), this._eventsCount = 0;
        }
        B.prototype.eventNames = function() {
          var L = [], D, _;
          if (this._eventsCount === 0)
            return L;
          for (_ in D = this._events)
            O.call(D, _) && L.push(p ? _.slice(1) : _);
          return Object.getOwnPropertySymbols ? L.concat(Object.getOwnPropertySymbols(D)) : L;
        }, B.prototype.listeners = function(L) {
          var D = p ? p + L : L, _ = this._events[D];
          if (!_)
            return [];
          if (_.fn)
            return [_.fn];
          for (var x = 0, g = _.length, S = new Array(g); x < g; x++)
            S[x] = _[x].fn;
          return S;
        }, B.prototype.listenerCount = function(L) {
          var D = p ? p + L : L, _ = this._events[D];
          return _ ? _.fn ? 1 : _.length : 0;
        }, B.prototype.emit = function(L, D, _, x, g, S) {
          var y = p ? p + L : L;
          if (!this._events[y])
            return !1;
          var l = this._events[y], u = arguments.length, a, s;
          if (l.fn) {
            switch (l.once && this.removeListener(L, l.fn, void 0, !0), u) {
              case 1:
                return l.fn.call(l.context), !0;
              case 2:
                return l.fn.call(l.context, D), !0;
              case 3:
                return l.fn.call(l.context, D, _), !0;
              case 4:
                return l.fn.call(l.context, D, _, x), !0;
              case 5:
                return l.fn.call(l.context, D, _, x, g), !0;
              case 6:
                return l.fn.call(l.context, D, _, x, g, S), !0;
            }
            for (s = 1, a = new Array(u - 1); s < u; s++)
              a[s - 1] = arguments[s];
            l.fn.apply(l.context, a);
          } else {
            var m = l.length, v;
            for (s = 0; s < m; s++)
              switch (l[s].once && this.removeListener(L, l[s].fn, void 0, !0), u) {
                case 1:
                  l[s].fn.call(l[s].context);
                  break;
                case 2:
                  l[s].fn.call(l[s].context, D);
                  break;
                case 3:
                  l[s].fn.call(l[s].context, D, _);
                  break;
                case 4:
                  l[s].fn.call(l[s].context, D, _, x);
                  break;
                default:
                  if (!a)
                    for (v = 1, a = new Array(u - 1); v < u; v++)
                      a[v - 1] = arguments[v];
                  l[s].fn.apply(l[s].context, a);
              }
          }
          return !0;
        }, B.prototype.on = function(L, D, _) {
          return k(this, L, D, _, !1);
        }, B.prototype.once = function(L, D, _) {
          return k(this, L, D, _, !0);
        }, B.prototype.removeListener = function(L, D, _, x) {
          var g = p ? p + L : L;
          if (!this._events[g])
            return this;
          if (!D)
            return C(this, g), this;
          var S = this._events[g];
          if (S.fn)
            S.fn === D && (!x || S.once) && (!_ || S.context === _) && C(this, g);
          else {
            for (var y = 0, l = [], u = S.length; y < u; y++)
              (S[y].fn !== D || x && !S[y].once || _ && S[y].context !== _) && l.push(S[y]);
            l.length ? this._events[g] = l.length === 1 ? l[0] : l : C(this, g);
          }
          return this;
        }, B.prototype.removeAllListeners = function(L) {
          var D;
          return L ? (D = p ? p + L : L, this._events[D] && C(this, D)) : (this._events = new P(), this._eventsCount = 0), this;
        }, B.prototype.off = B.prototype.removeListener, B.prototype.addListener = B.prototype.on, B.prefixed = p, B.EventEmitter = B, W.exports = B;
      },
      "./node_modules/url-toolkit/src/url-toolkit.js": function(W) {
        (function(O) {
          var p = /^(?=((?:[a-zA-Z0-9+\-.]+:)?))\1(?=((?:\/\/[^\/?#]*)?))\2(?=((?:(?:[^?#\/]*\/)*[^;?#\/]*)?))\3((?:;[^?#]*)?)(\?[^#]*)?(#[^]*)?$/, P = /^(?=([^\/?#]*))\1([^]*)$/, T = /(?:\/|^)\.(?=\/)/g, k = /(?:\/|^)\.\.\/(?!\.\.\/)[^\/]*(?=\/)/g, C = {
            buildAbsoluteURL: function(B, I, L) {
              if (L = L || {}, B = B.trim(), I = I.trim(), !I) {
                if (!L.alwaysNormalize)
                  return B;
                var D = C.parseURL(B);
                if (!D)
                  throw new Error("Error trying to parse base URL.");
                return D.path = C.normalizePath(
                  D.path
                ), C.buildURLFromParts(D);
              }
              var _ = C.parseURL(I);
              if (!_)
                throw new Error("Error trying to parse relative URL.");
              if (_.scheme)
                return L.alwaysNormalize ? (_.path = C.normalizePath(_.path), C.buildURLFromParts(_)) : I;
              var x = C.parseURL(B);
              if (!x)
                throw new Error("Error trying to parse base URL.");
              if (!x.netLoc && x.path && x.path[0] !== "/") {
                var g = P.exec(x.path);
                x.netLoc = g[1], x.path = g[2];
              }
              x.netLoc && !x.path && (x.path = "/");
              var S = {
                scheme: x.scheme,
                netLoc: _.netLoc,
                path: null,
                params: _.params,
                query: _.query,
                fragment: _.fragment
              };
              if (!_.netLoc && (S.netLoc = x.netLoc, _.path[0] !== "/"))
                if (!_.path)
                  S.path = x.path, _.params || (S.params = x.params, _.query || (S.query = x.query));
                else {
                  var y = x.path, l = y.substring(0, y.lastIndexOf("/") + 1) + _.path;
                  S.path = C.normalizePath(l);
                }
              return S.path === null && (S.path = L.alwaysNormalize ? C.normalizePath(_.path) : _.path), C.buildURLFromParts(S);
            },
            parseURL: function(B) {
              var I = p.exec(B);
              return I ? {
                scheme: I[1] || "",
                netLoc: I[2] || "",
                path: I[3] || "",
                params: I[4] || "",
                query: I[5] || "",
                fragment: I[6] || ""
              } : null;
            },
            normalizePath: function(B) {
              for (B = B.split("").reverse().join("").replace(T, ""); B.length !== (B = B.replace(k, "")).length; )
                ;
              return B.split("").reverse().join("");
            },
            buildURLFromParts: function(B) {
              return B.scheme + B.netLoc + B.path + B.params + B.query + B.fragment;
            }
          };
          W.exports = C;
        })();
      }
    }, G = {};
    function K(W) {
      var O = G[W];
      if (O !== void 0)
        return O.exports;
      var p = G[W] = {
        exports: {}
      };
      return R[W].call(p.exports, p, p.exports, K), p.exports;
    }
    K.m = R, K.n = (W) => {
      var O = W && W.__esModule ? () => W.default : () => W;
      return K.d(O, { a: O }), O;
    }, K.d = (W, O) => {
      for (var p in O)
        K.o(O, p) && !K.o(W, p) && Object.defineProperty(W, p, { enumerable: !0, get: O[p] });
    }, K.o = (W, O) => Object.prototype.hasOwnProperty.call(W, O), K.r = (W) => {
      typeof Symbol < "u" && Symbol.toStringTag && Object.defineProperty(W, Symbol.toStringTag, { value: "Module" }), Object.defineProperty(W, "__esModule", { value: !0 });
    };
    var V = K("./src/hls.ts");
    return V = V.default, V;
  })());
})($r);
const at = /* @__PURE__ */ Li($r.exports);
function rr(A, b, R, G) {
  var K, V = !1, W = 0;
  function O() {
    K && clearTimeout(K);
  }
  function p() {
    O(), V = !0;
  }
  typeof b != "boolean" && (G = R, R = b, b = void 0);
  function P() {
    for (var T = arguments.length, k = new Array(T), C = 0; C < T; C++)
      k[C] = arguments[C];
    var B = this, I = Date.now() - W;
    if (V)
      return;
    function L() {
      W = Date.now(), R.apply(B, k);
    }
    function D() {
      K = void 0;
    }
    G && !K && L(), O(), G === void 0 && I > A ? L() : b !== !0 && (K = setTimeout(G ? D : L, G === void 0 ? A - I : A));
  }
  return P.cancel = p, P;
}
function ir(A, b, R) {
  return R === void 0 ? rr(A, b, !1) : rr(A, R, b !== !1);
}
const nr = (A) => `${parseInt("0x" + A.slice(1, 3))},${parseInt("0x" + A.slice(3, 5))},${parseInt(
  "0x" + A.slice(5, 7)
)}`, Wt = (A) => {
  let b = ~~(A / 3600), R = ~~(A % 3600 / 60), G = ~~(A % 60);
  return b = b < 10 ? "0" + b : b, R = R < 10 ? "0" + R : R, G = G < 10 ? "0" + G : G, `${b}:${R}:${G}`;
}, ft = "ontouchstart" in window, Ai = (A) => {
  let b = document, R = b.webkitIsFullScreen || b.fullscreen;
  return R ? (document.exitFullscreen || b.webkitExitFullScreen).call(b) : (A.requestFullscreen || (A == null ? void 0 : A.webkitRequestFullScreen)).call(A), !R;
}, bi = () => {
  Object.defineProperty(Event.prototype, "path", {
    get() {
      return this.composedPath();
    }
  });
}, vt = function(A, b, R, G = !1) {
  A && b && R && A.addEventListener(b, R, G);
}, Ye = function(A, b, R, G = !1) {
  A && b && R && A.removeEventListener(b, R, G);
};
function Pi(A) {
  rt(A, "svelte-qzeq9z", ".d-slider.svelte-qzeq9z.svelte-qzeq9z{position:relative}.d-slider.svelte-qzeq9z .d-slider__runway.svelte-qzeq9z{width:100%;background-color:#333333;position:relative;cursor:pointer;vertical-align:middle}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__cursor.svelte-qzeq9z,.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__preload.svelte-qzeq9z,.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z{position:absolute;top:0;left:0;height:100%}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__cursor.svelte-qzeq9z{display:none;z-index:1;width:1px;background:#fff;pointer-events:none}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__cursor .d-slider__tips.svelte-qzeq9z{pointer-events:none;color:#fff;position:absolute;white-space:nowrap;z-index:2;bottom:14px;left:50%;padding:4px;box-sizing:border-box;display:block;font-size:12px;background:rgba(0, 0, 0, 0.6);border-radius:3px;transform:translateX(-50%)}.d-slider.svelte-qzeq9z .d-slider__runway:hover .d-slider__cursor.svelte-qzeq9z{display:block}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__preload.svelte-qzeq9z{background-color:#717171}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z{background:linear-gradient(to right, var(--primary-color) 0%, var(--primary-color-end) 80%, var(--primary-color-end) 100%)}.d-slider.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z::before{display:block;content:'';position:absolute;right:-6px;top:50%;width:5px;height:5px;transition:0.2s;transform:translateY(-50%) scale(1, 1);border-radius:50%;background:#fff;border:5px solid var(--primary-color)}.d-slider.is-vertical.svelte-qzeq9z.svelte-qzeq9z{height:100px;display:inline-block}.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway.svelte-qzeq9z{position:relative;height:100%;margin:0 6px}.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__preload.svelte-qzeq9z,.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z,.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__cursor.svelte-qzeq9z{bottom:0;top:auto;width:100%}.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__cursor.svelte-qzeq9z{height:1px}.d-slider.is-vertical.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z::before{top:-6px;left:50%;width:5px;height:5px;transform:translateX(-50%) scale(1, 1)}.d-progress-bar.svelte-qzeq9z.svelte-qzeq9z{position:absolute;left:0;right:0;bottom:0;width:100%;transition:height 0.1s;height:3px;z-index:1}.d-progress-bar.svelte-qzeq9z .d-slider__runway.svelte-qzeq9z{transition:height 0.1s;height:100% !important}.d-progress-bar.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z::before{transform:translateY(-50%) scale(0, 0)}.d-progress-bar.svelte-qzeq9z.svelte-qzeq9z:hover{height:100%}.d-progress-bar.svelte-qzeq9z:hover .d-slider__bar.svelte-qzeq9z::before{transform:translateY(-50%) scale(1, 1) !important}.d-player-filter-panel-item.svelte-qzeq9z .d-slider__runway.svelte-qzeq9z{background-color:#999}.d-player-filter-panel-item.svelte-qzeq9z .d-slider__runway .d-slider__bar.svelte-qzeq9z:before{width:5px;height:5px}.filter-panel-slider.svelte-qzeq9z.svelte-qzeq9z{width:100%}");
}
function Ii(A) {
  let b, R, G, K, V, W, O, p, P, T, k, C, B, I, L;
  return {
    c() {
      b = re("div"), R = re("div"), G = re("div"), K = re("div"), V = ve(A[2]), p = le(), P = re("div"), T = le(), k = re("div"), Q(K, "class", "d-slider__tips svelte-qzeq9z"), Q(K, "style", W = `left:${A[5].hoverTipsLeft};display:${A[2] ? "block" : "none"}`), Q(G, "class", "d-slider__cursor svelte-qzeq9z"), Q(G, "style", O = `${A[8]}; display:${A[0] ? "block" : "none"}`), Q(P, "class", "d-slider__preload svelte-qzeq9z"), Q(P, "style", A[9]), Q(k, "class", "d-slider__bar svelte-qzeq9z"), Q(k, "style", A[10]), Q(R, "class", "d-slider__runway svelte-qzeq9z"), Q(R, "style", C = A[1] ? "width:" + A[3] : "height:" + A[3]), Q(b, "class", B = Fe(`d-slider ${A[1] ? "is-vertical" : ""} ${A[4]}`) + " svelte-qzeq9z");
    },
    m(D, _) {
      de(D, b, _), J(b, R), J(R, G), J(G, K), J(K, V), A[19](K), J(R, p), J(R, P), J(R, T), J(R, k), A[20](b), I || (L = [
        he(R, "mousemove", A[15]),
        he(R, "mouseleave", A[14]),
        he(R, "mouseenter", A[13]),
        he(b, "mousedown", wt(A[12])),
        he(b, "contextmenu", A[11])
      ], I = !0);
    },
    p(D, [_]) {
      _ & 4 && De(V, D[2]), _ & 36 && W !== (W = `left:${D[5].hoverTipsLeft};display:${D[2] ? "block" : "none"}`) && Q(K, "style", W), _ & 257 && O !== (O = `${D[8]}; display:${D[0] ? "block" : "none"}`) && Q(G, "style", O), _ & 512 && Q(P, "style", D[9]), _ & 1024 && Q(k, "style", D[10]), _ & 10 && C !== (C = D[1] ? "width:" + D[3] : "height:" + D[3]) && Q(R, "style", C), _ & 18 && B !== (B = Fe(`d-slider ${D[1] ? "is-vertical" : ""} ${D[4]}`) + " svelte-qzeq9z") && Q(b, "class", B);
    },
    i: Pe,
    o: Pe,
    d(D) {
      D && fe(b), A[19](null), A[20](null), I = !1, ot(L);
    }
  };
}
function Ri(A, b, R) {
  let G, K, V;
  const W = gt();
  let { modelValue: O = 0 } = b, { disabled: p = !1 } = b, { vertical: P = !1 } = b, { hover: T = !1 } = b, { hoverText: k = "" } = b, { preload: C = 0 } = b, { size: B = "10px" } = b, { className: I = "" } = b;
  const L = {
    dragging: !1,
    hoverPosition: 0,
    hoverTipsLeft: "50%"
  };
  let D, _;
  const x = (n) => {
    n.preventDefault();
  }, g = (n) => {
    if (p) {
      const E = a(n);
      W("speedDisabled", E);
      return;
    }
    n.preventDefault(), R(5, L.dragging = !0, L), u(n), vt(window, "mousemove", s), vt(window, "touchmove", s), vt(window, "mouseup", m), vt(window, "touchend", m);
  }, S = () => {
    R(0, T = !0);
  }, y = () => {
    R(0, T = !1);
  }, l = (n) => {
    if (!T)
      return;
    let E = a(n);
    if (W("onMousemove", { ev: n, val: E }), R(5, L.hoverPosition = E, L), P)
      return;
    let r = D, o = _.clientWidth / 2, t = n.clientX - r.getBoundingClientRect().left;
    t < o ? R(5, L.hoverTipsLeft = o - t + "px", L) : r.clientWidth - t < o ? R(5, L.hoverTipsLeft = r.clientWidth - t - o + "px", L) : R(5, L.hoverTipsLeft = "50%", L);
  }, u = (n) => {
    let E = a(n);
    W("update", E), W("change", { ev: n, value: E });
  }, a = (n) => {
    let E = D, r = 0;
    if (P) {
      let o = E.clientHeight;
      r = (E.getBoundingClientRect().bottom - n.clientY) / o;
    } else
      r = (n.clientX - E.getBoundingClientRect().left) / E.clientWidth;
    return r < 0 ? 0 : r > 1 ? 1 : r;
  }, s = (n) => {
    u(n);
  }, m = (n) => {
    L.dragging && (Ye(window, "mousemove", s), Ye(window, "touchmove", s), Ye(window, "mouseup", m), Ye(window, "touchend", m), Ye(window, "contextmenu", m), setTimeout(
      () => {
        R(5, L.dragging = !1, L);
      },
      0
    ));
  };
  function v(n) {
    dt[n ? "unshift" : "push"](() => {
      _ = n, R(7, _);
    });
  }
  function i(n) {
    dt[n ? "unshift" : "push"](() => {
      D = n, R(6, D);
    });
  }
  return A.$$set = (n) => {
    "modelValue" in n && R(16, O = n.modelValue), "disabled" in n && R(17, p = n.disabled), "vertical" in n && R(1, P = n.vertical), "hover" in n && R(0, T = n.hover), "hoverText" in n && R(2, k = n.hoverText), "preload" in n && R(18, C = n.preload), "size" in n && R(3, B = n.size), "className" in n && R(4, I = n.className);
  }, A.$$.update = () => {
    A.$$.dirty & 65538 && R(10, G = (() => {
      let n = O < 0 ? 0 : O > 1 ? 1 : O;
      return P ? `height:${n * 100}%` : `width:${n * 100}%`;
    })()), A.$$.dirty & 262146 && R(9, K = (() => {
      let n = C < 0 ? 0 : C > 1 ? 1 : C;
      return P ? `height:${n * 100}%` : `width:${n * 100}%`;
    })()), A.$$.dirty & 34 && R(8, V = (() => {
      let n = L.hoverPosition < 0 ? 0 : L.hoverPosition > 1 ? 1 : L.hoverPosition;
      return P ? `bottom:${n * 100}%` : `left:${n * 100}%`;
    })());
  }, [
    T,
    P,
    k,
    B,
    I,
    L,
    D,
    _,
    V,
    K,
    G,
    x,
    g,
    S,
    y,
    l,
    O,
    p,
    C,
    v,
    i
  ];
}
class Lt extends nt {
  constructor(b) {
    super(), it(
      this,
      b,
      Ri,
      Ii,
      tt,
      {
        modelValue: 16,
        disabled: 17,
        vertical: 1,
        hover: 0,
        hoverText: 2,
        preload: 18,
        size: 3,
        className: 4
      },
      Pi
    );
  }
}
function Ci(A) {
  rt(A, "svelte-31e6zs", ".d-switch.svelte-31e6zs.svelte-31e6zs{position:relative;height:18px;transition:background 0.2s;background:#757575;border-radius:10px;display:inline-flex;align-items:center;vertical-align:middle}.d-switch.svelte-31e6zs .d-switch__input.svelte-31e6zs{position:relative;z-index:1;margin:0;width:100%;height:100%;opacity:0}.d-switch.svelte-31e6zs .d-switch_action.svelte-31e6zs{position:absolute;transition:0.2s;left:2px;top:2px;z-index:0;height:5px;width:5px;background:#fff;border-radius:50%}.d-switch.is-checked.svelte-31e6zs.svelte-31e6zs{background-color:var(--primary-color)}.d-switch.is-checked.svelte-31e6zs .d-switch_action.svelte-31e6zs{left:100%;background:#fff;margin-left:-18px}");
}
function Oi(A) {
  let b, R, G, K, V, W, O, p;
  return {
    c() {
      b = re("div"), R = re("input"), G = le(), K = re("span"), Q(R, "class", "d-switch__input svelte-31e6zs"), Q(R, "type", "checkbox"), R.checked = A[4], Q(R, "true-value", A[1]), Q(R, "false-value", A[2]), Q(K, "class", "d-switch_action svelte-31e6zs"), Q(b, "class", V = Fe(A[4] ? "is-checked d-switch" : "d-switch") + " svelte-31e6zs"), Q(b, "style", W = `width:${A[0]}`);
    },
    m(P, T) {
      de(P, b, T), J(b, R), A[8](R), J(b, G), J(b, K), O || (p = he(R, "change", A[5]), O = !0);
    },
    p(P, [T]) {
      T & 16 && (R.checked = P[4]), T & 2 && Q(R, "true-value", P[1]), T & 4 && Q(R, "false-value", P[2]), T & 16 && V !== (V = Fe(P[4] ? "is-checked d-switch" : "d-switch") + " svelte-31e6zs") && Q(b, "class", V), T & 1 && W !== (W = `width:${P[0]}`) && Q(b, "style", W);
    },
    i: Pe,
    o: Pe,
    d(P) {
      P && fe(b), A[8](null), O = !1, p();
    }
  };
}
function Mi(A, b, R) {
  let G;
  const K = gt();
  let { modelValue: V } = b, { width: W = "40px" } = b, { trueValue: O = !0 } = b, { falseValue: p = !0 } = b, { activeColor: P = "#409EFF" } = b, T;
  const k = async () => {
    await Vt();
    const B = T.checked;
    K("update", B), K("change", B);
  };
  function C(B) {
    dt[B ? "unshift" : "push"](() => {
      T = B, R(3, T);
    });
  }
  return A.$$set = (B) => {
    "modelValue" in B && R(6, V = B.modelValue), "width" in B && R(0, W = B.width), "trueValue" in B && R(1, O = B.trueValue), "falseValue" in B && R(2, p = B.falseValue), "activeColor" in B && R(7, P = B.activeColor);
  }, A.$$.update = () => {
    A.$$.dirty & 66 && R(4, G = (() => V === O)());
  }, [
    W,
    O,
    p,
    T,
    G,
    k,
    V,
    P,
    C
  ];
}
class Gt extends nt {
  constructor(b) {
    super(), it(
      this,
      b,
      Mi,
      Oi,
      tt,
      {
        modelValue: 6,
        width: 0,
        trueValue: 1,
        falseValue: 2,
        activeColor: 7
      },
      Ci
    );
  }
}
function ki(A) {
  rt(A, "svelte-6alrox", "@import '../asset/style/iconfont.css';.d-icon.svelte-6alrox{display:inline-block;cursor:pointer;overflow:hidden}.icon-play.svelte-6alrox{margin-left:5px}");
}
function Fi(A) {
  let b, R;
  return {
    c() {
      b = re("i"), Q(b, "class", R = Fe(`${A[0]} d-icon iconfont ${A[1]}`) + " svelte-6alrox"), Q(b, "style", A[2]);
    },
    m(G, K) {
      de(G, b, K);
    },
    p(G, [K]) {
      K & 3 && R !== (R = Fe(`${G[0]} d-icon iconfont ${G[1]}`) + " svelte-6alrox") && Q(b, "class", R), K & 4 && Q(b, "style", G[2]);
    },
    i: Pe,
    o: Pe,
    d(G) {
      G && fe(b);
    }
  };
}
function wi(A, b, R) {
  let G, { icon: K } = b, { size: V } = b, { className: W = "" } = b;
  return A.$$set = (O) => {
    "icon" in O && R(0, K = O.icon), "size" in O && R(3, V = O.size), "className" in O && R(1, W = O.className);
  }, A.$$.update = () => {
    A.$$.dirty & 8 && R(2, G = (() => `font-size:${/^\d+$/.test(V + "") ? V + "px" : V}`)());
  }, [K, W, G, V];
}
class mt extends nt {
  constructor(b) {
    super(), it(this, b, wi, Fi, tt, { icon: 0, size: 3, className: 1 }, ki);
  }
}
const sr = {
  en: {
    speed: "speed",
    mirror: "mirror",
    loop: "loop",
    lightOff: "light off",
    pictureInPicture: "picture in picture",
    webFullScreen: "web fullscreen",
    exitWebFullScreen: "exit web fullscreen",
    fullScreen: "fullscreen(f)",
    exitFullScreen: "exit fullscreen(f)",
    colorAdjustment: "Color adjustment",
    saturability: "saturability",
    brightness: "brightness",
    contrast: "contrast",
    reset: "reset",
    shortcutKeyInstructions: "Shortcut key instructions",
    copyVideoUrl: "Copy the url address",
    version: "Version",
    loading: "loading",
    replay: "replay",
    playError: "play error",
    playStuck: "play stuck",
    progressError: "The progress bar cannot be dragged",
    videoBlack: "The video is black but there is sound",
    soundPictueAsync: "Sound and picture are out of sync",
    feedbackTips: "Feedback success!",
    playerFeedBack: "Player problem feedback",
    other: "other",
    feedbackPlaceHolder: "Description of the problem in 100 words or less",
    confirm: "confirm"
  },
  "zh-cn": {
    speed: "\u500D\u901F",
    mirror: "\u955C\u50CF\u753B\u9762",
    loop: "\u5FAA\u73AF\u64AD\u653E",
    lightOff: "\u5173\u706F\u6A21\u5F0F",
    pictureInPicture: "\u753B\u4E2D\u753B",
    webFullScreen: "\u7F51\u9875\u5168\u5C4F",
    exitWebFullScreen: "\u9000\u51FA\u7F51\u9875\u5168\u5C4F",
    fullScreen: "\u5168\u5C4F(f)",
    exitFullScreen: "\u9000\u51FA\u5168\u5C4F(f)",
    colorAdjustment: "\u89C6\u9891\u8272\u5F69\u8C03\u6574",
    saturability: "\u9971\u548C\u5EA6",
    brightness: "\u4EAE\u5EA6",
    contrast: "\u5BF9\u6BD4\u5EA6",
    reset: "\u91CD\u7F6E",
    shortcutKeyInstructions: "\u5FEB\u6377\u952E\u8BF4\u660E",
    copyVideoUrl: "\u590D\u5236\u7F51\u5740\u89C6\u9891",
    version: "\u7248\u672C",
    loading: "\u6B63\u5728\u7F13\u51B2...",
    replay: "\u91CD\u65B0\u64AD\u653E",
    playError: "\u8BF7\u6C42\u9519\u8BEF",
    playStuck: "\u64AD\u653E\u5361\u987F",
    progressError: "\u8FDB\u5EA6\u6761\u65E0\u6CD5\u62D6\u52A8",
    videoBlack: "\u89C6\u9891\u9ED1\u5C4F\u4F46\u6709\u58F0\u97F3",
    soundPictueAsync: "\u97F3\u753B\u4E0D\u540C\u6B65",
    feedbackTips: "\u53CD\u9988\u6210\u529F\uFF01",
    playerFeedBack: "\u64AD\u653E\u5668\u95EE\u9898\u53CD\u9988",
    other: "\u5176\u4ED6",
    feedbackPlaceHolder: "\u95EE\u9898\u63CF\u8FF0\uFF0C\u9650100\u5B57\u5185",
    confirm: "\u786E\u8BA4"
  },
  "zh-tw": {
    speed: "\u500D\u901F",
    mirror: "\u93E1\u50CF\u756B\u9762",
    loop: "\u8FF4\u5708\u64AD\u653E",
    lightOff: "\u95DC\u71C8\u6A21\u5F0F",
    pictureInPicture: "\u756B\u4E2D\u756B",
    webFullScreen: "\u7DB2\u9801\u5168\u5C4F",
    exitWebFullScreen: "\u9000\u51FA\u7DB2\u9801\u5168\u5C4F",
    fullScreen: "\u5168\u5C4F(f)",
    exitFullScreen: "\u9000\u51FA\u5168\u5C4F(f)",
    colorAdjustment: "\u8996\u983B\u8272\u5F69\u8ABF\u6574",
    saturability: "\u98FD\u548C\u5EA6",
    brightness: "\u4EAE\u5EA6",
    contrast: "\u5C0D\u6BD4\u5EA6",
    reset: "\u91CD\u7F6E",
    shortcutKeyInstructions: "\u5FEB\u6377\u9375\u8AAA\u660E",
    copyVideoUrl: "\u8907\u88FD\u7DB2\u5740\u8996\u983B",
    version: "\u7248\u672C",
    loading: "\u6B63\u5728\u7DE9\u885D...",
    replay: "\u91CD\u65B0\u64AD\u653E",
    playError: "\u8ACB\u6C42\u932F\u8AA4",
    playStuck: "\u64AD\u653E\u5361\u9813",
    progressError: "\u9032\u5EA6\u689D\u7121\u6CD5\u62D6\u52D5",
    videoBlack: "\u8996\u983B\u9ED1\u5C4F\u4F46\u6709\u8072\u97F3",
    soundPictueAsync: "\u97F3\u756B\u4E0D\u540C\u6B65",
    feedbackTips: "\u56DE\u994B\u6210\u529F\uFF01",
    playerFeedBack: "\u64AD\u653E\u5668\u554F\u984C\u56DE\u994B",
    other: "\u5176\u4ED6",
    feedbackPlaceHolder: "\u554F\u984C\u63CF\u8FF0\uFF0C\u9650100\u5B57\u5167",
    confirm: "\u78BA\u8A8D"
  }
};
function Bi(A) {
  rt(A, "svelte-1sesy3u", "div.svelte-1sesy3u.svelte-1sesy3u,span.svelte-1sesy3u.svelte-1sesy3u,h5.svelte-1sesy3u.svelte-1sesy3u,i.svelte-1sesy3u.svelte-1sesy3u,ul.svelte-1sesy3u.svelte-1sesy3u,li.svelte-1sesy3u.svelte-1sesy3u{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}ul.svelte-1sesy3u.svelte-1sesy3u{list-style:none}@keyframes svelte-1sesy3u-rotating{100%{-webkit-transform:rotate(360deg)}}.d-player-contextmenu.svelte-1sesy3u.svelte-1sesy3u,.d-player-dialog.svelte-1sesy3u.svelte-1sesy3u{position:absolute;left:0;top:0;bottom:50px;width:100%;z-index:5}.d-player-contextmenu.svelte-1sesy3u .d-player-copyText.svelte-1sesy3u{opacity:0}.d-player-contextmenu.svelte-1sesy3u .d-player-contextmenu-body.svelte-1sesy3u{position:absolute;border-radius:5px;font-size:12px;background:rgba(0, 0, 0, 0.8);color:#efefef;padding:0;text-align:left;min-width:130px;box-sizing:border-box;padding:5px 0}.d-player-contextmenu.svelte-1sesy3u .d-player-contextmenu-body li.svelte-1sesy3u{padding:8px 20px;margin:0;cursor:pointer;transition:0.2s}.d-player-contextmenu.svelte-1sesy3u .d-player-contextmenu-body li.svelte-1sesy3u:hover{background-color:rgba(255, 255, 255, 0.1)}.d-player-dialog.svelte-1sesy3u.svelte-1sesy3u{display:flex;justify-content:center;align-items:center}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body.svelte-1sesy3u{background-color:rgba(33, 33, 33, 0.9);border-radius:5px;color:#fff;min-width:200px;padding:0 0 10px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-dialog-title.svelte-1sesy3u{text-align:center;position:relative;font-size:14px;font-weight:normal;margin:0;padding:12px 0px;border-bottom:1px solid rgba(255, 255, 255, 0.15);margin-bottom:10px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-dialog-title .icon-close.svelte-1sesy3u{position:absolute;right:0px;top:0px;width:40px;height:40px;line-height:40px;text-align:center;cursor:pointer}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-hotkey-panel.svelte-1sesy3u{font-size:12px;color:#eee;padding-right:40px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-hotkey-panel .d-player-hotkey-panel-item.svelte-1sesy3u{line-height:26px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-hotkey-panel .d-player-hotkey-panel-item span.svelte-1sesy3u{text-align:center;display:inline-block;width:120px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-hotkey-panel .d-player-hotkey-panel-item span.svelte-1sesy3u:nth-child(2){color:#999;width:160px}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel.svelte-1sesy3u{width:320px;padding:0 20px;text-align:center}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel .d-player-filter-reset.svelte-1sesy3u{text-align:center;cursor:pointer;margin-top:10px;padding:3px 20px;display:inline-block;border-radius:2px;font-size:12px;background:rgba(133, 133, 133, 0.5)}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel .d-player-filter-reset.svelte-1sesy3u:hover{background:rgba(255, 255, 255, 0.3)}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel .d-player-filter-panel-item.svelte-1sesy3u{height:32px;display:flex;align-items:center}.d-player-dialog.svelte-1sesy3u .d-player-dialog-body .d-player-filter-panel .d-player-filter-panel-item span.svelte-1sesy3u{font-size:12px;display:block;width:80px;text-align:center}");
}
function ar(A, b, R) {
  const G = A.slice();
  return G[17] = b[R], G;
}
function or(A, b, R) {
  const G = A.slice();
  return G[17] = b[R], G;
}
function lr(A) {
  let b, R, G, K = A[1].dialogTitle + "", V, W, O, p, P, T, k, C, B, I = A[1].dialogType == "hotkey" && ur(A), L = A[1].dialogType == "filter" && dr(A);
  return {
    c() {
      b = re("div"), R = re("div"), G = re("h5"), V = ve(K), W = le(), O = re("i"), O.textContent = "X", p = le(), I && I.c(), P = le(), L && L.c(), Q(O, "class", "icon icon-close svelte-1sesy3u"), Q(G, "class", "d-player-dialog-title svelte-1sesy3u"), Q(R, "class", "d-player-dialog-body svelte-1sesy3u"), Q(b, "class", "d-player-dialog svelte-1sesy3u");
    },
    m(D, _) {
      de(D, b, _), J(b, R), J(R, G), J(G, V), J(G, W), J(G, O), J(R, p), I && I.m(R, null), J(R, P), L && L.m(R, null), k = !0, C || (B = he(O, "click", A[9]), C = !0);
    },
    p(D, _) {
      (!k || _ & 2) && K !== (K = D[1].dialogTitle + "") && De(V, K), D[1].dialogType == "hotkey" ? I ? I.p(D, _) : (I = ur(D), I.c(), I.m(R, P)) : I && (I.d(1), I = null), D[1].dialogType == "filter" ? L ? (L.p(D, _), _ & 2 && se(L, 1)) : (L = dr(D), L.c(), se(L, 1), L.m(R, null)) : L && (Ke(), ue(L, 1, 1, () => {
        L = null;
      }), We());
    },
    i(D) {
      k || (se(L), lt(() => {
        T || (T = $e(b, et, {}, !0)), T.run(1);
      }), k = !0);
    },
    o(D) {
      ue(L), T || (T = $e(b, et, {}, !1)), T.run(0), k = !1;
    },
    d(D) {
      D && fe(b), I && I.d(), L && L.d(), D && T && T.end(), C = !1, B();
    }
  };
}
function ur(A) {
  let b, R = A[5], G = [];
  for (let K = 0; K < R.length; K += 1)
    G[K] = fr(or(A, R, K));
  return {
    c() {
      b = re("ul");
      for (let K = 0; K < G.length; K += 1)
        G[K].c();
      Q(b, "class", "d-player-hotkey-panel svelte-1sesy3u");
    },
    m(K, V) {
      de(K, b, V);
      for (let W = 0; W < G.length; W += 1)
        G[W].m(b, null);
    },
    p(K, V) {
      if (V & 32) {
        R = K[5];
        let W;
        for (W = 0; W < R.length; W += 1) {
          const O = or(K, R, W);
          G[W] ? G[W].p(O, V) : (G[W] = fr(O), G[W].c(), G[W].m(b, null));
        }
        for (; W < G.length; W += 1)
          G[W].d(1);
        G.length = R.length;
      }
    },
    d(K) {
      K && fe(b), bt(G, K);
    }
  };
}
function fr(A) {
  let b, R, G = A[17].key + "", K, V, W, O = A[17].label + "", p, P;
  return {
    c() {
      b = re("li"), R = re("span"), K = ve(G), V = le(), W = re("span"), p = ve(O), P = le(), Q(R, "class", "svelte-1sesy3u"), Q(W, "class", "svelte-1sesy3u"), Q(b, "class", "d-player-hotkey-panel-item svelte-1sesy3u");
    },
    m(T, k) {
      de(T, b, k), J(b, R), J(R, K), J(b, V), J(b, W), J(W, p), J(b, P);
    },
    p: Pe,
    d(T) {
      T && fe(b);
    }
  };
}
function dr(A) {
  let b, R, G, K = A[0].saturability + "", V, W, O, p, P, T = Math.round(A[2].saturate * 255) + "", k, C, B, I, L = A[0].brightness + "", D, _, x, g, S, y = Math.round(A[2].brightness * 255) + "", l, u, a, s, m = A[0].contrast + "", v, i, n, E, r, o = Math.round(A[2].contrast * 255) + "", t, d, e, h = A[0].reset + "", f, c, M, w;
  return O = new Lt({
    props: {
      className: "d-player-filter-panel-item filter-panel-slider",
      size: "5px",
      modelValue: A[2].saturate
    }
  }), O.$on("update", A[10]), x = new Lt({
    props: {
      className: "d-player-filter-panel-item filter-panel-slider",
      size: "5px",
      modelValue: A[2].brightness
    }
  }), x.$on("update", A[11]), n = new Lt({
    props: {
      className: "d-player-filter-panel-item filter-panel-slider",
      size: "5px",
      modelValue: A[2].contrast
    }
  }), n.$on("update", A[12]), {
    c() {
      b = re("ul"), R = re("li"), G = re("span"), V = ve(K), W = le(), be(O.$$.fragment), p = le(), P = re("span"), k = ve(T), C = le(), B = re("li"), I = re("span"), D = ve(L), _ = le(), be(x.$$.fragment), g = le(), S = re("span"), l = ve(y), u = le(), a = re("li"), s = re("span"), v = ve(m), i = le(), be(n.$$.fragment), E = le(), r = re("span"), t = ve(o), d = le(), e = re("span"), f = ve(h), Q(G, "class", "svelte-1sesy3u"), Q(P, "class", "svelte-1sesy3u"), Q(R, "class", "d-player-filter-panel-item svelte-1sesy3u"), Q(I, "class", "svelte-1sesy3u"), Q(S, "class", "svelte-1sesy3u"), Q(B, "class", "d-player-filter-panel-item svelte-1sesy3u"), Q(s, "class", "svelte-1sesy3u"), Q(r, "class", "svelte-1sesy3u"), Q(a, "class", "d-player-filter-panel-item svelte-1sesy3u"), Q(e, "title", "\u91CD\u7F6E"), Q(e, "aria-label", "\u91CD\u7F6E"), Q(e, "class", "d-player-filter-reset svelte-1sesy3u"), Q(b, "class", "d-player-filter-panel svelte-1sesy3u");
    },
    m(F, U) {
      de(F, b, U), J(b, R), J(R, G), J(G, V), J(R, W), Le(O, R, null), J(R, p), J(R, P), J(P, k), J(b, C), J(b, B), J(B, I), J(I, D), J(B, _), Le(x, B, null), J(B, g), J(B, S), J(S, l), J(b, u), J(b, a), J(a, s), J(s, v), J(a, i), Le(n, a, null), J(a, E), J(a, r), J(r, t), J(b, d), J(b, e), J(e, f), c = !0, M || (w = he(e, "click", A[6]), M = !0);
    },
    p(F, U) {
      (!c || U & 1) && K !== (K = F[0].saturability + "") && De(V, K);
      const N = {};
      U & 4 && (N.modelValue = F[2].saturate), O.$set(N), (!c || U & 4) && T !== (T = Math.round(F[2].saturate * 255) + "") && De(k, T), (!c || U & 1) && L !== (L = F[0].brightness + "") && De(D, L);
      const H = {};
      U & 4 && (H.modelValue = F[2].brightness), x.$set(H), (!c || U & 4) && y !== (y = Math.round(F[2].brightness * 255) + "") && De(l, y), (!c || U & 1) && m !== (m = F[0].contrast + "") && De(v, m);
      const j = {};
      U & 4 && (j.modelValue = F[2].contrast), n.$set(j), (!c || U & 4) && o !== (o = Math.round(F[2].contrast * 255) + "") && De(t, o), (!c || U & 1) && h !== (h = F[0].reset + "") && De(f, h);
    },
    i(F) {
      c || (se(O.$$.fragment, F), se(x.$$.fragment, F), se(n.$$.fragment, F), c = !0);
    },
    o(F) {
      ue(O.$$.fragment, F), ue(x.$$.fragment, F), ue(n.$$.fragment, F), c = !1;
    },
    d(F) {
      F && fe(b), Ae(O), Ae(x), Ae(n), M = !1, w();
    }
  };
}
function cr(A) {
  let b, R, G, K, V = A[4], W = [];
  for (let O = 0; O < V.length; O += 1)
    W[O] = hr(ar(A, V, O));
  return {
    c() {
      b = re("div"), R = re("ul");
      for (let O = 0; O < W.length; O += 1)
        W[O].c();
      G = le(), K = re("input"), Q(R, "class", "d-player-contextmenu-body svelte-1sesy3u"), Q(R, "style", A[3]), Q(K, "class", "d-player-copyText svelte-1sesy3u"), Q(b, "class", "d-player-contextmenu svelte-1sesy3u");
    },
    m(O, p) {
      de(O, b, p), J(b, R);
      for (let P = 0; P < W.length; P += 1)
        W[P].m(R, null);
      J(b, G), J(b, K);
    },
    p(O, p) {
      if (p & 16) {
        V = O[4];
        let P;
        for (P = 0; P < V.length; P += 1) {
          const T = ar(O, V, P);
          W[P] ? W[P].p(T, p) : (W[P] = hr(T), W[P].c(), W[P].m(R, null));
        }
        for (; P < W.length; P += 1)
          W[P].d(1);
        W.length = V.length;
      }
      p & 8 && Q(R, "style", O[3]);
    },
    d(O) {
      O && fe(b), bt(W, O);
    }
  };
}
function hr(A) {
  let b, R = A[17].label + "", G, K;
  return {
    c() {
      b = re("li"), G = ve(R), Q(b, "dplayerkeycode", K = A[17].key), Q(b, "class", "svelte-1sesy3u");
    },
    m(V, W) {
      de(V, b, W), J(b, G);
    },
    p(V, W) {
      W & 16 && R !== (R = V[17].label + "") && De(G, R), W & 16 && K !== (K = V[17].key) && Q(b, "dplayerkeycode", K);
    },
    d(V) {
      V && fe(b);
    }
  };
}
function Ui(A) {
  let b, R, G, K = A[1].dialogType && lr(A), V = A[1].show && cr(A);
  return {
    c() {
      b = re("div"), K && K.c(), R = le(), V && V.c(), Q(b, "class", "svelte-1sesy3u");
    },
    m(W, O) {
      de(W, b, O), K && K.m(b, null), J(b, R), V && V.m(b, null), G = !0;
    },
    p(W, [O]) {
      W[1].dialogType ? K ? (K.p(W, O), O & 2 && se(K, 1)) : (K = lr(W), K.c(), se(K, 1), K.m(b, R)) : K && (Ke(), ue(K, 1, 1, () => {
        K = null;
      }), We()), W[1].show ? V ? V.p(W, O) : (V = cr(W), V.c(), V.m(b, null)) : V && (V.d(1), V = null);
    },
    i(W) {
      G || (se(K), G = !0);
    },
    o(W) {
      ue(K), G = !1;
    },
    d(W) {
      W && fe(b), K && K.d(), V && V.d();
    }
  };
}
function Ni(A, b, R) {
  let G, { version: K = "1.0.0" } = b, { nowLanguage: V } = b, { contextMenu: W = ["filter", "hotkey", "copy", "version"] } = b;
  const O = {
    version: K,
    show: !1,
    dialogType: "",
    dialogTitle: "",
    mouseX: 0,
    mouseY: 0
  }, p = [
    {
      label: V.colorAdjustment,
      key: "filter"
    },
    {
      label: V.shortcutKeyInstructions,
      key: "hotkey"
    },
    {
      label: V.copyVideoUrl,
      key: "copy"
    },
    {
      label: `${V.version}\uFF1A` + K,
      key: "version"
    }
  ], P = [
    { key: "Space", label: "\u64AD\u653E/\u6682\u505C" },
    { key: "\u2192", label: "\u5355\u6B21\u5FEB\u8FDB10s\uFF0C\u957F\u63095\u500D\u901F\u64AD\u653E" },
    { key: "\u2190", label: "\u5FEB\u900010s" },
    { key: "\u2191", label: "\u97F3\u91CF\u589E\u52A010%" },
    { key: "\u2193", label: "\u97F3\u91CF\u589E\u52A0\u964D\u4F4E10%" }
  ], T = {
    saturate: 0.392,
    brightness: 0.392,
    contrast: 0.392
  };
  let k;
  const C = () => {
    R(2, T.saturate = 0.392, T), R(2, T.brightness = 0.392, T), R(2, T.contrast = 0.392, T);
  }, B = (S) => {
    S.key == "Escape" && L(0);
  }, I = (S) => {
    S.preventDefault(), vt(window, "keydown", B), vt(window, "click", L);
    const y = document.querySelector("#refPlayerWrap");
    vt(y, "click", L);
    let l = y.clientWidth;
    y.clientHeight, R(1, O.mouseX = S.clientX - y.getBoundingClientRect().left, O), l - O.mouseX < 130 && R(1, O.mouseX = O.mouseX + (l - O.mouseX - 130), O), R(1, O.mouseY = S.clientY - y.getBoundingClientRect().top, O), R(1, O.show = !0, O);
  }, L = (S) => {
    let y = S.path[0].tagName == "LI", l = S.path[0].attributes.dplayerKeyCode && S.path[0].attributes.dplayerKeyCode.value, u = G.map((s) => s.key);
    if (y && u.includes(l))
      if (R(1, O.dialogTitle = S.path[0].innerText, O), R(1, O.dialogType = l, O), l == "copy") {
        let s = document.querySelector(".d-player-copyText");
        s.value = window.location.href, s.select(), document.execCommand("copy"), R(1, O.dialogType = "", O);
      } else
        l == "version" && R(1, O.dialogType = "", O);
    R(1, O.show = !1, O), Ye(window, "keydown", B), Ye(window, "click", L);
    const a = document.querySelector("#refPlayerWrap");
    Ye(a, "click", L);
  };
  Qr(() => {
    const S = document.querySelector("#refPlayerWrap");
    Ye(window, "keydown", B), Ye(window, "click", L), Ye(S, "contextmenu", I), vt(S, "contextmenu", I);
  }), yi(() => {
    const S = document.querySelector("#refPlayerWrap");
    Ye(window, "keydown", B), Ye(window, "click", L), Ye(S, "contextmenu", I);
  });
  const D = () => {
    R(1, O.dialogType = !1, O);
  }, _ = (S) => {
    R(2, T.saturate = S.detail, T);
  }, x = (S) => {
    R(2, T.brightness = S.detail, T);
  }, g = (S) => {
    R(2, T.contrast = S.detail, T);
  };
  return A.$$set = (S) => {
    "version" in S && R(7, K = S.version), "nowLanguage" in S && R(0, V = S.nowLanguage), "contextMenu" in S && R(8, W = S.contextMenu);
  }, A.$$.update = () => {
    if (A.$$.dirty & 256 && R(4, G = p.filter((S) => W.includes(S.key))), A.$$.dirty & 2 && R(3, k = `left: ${O.mouseX}px;top:${O.mouseY}px`), A.$$.dirty & 4) {
      const S = document.querySelector("#dPlayerVideo");
      if (S) {
        const y = (T.saturate * 2.55).toFixed(2), l = (T.brightness * 2.55).toFixed(2), u = (T.contrast * 2.55).toFixed(2);
        S.style.filter = `saturate(${y}) brightness(${l}) contrast(${u})`, S.style["-webkit-filter"] = `saturate(${y}) brightness(${l}) contrast(${u})`;
      }
    }
  }, [
    V,
    O,
    T,
    k,
    G,
    P,
    C,
    K,
    W,
    D,
    _,
    x,
    g
  ];
}
class Ki extends nt {
  constructor(b) {
    super(), it(
      this,
      b,
      Ni,
      Ui,
      tt,
      {
        version: 7,
        nowLanguage: 0,
        contextMenu: 8
      },
      Bi
    );
  }
}
function Wi(A) {
  rt(A, "svelte-1dcs6nc", "@import '../asset/style/iconfont.css';div.svelte-1dcs6nc.svelte-1dcs6nc,span.svelte-1dcs6nc.svelte-1dcs6nc,p.svelte-1dcs6nc.svelte-1dcs6nc,img.svelte-1dcs6nc.svelte-1dcs6nc,i.svelte-1dcs6nc.svelte-1dcs6nc{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}.iconfont.svelte-1dcs6nc.svelte-1dcs6nc{display:inline-block}.d-flex-x.svelte-1dcs6nc.svelte-1dcs6nc{display:flex}.d-flex-x.svelte-1dcs6nc.svelte-1dcs6nc{align-items:center}.mr5.svelte-1dcs6nc.svelte-1dcs6nc{margin-right:5px}.d-pointer.svelte-1dcs6nc.svelte-1dcs6nc{cursor:pointer}.rotating.svelte-1dcs6nc.svelte-1dcs6nc{animation:svelte-1dcs6nc-rotating 2s linear infinite}@keyframes svelte-1dcs6nc-rotating{100%{-webkit-transform:rotate(360deg)}}.f50.svelte-1dcs6nc.svelte-1dcs6nc{font-size:50px}.f24.svelte-1dcs6nc.svelte-1dcs6nc{font-size:24px}.d-loading.svelte-1dcs6nc.svelte-1dcs6nc{position:absolute;left:0;right:0;bottom:0px;top:0;display:flex;align-items:center;justify-content:center;background:rgba(0, 0, 0, 0.3);z-index:2;color:#efefef;text-align:center;font-size:13px}.loading-img.svelte-1dcs6nc.svelte-1dcs6nc{width:50px}.d-logo-loading.svelte-1dcs6nc.svelte-1dcs6nc{position:relative;width:100px;height:23px;overflow:hidden}.d-logo-loading.svelte-1dcs6nc .d-logo.svelte-1dcs6nc{width:100%;height:100%;background:url(https://s.thsi.cn/cd/ths-frontend-hxmui-container/front/thsc-hxmui/1.11.0/img/logo_light.ed78645a.png) 50%;background-size:cover}.d-logo-loading.svelte-1dcs6nc .d-light.svelte-1dcs6nc{position:absolute;left:0;top:50%;-webkit-transform:translateY(-50%);transform:translateY(-50%);width:32px;height:23px;background:url(data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAGIAAABaCAMAAAB0UnP8AAAAhFBMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////8g2+bRAAAALHRSTlMABAgVDx4uDCU9ODMZKUJcRiFWYGZKt06ojpeJUq95bmqzo6CTfYRydaybgZ4JNUQAAAd9SURBVGjejNWNVtpAEIbhpoECGii/ojUCapEU7v/++s27ux23kMTxHH/O0Tx+Mzubb7eqsPquGo0Gg0FZllVVDYeLxVg1/VT6cbEYqqqqVOl3RyP7M/7+W2sV9gEhYARQBoDH/6Du9aFCWaBgOIFRtBqhsgwhAcD9p0KxaG4I8RhFWwqAIglEIAGPv7OaUPomMo440dUrD5FlCAHS4x2JxiIRg55peApCIDAGixD+/dlsNg+l76QIoV0YnqNzGP+HUJdcANiEckRBPIcTrRk8RIlABrVICXj8drutrfTVFBAZlqOqaFXPNAoqaxMZSABQ10vKEKLIULOmjDyLgdA3CQQyAITn/0wVFBnkwPBWdaZwgjZNp2QgQgBWoWQsZcQctMqJzhTXIciw2ZBgtVqnQhGiZmVGd6e8TwhVGISOknUpAgfVfr/XZynB2MzsXEEEA6JNcMJPUxBqBHv8iTJFSWQwDyc6O5UJEC5oCAL2+6bZhWqaE0hmiKi8U719KodD3RsQZFCTlEDC0UqIjJTDY1R9nYLwYVsIFw4C9PzLh9XlIqY5HQ6r1XL5L8aCgXenyE+sEZOJ2uSCgGdKyG5nORRju82JQSuRnyefRBIUQc9/okCOyag3ED/GGaFqSeFEnARtsgwXhN8qIWbYPAKh3fgKgaAaiAiT+EGIIGjOHwC/rEx5/mAca02DTokYc0+1EoUTPuxAqE3M4RkhGiJsHGEadAqi6iAYRTbs+3vbiZoQEizDr/P5XXU+C7EYx2a/XkMw70RgdBJcTyEEx8lCkAHhDYQcl6M6BTHvJ/Ijm/oUFpsQCAZQGEyDTtXajK+myM4Tk6gV4tQcLwgCHqlgcKhaCGbRsRUKARGHbSGeIBAwiGHE/hCISR9RXB9ZNrteatiEiMIfymKETt0g2ra7yAhWmxBGxEm8v5vw8vIiQsZtovxEFD2rzXlKfUohBFB/6FRG3OUperdiHIma8xT7pDbp6a+vbUR/CifoE0e2ZilsJ1KIVxXEW06k7ZbQmyKN4u4uHVkR9EmTQPgyUXRsBcRkPqdPzc6GbSEQMGzeELvG7loukOymbdmKIp+2H9mPZ44TxMPDA0RIYXuhC6SFKNoWr6riVtCndTxPCoGQEWy3EZzZzhTFrT5N0pG92LDfIAQ4wXaf1hAcqKsUvRfUtpN4zwh/d0v4SgqOrIg4iicRCBlh1yDvC3uxQkiAuH3PBiEjwpGFYBSEyImLESsRs0SUbYSfJ67ZeEHVSxHqk4hzIijbC12DTyJO/4g0CvrU/a5gt7nI2QobBXvnBKvH/cEbScRcxNVVfkO42gpu2RNbEUI48fjItEXYbjPtSAw8RRcxdYLFy0cBwShE7J0YQ9y+PopEIFTxDoxb0VyPgmmfbdp+fYjovz4gfPEi8bdSc1ttI4qh6ENbqKF1ZojBLZi0BOqG/P8HRmeNthVFntFknvy2kHS2rn5xVRghhcLTB/0HiCq8akUtRw/DT0u0UyhCeGpxXNs/QKyrAgRlG4Sr4kmhwAi+LDxrNxFeowoQqYMSwnIgofh1H/FfCIWi1TZ+CuE9UrYpeIQiCPZkibYhHqQKQ3wp0S5WpGgbwsu21QoQJRSoAoTq9tdAtKoAQQcVwst++q2i6pl8BoHwunIEgop3qgjlwFcQRPt8PoJoy1F0Bo4YqjiRAzMiiqoq3nlvUc0j3lEItF0QWXgHot1akUc89csgqHiOiFpBmj0tCYpod+UoI0LbSh9C0EPRlUt4F6miIgKwibgGgk9PlhYKxDRt+4kvDxZeLFRUQZAFIUh3JCg9WRC5M8hJcC8CgiPGuJob5rmqolphBCGOCcGLUk9Op8kkuWQPjcNpT7S2NFCGKog6WPCeeLKlHLVWZATiRnrPMR4xgXlN9VZToaBW7LPi8BFxG/I0R0YHJVUI0VhREai7TqqWn/BTWn7UJ9vHgsp9pYsS4zmM4MkK0aoCwj3E1taALFtG+p0IdEGO0trAGPYNAARN9IZQM5ubNCAN4gjCMoibwX7FCeYmjNC4rVqxJbwci5i48dRTXUMZwYxQsMNP9clWRF5+0B683FumuRF6T/2TLT2zth+YoZUgO8FYCa5tHbsdc906stgcDG02sYHFZvipZo/yZcSsnaCWpxYOg/BdiYMIUrZ6j2pFfVKB4NlaNB7/Eo5/BrHPAEG4xEIQRKiiWc++WwFr28+mXKtyA9gAGQQlj1RTy5eWgqGMSbvywYiF/x9swE0RCSHWrcjb+M9eLZoVM58QBEOeujHGWWE5vQDABOvPRlcgTRREdwab/W5xmMRIJyQDXC523Smnl3hPzd0Chm5503TmDhZnMAOYk4aXILCTCMKaKgridqY66JoXxzy/5mFDNaKzQoxv9qi4GMKoN8kBwAapLkSxaYWkERF3OwYkDqs6esoG3EQxam7Q9QLtJ+7V8/BigySRZLfjtCoGh3og+cgdhJlA7D9yw8BVYpizgORbvf4P8B0vJSPaU312lYXcPhgBsR9O4M8TEp1iLSvaRwUDyDyv/m8i2RCxLoCqjRwPvKW/f+j7KYAIDeIN31OsfyvZzREAAAAASUVORK5CYII=) 50%;background-size:cover;opacity:0.6;-webkit-animation:svelte-1dcs6nc-move 0.8s ease-in-out infinite;animation:svelte-1dcs6nc-move 0.8s ease-in-out infinite}@keyframes svelte-1dcs6nc-move{from{left:0}to{left:100%}}");
}
function vr(A) {
  let b, R, G = ["loadstart", "waiting"].includes(A[1]), K, V, W = G && gr(A), O = A[1] == "ended" && mr(A), p = (A[1] == "error" || A[1] == "stalled") && pr(A);
  return {
    c() {
      b = re("div"), R = re("div"), W && W.c(), K = le(), O && O.c(), V = le(), p && p.c(), Q(R, "class", "svelte-1dcs6nc"), Q(b, "class", "d-loading svelte-1dcs6nc"), Q(b, "style", A[6]);
    },
    m(P, T) {
      de(P, b, T), J(b, R), W && W.m(R, null), J(R, K), O && O.m(R, null), J(R, V), p && p.m(R, null);
    },
    p(P, T) {
      T & 2 && (G = ["loadstart", "waiting"].includes(P[1])), G ? W ? W.p(P, T) : (W = gr(P), W.c(), W.m(R, K)) : W && (W.d(1), W = null), P[1] == "ended" ? O ? O.p(P, T) : (O = mr(P), O.c(), O.m(R, V)) : O && (O.d(1), O = null), P[1] == "error" || P[1] == "stalled" ? p ? p.p(P, T) : (p = pr(P), p.c(), p.m(R, null)) : p && (p.d(1), p = null), T & 64 && Q(b, "style", P[6]);
    },
    d(P) {
      P && fe(b), W && W.d(), O && O.d(), p && p.d();
    }
  };
}
function gr(A) {
  let b, R, G, K;
  function V(p, P) {
    return p[3] ? ji : p[4] ? Vi : p[5] === "ths" ? Hi : Gi;
  }
  let W = V(A), O = W(A);
  return {
    c() {
      b = re("span"), O.c(), R = le(), G = re("p"), K = ve(A[2]), Q(G, "class", "svelte-1dcs6nc"), Q(b, "class", "svelte-1dcs6nc");
    },
    m(p, P) {
      de(p, b, P), O.m(b, null), J(b, R), J(b, G), J(G, K);
    },
    p(p, P) {
      W === (W = V(p)) && O ? O.p(p, P) : (O.d(1), O = W(p), O && (O.c(), O.m(b, R))), P & 4 && De(K, p[2]);
    },
    d(p) {
      p && fe(b), O.d();
    }
  };
}
function Gi(A) {
  let b;
  return {
    c() {
      b = re("i"), Q(b, "class", "rotating iconfont icon-loading f50 svelte-1dcs6nc");
    },
    m(R, G) {
      de(R, b, G);
    },
    p: Pe,
    d(R) {
      R && fe(b);
    }
  };
}
function Hi(A) {
  let b;
  return {
    c() {
      b = re("div"), b.innerHTML = `<div class="d-logo svelte-1dcs6nc"></div> 
              <div class="d-light svelte-1dcs6nc"></div>`, Q(b, "class", "d-logo-loading svelte-1dcs6nc");
    },
    m(R, G) {
      de(R, b, G);
    },
    p: Pe,
    d(R) {
      R && fe(b);
    }
  };
}
function Vi(A) {
  let b, R;
  return {
    c() {
      b = re("img"), Ot(b.src, R = A[4]) || Q(b, "src", R), Q(b, "alt", ""), Q(b, "class", "rotating f50 loading-img svelte-1dcs6nc");
    },
    m(G, K) {
      de(G, b, K);
    },
    p(G, K) {
      K & 16 && !Ot(b.src, R = G[4]) && Q(b, "src", R);
    },
    d(G) {
      G && fe(b);
    }
  };
}
function ji(A) {
  let b, R;
  return {
    c() {
      b = new hi(!1), R = St(), b.a = R;
    },
    m(G, K) {
      b.m(A[3], G, K), de(G, R, K);
    },
    p(G, K) {
      K & 8 && b.p(G[3]);
    },
    d(G) {
      G && fe(R), G && b.d();
    }
  };
}
function mr(A) {
  let b, R, G, K = A[0].replay + "", V, W, O;
  return {
    c() {
      b = re("span"), R = re("p"), G = re("i"), V = ve(K), Q(G, "class", "iconfont icon-replay f24 mr5 svelte-1dcs6nc"), Q(R, "class", "d-flex-x d-pointer svelte-1dcs6nc"), Q(b, "class", "svelte-1dcs6nc");
    },
    m(p, P) {
      de(p, b, P), J(b, R), J(R, G), J(R, V), W || (O = he(R, "click", A[8]), W = !0);
    },
    p(p, P) {
      P & 1 && K !== (K = p[0].replay + "") && De(V, K);
    },
    d(p) {
      p && fe(b), W = !1, O();
    }
  };
}
function pr(A) {
  let b, R, G, K = A[0].playError + "", V, W, O;
  return {
    c() {
      b = re("span"), R = re("p"), G = re("i"), V = ve(K), Q(G, "class", "iconfont icon-replay f24 mr5 svelte-1dcs6nc"), Q(R, "class", "d-flex-x d-pointer svelte-1dcs6nc"), Q(b, "class", "svelte-1dcs6nc");
    },
    m(p, P) {
      de(p, b, P), J(b, R), J(R, G), J(R, V), W || (O = he(R, "click", A[8]), W = !0);
    },
    p(p, P) {
      P & 1 && K !== (K = p[0].playError + "") && De(V, K);
    },
    d(p) {
      p && fe(b), W = !1, O();
    }
  };
}
function zi(A) {
  let b = A[7].includes(A[1]), R, G = b && vr(A);
  return {
    c() {
      G && G.c(), R = St();
    },
    m(K, V) {
      G && G.m(K, V), de(K, R, V);
    },
    p(K, [V]) {
      V & 2 && (b = K[7].includes(K[1])), b ? G ? G.p(K, V) : (G = vr(K), G.c(), G.m(R.parentNode, R)) : G && (G.d(1), G = null);
    },
    i: Pe,
    o: Pe,
    d(K) {
      G && G.d(K), K && fe(R);
    }
  };
}
function Yi(A, b, R) {
  const G = gt(), K = ["loadstart", "loadStateType", "waiting", "ended", "error", "stalled"];
  let { nowLanguage: V } = b, { loadType: W = V.loading } = b, { loadingText: O = "" } = b, { loadingDom: p = "" } = b, { loadingImg: P = "" } = b, { loadingType: T = "" } = b, k = "";
  const C = () => {
    G("playHandle");
  };
  return A.$$set = (B) => {
    "nowLanguage" in B && R(0, V = B.nowLanguage), "loadType" in B && R(1, W = B.loadType), "loadingText" in B && R(2, O = B.loadingText), "loadingDom" in B && R(3, p = B.loadingDom), "loadingImg" in B && R(4, P = B.loadingImg), "loadingType" in B && R(5, T = B.loadingType);
  }, A.$$.update = () => {
    if (A.$$.dirty & 2) {
      let B = "background: rgba(0, 0, 0, .1);z-index:1";
      W === "loadstart" && (B = "background: rgba(0, 0, 0, 1);;z-index:3"), R(6, k = B);
    }
  }, [
    V,
    W,
    O,
    p,
    P,
    T,
    k,
    K,
    C
  ];
}
class Xi extends nt {
  constructor(b) {
    super(), it(
      this,
      b,
      Yi,
      zi,
      tt,
      {
        nowLanguage: 0,
        loadType: 1,
        loadingText: 2,
        loadingDom: 3,
        loadingImg: 4,
        loadingType: 5
      },
      Wi
    );
  }
}
function Qi(A) {
  rt(A, "svelte-q8odyd", ".d-player-top.svelte-q8odyd{position:absolute;font-size:16px;left:0px;top:0;right:0px;color:#fff;display:flex;padding:0 20px;height:60px;background-image:linear-gradient(rgba(0, 0, 0, 0.6), transparent);justify-content:space-between;z-index:1}");
}
function Zi(A) {
  let b, R, G = (A[0] || "") + "", K;
  return {
    c() {
      b = re("div"), R = re("p"), K = ve(G), Q(R, "class", "top-title"), Q(b, "class", "d-player-top svelte-q8odyd");
    },
    m(V, W) {
      de(V, b, W), J(b, R), J(R, K);
    },
    p(V, [W]) {
      W & 1 && G !== (G = (V[0] || "") + "") && De(K, G);
    },
    i: Pe,
    o: Pe,
    d(V) {
      V && fe(b);
    }
  };
}
function Ji(A, b, R) {
  let { title: G = "" } = b;
  return A.$$set = (K) => {
    "title" in K && R(0, G = K.title);
  }, [G];
}
class qi extends nt {
  constructor(b) {
    super(), it(this, b, Ji, Zi, tt, { title: 0 }, Qi);
  }
}
function $i(A) {
  rt(A, "svelte-o0d56g", ".d-flex-center.svelte-o0d56g{display:flex}.d-flex-center.svelte-o0d56g{justify-content:center;align-items:center}.d-status.svelte-o0d56g{text-align:center;font-size:14px;vertical-align:middle;background:rgba(0, 0, 0, 0.8);padding:0 8px;height:30px;border-radius:5px;display:flex;align-items:center;color:rgba(255, 255, 255, 0.95)}");
}
function yr(A) {
  let b, R, G, K = A[0].handleType == "volume" && Er(A), V = (A[0].handleType === "playbackRate" || A[0].isMultiplesPlay) && Tr();
  return {
    c() {
      b = re("div"), K && K.c(), R = le(), V && V.c(), Q(b, "class", "d-status svelte-o0d56g");
    },
    m(W, O) {
      de(W, b, O), K && K.m(b, null), J(b, R), V && V.m(b, null), G = !0;
    },
    p(W, O) {
      W[0].handleType == "volume" ? K ? (K.p(W, O), O & 1 && se(K, 1)) : (K = Er(W), K.c(), se(K, 1), K.m(b, R)) : K && (Ke(), ue(K, 1, 1, () => {
        K = null;
      }), We()), W[0].handleType === "playbackRate" || W[0].isMultiplesPlay ? V || (V = Tr(), V.c(), V.m(b, null)) : V && (V.d(1), V = null);
    },
    i(W) {
      G || (se(K), G = !0);
    },
    o(W) {
      ue(K), G = !1;
    },
    d(W) {
      W && fe(b), K && K.d(), V && V.d();
    }
  };
}
function Er(A) {
  let b, R, G, K = ~~(A[0].volume * 100) + "", V, W, O;
  return R = new mt({
    props: {
      size: "18",
      className: "d-status-icon",
      icon: `icon-volume-${A[0].volume == 0 ? "mute" : A[0].volume > 0.5 ? "up" : "down"}`
    }
  }), {
    c() {
      b = re("li"), be(R.$$.fragment), G = le(), V = ve(K), W = ve("%"), Q(b, "class", "d-flex-center svelte-o0d56g");
    },
    m(p, P) {
      de(p, b, P), Le(R, b, null), J(b, G), J(b, V), J(b, W), O = !0;
    },
    p(p, P) {
      const T = {};
      P & 1 && (T.icon = `icon-volume-${p[0].volume == 0 ? "mute" : p[0].volume > 0.5 ? "up" : "down"}`), R.$set(T), (!O || P & 1) && K !== (K = ~~(p[0].volume * 100) + "") && De(V, K);
    },
    i(p) {
      O || (se(R.$$.fragment, p), O = !0);
    },
    o(p) {
      ue(R.$$.fragment, p), O = !1;
    },
    d(p) {
      p && fe(b), Ae(R);
    }
  };
}
function Tr(A) {
  let b;
  return {
    c() {
      b = re("li"), b.innerHTML = `<d-icon size="12" icon="icon-play"></d-icon> 
        <d-icon size="12" icon="icon-play" style="margin-right:5px"></d-icon>5X\u901F\u64AD\u653E\u4E2D`, Q(b, "class", "d-flex-center svelte-o0d56g");
    },
    m(R, G) {
      de(R, b, G);
    },
    d(R) {
      R && fe(b);
    }
  };
}
function en(A) {
  let b, R, G = (A[0].handleType || A[0].isMultiplesPlay) && yr(A);
  return {
    c() {
      G && G.c(), b = St();
    },
    m(K, V) {
      G && G.m(K, V), de(K, b, V), R = !0;
    },
    p(K, [V]) {
      K[0].handleType || K[0].isMultiplesPlay ? G ? (G.p(K, V), V & 1 && se(G, 1)) : (G = yr(K), G.c(), se(G, 1), G.m(b.parentNode, b)) : G && (Ke(), ue(G, 1, 1, () => {
        G = null;
      }), We());
    },
    i(K) {
      R || (se(G), R = !0);
    },
    o(K) {
      ue(G), R = !1;
    },
    d(K) {
      G && G.d(K), K && fe(b);
    }
  };
}
function tn(A, b, R) {
  let { state: G } = b;
  return A.$$set = (K) => {
    "state" in K && R(0, G = K.state);
  }, [G];
}
class rn extends nt {
  constructor(b) {
    super(), it(this, b, tn, en, tt, { state: 0 }, $i);
  }
}
function nn(A) {
  rt(A, "svelte-9brao2", ".d-radio.svelte-9brao2{position:relative;display:inline-block;padding-left:20px;box-sizing:border-box;height:18px;line-height:18px;font-size:14px;margin-left:12px;margin-top:10px;cursor:pointer;overflow:hidden;white-space:nowrap;text-overflow:ellipsis}.d-radio.svelte-9brao2::before{content:'';position:absolute;display:inline-block;top:2px;left:0;width:5px;height:5px;border:1px solid #ccc;border-radius:50%}.d-radio.d-radio-checked.svelte-9brao2::before{content:'';border-color:#409eff;position:absolute;display:inline-block;top:2px;left:0;width:5px;height:5px;border:1px solid #409eff;border-radius:50%}.d-radio.d-radio-checked.svelte-9brao2::after{content:'';position:absolute;top:5px;left:3px;display:inline-block;width:8px;height:8px;background-color:#00a1d6;border-radius:50%}");
}
function sn(A) {
  let b, R, G, K, V;
  return {
    c() {
      b = re("div"), R = ve(A[0]), Q(b, "title", A[0]), Q(b, "class", "d-radio svelte-9brao2"), Q(b, "style", G = `width:${A[1]}`), $t(b, "d-radio-checked", A[2]);
    },
    m(W, O) {
      de(W, b, O), J(b, R), K || (V = he(b, "click", wt(A[3])), K = !0);
    },
    p(W, [O]) {
      O & 1 && De(R, W[0]), O & 1 && Q(b, "title", W[0]), O & 2 && G !== (G = `width:${W[1]}`) && Q(b, "style", G), O & 4 && $t(b, "d-radio-checked", W[2]);
    },
    i: Pe,
    o: Pe,
    d(W) {
      W && fe(b), K = !1, V();
    }
  };
}
function an(A, b, R) {
  const G = gt();
  let { radioText: K = "" } = b, { width: V = "100%" } = b, W = !1;
  const O = () => {
    R(2, W = !W), G("checkRadio", { radioText: K, isChecked: W });
  };
  return A.$$set = (p) => {
    "radioText" in p && R(0, K = p.radioText), "width" in p && R(1, V = p.width);
  }, [K, V, W, O];
}
class on extends nt {
  constructor(b) {
    super(), it(this, b, an, sn, tt, { radioText: 0, width: 1 }, nn);
  }
}
function ln(A) {
  rt(A, "svelte-bbg92z", ".d-toast.svelte-bbg92z{position:fixed;top:50%;left:50%;transform:translate(-50%, -50%);background-color:rgba(40, 40, 40, 0.96);padding:0 18px;border-radius:10px}.d-toast-content.svelte-bbg92z{font-size:16px;line-height:1;word-break:break-all;color:#fefefe}");
}
function _r(A) {
  let b, R, G, K, V;
  return {
    c() {
      b = re("div"), R = re("p"), Q(R, "class", "d-toast-content svelte-bbg92z"), Q(b, "class", "d-toast svelte-bbg92z"), Q(b, "style", G = `z-index: ${A[1]}`);
    },
    m(W, O) {
      de(W, b, O), J(b, R), R.innerHTML = A[0], V = !0;
    },
    p(W, O) {
      (!V || O & 1) && (R.innerHTML = W[0]), (!V || O & 2 && G !== (G = `z-index: ${W[1]}`)) && Q(b, "style", G);
    },
    i(W) {
      V || (lt(() => {
        K || (K = $e(b, et, {}, !0)), K.run(1);
      }), V = !0);
    },
    o(W) {
      K || (K = $e(b, et, {}, !1)), K.run(0), V = !1;
    },
    d(W) {
      W && fe(b), W && K && K.end();
    }
  };
}
function un(A) {
  let b, R, G = A[2] && _r(A);
  return {
    c() {
      G && G.c(), b = St();
    },
    m(K, V) {
      G && G.m(K, V), de(K, b, V), R = !0;
    },
    p(K, [V]) {
      K[2] ? G ? (G.p(K, V), V & 4 && se(G, 1)) : (G = _r(K), G.c(), se(G, 1), G.m(b.parentNode, b)) : G && (Ke(), ue(G, 1, 1, () => {
        G = null;
      }), We());
    },
    i(K) {
      R || (se(G), R = !0);
    },
    o(K) {
      ue(G), R = !1;
    },
    d(K) {
      G && G.d(K), K && fe(b);
    }
  };
}
function fn(A, b, R) {
  const G = gt();
  let { content: K = "" } = b, { zIndex: V = 9999 } = b, { duration: W = 2e3 } = b, { isShow: O = !1 } = b;
  return A.$$set = (p) => {
    "content" in p && R(0, K = p.content), "zIndex" in p && R(1, V = p.zIndex), "duration" in p && R(3, W = p.duration), "isShow" in p && R(2, O = p.isShow);
  }, A.$$.update = () => {
    A.$$.dirty & 12 && O && setTimeout(
      () => {
        G("closeIsShow");
      },
      W
    );
  }, [K, V, O, W];
}
class dn extends nt {
  constructor(b) {
    super(), it(
      this,
      b,
      fn,
      un,
      tt,
      {
        content: 0,
        zIndex: 1,
        duration: 3,
        isShow: 2
      },
      ln
    );
  }
}
function cn(A) {
  rt(A, "svelte-bjqzkb", ".d-feedback-container.svelte-bjqzkb.svelte-bjqzkb{position:absolute;left:0;top:0;right:0;bottom:0;display:flex;justify-content:center;align-items:center;z-index:3}.d-feedback-container.svelte-bjqzkb .dialog.svelte-bjqzkb{width:400px;height:240px;background-color:rgba(33, 33, 33, 0.9);color:#ffffff}.d-feedback-container.svelte-bjqzkb .dialog .header.svelte-bjqzkb{width:100%;height:40px;display:flex;justify-content:center;align-items:center;font-size:16px;position:relative}.d-feedback-container.svelte-bjqzkb .dialog .header.svelte-bjqzkb::after{content:' ';position:absolute;width:100%;height:1px;bottom:0;left:0;background-color:hsla(0, 0%, 100%, 0.4)}.d-feedback-container.svelte-bjqzkb .dialog .header .icon-close.svelte-bjqzkb{position:absolute;right:0px;top:8px;width:40px;height:40px;line-height:40px;text-align:center;cursor:pointer;font:inherit}.d-feedback-container.svelte-bjqzkb .dialog .content.svelte-bjqzkb{position:relative;text-align:left}.d-feedback-container.svelte-bjqzkb .dialog .other.svelte-bjqzkb{font-size:14px;margin-left:12px}.d-feedback-container.svelte-bjqzkb .dialog #otherContent.svelte-bjqzkb{background-color:#191919;border:1px solid hsla(0, 0%, 100%, 0.4);resize:none;color:#ccc;margin-top:10px}.d-feedback-container.svelte-bjqzkb .dialog #otherContent.svelte-bjqzkb::-webkit-scrollbar{width:5px;background-color:rgba(255, 255, 255, 0.5)}.d-feedback-container.svelte-bjqzkb .dialog #otherContent.svelte-bjqzkb::-webkit-scrollbar-thumb{width:5px;height:5px;background-color:rgba(0, 0, 0, 0.5);border-radius:10px}.d-feedback-container.svelte-bjqzkb .dialog .footer.svelte-bjqzkb{text-align:center}.d-feedback-container.svelte-bjqzkb .dialog .footer .d-player-filter-reset.svelte-bjqzkb{cursor:pointer;margin-top:10px;padding:3px 20px;display:inline-block;border-radius:2px;font-size:12px;background:rgba(133, 133, 133, 0.5)}.d-feedback-container.svelte-bjqzkb .dialog .footer .d-player-filter-reset.svelte-bjqzkb:hover{background:rgba(255, 255, 255, 0.3)}");
}
function Sr(A, b, R) {
  const G = A.slice();
  return G[13] = b[R], G;
}
function xr(A) {
  let b, R, G, K, V = A[1].playerFeedBack + "", W, O, p, P, T, k, C, B = A[1].other + "", I, L, D, _, x, g, S, y, l = A[1].confirm + "", u, a, s, m, v, i, n, E = A[8], r = [];
  for (let t = 0; t < E.length; t += 1)
    r[t] = Dr(Sr(A, E, t));
  const o = (t) => ue(r[t], 1, 1, () => {
    r[t] = null;
  });
  return {
    c() {
      b = re("div"), R = re("div"), G = re("div"), K = re("span"), W = ve(V), O = le(), p = re("i"), p.textContent = "X", P = le(), T = re("div");
      for (let t = 0; t < r.length; t += 1)
        r[t].c();
      k = le(), C = re("span"), I = ve(B), L = ve("\uFF1A"), D = le(), _ = re("textarea"), g = le(), S = re("div"), y = re("span"), u = ve(l), Q(p, "class", "icon-close svelte-bjqzkb"), Q(G, "class", "header svelte-bjqzkb"), Q(C, "class", "other svelte-bjqzkb"), Q(_, "name", "otherContent"), Q(_, "id", "otherContent"), Q(_, "cols", "36"), Q(_, "rows", "3"), Q(_, "placeholder", x = A[1].feedbackPlaceHolder), Q(_, "class", "svelte-bjqzkb"), Q(T, "class", "content svelte-bjqzkb"), Q(y, "title", a = A[1].confirm), Q(y, "aria-label", s = A[1].confirm), Q(y, "class", "d-player-filter-reset svelte-bjqzkb"), Q(S, "class", "footer svelte-bjqzkb"), Q(R, "class", "dialog svelte-bjqzkb"), Q(b, "class", "d-feedback-container svelte-bjqzkb");
    },
    m(t, d) {
      de(t, b, d), J(b, R), J(R, G), J(G, K), J(K, W), J(G, O), J(G, p), J(R, P), J(R, T);
      for (let e = 0; e < r.length; e += 1)
        r[e].m(T, null);
      J(T, k), J(T, C), J(C, I), J(C, L), J(T, D), J(T, _), qt(_, A[2]), J(R, g), J(R, S), J(S, y), J(y, u), v = !0, i || (n = [
        he(p, "click", A[5]),
        he(_, "input", A[10]),
        he(y, "click", A[6]),
        he(R, "click", wt(A[9]))
      ], i = !0);
    },
    p(t, d) {
      if ((!v || d & 2) && V !== (V = t[1].playerFeedBack + "") && De(W, V), d & 384) {
        E = t[8];
        let e;
        for (e = 0; e < E.length; e += 1) {
          const h = Sr(t, E, e);
          r[e] ? (r[e].p(h, d), se(r[e], 1)) : (r[e] = Dr(h), r[e].c(), se(r[e], 1), r[e].m(T, k));
        }
        for (Ke(), e = E.length; e < r.length; e += 1)
          o(e);
        We();
      }
      (!v || d & 2) && B !== (B = t[1].other + "") && De(I, B), (!v || d & 2 && x !== (x = t[1].feedbackPlaceHolder)) && Q(_, "placeholder", x), d & 4 && qt(_, t[2]), (!v || d & 2) && l !== (l = t[1].confirm + "") && De(u, l), (!v || d & 2 && a !== (a = t[1].confirm)) && Q(y, "title", a), (!v || d & 2 && s !== (s = t[1].confirm)) && Q(y, "aria-label", s);
    },
    i(t) {
      if (!v) {
        for (let d = 0; d < E.length; d += 1)
          se(r[d]);
        lt(() => {
          m || (m = $e(b, et, {}, !0)), m.run(1);
        }), v = !0;
      }
    },
    o(t) {
      r = r.filter(Boolean);
      for (let d = 0; d < r.length; d += 1)
        ue(r[d]);
      m || (m = $e(b, et, {}, !1)), m.run(0), v = !1;
    },
    d(t) {
      t && fe(b), bt(r, t), t && m && m.end(), i = !1, ot(n);
    }
  };
}
function Dr(A) {
  let b, R;
  return b = new on({
    props: {
      radioText: A[13],
      width: "45%"
    }
  }), b.$on("checkRadio", A[7]), {
    c() {
      be(b.$$.fragment);
    },
    m(G, K) {
      Le(b, G, K), R = !0;
    },
    p: Pe,
    i(G) {
      R || (se(b.$$.fragment, G), R = !0);
    },
    o(G) {
      ue(b.$$.fragment, G), R = !1;
    },
    d(G) {
      Ae(b, G);
    }
  };
}
function hn(A) {
  let b, R, G, K;
  b = new dn({
    props: {
      isShow: A[3],
      content: A[1].feedbackTips
    }
  }), b.$on("closeIsShow", A[4]);
  let V = A[0] && xr(A);
  return {
    c() {
      be(b.$$.fragment), R = le(), V && V.c(), G = St();
    },
    m(W, O) {
      Le(b, W, O), de(W, R, O), V && V.m(W, O), de(W, G, O), K = !0;
    },
    p(W, [O]) {
      const p = {};
      O & 8 && (p.isShow = W[3]), O & 2 && (p.content = W[1].feedbackTips), b.$set(p), W[0] ? V ? (V.p(W, O), O & 1 && se(V, 1)) : (V = xr(W), V.c(), se(V, 1), V.m(G.parentNode, G)) : V && (Ke(), ue(V, 1, 1, () => {
        V = null;
      }), We());
    },
    i(W) {
      K || (se(b.$$.fragment, W), se(V), K = !0);
    },
    o(W) {
      ue(b.$$.fragment, W), ue(V), K = !1;
    },
    d(W) {
      Ae(b, W), W && fe(R), V && V.d(W), W && fe(G);
    }
  };
}
function vn(A, b, R) {
  const G = gt();
  let { isShow: K = !1 } = b, { nowLanguage: V } = b;
  const W = /* @__PURE__ */ new Set([]);
  let O = "", p = !1;
  const P = () => {
    R(3, p = !1);
  }, T = () => {
    G("closeFeedBack");
  }, k = () => {
    R(3, p = !0), T(), G("feedbackConfirm", {
      feedbackOptions: [...W],
      feedbackValue: O
    });
  }, C = ({ detail: { isChecked: D, radioText: _ } }) => {
    D ? W.add(_) : W.delete(_);
  }, B = [
    V.playStuck,
    V.progressError,
    V.videoBlack,
    V.soundPictueAsync
  ];
  function I(D) {
    Ei.call(this, A, D);
  }
  function L() {
    O = this.value, R(2, O);
  }
  return A.$$set = (D) => {
    "isShow" in D && R(0, K = D.isShow), "nowLanguage" in D && R(1, V = D.nowLanguage);
  }, [
    K,
    V,
    O,
    p,
    P,
    T,
    k,
    C,
    B,
    I,
    L
  ];
}
class gn extends nt {
  constructor(b) {
    super(), it(this, b, vn, hn, tt, { isShow: 0, nowLanguage: 1 }, cn);
  }
}
function mn(A) {
  rt(A, "svelte-v622af", ".d-icon-feedback.svelte-v622af{position:absolute;width:15px;height:15px;top:20px;right:35px;z-index:2;cursor:pointer}");
}
function pn(A) {
  let b, R, G, K, V, W, O;
  return K = new gn({
    props: {
      nowLanguage: A[0],
      isShow: A[1]
    }
  }), K.$on("closeFeedBack", A[3]), K.$on("feedbackConfirm", A[4]), {
    c() {
      b = re("div"), b.innerHTML = '<svg t="1669096469269" class="icon" viewBox="0 0 1024 1024" version="1.1" xmlns="http://www.w3.org/2000/svg" p-id="5486" width="25" height="25"><path d="M514.048 54.272q95.232 0 178.688 36.352t145.92 98.304 98.304 145.408 35.84 178.688-35.84 178.176-98.304 145.408-145.92 98.304-178.688 35.84-178.176-35.84-145.408-98.304-98.304-145.408-35.84-178.176 35.84-178.688 98.304-145.408 145.408-98.304 178.176-36.352zM515.072 826.368q26.624 0 44.544-17.92t17.92-43.52q0-26.624-17.92-44.544t-44.544-17.92-44.544 17.92-17.92 44.544q0 25.6 17.92 43.52t44.544 17.92zM567.296 574.464q-1.024-16.384 20.48-34.816t48.128-40.96 49.152-50.688 24.576-65.024q2.048-39.936-8.192-74.752t-33.792-59.904-60.928-39.936-87.552-14.848q-62.464 0-103.936 22.016t-67.072 53.248-35.84 64.512-9.216 55.808q1.024 26.624 16.896 38.912t34.304 12.8 33.792-10.24 15.36-31.232q0-12.288 7.68-30.208t20.992-34.304 32.256-27.648 42.496-11.264q46.08 0 73.728 23.04t25.6 57.856q0 17.408-10.24 32.256t-26.112 28.672-33.792 27.648-33.792 28.672-26.624 32.256-11.776 37.888l1.024 38.912q0 15.36 14.336 29.184t37.888 14.848q23.552-1.024 37.376-15.36t12.8-32.768l0-24.576z" p-id="5487" fill="rgba(255,255,255,0.5)"></path></svg>', G = le(), be(K.$$.fragment), Q(b, "class", "d-icon-feedback svelte-v622af");
    },
    m(p, P) {
      de(p, b, P), de(p, G, P), Le(K, p, P), V = !0, W || (O = he(b, "click", wt(A[2])), W = !0);
    },
    p(p, [P]) {
      const T = {};
      P & 1 && (T.nowLanguage = p[0]), P & 2 && (T.isShow = p[1]), K.$set(T);
    },
    i(p) {
      V || (lt(() => {
        R || (R = $e(b, et, {}, !0)), R.run(1);
      }), se(K.$$.fragment, p), V = !0);
    },
    o(p) {
      R || (R = $e(b, et, {}, !1)), R.run(0), ue(K.$$.fragment, p), V = !1;
    },
    d(p) {
      p && fe(b), p && R && R.end(), p && fe(G), Ae(K, p), W = !1, O();
    }
  };
}
function yn(A, b, R) {
  const G = gt();
  let { nowLanguage: K } = b, V = !1;
  const W = () => {
    R(1, V = !0);
  }, O = () => {
    R(1, V = !1);
  }, p = ({ detail: P }) => {
    G("feedbackConfirm", P);
  };
  return A.$$set = (P) => {
    "nowLanguage" in P && R(0, K = P.nowLanguage);
  }, [K, V, W, O, p];
}
class En extends nt {
  constructor(b) {
    super(), it(this, b, yn, pn, tt, { nowLanguage: 0 }, mn);
  }
}
const Tn = [
  "loadstart",
  "durationchange",
  "loadedmetadata",
  "loadeddata",
  "progress",
  "canplay",
  "canplaythrough",
  "play",
  "pause",
  "playing",
  "seeking",
  "seeked",
  "waiting",
  "timeupdate",
  "ended",
  "error",
  "stalled"
];
function _n(A) {
  rt(A, "svelte-uvv227", "div.svelte-uvv227.svelte-uvv227,span.svelte-uvv227.svelte-uvv227,ul.svelte-uvv227.svelte-uvv227,li.svelte-uvv227.svelte-uvv227,video.svelte-uvv227.svelte-uvv227{margin:0;padding:0;border:0;font-size:100%;font:inherit;vertical-align:baseline}ul.svelte-uvv227.svelte-uvv227{list-style:none}.d-fade-in-enter-active.svelte-uvv227.svelte-uvv227,.d-fade-in-leave-active.svelte-uvv227.svelte-uvv227{transition:0.5s}.d-fade-in-enter-from.svelte-uvv227.svelte-uvv227,.d-fade-in-leave-to.svelte-uvv227.svelte-uvv227{opacity:0}.d-scale-out-enter-active.svelte-uvv227.svelte-uvv227,.d-scale-out-leave-active.svelte-uvv227.svelte-uvv227{transition:0.3s}.d-scale-out-leave-to.svelte-uvv227.svelte-uvv227{transform:scale(1.3);opacity:0}.rotateHover.svelte-uvv227.svelte-uvv227{transition:0.2s}.rotateHover.svelte-uvv227.svelte-uvv227:hover{transform:rotate(90deg)}.rotating.svelte-uvv227.svelte-uvv227{animation:svelte-uvv227-rotating 2s linear infinite}@keyframes svelte-uvv227-rotating{100%{-webkit-transform:rotate(360deg)}}.iconfont.svelte-uvv227.svelte-uvv227{display:inline-block}.d-flex-x.svelte-uvv227.svelte-uvv227,.d-flex-y.svelte-uvv227.svelte-uvv227,.d-flex-center.svelte-uvv227.svelte-uvv227{display:flex}.d-flex-x.svelte-uvv227.svelte-uvv227{align-items:center}.d-flex-y.svelte-uvv227.svelte-uvv227{justify-content:center}.d-flex-center.svelte-uvv227.svelte-uvv227{justify-content:center;align-items:center}.mr5.svelte-uvv227.svelte-uvv227{margin-right:5px}.mr10.svelte-uvv227.svelte-uvv227{margin-right:10px}.ml5.svelte-uvv227.svelte-uvv227{margin-left:5px}.ml10.svelte-uvv227.svelte-uvv227{margin-left:10px}.d-pointer.svelte-uvv227.svelte-uvv227{cursor:pointer}.d-player-wrap.svelte-uvv227.svelte-uvv227{position:relative;overflow:hidden;background-color:#000}.d-player-wrap.web-full-screen.svelte-uvv227.svelte-uvv227{z-index:9999999;position:fixed;left:0;top:0;width:100vw !important;height:100vh !important}.d-player-wrap.svelte-uvv227 .d-player-video.svelte-uvv227{position:relative;z-index:1;width:100%;height:100%}.d-player-wrap.svelte-uvv227 .d-player-video .d-player-video-poster.svelte-uvv227{position:absolute;height:100%;width:100%;top:0;left:0}.d-player-wrap.svelte-uvv227 .d-player-video .d-player-video-main.svelte-uvv227{width:100%;height:100%;transition:0.2s}.d-player-wrap.svelte-uvv227 .d-player-video .d-player-video-main.video-mirror.svelte-uvv227{transform:rotateY(180deg)}.d-player-wrap.svelte-uvv227 .d-player-control.svelte-uvv227{transition:0.1s;transform:translateY(45px);position:absolute;z-index:2;left:0;bottom:0;height:50px;width:100%;color:#fff}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress.svelte-uvv227{width:100%;margin:0 auto;position:relative;height:5px;cursor:pointer}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress .d-progress-bar.svelte-uvv227{position:absolute;left:0;right:0;bottom:0;width:100%;transition:height 0.1s;height:3px;z-index:1}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress .d-progress-bar .d-slider__runway.svelte-uvv227{transition:height 0.1s;height:100%}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress .d-progress-bar .d-slider__runway .d-slider__bar.svelte-uvv227::before{transform:translateY(-50%) scale(0, 0)}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress:hover .d-progress-bar.svelte-uvv227{height:100%}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-progress:hover .d-progress-bar .d-slider__bar.svelte-uvv227::before{transform:translateY(-50%) scale(1, 1) !important}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool.svelte-uvv227{position:absolute;padding:0 10px;background-image:linear-gradient(180deg, transparent, rgba(0, 0, 0, 0.37), rgba(0, 0, 0, 0.75), rgba(0, 0, 0, 0.75));display:flex;justify-content:space-between;align-items:center;top:10px;left:0;bottom:0;width:100%;box-sizing:border-box}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-bar.svelte-uvv227{display:flex;height:100%}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-bar .d-tool-item.svelte-uvv227{position:relative;height:100%;cursor:pointer;text-align:center;padding:0 8px;display:flex;align-items:center;font-size:13px}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-bar .d-tool-item .d-tool-item-main.svelte-uvv227{position:absolute;white-space:nowrap;z-index:2;bottom:98%;left:50%;padding:6px 16px;box-sizing:border-box;display:none;background:rgba(0, 0, 0, 0.95);border-radius:5px;transform:translateX(-50%)}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-bar .d-tool-item:hover .d-tool-item-main.svelte-uvv227{display:flex}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-time.svelte-uvv227{font-size:12px;color:#fff;font-weight:300}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .d-tool-time .total-time.svelte-uvv227{color:rgba(255, 255, 255, 0.8)}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .volume-box.svelte-uvv227{height:160px;width:50px;display:flex;align-items:center;justify-content:center}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .volume-box .volume-main.svelte-uvv227{height:90%;display:flex;width:60px;flex-direction:column;align-items:center}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .volume-box .volume-main .volume-text-size.svelte-uvv227{margin-bottom:10px;font-size:12px;font-weight:400}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .volume-box .volume-main.is-muted .d-slider__bar.svelte-uvv227{height:0 !important}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .speed-main.svelte-uvv227{padding:0 10px}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .speed-main li.svelte-uvv227{cursor:pointer;line-height:34px;font-size:12px;color:#fff}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .speed-main li.svelte-uvv227:hover{opacity:0.8}.d-player-wrap.svelte-uvv227 .d-player-control .d-control-tool .speed-main li.speed-active.svelte-uvv227{color:var(--primary-color);font-weight:bold}.d-player-wrap.d-player-wrap-hover.svelte-uvv227 .d-player-control.svelte-uvv227{transform:translateY(0px)}.d-player-wrap.d-player-wrap-hover.svelte-uvv227 .d-control-progress.svelte-uvv227{width:96%}.d-player-state.svelte-uvv227.svelte-uvv227,.d-player-input.svelte-uvv227.svelte-uvv227{position:absolute;left:0;top:0;right:0;bottom:40px;display:flex;justify-content:center;align-items:center;overflow:hidden;z-index:1}.d-player-input.svelte-uvv227.svelte-uvv227{width:100%;border:none;opacity:0;cursor:default}.d-play-btn.svelte-uvv227.svelte-uvv227{width:90px;height:90px;color:#fff;display:flex;align-items:center;justify-content:center;background-color:rgba(0, 0, 0, 0.7);border-radius:50%}.d-player-lightoff.svelte-uvv227.svelte-uvv227{position:fixed;left:0;top:0;width:100vw;height:100vh;background-color:rgba(0, 0, 0, 0.9)}.is-lightoff.svelte-uvv227.svelte-uvv227{z-index:999998}.d-left-0.svelte-uvv227.svelte-uvv227{left:0 !important}.d-player-state-top.svelte-uvv227.svelte-uvv227{position:absolute;left:0;top:0;right:0;bottom:40px px;display:flex;justify-content:center;align-items:flex-start;padding-top:5%;overflow:hidden;z-index:1}");
}
function Lr(A, b, R) {
  const G = A.slice();
  return G[86] = b[R], G;
}
function Ar(A, b, R) {
  const G = A.slice();
  return G[86] = b[R], G[90] = R, G;
}
function br(A) {
  let b, R, G;
  return {
    c() {
      b = re("div"), Q(b, "class", "d-player-lightoff svelte-uvv227");
    },
    m(K, V) {
      de(K, b, V), G = !0;
    },
    i(K) {
      G || (lt(() => {
        R || (R = $e(b, et, {}, !0)), R.run(1);
      }), G = !0);
    },
    o(K) {
      R || (R = $e(b, et, {}, !1)), R.run(0), G = !1;
    },
    d(K) {
      K && fe(b), K && R && R.end();
    }
  };
}
function Pr(A) {
  let b, R;
  return b = new qi({ props: { title: A[4] } }), {
    c() {
      be(b.$$.fragment);
    },
    m(G, K) {
      Le(b, G, K), R = !0;
    },
    p(G, K) {
      const V = {};
      K[0] & 16 && (V.title = G[4]), b.$set(V);
    },
    i(G) {
      R || (se(b.$$.fragment, G), R = !0);
    },
    o(G) {
      ue(b.$$.fragment, G), R = !1;
    },
    d(G) {
      Ae(b, G);
    }
  };
}
function Sn(A) {
  let b, R, G, K, V, W, O, p = A[15].playBtnState === "play" && Ir();
  K = new rn({ props: { state: A[15] } });
  let P = A[15].hasFeedBack && (A[15].playBtnState === "play" || A[15].isVideoHovering) && Rr(A);
  return {
    c() {
      b = re("div"), p && p.c(), R = le(), G = re("div"), be(K.$$.fragment), V = le(), P && P.c(), W = St(), Q(b, "class", "d-player-state svelte-uvv227"), Q(G, "class", "d-player-state-top svelte-uvv227");
    },
    m(T, k) {
      de(T, b, k), p && p.m(b, null), de(T, R, k), de(T, G, k), Le(K, G, null), de(T, V, k), P && P.m(T, k), de(T, W, k), O = !0;
    },
    p(T, k) {
      T[15].playBtnState === "play" ? p ? k[0] & 32768 && se(p, 1) : (p = Ir(), p.c(), se(p, 1), p.m(b, null)) : p && (Ke(), ue(p, 1, 1, () => {
        p = null;
      }), We());
      const C = {};
      k[0] & 32768 && (C.state = T[15]), K.$set(C), T[15].hasFeedBack && (T[15].playBtnState === "play" || T[15].isVideoHovering) ? P ? (P.p(T, k), k[0] & 32768 && se(P, 1)) : (P = Rr(T), P.c(), se(P, 1), P.m(W.parentNode, W)) : P && (Ke(), ue(P, 1, 1, () => {
        P = null;
      }), We());
    },
    i(T) {
      O || (se(p), se(K.$$.fragment, T), se(P), O = !0);
    },
    o(T) {
      ue(p), ue(K.$$.fragment, T), ue(P), O = !1;
    },
    d(T) {
      T && fe(b), p && p.d(), T && fe(R), T && fe(G), Ae(K), T && fe(V), P && P.d(T), T && fe(W);
    }
  };
}
function Ir(A) {
  let b, R, G, K;
  return R = new mt({ props: { icon: "icon-play", size: "30" } }), {
    c() {
      b = re("div"), be(R.$$.fragment), Q(b, "class", "d-play-btn svelte-uvv227");
    },
    m(V, W) {
      de(V, b, W), Le(R, b, null), K = !0;
    },
    i(V) {
      K || (se(R.$$.fragment, V), lt(() => {
        G || (G = $e(b, et, {}, !0)), G.run(1);
      }), K = !0);
    },
    o(V) {
      ue(R.$$.fragment, V), G || (G = $e(b, et, {}, !1)), G.run(0), K = !1;
    },
    d(V) {
      V && fe(b), Ae(R), V && G && G.end();
    }
  };
}
function Rr(A) {
  let b, R;
  return b = new En({
    props: { nowLanguage: A[23] }
  }), b.$on("feedbackConfirm", A[26]), {
    c() {
      be(b.$$.fragment);
    },
    m(G, K) {
      Le(b, G, K), R = !0;
    },
    p: Pe,
    i(G) {
      R || (se(b.$$.fragment, G), R = !0);
    },
    o(G) {
      ue(b.$$.fragment, G), R = !1;
    },
    d(G) {
      Ae(b, G);
    }
  };
}
function xn(A) {
  let b, R, G;
  return {
    c() {
      b = re("input"), Q(b, "type", "input"), b.readOnly = !0, Q(b, "class", "d-player-input svelte-uvv227"), Q(b, "maxlength", "0");
    },
    m(K, V) {
      de(K, b, V), A[60](b), R || (G = [
        he(b, "dblclick", A[61]),
        he(b, "click", A[31]),
        he(b, "keyup", A[28]),
        he(b, "keydown", A[62])
      ], R = !0);
    },
    p: Pe,
    d(K) {
      K && fe(b), A[60](null), R = !1, ot(G);
    }
  };
}
function Cr(A) {
  let b, R = A[8].includes("progress"), G, K, V, W, O, p, P = A[8].includes("progressTime"), T, k, C = A[15].qualityLevels.length && A[8].includes("quality"), B, I = A[8].includes("speedRate"), L, D = A[8].includes("volume"), _, x = A[8].includes("setting"), g, S = A[8].includes("pip") && document.pictureInPictureEnabled, y, l = A[8].includes("pageFullScreen"), u, a = A[8].includes("fullScreen"), s, m, v, i = R && Or(A);
  O = new mt({
    props: {
      size: "24",
      icon: `icon-${A[15].playBtnState}`
    }
  });
  let n = P && Mr(A), E = C && kr(A), r = I && wr(A), o = D && Ur(A), t = x && Nr(A), d = S && Kr(A), e = l && Wr(A), h = a && Gr(A);
  return {
    c() {
      b = re("div"), i && i.c(), G = le(), K = re("div"), V = re("div"), W = re("div"), be(O.$$.fragment), p = le(), n && n.c(), T = le(), k = re("div"), E && E.c(), B = le(), r && r.c(), L = le(), o && o.c(), _ = le(), t && t.c(), g = le(), d && d.c(), y = le(), e && e.c(), u = le(), h && h.c(), Q(W, "class", "d-tool-item svelte-uvv227"), Q(V, "class", "d-tool-bar svelte-uvv227"), Q(k, "class", "d-tool-bar svelte-uvv227"), Q(K, "class", "d-control-tool svelte-uvv227"), Q(b, "class", "d-player-control svelte-uvv227");
    },
    m(f, c) {
      de(f, b, c), i && i.m(b, null), J(b, G), J(b, K), J(K, V), J(V, W), Le(O, W, null), J(V, p), n && n.m(V, null), J(K, T), J(K, k), E && E.m(k, null), J(k, B), r && r.m(k, null), J(k, L), o && o.m(k, null), J(k, _), t && t.m(k, null), J(k, g), d && d.m(k, null), J(k, y), e && e.m(k, null), J(k, u), h && h.m(k, null), A[72](b), s = !0, m || (v = [
        he(W, "click", A[31]),
        he(K, "click", A[29])
      ], m = !0);
    },
    p(f, c) {
      c[0] & 256 && (R = f[8].includes("progress")), R ? i ? (i.p(f, c), c[0] & 256 && se(i, 1)) : (i = Or(f), i.c(), se(i, 1), i.m(b, G)) : i && (Ke(), ue(i, 1, 1, () => {
        i = null;
      }), We());
      const M = {};
      c[0] & 32768 && (M.icon = `icon-${f[15].playBtnState}`), O.$set(M), c[0] & 256 && (P = f[8].includes("progressTime")), P ? n ? n.p(f, c) : (n = Mr(f), n.c(), n.m(V, null)) : n && (n.d(1), n = null), c[0] & 33024 && (C = f[15].qualityLevels.length && f[8].includes("quality")), C ? E ? E.p(f, c) : (E = kr(f), E.c(), E.m(k, B)) : E && (E.d(1), E = null), c[0] & 256 && (I = f[8].includes("speedRate")), I ? r ? r.p(f, c) : (r = wr(f), r.c(), r.m(k, L)) : r && (r.d(1), r = null), c[0] & 256 && (D = f[8].includes("volume")), D ? o ? (o.p(f, c), c[0] & 256 && se(o, 1)) : (o = Ur(f), o.c(), se(o, 1), o.m(k, _)) : o && (Ke(), ue(o, 1, 1, () => {
        o = null;
      }), We()), c[0] & 256 && (x = f[8].includes("setting")), x ? t ? (t.p(f, c), c[0] & 256 && se(t, 1)) : (t = Nr(f), t.c(), se(t, 1), t.m(k, g)) : t && (Ke(), ue(t, 1, 1, () => {
        t = null;
      }), We()), c[0] & 256 && (S = f[8].includes("pip") && document.pictureInPictureEnabled), S ? d ? (d.p(f, c), c[0] & 256 && se(d, 1)) : (d = Kr(f), d.c(), se(d, 1), d.m(k, y)) : d && (Ke(), ue(d, 1, 1, () => {
        d = null;
      }), We()), c[0] & 256 && (l = f[8].includes("pageFullScreen")), l ? e ? (e.p(f, c), c[0] & 256 && se(e, 1)) : (e = Wr(f), e.c(), se(e, 1), e.m(k, u)) : e && (Ke(), ue(e, 1, 1, () => {
        e = null;
      }), We()), c[0] & 256 && (a = f[8].includes("fullScreen")), a ? h ? (h.p(f, c), c[0] & 256 && se(h, 1)) : (h = Gr(f), h.c(), se(h, 1), h.m(k, null)) : h && (Ke(), ue(h, 1, 1, () => {
        h = null;
      }), We());
    },
    i(f) {
      s || (se(i), se(O.$$.fragment, f), se(o), se(t), se(d), se(e), se(h), s = !0);
    },
    o(f) {
      ue(i), ue(O.$$.fragment, f), ue(o), ue(t), ue(d), ue(e), ue(h), s = !1;
    },
    d(f) {
      f && fe(b), i && i.d(), Ae(O), n && n.d(), E && E.d(), r && r.d(), o && o.d(), t && t.d(), d && d.d(), e && e.d(), h && h.d(), A[72](null), m = !1, ot(v);
    }
  };
}
function Or(A) {
  let b, R, G;
  return R = new Lt({
    props: {
      className: "d-progress-bar",
      disabled: !A[15].canSpeed,
      hoverText: A[15].progressCursorTime,
      modelValue: A[15].playProgress,
      preload: A[15].preloadBar
    }
  }), R.$on("onMousemove", A[34]), R.$on("change", A[33]), R.$on("update", A[63]), R.$on("speedDisabled", A[27]), {
    c() {
      b = re("div"), be(R.$$.fragment), Q(b, "class", "d-control-progress svelte-uvv227");
    },
    m(K, V) {
      de(K, b, V), Le(R, b, null), G = !0;
    },
    p(K, V) {
      const W = {};
      V[0] & 32768 && (W.disabled = !K[15].canSpeed), V[0] & 32768 && (W.hoverText = K[15].progressCursorTime), V[0] & 32768 && (W.modelValue = K[15].playProgress), V[0] & 32768 && (W.preload = K[15].preloadBar), R.$set(W);
    },
    i(K) {
      G || (se(R.$$.fragment, K), G = !0);
    },
    o(K) {
      ue(R.$$.fragment, K), G = !1;
    },
    d(K) {
      K && fe(b), Ae(R);
    }
  };
}
function Mr(A) {
  let b, R, G = A[15].currentTime + "", K, V, W, O, p, P = A[15].totalTime + "", T;
  return {
    c() {
      b = re("div"), R = re("span"), K = ve(G), V = le(), W = re("span"), W.textContent = "/", O = le(), p = re("span"), T = ve(P), Q(R, "class", "svelte-uvv227"), Mt(W, "margin", "0 3px"), Q(W, "class", "svelte-uvv227"), Q(p, "class", "total-time svelte-uvv227"), Q(b, "class", "d-tool-item d-tool-time audioTrack-btn svelte-uvv227");
    },
    m(k, C) {
      de(k, b, C), J(b, R), J(R, K), J(b, V), J(b, W), J(b, O), J(b, p), J(p, T);
    },
    p(k, C) {
      C[0] & 32768 && G !== (G = k[15].currentTime + "") && De(K, G), C[0] & 32768 && P !== (P = k[15].totalTime + "") && De(T, P);
    },
    d(k) {
      k && fe(b);
    }
  };
}
function kr(A) {
  let b, R = (A[15].qualityLevels.length && (A[15].qualityLevels[A[15].currentLevel] || {}).height) + "", G, K, V, W, O = A[15].qualityLevels, p = [];
  for (let P = 0; P < O.length; P += 1)
    p[P] = Fr(Ar(A, O, P));
  return {
    c() {
      b = re("div"), G = ve(R), K = ve(`P
              `), V = re("div"), W = re("ul");
      for (let P = 0; P < p.length; P += 1)
        p[P].c();
      Q(W, "class", "speed-main svelte-uvv227"), Mt(W, "text-align", "center"), Q(V, "class", "d-tool-item-main svelte-uvv227"), Q(b, "class", "d-tool-item quality-btn svelte-uvv227");
    },
    m(P, T) {
      de(P, b, T), J(b, G), J(b, K), J(b, V), J(V, W);
      for (let k = 0; k < p.length; k += 1)
        p[k].m(W, null);
    },
    p(P, T) {
      if (T[0] & 32768 && R !== (R = (P[15].qualityLevels.length && (P[15].qualityLevels[P[15].currentLevel] || {}).height) + "") && De(G, R), T[0] & 32768 | T[1] & 32) {
        O = P[15].qualityLevels;
        let k;
        for (k = 0; k < O.length; k += 1) {
          const C = Ar(P, O, k);
          p[k] ? p[k].p(C, T) : (p[k] = Fr(C), p[k].c(), p[k].m(W, null));
        }
        for (; k < p.length; k += 1)
          p[k].d(1);
        p.length = O.length;
      }
    },
    d(P) {
      P && fe(b), bt(p, P);
    }
  };
}
function Fr(A) {
  let b, R = A[86].height + "", G, K, V, W, O;
  function p() {
    return A[64](A[86], A[90]);
  }
  return {
    c() {
      b = re("li"), G = ve(R), K = ve(`P
                    `), Q(b, "class", V = Fe(A[15].currentLevel == A[90] ? "speed-active" : "") + " svelte-uvv227");
    },
    m(P, T) {
      de(P, b, T), J(b, G), J(b, K), W || (O = he(b, "click", p), W = !0);
    },
    p(P, T) {
      A = P, T[0] & 32768 && R !== (R = A[86].height + "") && De(G, R), T[0] & 32768 && V !== (V = Fe(A[15].currentLevel == A[90] ? "speed-active" : "") + " svelte-uvv227") && Q(b, "class", V);
    },
    d(P) {
      P && fe(b), W = !1, O();
    }
  };
}
function wr(A) {
  let b, R = (A[15].speedActive == "1.0" ? A[23].speed : A[15].speedActive + "x") + "", G, K, V, W, O = A[15].speedRate, p = [];
  for (let P = 0; P < O.length; P += 1)
    p[P] = Br(Lr(A, O, P));
  return {
    c() {
      b = re("div"), G = ve(R), K = le(), V = re("div"), W = re("ul");
      for (let P = 0; P < p.length; P += 1)
        p[P].c();
      Q(W, "class", "speed-main svelte-uvv227"), Q(V, "class", "d-tool-item-main svelte-uvv227"), Q(b, "class", "d-tool-item speedRate-btn svelte-uvv227");
    },
    m(P, T) {
      de(P, b, T), J(b, G), J(b, K), J(b, V), J(V, W);
      for (let k = 0; k < p.length; k += 1)
        p[k].m(W, null);
    },
    p(P, T) {
      if (T[0] & 32768 && R !== (R = (P[15].speedActive == "1.0" ? P[23].speed : P[15].speedActive + "x") + "") && De(G, R), T[0] & 32768 | T[1] & 64) {
        O = P[15].speedRate;
        let k;
        for (k = 0; k < O.length; k += 1) {
          const C = Lr(P, O, k);
          p[k] ? p[k].p(C, T) : (p[k] = Br(C), p[k].c(), p[k].m(W, null));
        }
        for (; k < p.length; k += 1)
          p[k].d(1);
        p.length = O.length;
      }
    },
    d(P) {
      P && fe(b), bt(p, P);
    }
  };
}
function Br(A) {
  let b, R = A[86] + "", G, K, V, W, O;
  function p() {
    return A[65](A[86]);
  }
  return {
    c() {
      b = re("li"), G = ve(R), K = ve(`x
                    `), Q(b, "class", V = Fe(A[15].speedActive == A[86] ? "speed-active" : "") + " svelte-uvv227");
    },
    m(P, T) {
      de(P, b, T), J(b, G), J(b, K), W || (O = he(b, "click", p), W = !0);
    },
    p(P, T) {
      A = P, T[0] & 32768 && R !== (R = A[86] + "") && De(G, R), T[0] & 32768 && V !== (V = Fe(A[15].speedActive == A[86] ? "speed-active" : "") + " svelte-uvv227") && Q(b, "class", V);
    },
    d(P) {
      P && fe(b), W = !1, O();
    }
  };
}
function Ur(A) {
  let b, R, G, K, V = (A[15].muted ? 0 : ~~(A[15].volume * 100)) + "", W, O, p, P, T, k, C, B, I, L, D;
  return P = new Lt({
    props: {
      hover: !1,
      size: "5px",
      vertical: !0,
      modelValue: A[15].volume
    }
  }), P.$on("change", A[66]), P.$on("update", A[67]), B = new mt({
    props: {
      size: "20",
      icon: `icon-volume-${A[15].volume == 0 || A[15].muted ? "mute" : A[15].volume > 0.5 ? "up" : "down"}`
    }
  }), {
    c() {
      b = re("div"), R = re("div"), G = re("div"), K = re("span"), W = ve(V), O = ve("%"), p = le(), be(P.$$.fragment), k = le(), C = re("span"), be(B.$$.fragment), Q(K, "class", "volume-text-size svelte-uvv227"), Q(G, "class", T = Fe(`${A[15].muted ? "is-muted" : ""} volume-main`) + " svelte-uvv227"), Q(R, "class", "d-tool-item-main volume-box svelte-uvv227"), Mt(R, "width", "52px"), Mt(C, "display", "flex"), Q(C, "class", "svelte-uvv227"), Q(b, "class", "d-tool-item volume-btn svelte-uvv227");
    },
    m(_, x) {
      de(_, b, x), J(b, R), J(R, G), J(G, K), J(K, W), J(K, O), J(G, p), Le(P, G, null), J(b, k), J(b, C), Le(B, C, null), I = !0, L || (D = he(C, "click", A[32]), L = !0);
    },
    p(_, x) {
      (!I || x[0] & 32768) && V !== (V = (_[15].muted ? 0 : ~~(_[15].volume * 100)) + "") && De(W, V);
      const g = {};
      x[0] & 32768 && (g.modelValue = _[15].volume), P.$set(g), (!I || x[0] & 32768 && T !== (T = Fe(`${_[15].muted ? "is-muted" : ""} volume-main`) + " svelte-uvv227")) && Q(G, "class", T);
      const S = {};
      x[0] & 32768 && (S.icon = `icon-volume-${_[15].volume == 0 || _[15].muted ? "mute" : _[15].volume > 0.5 ? "up" : "down"}`), B.$set(S);
    },
    i(_) {
      I || (se(P.$$.fragment, _), se(B.$$.fragment, _), I = !0);
    },
    o(_) {
      ue(P.$$.fragment, _), ue(B.$$.fragment, _), I = !1;
    },
    d(_) {
      _ && fe(b), Ae(P), Ae(B), L = !1, D();
    }
  };
}
function Nr(A) {
  let b, R, G, K, V, W, O = A[23].mirror + "", p, P, T, k, C, B = A[23].loop + "", I, L, D, _, x, g = A[23].lightOff + "", S, y, l, u;
  return R = new mt({
    props: {
      size: "20",
      className: "rotateHover",
      icon: "icon-settings"
    }
  }), T = new Gt({
    props: { modelValue: A[15].mirror }
  }), T.$on("change", A[38]), T.$on("update", A[68]), D = new Gt({
    props: { modelValue: A[15].loop }
  }), D.$on("change", A[39]), D.$on("update", A[69]), l = new Gt({
    props: { modelValue: A[15].lightOff }
  }), l.$on("change", A[40]), l.$on("update", A[70]), {
    c() {
      b = re("div"), be(R.$$.fragment), G = le(), K = re("div"), V = re("ul"), W = re("li"), p = ve(O), P = le(), be(T.$$.fragment), k = le(), C = re("li"), I = ve(B), L = le(), be(D.$$.fragment), _ = le(), x = re("li"), S = ve(g), y = le(), be(l.$$.fragment), Q(W, "class", "svelte-uvv227"), Q(C, "class", "svelte-uvv227"), Q(x, "class", "svelte-uvv227"), Q(V, "class", "speed-main svelte-uvv227"), Q(K, "class", "d-tool-item-main svelte-uvv227"), Q(b, "class", "d-tool-item setting-btn svelte-uvv227");
    },
    m(a, s) {
      de(a, b, s), Le(R, b, null), J(b, G), J(b, K), J(K, V), J(V, W), J(W, p), J(W, P), Le(T, W, null), J(V, k), J(V, C), J(C, I), J(C, L), Le(D, C, null), J(V, _), J(V, x), J(x, S), J(x, y), Le(l, x, null), u = !0;
    },
    p(a, s) {
      const m = {};
      s[0] & 32768 && (m.modelValue = a[15].mirror), T.$set(m);
      const v = {};
      s[0] & 32768 && (v.modelValue = a[15].loop), D.$set(v);
      const i = {};
      s[0] & 32768 && (i.modelValue = a[15].lightOff), l.$set(i);
    },
    i(a) {
      u || (se(R.$$.fragment, a), se(T.$$.fragment, a), se(D.$$.fragment, a), se(l.$$.fragment, a), u = !0);
    },
    o(a) {
      ue(R.$$.fragment, a), ue(T.$$.fragment, a), ue(D.$$.fragment, a), ue(l.$$.fragment, a), u = !1;
    },
    d(a) {
      a && fe(b), Ae(R), Ae(T), Ae(D), Ae(l);
    }
  };
}
function Kr(A) {
  let b, R, G, K, V, W, O;
  return R = new mt({ props: { size: "20", icon: "icon-pip" } }), {
    c() {
      b = re("div"), be(R.$$.fragment), G = le(), K = re("div"), K.textContent = `${A[23].pictureInPicture}`, Q(K, "class", "d-tool-item-main svelte-uvv227"), Q(b, "class", "d-tool-item pip-btn svelte-uvv227");
    },
    m(p, P) {
      de(p, b, P), Le(R, b, null), J(b, G), J(b, K), V = !0, W || (O = he(b, "click", A[41]), W = !0);
    },
    p: Pe,
    i(p) {
      V || (se(R.$$.fragment, p), V = !0);
    },
    o(p) {
      ue(R.$$.fragment, p), V = !1;
    },
    d(p) {
      p && fe(b), Ae(R), W = !1, O();
    }
  };
}
function Wr(A) {
  let b, R, G, K, V, W, O, p, P;
  return R = new mt({
    props: { size: "20", icon: "icon-web-screen" }
  }), {
    c() {
      b = re("div"), be(R.$$.fragment), G = le(), K = re("div"), V = ve(A[22]), Q(K, "class", W = Fe(`d-tool-item-main  ${A[8].includes("fullScreen") ? "" : "d-left-0"}`) + " svelte-uvv227"), Q(b, "class", "d-tool-item pip-btn svelte-uvv227");
    },
    m(T, k) {
      de(T, b, k), Le(R, b, null), J(b, G), J(b, K), J(K, V), O = !0, p || (P = he(b, "click", A[71]), p = !0);
    },
    p(T, k) {
      (!O || k[0] & 4194304) && De(V, T[22]), (!O || k[0] & 256 && W !== (W = Fe(`d-tool-item-main  ${T[8].includes("fullScreen") ? "" : "d-left-0"}`) + " svelte-uvv227")) && Q(K, "class", W);
    },
    i(T) {
      O || (se(R.$$.fragment, T), O = !0);
    },
    o(T) {
      ue(R.$$.fragment, T), O = !1;
    },
    d(T) {
      T && fe(b), Ae(R), p = !1, P();
    }
  };
}
function Gr(A) {
  let b, R, G, K, V, W, O, p, P;
  return W = new mt({
    props: { size: "20", icon: "icon-screen" }
  }), {
    c() {
      b = re("div"), R = re("div"), G = ve(A[21]), V = le(), be(W.$$.fragment), Q(R, "class", K = Fe(`d-tool-item-main ${A[15].fullScreen || A[0] === "en" ? "d-left-0" : ""}`) + " svelte-uvv227"), Q(b, "class", "d-tool-item fullScreen-btn svelte-uvv227");
    },
    m(T, k) {
      de(T, b, k), J(b, R), J(R, G), J(b, V), Le(W, b, null), O = !0, p || (P = he(b, "click", A[42]), p = !0);
    },
    p(T, k) {
      (!O || k[0] & 2097152) && De(G, T[21]), (!O || k[0] & 32769 && K !== (K = Fe(`d-tool-item-main ${T[15].fullScreen || T[0] === "en" ? "d-left-0" : ""}`) + " svelte-uvv227")) && Q(R, "class", K);
    },
    i(T) {
      O || (se(W.$$.fragment, T), O = !0);
    },
    o(T) {
      ue(W.$$.fragment, T), O = !1;
    },
    d(T) {
      T && fe(b), Ae(W), p = !1, P();
    }
  };
}
function Dn(A) {
  let b, R, G, K, V, W, O, p, P, T, k, C, B, I, L, D, _, x, g, S, y, l, u, a = A[15].lightOff && br(), s = A[15].fullScreen && A[4] && Pr(A), m = !ft && Sn(A), v = !ft && xn(A);
  L = new Xi({
    props: {
      nowLanguage: A[23],
      loadingText: A[14],
      loadType: A[15].loadStateType,
      loadingDom: A[12],
      loadingImg: A[11],
      loadingType: A[13]
    }
  }), L.$on("playHandle", A[30]), _ = new Ki({
    props: {
      contextMenu: A[10],
      nowLanguage: A[23],
      version: Ln
    }
  });
  let i = !ft && A[7] && Cr(A);
  return {
    c() {
      a && a.c(), b = le(), R = re("div"), G = re("div"), K = re("video"), V = ve("\u60A8\u7684\u6D4F\u89C8\u5668\u4E0D\u652F\u6301Video\u6807\u7B7E\u3002"), k = le(), s && s.c(), C = le(), m && m.c(), B = le(), v && v.c(), I = le(), be(L.$$.fragment), D = le(), be(_.$$.fragment), x = le(), i && i.c(), Q(K, "class", W = Fe(`${A[15].mirror ? "video-mirror" : ""} d-player-video-main`) + " svelte-uvv227"), Q(K, "id", "dPlayerVideoMain"), K.controls = O = ft && A[15].canSpeed, K.muted = p = A[15].muted, K.loop = P = A[15].loop, K.playsInline = A[6], Ot(K.src, T = A[3]) || Q(K, "src", T), Q(K, "poster", A[5]), Q(K, "preload", A[9]), Q(K, "webkit-playsinline", A[6]), Q(K, "width", "100%"), Q(K, "height", "100%"), Q(G, "id", "dPlayerVideo"), Q(G, "class", "d-player-video svelte-uvv227"), Q(R, "id", "refPlayerWrap"), Q(R, "style", g = `width:${A[1]};height:${A[2]};--primary-color:rgb(${A[24]});--primary-color-end:rgb(${A[25]})`), Q(R, "class", S = Fe(`d-player-wrap ${A[15].webFullScreen ? "web-full-screen" : ""} ${A[15].lightOff ? "is-lightoff" : ""} ${A[15].playBtnState === "play" || A[15].isVideoHovering ? "d-player-wrap-hover" : ""}`) + " svelte-uvv227");
    },
    m(n, E) {
      a && a.m(n, E), de(n, b, E), de(n, R, E), J(R, G), J(G, K), J(K, V), A[58](K), isNaN(A[15].volume) || (K.volume = A[15].volume), J(R, k), s && s.m(R, null), J(R, C), m && m.m(R, null), J(R, B), v && v.m(R, null), J(R, I), Le(L, R, null), J(R, D), Le(_, R, null), J(R, x), i && i.m(R, null), A[73](R), y = !0, l || (u = [
        he(K, "volumechange", A[59]),
        he(K, "loadstart", function() {
          ke(A[20].loadstart) && A[20].loadstart.apply(this, arguments);
        }),
        he(K, "durationchange", function() {
          ke(A[20].durationchange) && A[20].durationchange.apply(this, arguments);
        }),
        he(K, "loadedmetadata", function() {
          ke(A[20].loadedmetadata) && A[20].loadedmetadata.apply(this, arguments);
        }),
        he(K, "loadeddata", function() {
          ke(A[20].loadeddata) && A[20].loadeddata.apply(this, arguments);
        }),
        he(K, "progress", function() {
          ke(A[20].progress) && A[20].progress.apply(this, arguments);
        }),
        he(K, "canplay", function() {
          ke(A[20].canplay) && A[20].canplay.apply(this, arguments);
        }),
        he(K, "canplaythrough", function() {
          ke(A[20].canplaythrough) && A[20].canplaythrough.apply(this, arguments);
        }),
        he(K, "ended", function() {
          ke(A[20].ended) && A[20].ended.apply(this, arguments);
        }),
        he(K, "error", function() {
          ke(A[20].error) && A[20].error.apply(this, arguments);
        }),
        he(K, "pause", function() {
          ke(A[20].pause) && A[20].pause.apply(this, arguments);
        }),
        he(K, "play", function() {
          ke(A[20].play) && A[20].play.apply(this, arguments);
        }),
        he(K, "playing", function() {
          ke(A[20].playing) && A[20].playing.apply(this, arguments);
        }),
        he(K, "seeked", function() {
          ke(A[20].seeked) && A[20].seeked.apply(this, arguments);
        }),
        he(K, "seeking", function() {
          ke(A[20].seeking) && A[20].seeking.apply(this, arguments);
        }),
        he(K, "stalled", function() {
          ke(A[20].stalled) && A[20].stalled.apply(this, arguments);
        }),
        he(K, "timeupdate", function() {
          ke(A[20].timeupdate) && A[20].timeupdate.apply(this, arguments);
        }),
        he(K, "waiting", function() {
          ke(A[20].waiting) && A[20].waiting.apply(this, arguments);
        }),
        he(R, "mousemove", A[35])
      ], l = !0);
    },
    p(n, E) {
      A = n, A[15].lightOff ? a ? E[0] & 32768 && se(a, 1) : (a = br(), a.c(), se(a, 1), a.m(b.parentNode, b)) : a && (Ke(), ue(a, 1, 1, () => {
        a = null;
      }), We()), (!y || E[0] & 32768 && W !== (W = Fe(`${A[15].mirror ? "video-mirror" : ""} d-player-video-main`) + " svelte-uvv227")) && Q(K, "class", W), (!y || E[0] & 32768 && O !== (O = ft && A[15].canSpeed)) && (K.controls = O), (!y || E[0] & 32768 && p !== (p = A[15].muted)) && (K.muted = p), (!y || E[0] & 32768 && P !== (P = A[15].loop)) && (K.loop = P), (!y || E[0] & 64) && (K.playsInline = A[6]), (!y || E[0] & 8 && !Ot(K.src, T = A[3])) && Q(K, "src", T), (!y || E[0] & 32) && Q(K, "poster", A[5]), (!y || E[0] & 512) && Q(K, "preload", A[9]), (!y || E[0] & 64) && Q(K, "webkit-playsinline", A[6]), E[0] & 32768 && !isNaN(A[15].volume) && (K.volume = A[15].volume), A[15].fullScreen && A[4] ? s ? (s.p(A, E), E[0] & 32784 && se(s, 1)) : (s = Pr(A), s.c(), se(s, 1), s.m(R, C)) : s && (Ke(), ue(s, 1, 1, () => {
        s = null;
      }), We()), ft || m.p(A, E), ft || v.p(A, E);
      const r = {};
      E[0] & 16384 && (r.loadingText = A[14]), E[0] & 32768 && (r.loadType = A[15].loadStateType), E[0] & 4096 && (r.loadingDom = A[12]), E[0] & 2048 && (r.loadingImg = A[11]), E[0] & 8192 && (r.loadingType = A[13]), L.$set(r);
      const o = {};
      E[0] & 1024 && (o.contextMenu = A[10]), _.$set(o), !ft && A[7] ? i ? (i.p(A, E), E[0] & 128 && se(i, 1)) : (i = Cr(A), i.c(), se(i, 1), i.m(R, null)) : i && (Ke(), ue(i, 1, 1, () => {
        i = null;
      }), We()), (!y || E[0] & 6 && g !== (g = `width:${A[1]};height:${A[2]};--primary-color:rgb(${A[24]});--primary-color-end:rgb(${A[25]})`)) && Q(R, "style", g), (!y || E[0] & 32768 && S !== (S = Fe(`d-player-wrap ${A[15].webFullScreen ? "web-full-screen" : ""} ${A[15].lightOff ? "is-lightoff" : ""} ${A[15].playBtnState === "play" || A[15].isVideoHovering ? "d-player-wrap-hover" : ""}`) + " svelte-uvv227")) && Q(R, "class", S);
    },
    i(n) {
      y || (se(a), se(s), se(m), se(L.$$.fragment, n), se(_.$$.fragment, n), se(i), y = !0);
    },
    o(n) {
      ue(a), ue(s), ue(m), ue(L.$$.fragment, n), ue(_.$$.fragment, n), ue(i), y = !1;
    },
    d(n) {
      a && a.d(n), n && fe(b), n && fe(R), A[58](null), s && s.d(), m && m.d(), v && v.d(), Ae(L), Ae(_), i && i.d(), A[73](null), l = !1, ot(u);
    }
  };
}
const Ln = "1.0.0";
function An(A, b, R) {
  let G, K;
  bi();
  const V = gt();
  let { languageType: W = "zh-cn" } = b;
  const O = sr[W] || sr["zh-cn"];
  let { width: p = "800px" } = b, { height: P = "450px" } = b, { color: T = "#E93030" } = b, { colorEnd: k = "#F06F6F" } = b, { src: C = "" } = b, { title: B = "" } = b, { type: I = "video/mp4" } = b, { poster: L = "" } = b, { webFullScreen: D = !1 } = b, { canSpeed: _ = !0 } = b, { currentTime: x = 0 } = b, { playsinline: g = !1 } = b, { muted: S = !1 } = b, { speedRate: y = ["2.0", "1.5", "1.25", "1.0", "0.75", "0.5"] } = b, { autoPlay: l = !1 } = b, { loop: u = !1 } = b, { mirror: a = !1 } = b, { lightOff: s = !1 } = b, { volume: m = 1 } = b, { control: v = !0 } = b, { controlBtns: i = [
    "progress",
    "progressTime",
    "quality",
    "speedRate",
    "volume",
    "setting",
    "pip",
    "pageFullScreen",
    "fullScreen"
  ] } = b, { preload: n = "auto" } = b, { qualityLevels: E = [] } = b, { contextMenu: r = ["filter", "hotkey", "copy", "version"] } = b, { loadingImg: o = "" } = b, { loadingDom: t = "" } = b, { loadingType: d = "" } = b, { loadingText: e = O.loading } = b, { hasFeedBack: h = !1 } = b;
  const f = {
    width: p,
    height: P,
    color: T,
    colorEnd: k,
    src: C,
    title: B,
    type: I,
    poster: L,
    webFullScreen: D,
    canSpeed: _,
    playsinline: g,
    muted: S,
    speedRate: y,
    autoPlay: l,
    loop: u,
    mirror: a,
    lightOff: s,
    volume: m,
    control: v,
    controlBtns: i,
    preload: n,
    qualityLevels: E,
    hasFeedBack: h,
    isShowFeedBack: !1,
    currentTime: "",
    dVideo: null,
    playBtnState: l ? "pause" : "play",
    loadStateType: "loadstart",
    fullScreen: !1,
    handleType: "",
    preloadBar: 0,
    totalTime: "00:00:00",
    isVideoHovering: !0,
    speedActive: "1.0",
    playProgress: 0,
    isMultiplesPlay: !1,
    longPressTimeout: null,
    progressCursorTime: "00:00:00",
    currentLevel: 0
  };
  let c, M, w, F, U;
  const N = nr(f.color), H = nr(f.colorEnd), j = ({ detail: q }) => {
    V("feedbackConfirm", q);
  }, z = ({ detail: q }) => {
    V("speedDisabled", q);
  }, Y = ir(500, () => {
    R(15, f.handleType = "", f);
  }), X = (q) => {
    q.preventDefault(), q.code == "ArrowUp" ? R(15, f.volume = f.volume + 0.1 > 1 ? 1 : f.volume + 0.1, f) : R(15, f.volume = f.volume - 0.1 < 0 ? 0 : f.volume - 0.1, f), R(15, f.muted = !1, f), R(15, f.handleType = "volume", f), Y();
  }, Z = (q) => {
    !_ || (R(
      15,
      f.dVideo.currentTime = f.dVideo.currentTime < 10 ? 0.1 : f.dVideo.currentTime - 10,
      f
    ), ye.timeupdate(f.dVideo), ne());
  }, te = (q, ge) => {
    q.preventDefault();
    const Ne = q.type;
    if (q.keyCode === 39) {
      if (ne(), Ne === "keyup") {
        if (clearTimeout(f.longPressTimeout), !_ && !f.longPressTimeout)
          return;
        f.isMultiplesPlay ? (R(15, f.dVideo.playbackRate = +f.speedActive, f), R(15, f.isMultiplesPlay = !1, f)) : (R(15, f.dVideo.currentTime = f.dVideo.currentTime + 10, f), ye.timeupdate(f.dVideo));
      } else if (Ne === "keydown") {
        if (!_)
          return;
        f.isMultiplesPlay && clearTimeout(f.longPressTimeout), R(
          15,
          f.longPressTimeout = window.setTimeout(
            () => {
              R(15, f.isMultiplesPlay = !0, f), R(15, f.dVideo.playbackRate = 5, f), R(15, f.handleType = "playbackRate", f), Y();
            },
            500
          ),
          f
        );
      }
    }
    if (ge === "keydown") {
      switch (q.keyCode) {
        case 32:
          ae(q);
          break;
        case 70:
          i.includes("fullScreen") && Me();
          break;
        case 37:
          Z();
          break;
        case 38:
          X(q);
          break;
        case 40:
          X(q);
          break;
      }
      Y();
    }
  }, $ = () => {
    ft || U.focus();
  }, ee = (q) => {
    const { code: ge, message: Ne, name: Je } = q;
    Ne.includes("play() failed because the user didn't interact with the document first") && ge === 0 && Je === "NotAllowedError" ? (R(15, f.muted = !0, f), Vt().then(() => {
      ne();
    })) : setTimeout(
      () => {
        R(15, f.playBtnState = "replay", f), R(15, f.loadStateType = "error", f);
      },
      500
    );
  }, ne = () => {
    R(15, f.loadStateType = "play", f);
    const q = f.dVideo.play();
    q && q.catch((ge) => {
      ee(ge);
    }), R(15, f.playBtnState = "pause", f);
  }, oe = () => {
    R(15, f.loadStateType = "pause", f), f.dVideo.pause(), R(15, f.playBtnState = "play", f);
  }, ae = (q) => {
    q && q.preventDefault(), f.playBtnState == "play" || f.playBtnState == "replay" ? ne() : f.playBtnState == "pause" && oe();
  }, ie = () => {
    R(15, f.muted = !f.muted, f), f.volume === 0 && R(15, f.volume = 0.05, f);
  }, ce = ({ detail: { ev: q, value: ge } }) => {
    var Je, ze;
    const Ne = f.dVideo.duration || ((ze = (Je = f == null ? void 0 : f.dVideo) == null ? void 0 : Je.target) == null ? void 0 : ze.duration);
    R(15, f.dVideo.currentTime = Ne * ge, f), f.playBtnState === "play" && ne();
  }, me = ({ detail: { ev: q, val: ge } }) => {
    R(15, f.progressCursorTime = Wt(f.dVideo.duration * ge), f);
  }, pe = ir(2500, () => {
    R(15, f.isVideoHovering = !1, f);
  }), Ie = (q) => {
    R(15, f.isVideoHovering = !0, f), pe();
  }, Ee = (q, ge) => {
    c && (c.currentLevel = ge), R(15, f.currentLevel = ge, f);
  }, _e = (q) => {
    R(15, f.speedActive = q, f), R(15, f.dVideo.playbackRate = +q, f);
  }, Te = (q) => {
    V("mirrorChange", {
      mirrorStatus: q.detail,
      videoDom: f.dVideo
    });
  }, Se = (q) => {
    V("loopChange", {
      loopStatus: q.detail,
      videoDom: f.dVideo
    });
  }, xe = (q) => {
    V("lightOffChange", {
      lightOffStatus: q.detail,
      videoDom: f.dVideo
    });
  }, Re = () => {
    document.exitPictureInPicture();
  }, we = () => {
    f.dVideo.requestPictureInPicture();
  }, Ce = () => {
    document.pictureInPictureElement ? Re() : we();
  }, Me = () => {
    R(15, f.fullScreen = Ai(M), f);
  }, Ge = (...q) => (ge) => q.reverse().reduce(
    (Ne, Je) => {
      if (Je)
        return Je(Ne);
    },
    ge
  ), ye = Tn.reduce(
    (q, ge) => (q[ge] = (Ne) => {
      ["stalled", "error"].includes(ge) && R(15, f.playBtnState = "replay", f), R(15, f.loadStateType = ge, f), ["canplay", "durationchange", "progress", "timeupdate"].includes(ge) || V(ge, {
        currentTime: f.dVideo.currentTime,
        duration: f.dVideo.duration
      });
    }, q),
    {}
  );
  ye.canplay = Ge(ye.canplay, (q) => {
    (f.playBtnState !== "play" || f.autoPlay) && ne(), V("canplay", {
      videoDom: f.dVideo,
      duration: f.dVideo.duration
    });
  }), ye.ended = Ge(ye.ended, (q) => {
    R(15, f.playBtnState = "replay", f);
  }), ye.durationchange = (q) => {
    V("durationchange", { duration: f.dVideo.duration }), x !== 0 && R(15, f.dVideo.currentTime = x, f), ye.timeupdate(q);
  }, ye.progress = (q) => {
    const ge = q.target.duration;
    V("progress", {
      duration: ge,
      currentTime: f.dVideo.currentTime
    });
    const Ne = q.target.buffered, Je = q.target.buffered.length && q.target.buffered.end(Ne - 1);
    R(15, f.preloadBar = Je / ge, f);
  }, ye.timeupdate = (q) => {
    const ge = q.duration || q.target.duration || 0, Ne = q.currentTime || q.target.currentTime;
    V("timeupdate", { currentTime: Ne, duration: ge }), R(15, f.playProgress = Ne / ge, f), R(15, f.currentTime = Wt(Ne), f), R(15, f.totalTime = Wt(ge), f);
  }, ye.playing = Ge(ye.playing, () => {
    R(15, f.playBtnState = "pause", f);
  }), ye.pause = Ge(ye.pause, () => {
    R(15, f.playBtnState = "play", f);
  }), ye.error = Ge(ye.error, (q) => {
    R(15, f.loadStateType = "error", f), R(15, f.playBtnState = "replay", f);
  });
  const st = () => {
    if (f.dVideo.canPlayType(I) || f.dVideo.canPlayType("application/vnd.apple.mpegurl")) {
      c && (c.detachMedia(), R(15, f.qualityLevels = [], f)), _e(f.speedActive || "1.0");
      return;
    }
    at.isSupported() && (c = new at({ fragLoadingTimeOut: 2e3 }), c.detachMedia(), c.attachMedia(f.dVideo), c.on(at.Events.MEDIA_ATTACHED, () => {
      c.loadSource(C), c.on(at.Events.MANIFEST_PARSED, (q, ge) => {
        R(15, f.qualityLevels = ge.levels || [], f);
      });
    }), c.on(at.Events.ERROR, (q, ge) => {
      if (ge.fatal)
        switch (ge.type) {
          case at.ErrorTypes.NETWORK_ERROR:
            c.startLoad();
            break;
          case at.ErrorTypes.MEDIA_ERROR:
            c.recoverMediaError();
            break;
          default:
            c.destroy();
            break;
        }
    }), c.on(at.Events.LEVEL_SWITCHING, (q, ge) => {
      V(at.Events.LEVEL_SWITCHING, ge.level);
    }), c.on(at.Events.LEVEL_SWITCHED, (q, ge) => {
      R(15, f.currentLevel = ge.level, f), V(at.Events.LEVEL_SWITCHED, f.currentLevel);
    }));
  };
  Qr(() => {
    R(15, f.dVideo = w, f), $();
  });
  function Xe(q) {
    dt[q ? "unshift" : "push"](() => {
      w = q, R(17, w);
    });
  }
  function He() {
    f.volume = this.volume, R(15, f);
  }
  function Ve(q) {
    dt[q ? "unshift" : "push"](() => {
      U = q, R(19, U);
    });
  }
  const Ue = () => {
    i.includes("fullScreen") && Me();
  }, Be = (q) => {
    te(q, "keydown");
  }, je = (q) => {
    R(15, f.playProgress = q.detail, f);
  }, Qe = (q, ge) => {
    Ee(q, ge);
  }, Oe = (q) => {
    _e(q);
  }, qe = () => {
    R(15, f.muted = !1, f);
  }, Ze = (q) => {
    R(15, f.volume = q.detail, f);
  }, pt = (q) => {
    R(15, f.mirror = q.detail, f);
  }, ut = (q) => {
    R(15, f.loop = q.detail, f);
  }, ht = (q) => {
    R(15, f.lightOff = q.detail, f);
  }, Pt = () => {
    R(15, f.webFullScreen = !f.webFullScreen, f);
  };
  function yt(q) {
    dt[q ? "unshift" : "push"](() => {
      F = q, R(18, F);
    });
  }
  function Bt(q) {
    dt[q ? "unshift" : "push"](() => {
      M = q, R(16, M);
    });
  }
  return A.$$set = (q) => {
    "languageType" in q && R(0, W = q.languageType), "width" in q && R(1, p = q.width), "height" in q && R(2, P = q.height), "color" in q && R(43, T = q.color), "colorEnd" in q && R(44, k = q.colorEnd), "src" in q && R(3, C = q.src), "title" in q && R(4, B = q.title), "type" in q && R(45, I = q.type), "poster" in q && R(5, L = q.poster), "webFullScreen" in q && R(46, D = q.webFullScreen), "canSpeed" in q && R(47, _ = q.canSpeed), "currentTime" in q && R(48, x = q.currentTime), "playsinline" in q && R(6, g = q.playsinline), "muted" in q && R(49, S = q.muted), "speedRate" in q && R(50, y = q.speedRate), "autoPlay" in q && R(51, l = q.autoPlay), "loop" in q && R(52, u = q.loop), "mirror" in q && R(53, a = q.mirror), "lightOff" in q && R(54, s = q.lightOff), "volume" in q && R(55, m = q.volume), "control" in q && R(7, v = q.control), "controlBtns" in q && R(8, i = q.controlBtns), "preload" in q && R(9, n = q.preload), "qualityLevels" in q && R(56, E = q.qualityLevels), "contextMenu" in q && R(10, r = q.contextMenu), "loadingImg" in q && R(11, o = q.loadingImg), "loadingDom" in q && R(12, t = q.loadingDom), "loadingType" in q && R(13, d = q.loadingType), "loadingText" in q && R(14, e = q.loadingText), "hasFeedBack" in q && R(57, h = q.hasFeedBack);
  }, A.$$.update = () => {
    A.$$.dirty[0] & 32768 && R(22, G = f.webFullScreen ? O.exitWebFullScreen : O.webFullScreen), A.$$.dirty[0] & 32768 && R(21, K = f.fullScreen ? O.exitFullScreen : O.fullScreen), A.$$.dirty[0] & 8 && C && Vt().then(() => {
      st();
    });
  }, [
    W,
    p,
    P,
    C,
    B,
    L,
    g,
    v,
    i,
    n,
    r,
    o,
    t,
    d,
    e,
    f,
    M,
    w,
    F,
    U,
    ye,
    K,
    G,
    O,
    N,
    H,
    j,
    z,
    te,
    $,
    ne,
    ae,
    ie,
    ce,
    me,
    Ie,
    Ee,
    _e,
    Te,
    Se,
    xe,
    Ce,
    Me,
    T,
    k,
    I,
    D,
    _,
    x,
    S,
    y,
    l,
    u,
    a,
    s,
    m,
    E,
    h,
    Xe,
    He,
    Ve,
    Ue,
    Be,
    je,
    Qe,
    Oe,
    qe,
    Ze,
    pt,
    ut,
    ht,
    Pt,
    yt,
    Bt
  ];
}
class bn extends nt {
  constructor(b) {
    super(), it(
      this,
      b,
      An,
      Dn,
      tt,
      {
        languageType: 0,
        width: 1,
        height: 2,
        color: 43,
        colorEnd: 44,
        src: 3,
        title: 4,
        type: 45,
        poster: 5,
        webFullScreen: 46,
        canSpeed: 47,
        currentTime: 48,
        playsinline: 6,
        muted: 49,
        speedRate: 50,
        autoPlay: 51,
        loop: 52,
        mirror: 53,
        lightOff: 54,
        volume: 55,
        control: 7,
        controlBtns: 8,
        preload: 9,
        qualityLevels: 56,
        contextMenu: 10,
        loadingImg: 11,
        loadingDom: 12,
        loadingType: 13,
        loadingText: 14,
        hasFeedBack: 57
      },
      _n,
      [-1, -1, -1]
    );
  }
}
export {
  bn as default
};
